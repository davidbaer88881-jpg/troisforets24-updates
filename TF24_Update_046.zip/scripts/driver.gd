# The race driver: a real human body (MakeHuman base mesh, CC0) in a race suit with the team's colours,
# gloves, boots, balaclava and the GP helmet; skinned to a skeleton, sitting in the seat with the arms
# on the steering wheel (two-bone IK, the hands follow the rim when the wheel turns, fingers wrapped
# around it).
extends RefCounted

const Human = preload("res://scripts/human.gd")
const DATA := "res://props/driver.bin"
const MASK := "res://art/driver_suit.png"

const SUIT_SHADER := """
shader_type spatial;
render_mode cull_back;
uniform sampler2D mask : filter_linear_mipmap, repeat_disable;
uniform vec3 col_a : source_color = vec3(0.1, 0.12, 0.35);
uniform vec3 col_b : source_color = vec3(0.9, 0.1, 0.1);
uniform vec3 col_c : source_color = vec3(1.0, 0.8, 0.1);
uniform vec3 col_dark : source_color = vec3(0.035, 0.037, 0.045);
uniform bool hide_head = false;
uniform bool hide_arms = false;
varying float fabric;
void vertex() {
	// in the cockpit the camera sits in the helmet: head (and, if wanted, the arms) are not drawn
	if ((hide_head && UV2.x > 0.5) || (hide_arms && UV2.y > 0.5)) {
		VERTEX = vec3(0.0);
	}
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void fragment() {
	vec4 m = texture(mask, UV);
	vec3 c = col_a;
	c = mix(c, col_dark, m.b);
	c = mix(c, col_b, m.r);
	c = mix(c, col_c, m.g);
	// stitched seams and a fine fabric weave
	float weave = 0.5 + 0.5 * sin(UV.x * 2600.0) * sin(UV.y * 2600.0);
	c *= 1.0 - 0.42 * m.a;
	c *= 0.94 + 0.06 * weave;
	ALBEDO = c;
	float leather = m.b * (1.0 - m.r);
	ROUGHNESS = mix(0.78, 0.5, leather) - 0.04 * weave;
	SPECULAR = mix(0.35, 0.5, leather);
	// soft sheen of the Nomex fabric at grazing angles
	float fres = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0);
	EMISSION = c * fres * 0.08;
}
"""

static var _data: Dictionary = {}
static var _shader: Shader = null
static var _mask: Texture2D = null


static func available() -> bool:
	return not _load().is_empty()


static func _load() -> Dictionary:
	if not _data.is_empty():
		return _data
	if not FileAccess.file_exists(DATA):
		return _data
	var b := FileAccess.get_file_as_bytes(DATA)
	if b.size() < 12 or b.slice(0, 8).get_string_from_ascii() != "TF24DRV1":
		return _data
	var hl := b.decode_u32(8)
	var hdr = JSON.parse_string(b.slice(12, 12 + hl).get_string_from_utf8())
	if not (hdr is Dictionary):
		return _data
	var nv: int = int(hdr["verts"])
	var nt: int = int(hdr["tris"])
	var o := 12 + hl
	var sizes := [nv * 12, nv * 12, nv * 8, nv * 8, nv * 16, nv * 16, nt * 12]
	var chunks: Array = []
	for sz in sizes:
		chunks.append(b.slice(o, o + sz))
		o += sz
	var f3 := func(bytes: PackedByteArray) -> PackedVector3Array:
		var f := bytes.to_float32_array()
		var out := PackedVector3Array()
		out.resize(f.size() / 3)
		for k in out.size():
			out[k] = Vector3(f[k * 3], f[k * 3 + 1], f[k * 3 + 2])
		return out
	var f2 := func(bytes: PackedByteArray) -> PackedVector2Array:
		var f := bytes.to_float32_array()
		var out := PackedVector2Array()
		out.resize(f.size() / 2)
		for k in out.size():
			out[k] = Vector2(f[k * 2], f[k * 2 + 1])
		return out
	var pos: PackedVector3Array = f3.call(chunks[0])
	var nor: PackedVector3Array = f3.call(chunks[1])
	var uv: PackedVector2Array = f2.call(chunks[2])
	var flags: PackedVector2Array = f2.call(chunks[3])
	var bones: PackedInt32Array = (chunks[4] as PackedByteArray).to_int32_array()
	var weights: PackedFloat32Array = (chunks[5] as PackedByteArray).to_float32_array()
	var tris: PackedInt32Array = (chunks[6] as PackedByteArray).to_int32_array()
	if tris.size() != nt * 3 or weights.size() != nv * 4:
		return _data
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = pos
	arr[Mesh.ARRAY_NORMAL] = nor
	arr[Mesh.ARRAY_TEX_UV] = uv
	arr[Mesh.ARRAY_TEX_UV2] = flags
	arr[Mesh.ARRAY_BONES] = bones
	arr[Mesh.ARRAY_WEIGHTS] = weights
	arr[Mesh.ARRAY_INDEX] = tris
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	# detail levels: a driver further away is drawn with far fewer triangles
	var im := ImporterMesh.new()
	im.add_surface(Mesh.PRIMITIVE_TRIANGLES, arr)
	im.generate_lods(25.0, 60.0, [])
	var lm: ArrayMesh = im.get_mesh()
	if lm != null and lm.get_surface_count() == 1:
		mesh = lm
	var bl: Array = hdr["bones"]
	var names := PackedStringArray()
	var parents := PackedInt32Array()
	var heads := PackedVector3Array()
	var tails := PackedVector3Array()
	for bd in bl:
		names.append(String(bd["name"]))
		parents.append(int(bd["parent"]))
		heads.append(Vector3(bd["head"][0], bd["head"][1], bd["head"][2]))
		tails.append(Vector3(bd["tail"][0], bd["tail"][1], bd["tail"][2]))
	var e: Array = hdr["eye"]
	var index := {}
	for i in names.size():
		index[names[i]] = i
	# per arm: its bones in parent-first order (for the per-frame update of just that arm)
	var chains := {}
	for sd in ["L", "R"]:
		var lst := PackedInt32Array()
		for i in names.size():
			var n := names[i]
			if n.ends_with("." + sd) and (n.begins_with("clavicle") or n.begins_with("shoulder") or n.begins_with("upperarm")
					or n.begins_with("lowerarm") or n.begins_with("wrist") or n.begins_with("metacarpal") or n.begins_with("finger")):
				lst.append(i)
		chains[sd] = lst
	_data = {"mesh": mesh, "names": names, "parents": parents, "heads": heads, "tails": tails,
		"eye": Vector3(e[0], e[1], e[2]), "index": index, "chains": chains}
	var mb := FileAccess.get_file_as_bytes(MASK)
	if mb.size() > 0:
		var img := Image.new()
		if img.load_png_from_buffer(mb) == OK:
			img.generate_mipmaps()
			_mask = ImageTexture.create_from_image(img)
	_shader = Shader.new()
	_shader.code = SUIT_SHADER
	return _data


static func _bone(d: Dictionary, n: String) -> int:
	return int((d["index"] as Dictionary).get(n, -1))


# a new driver: Node3D (+Z forward, +X = his left) with the skeleton, the suit and the helmet
static func build(look: Dictionary) -> Node3D:
	var d := _load()
	if d.is_empty():
		return null
	var root := Node3D.new()
	root.name = "Driver"
	var sk := Skeleton3D.new()
	sk.name = "Skeleton"
	root.add_child(sk)
	var names: PackedStringArray = d["names"]
	var parents: PackedInt32Array = d["parents"]
	var heads: PackedVector3Array = d["heads"]
	for i in names.size():
		sk.add_bone(names[i])
	for i in names.size():
		var p := parents[i]
		if p >= 0:
			sk.set_bone_parent(i, p)
		var rel: Vector3 = heads[i] - (heads[p] if p >= 0 else Vector3.ZERO)
		sk.set_bone_rest(i, Transform3D(Basis.IDENTITY, rel))
		sk.set_bone_pose_position(i, rel)
		sk.set_bone_pose_rotation(i, Quaternion.IDENTITY)
	var mi := MeshInstance3D.new()
	mi.name = "Suit"
	mi.mesh = d["mesh"]
	sk.add_child(mi)
	mi.skeleton = NodePath("..")
	var sm := ShaderMaterial.new()
	sm.shader = _shader
	if _mask != null:
		sm.set_shader_parameter("mask", _mask)
	sm.set_shader_parameter("col_a", look.get("suit", Color(0.07, 0.1, 0.2)))
	sm.set_shader_parameter("col_b", look.get("accent", Color(0.95, 0.75, 0.05)))
	sm.set_shader_parameter("col_c", look.get("stripe", Color(0.95, 0.95, 0.95)))
	mi.material_override = sm
	# helmet on the head bone
	var hb := _bone(d, "head")
	var ba := BoneAttachment3D.new()
	ba.bone_name = "head"
	sk.add_child(ba)
	var helmet_mesh: ArrayMesh = Human._gp_helmet(look, Vector3.ZERO)
	var hm := MeshInstance3D.new()
	hm.name = "Helmet"
	hm.mesh = helmet_mesh
	ba.add_child(hm)
	# helmet centre on the head: a little lower and further back than the middle of the head bone
	hm.position = Vector3(0.0, 0.063, 0.036)
	hm.scale = Vector3.ONE * 1.06
	# HANS: the carbon head restraint lying on the shoulders, collar up behind the helmet
	var sp := _bone(d, "spine01")
	var nk := _bone(d, "neck01")
	var hans_att := BoneAttachment3D.new()
	hans_att.bone_name = "spine01"
	sk.add_child(hans_att)
	var hans := MeshInstance3D.new()
	hans.name = "HANS"
	hans.mesh = _hans_mesh()
	hans.position = heads[nk] - heads[sp] + Vector3(0, -0.035, -0.005)
	hans_att.add_child(hans)
	var state := {"skel": sk, "suit": mi, "mat": sm, "helmet": hm, "att": ba, "hans": hans,
		"rot": [], "grot": [], "gpos": []}
	for i in names.size():
		(state["rot"] as Array).append(Quaternion.IDENTITY)
		(state["grot"] as Array).append(Quaternion.IDENTITY)
		(state["gpos"] as Array).append(heads[i])
	root.set_meta("drv", state)
	_seat(root)
	return root


static var _hans: ArrayMesh = null


# horseshoe yoke round the neck (open at the front), prongs down the chest, collar up at the back
static func _hans_mesh() -> ArrayMesh:
	if _hans != null:
		return _hans
	var path: Array = []
	for k in 25:
		var a := lerpf(-PI * 0.78, PI * 0.78, float(k) / 24.0)     # 0 = behind the neck
		var r := 0.085 + 0.012 * absf(sin(a))
		var p := Vector3(sin(a) * r, 0.012 * cos(a), -cos(a) * r * 0.9)
		path.append(p)
	# the prongs run down onto the chest
	var full: Array = []
	for k in 6:
		var f := 1.0 - float(k) / 6.0
		full.append(path[0] + Vector3(-0.012 * f, -0.10 * f, 0.07 * f))
	full.append_array(path)
	for k in range(1, 7):
		var f := float(k) / 6.0
		full.append(path[path.size() - 1] + Vector3(0.012 * f, -0.10 * f, 0.07 * f))
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rings: Array = []
	for k in full.size():
		var p: Vector3 = full[k]
		var tg: Vector3 = (full[mini(k + 1, full.size() - 1)] - full[maxi(k - 1, 0)]).normalized()
		var outv := Vector3(p.x, 0, p.z).normalized()
		var up := tg.cross(outv).normalized()
		if up.y < 0.0:
			up = -up
		# behind the neck the collar stands up
		var back := clampf(-p.z / 0.08, 0.0, 1.0)
		var h := 0.018 + 0.05 * back * back
		var w := 0.05
		var ring := [p + outv * w * 0.5, p + outv * w * 0.5 + up * h, p - outv * w * 0.5 + up * h, p - outv * w * 0.5]
		rings.append(ring)
	for k in rings.size() - 1:
		var r0: Array = rings[k]
		var r1: Array = rings[k + 1]
		for e in 4:
			var a0: Vector3 = r0[e]
			var b0: Vector3 = r0[(e + 1) % 4]
			var a1: Vector3 = r1[e]
			var b1: Vector3 = r1[(e + 1) % 4]
			var n := (b0 - a0).cross(a1 - a0).normalized()
			for v in [a0, a1, b0, b0, a1, b1]:
				st.set_normal(n)
				st.add_vertex(v)
	st.generate_normals()
	_hans = st.commit()
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.05, 0.055, 0.06)
	m.roughness = 0.3
	m.metallic = 0.35
	m.clearcoat_enabled = true
	m.clearcoat = 0.8
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	_hans.surface_set_material(0, m)
	return _hans


# ---------------------------------------------------------------- forward kinematics (own, rest = identity)
static func _fk(state: Dictionary, d: Dictionary) -> void:
	var parents: PackedInt32Array = d["parents"]
	var heads: PackedVector3Array = d["heads"]
	var rot: Array = state["rot"]
	var grot: Array = state["grot"]
	var gpos: Array = state["gpos"]
	for i in parents.size():
		var p := parents[i]
		if p < 0:
			grot[i] = rot[i]
			gpos[i] = heads[i]
		else:
			grot[i] = (grot[p] as Quaternion) * (rot[i] as Quaternion)
			gpos[i] = (gpos[p] as Vector3) + (grot[p] as Quaternion) * (heads[i] - heads[p])


# forward kinematics for a list of bones only (their parents are up to date)
static func _fk_list(state: Dictionary, d: Dictionary, lst: PackedInt32Array) -> void:
	var parents: PackedInt32Array = d["parents"]
	var heads: PackedVector3Array = d["heads"]
	var rot: Array = state["rot"]
	var grot: Array = state["grot"]
	var gpos: Array = state["gpos"]
	for i in lst:
		var p := parents[i]
		grot[i] = (grot[p] as Quaternion) * (rot[i] as Quaternion)
		gpos[i] = (gpos[p] as Vector3) + (grot[p] as Quaternion) * (heads[i] - heads[p])


# rotation that turns direction a into direction b (shortest arc)
static func _arc(a: Vector3, b: Vector3) -> Quaternion:
	a = a.normalized()
	b = b.normalized()
	var c := a.cross(b)
	var dt := a.dot(b)
	if dt < -0.9999:
		var ax := a.cross(Vector3.RIGHT)
		if ax.length() < 0.01:
			ax = a.cross(Vector3.UP)
		return Quaternion(ax.normalized(), PI)
	return Quaternion(c.x, c.y, c.z, 1.0 + dt).normalized()


# sets bone i so that it points (head->tail) along dir in skeleton space; parents must be up to date
static func _aim(state: Dictionary, d: Dictionary, i: int, dir: Vector3, extra := Quaternion.IDENTITY) -> void:
	var heads: PackedVector3Array = d["heads"]
	var tails: PackedVector3Array = d["tails"]
	var p: int = (d["parents"] as PackedInt32Array)[i]
	var g := _arc(tails[i] - heads[i], dir) * extra
	var pg: Quaternion = (state["grot"] as Array)[p] if p >= 0 else Quaternion.IDENTITY
	(state["rot"] as Array)[i] = pg.inverse() * g
	(state["grot"] as Array)[i] = g


# ---------------------------------------------------------------- the seated pose
const LEAN := 0.42          # reclined seat (rad)


static func _seat(root: Node3D) -> void:
	var d := _load()
	var st: Dictionary = root.get_meta("drv")
	var rot: Array = st["rot"]
	for i in rot.size():
		rot[i] = Quaternion.IDENTITY
	var b := func(n: String) -> int: return _bone(d, n)
	rot[b.call("root")] = Quaternion(Vector3.RIGHT, -LEAN)
	# a slightly rounded back, the head upright again to look at the road
	for n in ["spine04", "spine03", "spine02"]:
		rot[b.call(n)] = Quaternion(Vector3.RIGHT, 0.05)
	rot[b.call("neck01")] = Quaternion(Vector3.RIGHT, LEAN * 0.45)
	rot[b.call("neck02")] = Quaternion(Vector3.RIGHT, LEAN * 0.3)
	rot[b.call("head")] = Quaternion(Vector3.RIGHT, LEAN * 0.15)
	_fk(st, d)
	# legs: thighs forward (a little up, knees apart), shins down to the pedals, feet on them
	for s in ["L", "R"]:
		var sg := 1.0 if s == "L" else -1.0
		_aim(st, d, b.call("upperleg01." + s), Vector3(sg * 0.12, 0.22, 1.0))
		rot[b.call("upperleg02." + s)] = Quaternion.IDENTITY
		_fk(st, d)
		_aim(st, d, b.call("lowerleg01." + s), Vector3(sg * 0.02, -0.55, 1.0))
		rot[b.call("lowerleg02." + s)] = Quaternion.IDENTITY
		_fk(st, d)
		_aim(st, d, b.call("foot." + s), Vector3(0.0, 0.55, 1.0))
		_fk(st, d)
	# arms: resting forward until the wheel is known
	_arms(root, Vector3(0.2, 1.05, 0.55), Vector3(-0.2, 1.05, 0.55), Vector3(0, 0, -1), Vector3(0, 1.1, 0.5))
	_apply(st)


static func _apply(st: Dictionary, only := PackedInt32Array()) -> void:
	var sk: Skeleton3D = st["skel"]
	var rot: Array = st["rot"]
	if only.is_empty():
		for i in rot.size():
			sk.set_bone_pose_rotation(i, rot[i])
	else:
		for i in only:
			sk.set_bone_pose_rotation(i, rot[i])


# eyes of the seated driver in the driver node's space (for placing him in the car)
static func eye_point(root: Node3D) -> Vector3:
	var d := _load()
	var st: Dictionary = root.get_meta("drv")
	var hb := _bone(d, "head")
	var gp: Vector3 = (st["gpos"] as Array)[hb]
	var gr: Quaternion = (st["grot"] as Array)[hb]
	return gp + gr * ((d["eye"] as Vector3) - (d["heads"] as PackedVector3Array)[hb])


# ---------------------------------------------------------------- hands on the wheel
# grip_l / grip_r: where the hands hold the rim, centre: wheel centre, axis: steering column (towards
# the driver), all in the driver node's space
static func _arms(root: Node3D, grip_l: Vector3, grip_r: Vector3, axis: Vector3, centre: Vector3) -> void:
	var d := _load()
	var st: Dictionary = root.get_meta("drv")
	var rot: Array = st["rot"]
	var heads: PackedVector3Array = d["heads"]
	var b := func(n: String) -> int: return _bone(d, n)
	for s in ["L", "R"]:
		var chain: PackedInt32Array = (d["chains"] as Dictionary)[s]
		var sg := 1.0 if s == "L" else -1.0
		var grip := grip_l if s == "L" else grip_r
		var ua := int(b.call("upperarm01." + s))
		var la := int(b.call("lowerarm01." + s))
		var wr := int(b.call("wrist." + s))
		# shoulders forward a little towards the wheel
		rot[b.call("clavicle." + s)] = Quaternion(Vector3.UP, sg * -0.12)
		rot[b.call("shoulder01." + s)] = Quaternion.IDENTITY
		for n in ["upperarm02." + s, "lowerarm02." + s]:
			rot[b.call(n)] = Quaternion.IDENTITY
		_fk_list(st, d, chain)
		var S: Vector3 = (st["gpos"] as Array)[ua]
		var a := (heads[int(b.call("lowerarm01." + s))] - heads[ua]).length()
		var c2 := (heads[wr] - heads[int(b.call("lowerarm01." + s))]).length()
		var radial := (grip - centre)
		radial -= axis * radial.dot(axis)
		radial = radial.normalized() if radial.length() > 0.001 else Vector3(sg, 0, 0)
		# fist round the rim: knuckles forward, back of the hand outward, palm towards the hub
		var tangent := radial.cross(axis).normalized() * sg
		var want_dir := (-axis * 0.75 - radial * 0.1 + tangent * 0.45).normalized()
		var want_palm := -radial
		want_palm = (want_palm - want_dir * want_palm.dot(want_dir)).normalized()
		# the wrist sits a palm length behind the rim, the rim lies in the palm
		var H := grip - want_dir * 0.075 - want_palm * 0.035
		var dv := H - S
		var dist := clampf(dv.length(), absf(a - c2) + 0.01, a + c2 - 0.005)
		var dir := dv.normalized()
		# elbows down and out
		var pole := (Vector3(sg * 0.6, -1.0, -0.2)).normalized()
		pole = (pole - dir * pole.dot(dir)).normalized()
		var cos_a := clampf((a * a + dist * dist - c2 * c2) / (2.0 * a * dist), -1.0, 1.0)
		var E := S + dir * (a * cos_a) + pole * (a * sqrt(1.0 - cos_a * cos_a))
		_aim(st, d, ua, E - S)
		_fk_list(st, d, chain)
		var E2: Vector3 = (st["gpos"] as Array)[la]
		_aim(st, d, la, (S + dir * dist) - E2)
		_fk_list(st, d, chain)
		# hand: back of the hand outward, knuckles forward, fingers wrapped round the rim
		var hand_dir := (heads[int(b.call("finger3-1." + s))] - heads[wr]).normalized()
		var across := heads[int(b.call("finger2-1." + s))] - heads[int(b.call("finger5-1." + s))]
		var rest_palm := hand_dir.cross(across).normalized() * sg
		rest_palm = (rest_palm - hand_dir * rest_palm.dot(hand_dir)).normalized()
		var rest_b := Basis(hand_dir, rest_palm, hand_dir.cross(rest_palm)).orthonormalized()
		var want_b := Basis(want_dir, want_palm, want_dir.cross(want_palm)).orthonormalized()
		var g := Quaternion(want_b * rest_b.inverse())
		var pg: Quaternion = (st["grot"] as Array)[int((d["parents"] as PackedInt32Array)[wr])]
		rot[wr] = pg.inverse() * g
		_fk_list(st, d, chain)
		# fingers curled round the rim
		var curl_axis := hand_dir.cross(rest_palm).normalized()
		for f in range(2, 6):
			for k in range(1, 4):
				var bi := int(b.call("finger%d-%d.%s" % [f, k, s]))
				if bi >= 0:
					rot[bi] = Quaternion(curl_axis, [0.75, 0.95, 0.7][k - 1])
		for k in range(1, 4):
			var ti := int(b.call("finger1-%d.%s" % [k, s]))
			if ti >= 0:
				rot[ti] = Quaternion(hand_dir, sg * 0.25) * Quaternion(curl_axis, 0.3)
		_fk_list(st, d, chain)


# per frame: hands to the rim (grips and wheel in the driver node's space)
static func steer(root: Node3D, grip_l: Vector3, grip_r: Vector3, axis: Vector3, centre: Vector3) -> void:
	var d := _load()
	_arms(root, grip_l, grip_r, axis, centre)
	var st: Dictionary = root.get_meta("drv")
	_apply(st, (d["chains"] as Dictionary)["L"])
	_apply(st, (d["chains"] as Dictionary)["R"])


static func set_cockpit(root: Node3D, in_cockpit: bool, hands: bool) -> void:
	var st: Dictionary = root.get_meta("drv")
	var sm: ShaderMaterial = st["mat"]
	sm.set_shader_parameter("hide_head", in_cockpit)
	sm.set_shader_parameter("hide_arms", in_cockpit and not hands)
	(st["helmet"] as Node3D).visible = not in_cockpit
	(st["hans"] as Node3D).visible = not in_cockpit


# ---------------------------------------------------------------- standing (driver editor, podium)
static func stand(root: Node3D) -> void:
	var d := _load()
	var st: Dictionary = root.get_meta("drv")
	var rot: Array = st["rot"]
	for i in rot.size():
		rot[i] = Quaternion.IDENTITY
	_fk(st, d)
	arms(root, Vector3(0.22, -1.0, 0.02), Vector3(-0.22, -1.0, 0.02), 0.12, 0.12)
	_apply(st)


# arms in given directions (driver space), forearms bent forward by "bend", fingers relaxed
static func arms(root: Node3D, dir_l: Vector3, dir_r: Vector3, bend_l: float, bend_r: float) -> void:
	var d := _load()
	var st: Dictionary = root.get_meta("drv")
	var rot: Array = st["rot"]
	for s in ["L", "R"]:
		var chain: PackedInt32Array = (d["chains"] as Dictionary)[s]
		var dir := dir_l if s == "L" else dir_r
		var bend := bend_l if s == "L" else bend_r
		for n in ["clavicle.", "shoulder01.", "upperarm02.", "lowerarm02.", "wrist."]:
			rot[_bone(d, n + s)] = Quaternion.IDENTITY
		_fk_list(st, d, chain)
		_aim(st, d, _bone(d, "upperarm01." + s), dir)
		_fk_list(st, d, chain)
		var fdir := (dir.normalized() + Vector3(0, 0.25, 1.0) * bend * 3.0).normalized()
		_aim(st, d, _bone(d, "lowerarm01." + s), fdir)
		_fk_list(st, d, chain)
		_apply(st, chain)


# a node in the driver's hand (bottle, trophy): follows the wrist; its -Y points along the fingers
static func hand_node(root: Node3D, side: String) -> Node3D:
	var d := _load()
	var st: Dictionary = root.get_meta("drv")
	var key := "hand_" + side
	if st.has(key):
		return st[key]
	var ba := BoneAttachment3D.new()
	ba.bone_name = "wrist." + side
	(st["skel"] as Skeleton3D).add_child(ba)
	var holder := Node3D.new()
	ba.add_child(holder)
	var heads: PackedVector3Array = d["heads"]
	var hd := heads[_bone(d, "finger3-1." + side)] - heads[_bone(d, "wrist." + side)]
	holder.basis = Basis(_arc(Vector3.DOWN, hd))
	holder.position = hd * 0.9
	st[key] = holder
	return holder

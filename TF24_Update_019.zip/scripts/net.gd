# Online multiplayer over ENet (UDP): one player hosts the lobby, the others join with the host's IP.
# Every computer simulates its own car and sends its state ~30 times a second; the host also simulates
# the AI cars and sends theirs. Cars from other computers are drawn with dead reckoning + smooth correction.
extends Node

signal lobby_changed

const PORT := 24724
const MAX_PEERS := 16
const SEND_HZ := 30.0
const Profile = preload("res://scripts/profile.gd")
const Updater = preload("res://scripts/updater.gd")

var game
var peer: ENetMultiplayerPeer
var players := {}          # peer id -> {name, team, number, cls, livery, c1, c2}
var online := false
var status := ""
var ready_peers := {}
var send_acc := 0.0
var corr := {}             # car index -> Vector3 position error still to blend in
var ext_ip := ""           # host: internet address (found via UPnP)
var upnp_state := ""       # "", "busy", "ok", "fail"
var _upnp: UPNP
var _upnp_thread: Thread


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)


func my_id() -> int:
	return multiplayer.get_unique_id() if online else 1


func is_host() -> bool:
	return online and multiplayer.is_server()


func status_text() -> String:
	return status


func _me() -> Dictionary:
	var p: Dictionary = Profile.current
	var s: Dictionary = game.settings
	var liv: Array = game.menu.LIVERIES[int(s["livery"]) % game.menu.LIVERIES.size()]
	return {"name": String(p.get("name", "Fahrer")), "team": String(p.get("team", "Team")), "number": int(p.get("number", 24)),
		"cls": String(s["cls"]), "c1": p.get("c1", liv[1]).to_html(), "c2": p.get("c2", liv[2]).to_html(), "c3": Color(liv[3]).to_html(),
		"ver": Updater.installed_number()}


func host() -> String:
	leave()
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PEERS)
	if err != OK:
		status = "Lobby konnte nicht gestartet werden (Port %d belegt? Fehler %d)." % [PORT, err]
		return status
	multiplayer.multiplayer_peer = peer
	online = true
	players = {1: _me()}
	status = "Lobby läuft. Freunde verbinden sich mit deiner IP-Adresse."
	lobby_changed.emit()
	_open_router_port()
	return status


# ---------------------------------------------------------------- router (UPnP): open the port automatically
func _open_router_port() -> void:
	if upnp_state == "busy":
		return
	upnp_state = "busy"
	ext_ip = ""
	_upnp_thread = Thread.new()
	_upnp_thread.start(_upnp_work)


func _upnp_work() -> void:
	var u := UPNP.new()
	var ok := false
	var ip := ""
	if u.discover(2500, 2, "InternetGatewayDevice") == UPNP.UPNP_RESULT_SUCCESS and u.get_gateway() != null and u.get_gateway().is_valid_gateway():
		var r := u.add_port_mapping(PORT, PORT, "Trois Forets 24", "UDP", 0)
		ok = r == UPNP.UPNP_RESULT_SUCCESS
		ip = u.query_external_address()
	call_deferred("_upnp_done", u, ok, ip)


func _upnp_done(u: UPNP, ok: bool, ip: String) -> void:
	if _upnp_thread != null:
		_upnp_thread.wait_to_finish()
		_upnp_thread = null
	_upnp = u if ok else null
	ext_ip = ip
	upnp_state = "ok" if ok else "fail"
	if online and is_host():
		if ok:
			status = "Lobby läuft. Router-Port automatisch geöffnet – Freunde im Internet nehmen deine Internet-IP %s." % ip
		else:
			status = "Lobby läuft. Im gleichen WLAN mit deiner WLAN-IP verbinden. Übers Internet: Tailscale nutzen (siehe unten) – der Router hat die automatische Freigabe abgelehnt."
	lobby_changed.emit()


func join(ip: String) -> String:
	leave()
	ip = ip.strip_edges().get_slice(" ", 0)      # "192.168.1.5  (WLAN)" -> address only
	if ip == "":
		status = "Bitte die IP-Adresse des Hosts eingeben."
		return status
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK:
		status = "Verbindung fehlgeschlagen (Fehler %d)." % err
		return status
	multiplayer.multiplayer_peer = peer
	online = true
	status = "Verbinde mit %s …" % ip
	return status


func leave() -> void:
	if _upnp != null:
		_upnp.delete_port_mapping(PORT, "UDP")
		_upnp = null
		upnp_state = ""
	if peer != null:
		peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	peer = null
	online = false
	players = {}
	ready_peers = {}
	corr = {}
	lobby_changed.emit()


# ---------------------------------------------------------------- lobby
func _on_peer_connected(_id: int) -> void:
	pass


func _on_connected() -> void:
	status = "Verbunden! Warte auf den Start durch den Host."
	register.rpc_id(1, _me())
	lobby_changed.emit()


func _on_failed() -> void:
	status = "Host nicht erreichbar. IP richtig? Gleiches WLAN oder Port %d freigegeben?" % PORT
	leave()


func _on_server_gone() -> void:
	status = "Der Host hat die Lobby geschlossen."
	leave()
	if game != null and game.is_online():
		game.show_msg("Verbindung zum Host verloren", 4.0, Color(1.0, 0.3, 0.25))


func _on_peer_disconnected(id: int) -> void:
	players.erase(id)
	ready_peers.erase(id)
	if is_host():
		sync_players.rpc(players)
	# the car stays on track, but stops (retired)
	if game != null and game.is_online():
		for c in game.cars:
			if c.has_meta("peer") and int(c.get_meta("peer")) == id:
				c.retired = true
				c.u = 0.0
	lobby_changed.emit()


@rpc("any_peer", "reliable")
func register(info: Dictionary) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	var mine := Updater.installed_number()
	if int(info.get("ver", 0)) != mine:
		# different game versions do not fit together: tell the friend and drop him
		rejected.rpc_id(sender, "Andere Spielversion: Host hat Version %d, du hast Version %d. Bitte beide auf denselben Stand bringen." % [mine, int(info.get("ver", 0))])
		var _lfk := func():
			if peer != null:
				peer.disconnect_peer(sender)
		get_tree().create_timer(1.0).timeout.connect(_lfk)
		return
	players[sender] = info
	sync_players.rpc(players)
	lobby_changed.emit()


@rpc("authority", "reliable")
func rejected(reason: String) -> void:
	status = reason
	lobby_changed.emit()
	get_tree().create_timer(0.5).timeout.connect(leave)


@rpc("authority", "reliable", "call_local")
func sync_players(p: Dictionary) -> void:
	players = p
	lobby_changed.emit()


# ---------------------------------------------------------------- race start
func start_online_race() -> void:
	if not is_host():
		return
	players[1] = _me()
	var s: Dictionary = game.settings
	var grid: Array = []
	# humans first (in join order), then AI cars of the chosen classes
	var ids: Array = players.keys()
	ids.sort()
	for id in ids:
		var pl: Dictionary = players[id]
		grid.append({"cls": pl["cls"], "team": [pl["team"], pl["c1"], pl["c2"], pl.get("c3", "ffffff"), int(pl["number"])], "peer": int(id), "driver": pl["name"]})
	for k in int(s.get("n_hy", 0)):
		var t: Array = game._team("hyper", k)
		grid.append({"cls": "hyper", "team": [t[0], Color(t[1]).to_html(), Color(t[2]).to_html(), Color(t[3]).to_html(), t[4]], "peer": 0})
	for k in int(s.get("n_gt3", 0)):
		var t: Array = game._team("gt3", k)
		grid.append({"cls": "gt3", "team": [t[0], Color(t[1]).to_html(), Color(t[2]).to_html(), Color(t[3]).to_html(), t[4]], "peer": 0})
	var cfg := {"grid": grid, "lights": 6.0 + randf() * 1.6}
	for k in ["track", "duration", "start_hour", "time_scale", "weather", "wear", "damage", "ai_diff", "quali_limits"]:
		cfg[k] = s[k]
	ready_peers = {}
	begin_race.rpc(cfg)


@rpc("authority", "reliable", "call_local")
func begin_race(cfg: Dictionary) -> void:
	# colours travel as html strings
	var grid: Array = cfg["grid"]
	for g in grid:
		var gd: Dictionary = g
		var t: Array = gd["team"]
		gd["team"] = [t[0], Color.html(String(t[1])), Color.html(String(t[2])), Color.html(String(t[3])), int(t[4])]
		gd["player"] = false
	game.start_online(cfg)


func send_ready() -> void:
	if not online:
		return
	for k in game.cars.size():
		var c = game.cars[k]
		var g: Dictionary = game.online_grid[k]
		c.set_meta("peer", int(g.get("peer", 0)))
	if is_host():
		ready_peers[1] = true
	else:
		client_ready.rpc_id(1)


@rpc("any_peer", "reliable")
func client_ready() -> void:
	ready_peers[multiplayer.get_remote_sender_id()] = true


func all_ready() -> bool:
	for id in players.keys():
		if not ready_peers.has(id):
			return false
	return true


func send_go() -> void:
	go.rpc()


@rpc("authority", "reliable")
func go() -> void:
	if game != null:
		game.lights_out_at = game.lights_t      # lights out now on this computer too


# ---------------------------------------------------------------- car states
func tick(dt: float) -> void:
	if not online or game.cars.is_empty():
		return
	send_acc += dt
	if send_acc < 1.0 / SEND_HZ:
		return
	send_acc = 0.0
	var me := my_id()
	var host := is_host()
	var buf := PackedFloat32Array()
	for k in game.cars.size():
		var c = game.cars[k]
		var p: int = int(c.get_meta("peer", 0))
		if p == me or (p == 0 and host):
			buf.append_array(_pack(k, c))
	if buf.size() > 0:
		states.rpc(buf)


const STRIDE := 18


func _pack(k: int, c) -> PackedFloat32Array:
	return PackedFloat32Array([k, c.x, c.y, c.z, c.psi, c.u, c.v, c.r, c.steer, c.rpm, c.gear, c.throttle, c.brake,
		c.s, c.lat, c.lap, 1.0 if c.in_pit else 0.0, 1.0 if c.retired else 0.0])


@rpc("any_peer", "unreliable_ordered")
func states(buf: PackedFloat32Array) -> void:
	if game == null or game.cars.is_empty():
		return
	var n := buf.size() / STRIDE
	for q in n:
		var o := q * STRIDE
		var k := int(buf[o])
		if k < 0 or k >= game.cars.size():
			continue
		var c = game.cars[k]
		if not c.remote:
			continue
		var target := Vector3(buf[o + 1], buf[o + 2], buf[o + 3])
		var err := target - Vector3(c.x, c.y, c.z)
		if err.length() > 25.0:
			# far off (first packet, reset): jump
			c.x = target.x
			c.y = target.y
			c.z = target.z
			corr[k] = Vector3.ZERO
		else:
			corr[k] = err
		c.psi = lerp_angle(c.psi, buf[o + 4], 0.6)
		c.u = buf[o + 5]
		c.v = buf[o + 6]
		c.r = buf[o + 7]
		c.steer = buf[o + 8]
		c.rpm = buf[o + 9]
		c.gear = int(buf[o + 10])
		c.throttle = buf[o + 11]
		c.brake = buf[o + 12]
		c.s = buf[o + 13]
		c.lat = buf[o + 14]
		c.lap = int(buf[o + 15])
		c.in_pit = buf[o + 16] > 0.5
		c.retired = buf[o + 17] > 0.5


# remote cars between packets: keep moving with their last speed, blend in the correction
func dead_reckon(c, dt: float) -> void:
	var k: int = game.cars.find(c)
	var wv: Vector2 = c.world_vel()
	c.x += wv.x * dt
	c.z += wv.y * dt
	c.psi += c.r * dt
	if corr.has(k):
		var e: Vector3 = corr[k]
		var f := minf(1.0, dt * 8.0)
		c.x += e.x * f
		c.y += e.y * f
		c.z += e.z * f
		corr[k] = e * (1.0 - f)
	c.idx = game.T.idx(c.s)

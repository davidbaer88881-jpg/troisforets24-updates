# Shared helpers: procedural meshes (with Godot's clockwise front-face winding), materials, textures.
extends RefCounted


# Builds an ArrayMesh. Triangles are re-wound so that their front face matches the supplied normals
# (Godot treats clockwise triangles as front faces).
static func make_mesh(verts: PackedVector3Array, normals: PackedVector3Array, uvs: PackedVector2Array,
		colors: PackedColorArray, indices: PackedInt32Array, tangents: bool = false) -> ArrayMesh:
	var n := indices.size()
	var k := 0
	while k < n:
		var i0 := indices[k]
		var i1 := indices[k + 1]
		var i2 := indices[k + 2]
		var c := (verts[i1] - verts[i0]).cross(verts[i2] - verts[i0])
		var nn := normals[i0] + normals[i1] + normals[i2]
		if c.dot(nn) > 0.0:
			indices[k + 1] = i2
			indices[k + 2] = i1
		k += 3
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = normals
	if uvs.size() == verts.size():
		arr[Mesh.ARRAY_TEX_UV] = uvs
	if colors.size() == verts.size():
		arr[Mesh.ARRAY_COLOR] = colors
	arr[Mesh.ARRAY_INDEX] = indices
	if tangents and uvs.size() == verts.size():
		# normal-mapped surfaces need tangents
		var st := SurfaceTool.new()
		st.create_from_arrays(arr, Mesh.PRIMITIVE_TRIANGLES)
		st.generate_tangents()
		return st.commit()
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	return m


static func mat(color: Color, rough: float = 0.8, metal: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	return m


static func emissive(color: Color, energy: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color.darkened(0.6)
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	return m


static func image_tex(img: Image, mipmaps: bool = true) -> ImageTexture:
	if mipmaps:
		img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


static func noise(sd: int, freq: float, octaves: int = 4) -> FastNoiseLite:
	var n := FastNoiseLite.new()
	n.seed = sd
	n.frequency = freq
	n.fractal_octaves = octaves
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	return n


# ---------------------------------------------------------------- textures
static func asphalt(lines: bool = true) -> Dictionary:
	var w := 512
	var h := 512
	var grain := noise(3, 0.18, 2)
	var patch := noise(9, 0.006, 3)
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	var rough := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	var bump := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 11
	for yy in h:
		for xx in w:
			var gn := grain.get_noise_2d(xx, yy) * 0.5 + 0.5
			var r := rnd.randf()
			var pt := patch.get_noise_2d(xx, yy) * 0.5 + 0.5
			var val := (50.0 + gn * 28.0 + r * 20.0 - pt * 16.0) / 255.0
			var ro := 0.78 + r * 0.16 - pt * 0.12
			var bb := r * 0.6 + gn * 0.4
			# aggregate: light stones (some polished), dark pores between them
			var st := rnd.randf()
			if st < 0.07:
				val = rnd.randf_range(0.36, 0.56)
				ro = rnd.randf_range(0.45, 0.7)
				bb = 0.95
			elif st < 0.15:
				val *= 0.45
				ro = 0.95
				bb = 0.05
			img.set_pixel(xx, yy, Color(val, val * 1.0, val * 1.04))
			rough.set_pixel(xx, yy, Color(ro, ro, ro))
			bump.set_pixel(xx, yy, Color(bb, bb, bb))
	bump.bump_map_to_normal_map(4.0)
	if not lines:
		return {"albedo": image_tex(img), "rough": image_tex(rough), "normal": image_tex(bump)}
	# white edge lines (texture spans the full road width)
	var lw := int(w * 0.22 / 14.0)
	var lx := int(w * 0.25 / 14.0)
	img.fill_rect(Rect2i(lx, 0, lw, h), Color(0.88, 0.88, 0.85))
	img.fill_rect(Rect2i(w - lx - lw, 0, lw, h), Color(0.88, 0.88, 0.85))
	rough.fill_rect(Rect2i(lx, 0, lw, h), Color(0.6, 0.6, 0.6))
	rough.fill_rect(Rect2i(w - lx - lw, 0, lw, h), Color(0.6, 0.6, 0.6))
	return {"albedo": image_tex(img), "rough": image_tex(rough), "normal": image_tex(bump)}


static func grass() -> Dictionary:
	var w := 512
	var n1 := noise(5, 0.02, 4)
	var n2 := noise(6, 0.25, 2)
	var img := Image.create_empty(w, w, false, Image.FORMAT_RGBA8)
	var bump := Image.create_empty(w, w, false, Image.FORMAT_RGBA8)
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 5
	for yy in w:
		for xx in w:
			var a := n1.get_noise_2d(xx, yy) * 0.5 + 0.5
			var b := rnd.randf()
			var c := n2.get_noise_2d(xx, yy) * 0.5 + 0.5
			img.set_pixel(xx, yy, Color((48.0 + a * 40.0 + b * 16.0 + c * 10.0) / 255.0, (80.0 + a * 52.0 + b * 24.0 + c * 10.0) / 255.0, (28.0 + a * 18.0 + b * 8.0) / 255.0))
			bump.set_pixel(xx, yy, Color(b, b, b))
	bump.bump_map_to_normal_map(2.0)
	return {"albedo": image_tex(img), "normal": image_tex(bump)}


static func gravel() -> ImageTexture:
	var img := Image.create_empty(256, 256, false, Image.FORMAT_RGBA8)
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 2
	for yy in 256:
		for xx in 256:
			var v := 0.6 + rnd.randf() * 0.28
			img.set_pixel(xx, yy, Color(v, v * 0.9, v * 0.72))
	return image_tex(img)


static func curb() -> ImageTexture:
	var img := Image.create_empty(64, 256, false, Image.FORMAT_RGBA8)
	for k in 4:
		img.fill_rect(Rect2i(0, k * 64, 64, 64), Color(0.95, 0.95, 0.95) if k % 2 else Color(0.78, 0.06, 0.09))
	for yy in range(0, 256, 4):
		img.fill_rect(Rect2i(0, yy, 64, 1), img.get_pixel(0, yy).darkened(0.12))
	return image_tex(img)


static func armco() -> ImageTexture:
	var img := Image.create_empty(256, 64, false, Image.FORMAT_RGBA8)
	for yy in 64:
		var t := float(yy) / 63.0
		var v := 0.62 + 0.28 * sin(t * TAU * 2.0)
		img.fill_rect(Rect2i(0, yy, 256, 1), Color(v, v * 1.01, v * 1.03))
	for xx in range(0, 256, 64):
		img.fill_rect(Rect2i(xx, 0, 3, 64), Color(0.25, 0.25, 0.25))
	return image_tex(img)


static func fence() -> ImageTexture:
	var s := 128
	var img := Image.create_empty(s, s, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.6, 0.62, 0.65, 0.0))
	for yy in s:
		for xx in s:
			var d1 := posmod(xx + yy, 16)
			var d2 := posmod(xx - yy, 16)
			if d1 < 2 or d2 < 2 or yy < 3:
				img.set_pixel(xx, yy, Color(0.62, 0.64, 0.67, 1.0))
	return image_tex(img)


static func checker() -> ImageTexture:
	var img := Image.create_empty(256, 32, false, Image.FORMAT_RGBA8)
	for xx in 32:
		for yy in 4:
			img.fill_rect(Rect2i(xx * 8, yy * 8, 8, 8), Color(0.07, 0.07, 0.07) if (xx + yy) % 2 else Color(0.93, 0.93, 0.93))
	return image_tex(img)


static func livery(base: Color, acc: Color, acc2: Color) -> ImageTexture:
	var w := 512
	var h := 256
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	img.fill(base)
	# side swoosh around v = 0 / 0.5 / 1.0 (the two flanks of the lofted body)
	for vc in [0.0, 0.5, 1.0]:
		var y0 := int(vc * h)
		for xx in w:
			var t := float(xx) / w
			var top := y0 - 20 - int(28.0 * smoothstep(0.35, 0.6, t))
			var bot := y0 + 15 - int(25.0 * smoothstep(0.38, 0.62, t))
			var t0 := clampi(top, 0, h)
			var b0 := clampi(bot, 0, h)
			if b0 > t0:
				img.fill_rect(Rect2i(xx, t0, 1, b0 - t0), acc)
			var b1 := clampi(bot + 4, 0, h)
			if b1 > b0:
				img.fill_rect(Rect2i(xx, b0, 1, b1 - b0), acc2)
	img.fill_rect(Rect2i(0, 64 - 7, w, 14), acc)
	img.fill_rect(Rect2i(0, 64 - 2, w, 3), acc2)
	for xx in [150, 260, 380]:
		img.fill_rect(Rect2i(xx, 0, 1, h), base.darkened(0.3))
	return image_tex(img)


static func stars() -> ImageTexture:
	var w := 2048
	var h := 1024
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0))
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 99
	for k in 4000:
		var xx := rnd.randi_range(0, w - 1)
		var yy := rnd.randi_range(0, int(h * 0.5))
		var b := pow(rnd.randf(), 3.0)
		img.set_pixel(xx, yy, Color(b, b, b * 1.05))
	return image_tex(img, false)


static func soft_dot() -> ImageTexture:
	var s := 64
	var img := Image.create_empty(s, s, false, Image.FORMAT_RGBA8)
	for yy in s:
		for xx in s:
			var d := Vector2(xx - 31.5, yy - 31.5).length() / 32.0
			var a := clampf(1.0 - d, 0.0, 1.0)
			img.set_pixel(xx, yy, Color(1, 1, 1, a * a))
	return image_tex(img)


static func ui_font() -> Font:
	var f := SystemFont.new()
	f.font_names = PackedStringArray(["Bahnschrift", "Barlow Condensed", "Roboto Condensed", "Arial Narrow", "DejaVu Sans Condensed", "Arial"])
	f.font_weight = 600
	f.antialiasing = TextServer.FONT_ANTIALIASING_GRAY
	return f


static func temp_col(t: float, topt: float) -> Color:
	var d := t - topt
	if d < -22.0:
		return Color(0.15, 0.4, 0.95)
	if d < -8.0:
		return Color(0.1, 0.65, 0.7)
	if d < 12.0:
		return Color(0.12, 0.62, 0.22)
	if d < 25.0:
		return Color(0.85, 0.6, 0.05)
	return Color(0.85, 0.12, 0.1)


# sky with sun disc, glow, stars and two-layer drifting clouds (cover/darkness follow the weather)
const SKY_SHADER := """
shader_type sky;
render_mode use_debanding;
uniform vec3 top_col : source_color = vec3(0.2, 0.4, 0.75);
uniform vec3 hor_col : source_color = vec3(0.66, 0.76, 0.86);
uniform vec3 gnd_col : source_color = vec3(0.1, 0.12, 0.1);
uniform vec3 sun_col : source_color = vec3(1.0);
uniform float sun_vis = 1.0;
uniform float energy = 1.0;
uniform sampler2D stars : source_color, filter_linear;
uniform float star_a = 0.0;
uniform float cover = 0.35;
uniform float cloud_dark = 0.0;
uniform vec2 wind = vec2(0.0);

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
	float a = 0.5;
	float s = 0.0;
	for (int i = 0; i < 6; i++) {
		s += a * vnoise(p);
		p = p * 2.07 + vec2(1.7, 9.2);
		a *= 0.5;
	}
	return s;
}

void sky() {
	vec3 d = EYEDIR;
	float h = d.y;
	vec3 col;
	if (h >= 0.0) {
		col = mix(hor_col, top_col, pow(clamp(h, 0.0, 1.0), 0.5));
	} else {
		col = mix(hor_col * 0.85, gnd_col, clamp(-h * 5.0, 0.0, 1.0));
	}
	float sd = 0.0;
	if (LIGHT0_ENABLED) {
		sd = max(dot(d, LIGHT0_DIRECTION), 0.0);
		col += sun_col * sun_vis * (smoothstep(0.99985, 0.99993, sd) * 40.0 + pow(sd, 10.0) * 0.35 + pow(sd, 3.0) * 0.08);
	}
	if (h > 0.0) {
		col += texture(stars, SKY_COORDS).rgb * star_a * smoothstep(0.0, 0.2, h);
		vec2 uv = d.xz / (h + 0.1) * 1.4 + wind;
		float n = fbm(uv);
		float n_hi = fbm(uv * 0.35 + wind * 0.5 + vec2(40.0, 7.0));
		float c = smoothstep(1.0 - cover - 0.12, 1.0 - cover + 0.28, n * 0.75 + n_hi * 0.35) * smoothstep(0.0, 0.15, h);
		float n2 = fbm(uv + LIGHT0_DIRECTION.xz * 0.25);
		float shade = clamp(0.55 + (n - n2) * 3.0, 0.15, 1.0);
		vec3 base = mix(hor_col * 1.1 + vec3(0.08), vec3(0.55), cloud_dark);
		vec3 lit = base + sun_col * sun_vis * 0.25;
		vec3 cloud = mix(base * 0.55, lit * 1.15, shade) * (1.0 - cloud_dark * 0.5);
		cloud += sun_col * sun_vis * pow(sd, 6.0) * 0.8 * (1.0 - c);
		col = mix(col, cloud, c * 0.94);
	}
	COLOR = col * energy;
}
"""


static func sky_material() -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = SKY_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	m.set_shader_parameter("stars", stars())
	return m


# seamless large-scale noise for breaking up tiling (patches, repairs, dry/lush grass, dirt)
static func macro_noise(sd: int = 21) -> NoiseTexture2D:
	var nt := NoiseTexture2D.new()
	nt.width = 512
	nt.height = 512
	nt.seamless = true
	nt.generate_mipmaps = true
	var n := noise(sd, 0.012, 5)
	n.noise_type = FastNoiseLite.TYPE_PERLIN
	nt.noise = n
	return nt


# Track asphalt: two detail scales + large patches (repairs, ageing), rubbered-in racing line from the
# vertex colour, dusty edges, and in the rain a dark glossy surface with standing water in the dips.
const ROAD_SHADER := """
shader_type spatial;
render_mode blend_mix, cull_back;
uniform sampler2D alb : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D rough_t : hint_roughness_r, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D nrm : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D macro : filter_linear_mipmap, repeat_enable;
uniform float width = 14.0;
uniform float vscale = 14.0;
uniform float wet = 0.0;
uniform float tint = 1.0;
uniform float rubber_k = 1.0;
varying vec2 mp;
void vertex() {
	mp = vec2(UV.x * width, UV.y * vscale);
}
void fragment() {
	vec2 uv1 = mp / 3.6;
	vec2 uv2 = mp / 1.15 + vec2(0.37, 0.71);
	vec3 a = mix(texture(alb, uv1).rgb, texture(alb, uv2).rgb, 0.45);
	float m1 = texture(macro, mp / 70.0).r;
	float m2 = texture(macro, mp / 11.0 + vec2(0.5)).r;
	float m3 = texture(macro, vec2(mp.x / 3.0, mp.y / 40.0) + vec2(0.2, 0.9)).r;
	vec3 col = a * mix(0.84, 1.12, m1) * tint * vec3(0.97, 0.99, 1.03);
	// repaired strips of newer, darker tarmac with a visible seam
	float patch_m = smoothstep(0.66, 0.69, m1);
	col = mix(col, col * 0.68, patch_m);
	float seam = smoothstep(0.655, 0.665, m1) * (1.0 - smoothstep(0.675, 0.69, m1));
	// tar snakes: black, shiny bitumen crack sealing
	float crack = 1.0 - smoothstep(0.0, 0.011, abs(m3 - 0.5));
	float tar = max(crack * (1.0 - patch_m), seam);
	col = mix(col, vec3(0.025, 0.025, 0.028), tar * 0.85);
	// rubber laid down on the racing line, tyre smears and braking streaks along the track
	float rub = clamp((1.0 - COLOR.r) * rubber_k, 0.0, 1.0);
	col *= 1.0 - rub * 1.5;
	float streak = texture(macro, vec2(mp.x / 0.35, mp.y / 28.0) + vec2(0.13, 0.4)).r;
	float skid = smoothstep(0.62, 0.78, streak) * smoothstep(0.05, 0.25, rub);
	col *= 1.0 - skid * 0.35;
	col *= 1.0 - smoothstep(0.58, 0.8, m2) * 0.12;
	// oil / fluid stains here and there
	float stain = smoothstep(0.82, 0.9, texture(macro, mp / 5.0 + vec2(0.71, 0.29)).r);
	col *= 1.0 - stain * 0.25;
	// dusty, lighter edges where nobody drives
	float edge = min(UV.x, 1.0 - UV.x) * width;
	col = mix(col * vec3(1.1, 1.07, 1.0), col, smoothstep(0.2, 1.8, edge));
	float r = mix(texture(rough_t, uv1).r, texture(rough_t, uv2).r, 0.5);
	r = r - rub * 0.3 - patch_m * 0.06 - tar * 0.45 - stain * 0.2;
	// rain: darker, glossy, puddles in the low spots
	float puddle = smoothstep(0.56, 0.72, m2) * smoothstep(0.25, 0.85, wet);
	col *= mix(1.0, 0.5, wet * 0.85);
	r = mix(r, 0.14, wet * 0.8);
	r = mix(r, 0.03, puddle);
	ALBEDO = col;
	ROUGHNESS = clamp(r, 0.03, 1.0);
	SPECULAR = 0.45 + tar * 0.2;
	vec3 n = mix(texture(nrm, uv1).rgb, texture(nrm, uv2).rgb, 0.5);
	NORMAL_MAP = mix(n, vec3(0.5, 0.5, 1.0), clamp(puddle + wet * 0.3, 0.0, 1.0));
	NORMAL_MAP_DEPTH = 0.75;
}
"""

# Kerbs: painted concrete blocks (red/white, ~1.5 m) with dark joints, a ribbed surface,
# grime and black rubber where the cars run over them, glossy when wet.
const CURB_SHADER := """
shader_type spatial;
render_mode cull_back;
uniform sampler2D macro : filter_linear_mipmap, repeat_enable;
uniform float wet = 0.0;
uniform float block = 1.5;
varying vec2 mp;
void vertex() {
	mp = vec2(UV.x * 1.32, UV.y * 8.0);
}
void fragment() {
	float bi = floor(mp.y / block);
	float red = mod(bi, 2.0);
	vec3 col = mix(vec3(0.88, 0.88, 0.85), vec3(0.7, 0.06, 0.07), red);
	float jf = fract(mp.y / block);
	float joint = smoothstep(0.0, 0.008, jf) * smoothstep(1.0, 0.992, jf);
	col *= mix(0.35, 1.0, joint);
	float n1 = texture(macro, mp * vec2(0.5, 0.18)).r;
	float n2 = texture(macro, mp * 1.9 + vec2(0.3)).r;
	float n3 = texture(macro, mp * 6.0 + vec2(0.7)).r;
	// rubber smears and grime, paint worn through to the concrete in places
	float rub = smoothstep(0.42, 0.85, n1) * 0.75;
	col = mix(col, vec3(0.07, 0.07, 0.075), rub * 0.55);
	col = mix(col, col * vec3(0.86, 0.82, 0.74), n2 * 0.4);
	float chip = smoothstep(0.74, 0.8, n3);
	col = mix(col, vec3(0.55, 0.54, 0.52), chip * 0.7);
	float rib = sin(mp.y * 52.36);
	ALBEDO = col * mix(1.0, 0.62, wet * 0.8);
	ROUGHNESS = mix(mix(0.55, 0.8, rub), 0.12, wet * 0.85);
	NORMAL_MAP = vec3(0.5, 0.5 + cos(mp.y * 52.36) * 0.22 * joint, 1.0);
	NORMAL_MAP_DEPTH = 1.0;
	AO = 0.85 + 0.15 * rib;
}
"""

# Grass ground (verges and terrain) in world space: two detail scales, large lush/dry/dark variation,
# bare earth patches and gloss when wet. Vertex colour = terrain tint.
const GRASS_SHADER := """
shader_type spatial;
render_mode cull_back;
uniform sampler2D alb : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D nrm : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D macro : filter_linear_mipmap, repeat_enable;
uniform float wet = 0.0;
varying vec2 wp;
void vertex() {
	wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xz;
}
void fragment() {
	vec3 a = texture(alb, wp / 2.7).rgb;
	vec3 b = texture(alb, wp / 9.5 + vec2(0.3, 0.6)).rgb;
	vec3 col = mix(a, b, 0.5);
	float m = texture(macro, wp / 140.0).r;
	float m2 = texture(macro, wp / 31.0 + vec2(0.4)).r;
	float m3 = texture(macro, wp / 13.0 + vec2(0.7, 0.1)).r;
	// lush green <-> dry, yellowish summer grass, plus clover-dark spots
	col *= mix(vec3(0.82, 0.98, 0.78), vec3(1.18, 1.08, 0.72), smoothstep(0.38, 0.72, m));
	col *= mix(0.78, 1.12, m2);
	float earth = smoothstep(0.76, 0.83, m3) * 0.75;
	col = mix(col, vec3(0.3, 0.24, 0.17), earth);
	col *= COLOR.rgb;
	ALBEDO = col * mix(1.0, 0.75, wet);
	ROUGHNESS = mix(0.95, 0.45, wet);
	SPECULAR = 0.3;
	NORMAL_MAP = mix(texture(nrm, wp / 2.7).rgb, texture(nrm, wp / 9.5 + vec2(0.3, 0.6)).rgb, 0.5);
	NORMAL_MAP_DEPTH = 0.8;
	BACKLIGHT = col * 0.15;
}
"""

# meadow grass tufts: sway in the wind (stronger at the tips), darker at the roots, light shines through
const TUFT_SHADER := """
shader_type spatial;
render_mode cull_disabled;
uniform sampler2D tex : source_color, filter_linear_mipmap;
uniform float wind = 1.0;
void vertex() {
	vec3 wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float h = clamp(VERTEX.y / 0.75, 0.0, 1.0);
	float s = sin(TIME * 1.6 + wpos.x * 0.31 + wpos.z * 0.23) * 0.07 + sin(TIME * 3.3 + wpos.x * 1.1 + wpos.z * 0.7) * 0.025;
	VERTEX.x += s * h * h * wind;
	VERTEX.z += s * 0.55 * h * h * wind;
}
void fragment() {
	vec4 t = texture(tex, UV);
	vec2 fw = fwidth(UV) * 256.0;
	float lod = log2(max(max(fw.x, fw.y), 1.0));
	ALPHA = clamp(t.a * (1.0 + lod * 0.4), 0.0, 1.0);
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	NORMAL = FRONT_FACING ? NORMAL : -NORMAL;
	vec3 c = COLOR.rgb * t.rgb * mix(1.1, 0.6, UV.y);
	ALBEDO = c;
	ROUGHNESS = 0.9;
	BACKLIGHT = c * 0.45;
}
"""

# Spectators: one mesh, the part is coded in the vertex colour (shirt, arms, trousers, skin, hands,
# hair/cap, shoes). Per person: shirt = instance colour, custom = (trousers, hair/cap, skin, phase).
# Some cheer with raised arms and bounce, the others shift around a little.
# Spectators: one mesh, the body part is coded in the vertex colour (r): shirt, arms, trousers, skin,
# hands, hair/cap, shoes. Per person (custom data): r = shirt colour, g = trousers (int) + hair/cap (fract),
# b = skin tone, a = phase. Some cheer with raised arms and bounce, the others shift around a little.
const CROWD_SHADER := """
shader_type spatial;
render_mode cull_back;
varying vec3 pcol;
// shirt colours (written as a function: constant arrays are not accepted by every graphics driver)
vec3 shirt_col(int k) {
	if (k == 0) return vec3(0.85, 0.1, 0.1);
	if (k == 1) return vec3(0.95, 0.95, 0.95);
	if (k == 2) return vec3(0.1, 0.2, 0.6);
	if (k == 3) return vec3(0.08, 0.08, 0.1);
	if (k == 4) return vec3(1.0, 0.75, 0.1);
	if (k == 5) return vec3(0.2, 0.55, 0.25);
	if (k == 6) return vec3(0.95, 0.45, 0.1);
	if (k == 7) return vec3(0.5, 0.5, 0.55);
	if (k == 8) return vec3(0.15, 0.6, 0.85);
	return vec3(0.6, 0.12, 0.45);
}
void vertex() {
	float part = COLOR.r;
	vec4 cu = INSTANCE_CUSTOM;
	float ph = cu.a * 6.2831;
	float cheer = step(0.62, fract(cu.a * 7.31));
	float lift = cheer * (0.55 + 0.45 * sin(TIME * 4.2 + ph));
	// arms (and hands) rotate up around the shoulder
	if ((part > 0.1 && part < 0.2) || (part > 0.55 && part < 0.65)) {
		float sd = sign(VERTEX.x);
		vec2 sh = vec2(sd * 0.2, 0.6);
		vec2 d = VERTEX.xy - sh;
		float an = sd * lift * 2.5;
		VERTEX.xy = sh + vec2(d.x * cos(an) - d.y * sin(an), d.x * sin(an) + d.y * cos(an));
	}
	if (part < 0.25 || part > 0.4) {
		float up = step(0.15, VERTEX.y);
		VERTEX.y += cheer * max(0.0, sin(TIME * 4.2 + ph)) * 0.05 * up;
		VERTEX.x += sin(TIME * 0.6 + ph * 3.0) * 0.025 * clamp(VERTEX.y, 0.0, 1.0);
	}
	vec3 shirt = shirt_col(int(clamp(cu.r * 10.0, 0.0, 9.0)));
	vec3 skin = mix(vec3(0.95, 0.77, 0.64), vec3(0.38, 0.25, 0.17), cu.b);
	float pi = floor(cu.g);
	float hv = fract(cu.g);
	vec3 pants = pi < 1.0 ? vec3(0.1, 0.12, 0.19) : (pi < 2.0 ? vec3(0.22, 0.27, 0.42) : (pi < 3.0 ? vec3(0.07, 0.07, 0.08) : vec3(0.55, 0.5, 0.4)));
	vec3 hair = hv < 0.55 ? mix(vec3(0.06, 0.045, 0.035), vec3(0.6, 0.45, 0.25), hv * 1.8) :
		(hv < 0.7 ? vec3(0.85, 0.1, 0.1) : (hv < 0.85 ? vec3(0.95, 0.95, 0.95) : vec3(0.1, 0.2, 0.5)));
	pcol = part < 0.25 ? shirt : (part < 0.4 ? pants : (part < 0.68 ? skin : (part < 0.8 ? hair : vec3(0.06))));
}
void fragment() {
	ALBEDO = pcol;
	ROUGHNESS = 0.85;
	BACKLIGHT = pcol * 0.1;
}
"""


static func shader_mat(code: String) -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = code
	var m := ShaderMaterial.new()
	m.shader = sh
	return m

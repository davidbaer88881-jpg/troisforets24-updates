extends Node
# Friends and the public lobby list (Supabase tables tf24_players / tf24_friends / tf24_lobbies /
# tf24_join_requests, protected by row level security - every call runs as the signed-in player).
#  - every player has a 6-letter friend code; adding it makes you friends both ways
#  - a code lobby is listed while it is open ("Alle" or "Nur Freunde"); others send a join request,
#    the host accepts or declines, an accepted player joins with the lobby code automatically
#  - friends show whether they are online and which lobby they are in

signal friends_changed
signal lobbies_changed
signal requests_changed                 # host: the pending requests changed
signal request_answer(accepted: bool, code: String)

const Profile = preload("res://scripts/profile.gd")
const CODE_CHARS := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
const LOBBY_STALE := 60.0               # a lobby without a sign of life for this long is gone
const ONLINE_STALE := 180.0             # a friend seen within this time counts as online

var game
var acc                                  # the Account node (session + REST helper)
var friend_code := ""
var friends: Array = []                  # [{uid, name, friend_code, online, lobby}]
var lobbies: Array = []                  # [{code, host_uid, host_name, track, players, max_players, racing, friend}]
var requests: Array = []                 # host: [{id, from_name, from_uid}]
var listing := "all"                     # host: "all", "friends", "off"
var waiting_id := -1                     # player: own pending join request
var waiting_code := ""

var _me_t := 0.0
var _lobby_t := 0.0
var _req_t := 0.0
var _wait_t := 0.0
var _published := ""
var _busy := {}


func ready_to_use() -> bool:
	return acc != null and acc.signed_in()


func _process(dt: float) -> void:
	if not ready_to_use():
		return
	var net = game.net
	_me_t -= dt
	if _me_t <= 0.0:
		_me_t = 60.0
		_run("me", _heartbeat)
	# own lobby in the list
	var hosting: bool = net.online and net.mode == "code" and net.is_host() and net.relay.is_open()
	if hosting and listing != "off":
		_lobby_t -= dt
		if _lobby_t <= 0.0:
			_lobby_t = 15.0
			_run("pub", _publish)
		_req_t -= dt
		if _req_t <= 0.0:
			_req_t = 3.0
			_run("req", _load_requests)
	elif _published != "":
		_run("unpub", _unpublish)
	# waiting for the host's answer
	if waiting_id >= 0:
		_wait_t -= dt
		if _wait_t <= 0.0:
			_wait_t = 2.0
			_run("wait", _check_request)


# one request of a kind at a time
func _run(key: String, f: Callable) -> void:
	if _busy.get(key, false):
		return
	_busy[key] = true
	await f.call()
	_busy[key] = false


func _now_iso(offset := 0.0) -> String:
	return Time.get_datetime_string_from_unix_time(int(Time.get_unix_time_from_system() + offset)) + "Z"


func _my_name() -> String:
	var n := String(Profile.current.get("name", "Fahrer")).strip_edges()
	return n.substr(0, 32) if n != "" else "Fahrer"


static func _random_code() -> String:
	var s := ""
	for i in 6:
		s += CODE_CHARS[randi() % CODE_CHARS.length()]
	return s


# ------------------------------------------------------------------ own player row
func _heartbeat() -> void:
	if not await acc.ensure_session():
		return
	var lob := String(game.net.code) if game.net.online and game.net.mode == "code" else ""
	if friend_code == "":
		var r: Dictionary = await acc._request(HTTPClient.METHOD_GET, "/rest/v1/tf24_players?uid=eq.%s&select=friend_code" % acc.uid, null, true)
		if r["ok"] and r["data"] is Array and not (r["data"] as Array).is_empty():
			friend_code = String(r["data"][0]["friend_code"])
	if friend_code == "":
		for _try in 5:
			var c := _random_code()
			var ins: Dictionary = await acc._request(HTTPClient.METHOD_POST, "/rest/v1/tf24_players",
					{"uid": acc.uid, "name": _my_name(), "friend_code": c, "lobby_code": lob if lob != "" else null, "last_seen": _now_iso()}, true)
			if ins["ok"]:
				friend_code = c
				break
			if int(ins["code"]) != 409:
				return
		friends_changed.emit()
		return
	await acc._request(HTTPClient.METHOD_PATCH, "/rest/v1/tf24_players?uid=eq." + acc.uid,
			{"name": _my_name(), "lobby_code": lob if lob != "" else null, "last_seen": _now_iso()}, true)


func touch() -> void:
	_me_t = 0.0


# ------------------------------------------------------------------ friends
func refresh_friends() -> void:
	if not ready_to_use() or not await acc.ensure_session():
		return
	if friend_code == "":
		await _heartbeat()
	var r: Dictionary = await acc._request(HTTPClient.METHOD_GET, "/rest/v1/tf24_friends?select=uid,friend_uid", null, true)
	if not r["ok"] or not r["data"] is Array:
		return
	var ids := {}
	for row in r["data"]:
		var other := String(row["friend_uid"]) if String(row["uid"]) == acc.uid else String(row["uid"])
		ids[other] = true
	var out: Array = []
	if not ids.is_empty():
		var q := "/rest/v1/tf24_players?uid=in.(%s)&select=uid,name,friend_code,lobby_code,last_seen" % ",".join(PackedStringArray(ids.keys()))
		var p: Dictionary = await acc._request(HTTPClient.METHOD_GET, q, null, true)
		if p["ok"] and p["data"] is Array:
			var now := Time.get_unix_time_from_system()
			for row in p["data"]:
				var seen := Time.get_unix_time_from_datetime_string(String(row["last_seen"]).substr(0, 19))
				var on: bool = now - seen < ONLINE_STALE
				out.append({"uid": String(row["uid"]), "name": String(row["name"]), "friend_code": String(row["friend_code"]),
						"online": on, "lobby": String(row["lobby_code"]) if on and row["lobby_code"] != null else ""})
	out.sort_custom(func(a, b): return (a["online"] and not b["online"]) or (a["online"] == b["online"] and String(a["name"]) < String(b["name"])))
	friends = out
	friends_changed.emit()


func add_friend(code: String) -> String:
	if not ready_to_use():
		return "Melde dich zuerst mit deinem Konto an (Profil)."
	code = code.strip_edges().to_upper().replace(" ", "")
	if code.length() != 6:
		return "Ein Freundes-Code hat 6 Zeichen."
	if code == friend_code:
		return "Das ist dein eigener Code."
	if not await acc.ensure_session():
		return "Bitte neu anmelden."
	var r: Dictionary = await acc._request(HTTPClient.METHOD_GET, "/rest/v1/tf24_players?friend_code=eq.%s&select=uid,name" % code.uri_encode(), null, true)
	if not r["ok"]:
		return String(r["error"])
	if not r["data"] is Array or (r["data"] as Array).is_empty():
		return "Keinen Fahrer mit dem Code %s gefunden." % code
	var other: Dictionary = r["data"][0]
	var ins: Dictionary = await acc._request(HTTPClient.METHOD_POST, "/rest/v1/tf24_friends", {"uid": acc.uid, "friend_uid": other["uid"]}, true)
	if not ins["ok"] and int(ins["code"]) != 409:
		return String(ins["error"])
	await refresh_friends()
	return "%s ist jetzt dein Freund!" % String(other["name"])


func remove_friend(other_uid: String) -> void:
	if not ready_to_use() or not await acc.ensure_session():
		return
	await acc._request(HTTPClient.METHOD_DELETE, "/rest/v1/tf24_friends?uid=eq.%s&friend_uid=eq.%s" % [acc.uid, other_uid], null, true)
	await acc._request(HTTPClient.METHOD_DELETE, "/rest/v1/tf24_friends?uid=eq.%s&friend_uid=eq.%s" % [other_uid, acc.uid], null, true)
	await refresh_friends()


# ------------------------------------------------------------------ lobby list
func refresh_lobbies() -> void:
	if not ready_to_use() or not await acc.ensure_session():
		return
	var q := "/rest/v1/tf24_lobbies?updated_at=gt.%s&order=updated_at.desc&limit=40&select=code,host_uid,host_name,track,players,max_players,racing,friends_only" % _now_iso(-LOBBY_STALE)
	var r: Dictionary = await acc._request(HTTPClient.METHOD_GET, q, null, true)
	if not r["ok"] or not r["data"] is Array:
		return
	var fr := {}
	for f in friends:
		fr[f["uid"]] = true
	var out: Array = []
	for row in r["data"]:
		if String(row["host_uid"]) == acc.uid:
			continue
		var d: Dictionary = row
		d["friend"] = fr.has(String(row["host_uid"]))
		out.append(d)
	out.sort_custom(func(a, b): return a["friend"] and not b["friend"])
	lobbies = out
	lobbies_changed.emit()


func _publish() -> void:
	if not await acc.ensure_session():
		return
	var net = game.net
	var row := {"code": net.code, "host_uid": acc.uid, "host_name": _my_name(), "track": String(net.lobby_cfg.get("track", "")),
		"players": net.players.size(), "max_players": int(net.lobby_cfg.get("max_humans", net.MAX_PEERS)), "racing": game.state != "menu",
		"friends_only": listing == "friends", "updated_at": _now_iso()}
	var r: Dictionary = await acc._request(HTTPClient.METHOD_POST, "/rest/v1/tf24_lobbies?on_conflict=code", row, true,
			PackedStringArray(["Prefer: resolution=merge-duplicates"]))
	if r["ok"]:
		_published = String(net.code)


func _unpublish() -> void:
	var c := _published
	_published = ""
	requests = []
	if c != "" and await acc.ensure_session():
		await acc._request(HTTPClient.METHOD_DELETE, "/rest/v1/tf24_lobbies?code=eq." + c, null, true)
	requests_changed.emit()


func set_listing(v: String) -> void:
	listing = v
	_lobby_t = 0.0
	if v == "off" and _published != "":
		_run("unpub", _unpublish)


# ------------------------------------------------------------------ join requests
func send_request(code: String) -> String:
	if not ready_to_use() or not await acc.ensure_session():
		return "Melde dich zuerst mit deinem Konto an (Profil)."
	var r: Dictionary = await acc._request(HTTPClient.METHOD_POST, "/rest/v1/tf24_join_requests",
			{"code": code, "from_uid": acc.uid, "from_name": _my_name()}, true, PackedStringArray(["Prefer: return=representation"]))
	if not r["ok"] or not r["data"] is Array or (r["data"] as Array).is_empty():
		return "Anfrage ging nicht durch: " + String(r["error"])
	waiting_id = int(r["data"][0]["id"])
	waiting_code = code
	_wait_t = 2.0
	return "Anfrage an Lobby %s geschickt – warte auf den Host …" % code


func cancel_request() -> void:
	var id := waiting_id
	waiting_id = -1
	waiting_code = ""
	if id >= 0 and await acc.ensure_session():
		await acc._request(HTTPClient.METHOD_DELETE, "/rest/v1/tf24_join_requests?id=eq.%d" % id, null, true)


func _check_request() -> void:
	if waiting_id < 0 or not await acc.ensure_session():
		return
	var r: Dictionary = await acc._request(HTTPClient.METHOD_GET, "/rest/v1/tf24_join_requests?id=eq.%d&select=status" % waiting_id, null, true)
	if not r["ok"] or not r["data"] is Array:
		return
	var code := waiting_code
	if (r["data"] as Array).is_empty():
		# the lobby closed (its requests went with it)
		waiting_id = -1
		waiting_code = ""
		request_answer.emit(false, code)
		return
	var st := String(r["data"][0]["status"])
	if st == "pending":
		return
	var id := waiting_id
	waiting_id = -1
	waiting_code = ""
	await acc._request(HTTPClient.METHOD_DELETE, "/rest/v1/tf24_join_requests?id=eq.%d" % id, null, true)
	request_answer.emit(st == "accepted", code)


func _load_requests() -> void:
	if not await acc.ensure_session():
		return
	var q := "/rest/v1/tf24_join_requests?code=eq.%s&status=eq.pending&order=created_at&select=id,from_name,from_uid" % game.net.code
	var r: Dictionary = await acc._request(HTTPClient.METHOD_GET, q, null, true)
	if not r["ok"] or not r["data"] is Array:
		return
	var changed: bool = (r["data"] as Array).size() != requests.size()
	requests = r["data"]
	if changed:
		requests_changed.emit()


func answer(id: int, accept: bool) -> void:
	for k in requests.size():
		if int(requests[k]["id"]) == id:
			requests.remove_at(k)
			break
	requests_changed.emit()
	if await acc.ensure_session():
		await acc._request(HTTPClient.METHOD_PATCH, "/rest/v1/tf24_join_requests?id=eq.%d" % id, {"status": "accepted" if accept else "declined"}, true)

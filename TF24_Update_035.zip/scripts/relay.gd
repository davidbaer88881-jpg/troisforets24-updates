extends Node
# Online lobby through a server (Supabase Realtime, broadcast channel "tf24-<CODE>"): no IP addresses,
# no router settings. Every message goes to everybody in the channel; "t" picks one receiver.

signal opened                          # joined the channel
signal failed(reason: String)
signal message(from: int, ev: String, data)

const WS_URL := "wss://jrbfbvlwngvjzddfuesu.supabase.co/realtime/v1/websocket?vsn=1.0.0&apikey="
const API_KEY := "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpyYmZidmx3bmd2anpkZGZ1ZXN1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI3NTcxMjEsImV4cCI6MjEwODMzMzEyMX0.7v59xZeH4St1ACQAsv7MlcIbVaAfiyT-5kbtihiMVqw"
const HEARTBEAT := 20.0
const CODE_CHARS := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # no 0/O, 1/I

var url := WS_URL + API_KEY           # can be pointed at a test server
var ws: WebSocketPeer
var topic := ""
var my_id := 0
var joined := false
var _ref := 1
var _join_ref := ""
var _hb := 0.0
var _state := WebSocketPeer.STATE_CLOSED
var _join_t := 0.0


static func new_code() -> String:
	var s := ""
	for i in 5:
		s += CODE_CHARS[randi() % CODE_CHARS.length()]
	return s


static func clean_code(c: String) -> String:
	var out := ""
	for ch in c.strip_edges().to_upper():
		if CODE_CHARS.contains(ch):
			out += ch
	return out


func open(code: String, id: int) -> void:
	close()
	my_id = id
	topic = "realtime:tf24-" + code
	ws = WebSocketPeer.new()
	ws.inbound_buffer_size = 1 << 20
	ws.outbound_buffer_size = 1 << 20
	var err := ws.connect_to_url(url)
	if err != OK:
		ws = null
		failed.emit("Keine Verbindung zum Server (Fehler %d)." % err)
		return
	_state = WebSocketPeer.STATE_CONNECTING
	_join_t = 12.0


func close() -> void:
	if ws != null:
		if joined:
			_raw({"topic": topic, "event": "phx_leave", "payload": {}, "ref": _next(), "join_ref": _join_ref})
		ws.close()
	ws = null
	joined = false
	_state = WebSocketPeer.STATE_CLOSED


func is_open() -> bool:
	return ws != null and joined


func _next() -> String:
	_ref += 1
	return str(_ref)


func _raw(msg: Dictionary) -> void:
	if ws != null and ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
		ws.send_text(JSON.stringify(msg))


# to = 0: everybody, otherwise only that player reads it
func send(ev: String, data, to: int = 0) -> void:
	if not joined:
		return
	_raw({"topic": topic, "event": "broadcast", "ref": null, "join_ref": _join_ref,
		"payload": {"type": "broadcast", "event": "m", "payload": {"f": my_id, "t": to, "e": ev, "d": data}}})


func _process(dt: float) -> void:
	if ws == null:
		return
	ws.poll()
	var st := ws.get_ready_state()
	if st == WebSocketPeer.STATE_OPEN and _state != WebSocketPeer.STATE_OPEN:
		_state = st
		_join_ref = _next()
		_raw({"topic": topic, "event": "phx_join", "ref": _join_ref, "join_ref": _join_ref,
			"payload": {"config": {"broadcast": {"ack": false, "self": false}, "presence": {"enabled": false}, "private": false}}})
	elif st == WebSocketPeer.STATE_CLOSED:
		var was_joined := joined
		var reason := ws.get_close_reason()
		ws = null
		joined = false
		_state = st
		failed.emit("Verbindung zum Server getrennt." if was_joined else "Server nicht erreichbar. Internetverbindung prüfen. " + reason)
		return
	if not joined:
		_join_t -= dt
		if _join_t <= 0.0:
			close()
			failed.emit("Server antwortet nicht. Internetverbindung prüfen.")
			return
	_hb -= dt
	if _hb <= 0.0 and st == WebSocketPeer.STATE_OPEN:
		_hb = HEARTBEAT
		_raw({"topic": "phoenix", "event": "heartbeat", "payload": {}, "ref": _next()})
	while ws != null and ws.get_available_packet_count() > 0:
		var txt := ws.get_packet().get_string_from_utf8()
		var m = JSON.parse_string(txt)
		if m is Dictionary:
			_handle(m)


func _handle(m: Dictionary) -> void:
	var ev := String(m.get("event", ""))
	var pl = m.get("payload", {})
	if ev == "phx_reply" and String(m.get("ref", "")) == _join_ref and String(m.get("topic", "")) == topic:
		if pl is Dictionary and String(pl.get("status", "")) == "ok":
			joined = true
			opened.emit()
		else:
			var why := str(pl.get("response", "")) if pl is Dictionary else ""
			close()
			failed.emit("Server hat die Lobby abgelehnt. " + why)
	elif ev == "broadcast" and pl is Dictionary:
		var inner = pl.get("payload", {})
		if inner is Dictionary:
			var to := int(inner.get("t", 0))
			if to == 0 or to == my_id:
				message.emit(int(inner.get("f", 0)), String(inner.get("e", "")), inner.get("d"))
	elif ev == "phx_error" or ev == "phx_close" or ev == "system":
		if ev != "system" or (pl is Dictionary and String(pl.get("status", "ok")) == "error"):
			var msg := str(pl.get("message", "")) if pl is Dictionary else ""
			if "Too many" in msg or "too_many" in msg:
				failed.emit("Server überlastet (zu viele Nachrichten) – kurz warten und neu verbinden.")

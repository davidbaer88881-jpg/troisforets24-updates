# UI kit in the style of a modern endurance sim menu: condensed bold type, dark navy panels,
# a crimson/pink wedge, white primary buttons, ‹ value › selectors, pill switches, rank badges.
extends RefCounted

const NAVY := Color(0.035, 0.05, 0.09)
const PANEL := Color(0.06, 0.08, 0.13, 0.92)
const PANEL2 := Color(0.09, 0.12, 0.19, 0.95)
const LINE := Color(1, 1, 1, 0.09)
const RED := Color(0.9, 0.11, 0.24)
const PINK := Color(0.96, 0.36, 0.5)
const TEXT := Color(0.95, 0.96, 0.98)
const MUTED := Color(0.58, 0.62, 0.7)
const GOLD := Color(0.91, 0.66, 0.15)
const GREEN := Color(0.18, 0.72, 0.38)
const HY := Color(0.86, 0.13, 0.17)
const GT := Color(0.13, 0.62, 0.3)

static var _fonts := {}


# fonts are read from the raw .ttf files (works inside update packs, no import needed)
static func font(kind: String) -> Font:
	if _fonts.has(kind):
		return _fonts[kind]
	var file: String = {"head": "BarlowCondensed-ExtraBold", "bold": "BarlowCondensed-Bold", "semi": "BarlowCondensed-SemiBold",
		"body": "Barlow-Medium", "body2": "Barlow-SemiBold"}.get(kind, "Barlow-Medium")
	var path: String = "res://fonts/" + file + ".ttf"
	var f := FontFile.new()
	var err := ERR_FILE_NOT_FOUND
	if FileAccess.file_exists(path):
		err = f.load_dynamic_font(path)          # raw file (project folder / update pack)
	elif ResourceLoader.exists(path):
		var imp = load(path)                        # exported game: Godot stores the imported font
		if imp is FontFile:
			f = imp
			err = OK
	var fb := SystemFont.new()
	fb.font_names = PackedStringArray(["Bahnschrift", "Arial Narrow", "Helvetica Neue", "DejaVu Sans Condensed", "Arial"])
	fb.font_weight = 700 if kind != "body" else 500
	var out: Font
	if err == OK:
		f.fallbacks = [fb]
		f.antialiasing = TextServer.FONT_ANTIALIASING_GRAY
		out = f
	else:
		out = fb
	_fonts[kind] = out
	return out


static func label(text: String, kind: String = "body", size: int = 18, col: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", font(kind))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	return l


static func box(col: Color, radius: int = 6, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(radius)
	if bw > 0:
		sb.border_color = border
		sb.set_border_width_all(bw)
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	return sb


static func panel(col: Color = PANEL, radius: int = 8, border: Color = Color(1, 1, 1, 0.1), bw: int = 1) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", box(col, radius, border, bw))
	return p


static func _btn_style(b: Button, normal: Color, hover: Color, text: Color, text_hover: Color, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> void:
	b.add_theme_stylebox_override("normal", box(normal, 4, border, bw))
	b.add_theme_stylebox_override("hover", box(hover, 4, border, bw))
	b.add_theme_stylebox_override("pressed", box(hover.darkened(0.1), 4, border, bw))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_stylebox_override("disabled", box(normal.darkened(0.4), 4, border, bw))
	b.add_theme_color_override("font_color", text)
	b.add_theme_color_override("font_hover_color", text_hover)
	b.add_theme_color_override("font_pressed_color", text_hover)
	b.add_theme_color_override("font_focus_color", text)


# white filled button with dark text (main actions)
static func primary(text: String, size: int = 24, w: float = 0.0) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_override("font", font("head"))
	b.add_theme_font_size_override("font_size", size)
	_btn_style(b, Color(0.96, 0.96, 0.97), Color(1, 1, 1), Color(0.05, 0.06, 0.09), RED)
	b.custom_minimum_size = Vector2(w, size + 26)
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	return b


# outlined button (secondary actions)
static func outline(text: String, size: int = 18, w: float = 0.0) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_override("font", font("bold"))
	b.add_theme_font_size_override("font_size", size)
	_btn_style(b, Color(0, 0, 0, 0.2), Color(1, 1, 1, 0.12), TEXT, Color.WHITE, Color(1, 1, 1, 0.75), 2)
	b.custom_minimum_size = Vector2(w, size + 20)
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	return b


# red accent button
static func accent(text: String, size: int = 20, w: float = 0.0) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_override("font", font("head"))
	b.add_theme_font_size_override("font_size", size)
	_btn_style(b, RED, RED.lightened(0.15), Color.WHITE, Color.WHITE)
	b.custom_minimum_size = Vector2(w, size + 22)
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	return b


# top navigation entry with underline when active
static func nav(text: String, active: bool, size: int = 26) -> Button:
	var b := Button.new()
	b.text = text
	b.flat = true
	b.add_theme_font_override("font", font("bold"))
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_color_override("font_color", Color.WHITE if active else Color(0.9, 0.92, 0.95, 0.75))
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0)
	sb.border_color = Color.WHITE
	sb.border_width_bottom = 3 if active else 0
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_bottom = 6
	b.add_theme_stylebox_override("normal", sb)
	var sbh: StyleBoxFlat = sb.duplicate()
	sbh.border_width_bottom = 3
	sbh.border_color = Color(1, 1, 1, 0.6) if not active else Color.WHITE
	b.add_theme_stylebox_override("hover", sbh)
	b.add_theme_stylebox_override("pressed", sbh)
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	return b


static func line_edit(text: String, placeholder: String, w: float = 320.0, secret: bool = false) -> LineEdit:
	var e := LineEdit.new()
	e.text = text
	e.placeholder_text = placeholder
	e.secret = secret
	e.custom_minimum_size = Vector2(w, 44)
	e.add_theme_font_override("font", font("body2"))
	e.add_theme_font_size_override("font_size", 18)
	e.add_theme_stylebox_override("normal", box(Color(0, 0, 0, 0.35), 4, Color(1, 1, 1, 0.35), 1))
	e.add_theme_stylebox_override("focus", box(Color(0, 0, 0, 0.45), 4, Color.WHITE, 2))
	e.add_theme_color_override("font_color", TEXT)
	e.add_theme_color_override("font_placeholder_color", MUTED)
	return e


static func spacer(h: float) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c


static func hexpand(c: Control) -> Control:
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return c


static func fmt_time(t: float) -> String:
	if t <= 0.0 or t > 36000.0:
		return "-:--.---"
	var m := int(t / 60.0)
	return "%d:%06.3f" % [m, t - m * 60.0]


# ---------------------------------------------------------------- custom controls
# ‹ value › selector: cycles through [label, value] pairs
class Selector extends HBoxContainer:
	var items: Array = []
	var idx := 0
	var on_change: Callable
	var lbl: Label

	func setup(list: Array, current, cb: Callable, size: int = 20, w: float = 170.0) -> Selector:
		items = list
		on_change = cb
		for k in items.size():
			var it: Array = items[k]
			if it[1] == current:
				idx = k
		add_theme_constant_override("separation", 4)
		var l := _arrow("‹", -1)
		add_child(l)
		lbl = Label.new()
		lbl.add_theme_font_override("font", font_of("bold"))
		lbl.add_theme_font_size_override("font_size", size)
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lbl.custom_minimum_size = Vector2(w, 0)
		lbl.clip_text = true
		add_child(lbl)
		add_child(_arrow("›", 1))
		_refresh()
		return self

	static func font_of(k: String) -> Font:
		return load("res://scripts/ui.gd").font(k)

	func _arrow(t: String, d: int) -> Button:
		var b := Button.new()
		b.text = t
		b.flat = true
		b.add_theme_font_override("font", font_of("head"))
		b.add_theme_font_size_override("font_size", 28)
		b.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
		b.add_theme_color_override("font_hover_color", Color(0.96, 0.36, 0.5))
		b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		b.custom_minimum_size = Vector2(28, 0)
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		b.pressed.connect(_step.bind(d))
		return b

	func _step(d: int) -> void:
		if items.is_empty():
			return
		idx = posmod(idx + d, items.size())
		_refresh()
		var it: Array = items[idx]
		if on_change.is_valid():
			on_change.call(it[1])

	func _refresh() -> void:
		if items.is_empty():
			lbl.text = "-"
			return
		var it: Array = items[idx]
		lbl.text = String(it[0])

	func set_value(v) -> void:
		for k in items.size():
			var it: Array = items[k]
			if it[1] == v:
				idx = k
		_refresh()


# pill switch (on/off)
class Pill extends Control:
	var on := false
	var on_change: Callable
	var anim := 0.0

	func setup(state: bool, cb: Callable) -> Pill:
		on = state
		anim = 1.0 if on else 0.0
		on_change = cb
		custom_minimum_size = Vector2(54, 28)
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		return self

	func _gui_input(ev: InputEvent) -> void:
		if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
			on = not on
			if on_change.is_valid():
				on_change.call(on)
			accept_event()

	func _process(dt: float) -> void:
		var t := 1.0 if on else 0.0
		if absf(anim - t) > 0.001:
			anim = move_toward(anim, t, dt * 8.0)
			queue_redraw()

	func _draw() -> void:
		var r := Rect2(Vector2(0, 2), Vector2(52, 24))
		var col := Color(0.35, 0.38, 0.44).lerp(Color(0.16, 0.5, 0.95), anim)
		draw_rect(Rect2(r.position + Vector2(12, 0), Vector2(28, 24)), col)
		draw_circle(r.position + Vector2(12, 12), 12, col)
		draw_circle(r.position + Vector2(40, 12), 12, col)
		var kx := lerpf(12.0, 40.0, anim)
		draw_circle(Vector2(kx, 14), 9.5, Color.WHITE)
		if anim > 0.5:
			draw_polyline(PackedVector2Array([Vector2(kx - 4, 14), Vector2(kx - 1, 17), Vector2(kx + 4, 11)]), col, 2.0, true)


# track outline from control points
class Outline extends Control:
	var pts := PackedVector2Array()
	var col := Color.WHITE
	var width := 4.0

	func setup(ctrl: Array, c: Color = Color.WHITE, w: float = 4.0) -> Outline:
		col = c
		width = w
		for p in ctrl:
			pts.append(p)
		if pts.size() > 1:
			pts.append(pts[0])
		resized.connect(queue_redraw)
		return self

	func _draw() -> void:
		if pts.size() < 3:
			return
		var mn := Vector2(1e9, 1e9)
		var mx := Vector2(-1e9, -1e9)
		for p in pts:
			mn = Vector2(minf(mn.x, p.x), minf(mn.y, p.y))
			mx = Vector2(maxf(mx.x, p.x), maxf(mx.y, p.y))
		var sz := size - Vector2(width * 2.0, width * 2.0)
		var sc := minf(sz.x / maxf(1.0, mx.x - mn.x), sz.y / maxf(1.0, mx.y - mn.y))
		var off := (size - (mx - mn) * sc) * 0.5
		var out := PackedVector2Array()
		for p in pts:
			out.append(off + (p - mn) * sc)
		draw_polyline(out, Color(0, 0, 0, 0.35), width + 3.0, true)
		draw_polyline(out, col, width, true)
		draw_circle(out[0], width * 1.4, Color(0.9, 0.11, 0.24))


# DR / SR rank tile (letter + level, coloured by tier, progress bar)
class Badge extends Control:
	var tier := "BRONZE"
	var level := 1
	var frac := 0.0
	var big := true

	func setup(t: String, lv: int, f: float, large: bool = true) -> Badge:
		tier = t
		level = lv
		frac = f
		big = large
		custom_minimum_size = Vector2(150, 200) if big else Vector2(56, 26)
		return self

	static func tier_col(t: String) -> Color:
		match t:
			"SILBER":
				return Color(0.72, 0.75, 0.8)
			"GOLD":
				return Color(0.91, 0.66, 0.15)
			"PLATIN":
				return Color(0.55, 0.8, 0.88)
			_:
				return Color(0.66, 0.48, 0.3)

	func _draw() -> void:
		var c := tier_col(tier)
		var uk = load("res://scripts/ui.gd")
		if not big:
			draw_rect(Rect2(Vector2.ZERO, size), c)
			draw_string(uk.font("head"), Vector2(0, size.y - 6), tier.substr(0, 1) + str(level), HORIZONTAL_ALIGNMENT_CENTER, size.x, 18, Color(0.08, 0.06, 0.04))
			return
		var r := Rect2(Vector2.ZERO, size)
		draw_rect(r, c)
		draw_rect(Rect2(4, 4, size.x - 8, size.y - 8), Color(1, 1, 1, 0.18), false, 2.0)
		draw_string(uk.font("head"), Vector2(0, size.y * 0.55), str(level), HORIZONTAL_ALIGNMENT_CENTER, size.x, int(size.y * 0.5), Color(1, 1, 1))
		draw_rect(Rect2(14, size.y * 0.66, size.x - 28, 6), Color(0, 0, 0, 0.25))
		draw_rect(Rect2(14, size.y * 0.66, (size.x - 28) * clampf(frac, 0.0, 1.0), 6), Color.WHITE)
		draw_rect(Rect2(0, size.y * 0.76, size.x, size.y * 0.24), Color(1, 1, 1, 0.92))
		draw_string(uk.font("head"), Vector2(0, size.y - 14), tier, HORIZONTAL_ALIGNMENT_CENTER, size.x, 26, c.darkened(0.25))


# profile icon: 8 motifs in two chosen colours
const ICONS := ["Helm Klassik", "Helm Doppelstreifen", "Helm Stern", "Helm Blitz", "Startnummer", "Zielflagge", "Lenkrad", "Pokal"]
const ICON_COLORS := [Color(0.95, 0.95, 0.96), Color(0.08, 0.08, 0.1), Color(0.86, 0.1, 0.14), Color(0.96, 0.4, 0.55), Color(1.0, 0.55, 0.08),
	Color(1.0, 0.82, 0.1), Color(0.15, 0.7, 0.3), Color(0.1, 0.75, 0.75), Color(0.12, 0.38, 0.95), Color(0.05, 0.15, 0.4), Color(0.55, 0.2, 0.85), Color(0.6, 0.62, 0.66)]


class Avatar extends Control:
	var c1 := Color.WHITE
	var c2 := Color.RED
	var style := 0
	var num := 24
	var selected := false

	func setup(a: Color, b: Color, s: float = 120.0, st: int = 0, n: int = 24) -> Avatar:
		c1 = a
		c2 = b
		style = st
		num = n
		custom_minimum_size = Vector2(s, s)
		size_flags_vertical = Control.SIZE_SHRINK_CENTER
		size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		return self

	func _helmet(cen: Vector2, R: float) -> void:
		var shell := Color(c1)
		draw_circle(cen + Vector2(0, R * 0.05), R * 0.66, shell)
		draw_rect(Rect2(cen + Vector2(-R * 0.66, R * 0.05), Vector2(R * 1.32, R * 0.42)), shell)
		draw_rect(Rect2(cen + Vector2(-R * 0.66, R * 0.42), Vector2(R * 1.32, R * 0.08)), shell.darkened(0.25))
		# visor with reflection
		var visor := PackedVector2Array([cen + Vector2(-R * 0.58, -R * 0.06), cen + Vector2(R * 0.58, -R * 0.06), cen + Vector2(R * 0.5, R * 0.24), cen + Vector2(-R * 0.5, R * 0.24)])
		draw_colored_polygon(visor, Color(0.05, 0.06, 0.09))
		draw_line(cen + Vector2(-R * 0.44, R * 0.0), cen + Vector2(-R * 0.05, R * 0.0), Color(1, 1, 1, 0.35), maxf(1.0, R * 0.05))

	func _draw() -> void:
		var R := minf(size.x, size.y) * 0.5
		var cen := size * 0.5
		var uk = load("res://scripts/ui.gd")
		draw_circle(cen, R, Color(0.96, 0.36, 0.5) if selected else Color(0.9, 0.45, 0.15))
		draw_circle(cen, R - maxf(2.0, R * 0.06), Color(0.1, 0.11, 0.15))
		match style:
			1:
				_helmet(cen, R)
				for sx in [-0.22, 0.12]:
					draw_rect(Rect2(cen + Vector2(R * sx, -R * 0.6), Vector2(R * 0.1, R * 0.54)), c2)
			2:
				_helmet(cen, R)
				_star(cen + Vector2(0, -R * 0.32), R * 0.2, c2)
			3:
				_helmet(cen, R)
				var bolt := PackedVector2Array([cen + Vector2(-R * 0.1, -R * 0.62), cen + Vector2(R * 0.12, -R * 0.62), cen + Vector2(0.0, -R * 0.34),
					cen + Vector2(R * 0.16, -R * 0.34), cen + Vector2(-R * 0.14, R * 0.0), cen + Vector2(-R * 0.02, -R * 0.26), cen + Vector2(-R * 0.18, -R * 0.26)])
				draw_colored_polygon(bolt, c2)
			4:
				draw_circle(cen, R * 0.7, c1)
				draw_arc(cen, R * 0.7, 0, TAU, 48, c2, maxf(2.0, R * 0.1), true)
				draw_string(uk.font("head"), Vector2(0, cen.y + R * 0.36), str(num), HORIZONTAL_ALIGNMENT_CENTER, size.x, int(R * 0.95), c2)
			5:
				var sq := R * 0.24
				for gy in 4:
					for gx in 5:
						var col: Color = c1 if (gx + gy) % 2 == 0 else c2
						draw_rect(Rect2(cen + Vector2(-sq * 2.5 + gx * sq, -sq * 2.0 + gy * sq + sin(gx * 0.9) * sq * 0.25), Vector2(sq, sq)), col)
				draw_line(cen + Vector2(-sq * 2.6, -sq * 2.2), cen + Vector2(-sq * 2.6, R * 0.75), Color(0.85, 0.87, 0.9), maxf(2.0, R * 0.06))
			6:
				draw_arc(cen, R * 0.6, 0, TAU, 48, c1, maxf(3.0, R * 0.14), true)
				draw_rect(Rect2(cen + Vector2(-R * 0.6, -R * 0.06), Vector2(R * 1.2, R * 0.12)), c1)
				draw_rect(Rect2(cen + Vector2(-R * 0.06, 0), Vector2(R * 0.12, R * 0.6)), c1)
				draw_circle(cen, R * 0.16, c2)
				draw_rect(Rect2(cen + Vector2(-R * 0.08, -R * 0.66), Vector2(R * 0.16, R * 0.12)), c2)
			7:
				var cup := PackedVector2Array([cen + Vector2(-R * 0.42, -R * 0.5), cen + Vector2(R * 0.42, -R * 0.5), cen + Vector2(R * 0.3, -R * 0.05), cen + Vector2(0, R * 0.12), cen + Vector2(-R * 0.3, -R * 0.05)])
				draw_colored_polygon(cup, c1)
				draw_arc(cen + Vector2(-R * 0.42, -R * 0.3), R * 0.16, PI * 0.5, PI * 1.5, 16, c1, maxf(2.0, R * 0.06), true)
				draw_arc(cen + Vector2(R * 0.42, -R * 0.3), R * 0.16, -PI * 0.5, PI * 0.5, 16, c1, maxf(2.0, R * 0.06), true)
				draw_rect(Rect2(cen + Vector2(-R * 0.07, R * 0.1), Vector2(R * 0.14, R * 0.22)), c1)
				draw_rect(Rect2(cen + Vector2(-R * 0.32, R * 0.32), Vector2(R * 0.64, R * 0.14)), c2)
				_star(cen + Vector2(0, -R * 0.26), R * 0.14, c2)
			_:
				_helmet(cen, R)
				draw_rect(Rect2(cen + Vector2(-R * 0.1, -R * 0.62), Vector2(R * 0.2, R * 0.56)), c2)

	func _star(c: Vector2, r: float, col: Color) -> void:
		var pts := PackedVector2Array()
		for k in 10:
			var a := -PI / 2 + k * PI / 5.0
			var rr := r if k % 2 == 0 else r * 0.45
			pts.append(c + Vector2(cos(a), sin(a)) * rr)
		draw_colored_polygon(pts, col)


# country flag (three stripes)
class Flag extends Control:
	var cols: Array = []
	var vertical := false

	func setup(country: String, w: float = 54.0) -> Flag:
		var fl: Dictionary = load("res://scripts/ui.gd").FLAGS
		var d: Dictionary = fl.get(country, fl["DE"])
		cols = d["c"]
		vertical = d["v"]
		custom_minimum_size = Vector2(w, w * 0.62)
		size_flags_vertical = Control.SIZE_SHRINK_CENTER
		size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		queue_redraw()
		return self

	func _draw() -> void:
		var n := cols.size()
		for k in n:
			var c: Color = cols[k]
			if vertical:
				draw_rect(Rect2(size.x * k / n, 0, size.x / n + 0.5, size.y), c)
			else:
				draw_rect(Rect2(0, size.y * k / n, size.x, size.y / n + 0.5), c)


const FLAGS := {
	"DE": {"n": "Deutschland", "c": [Color(0.05, 0.05, 0.05), Color(0.85, 0.0, 0.0), Color(1.0, 0.8, 0.0)], "v": false},
	"AT": {"n": "Österreich", "c": [Color(0.8, 0.05, 0.15), Color.WHITE, Color(0.8, 0.05, 0.15)], "v": false},
	"CH": {"n": "Schweiz", "c": [Color(0.85, 0.05, 0.1), Color(0.85, 0.05, 0.1)], "v": false},
	"BE": {"n": "Belgien", "c": [Color(0.05, 0.05, 0.05), Color(1.0, 0.85, 0.1), Color(0.9, 0.12, 0.2)], "v": true},
	"NL": {"n": "Niederlande", "c": [Color(0.68, 0.11, 0.16), Color.WHITE, Color(0.13, 0.27, 0.55)], "v": false},
	"FR": {"n": "Frankreich", "c": [Color(0.0, 0.14, 0.58), Color.WHITE, Color(0.94, 0.16, 0.2)], "v": true},
	"IT": {"n": "Italien", "c": [Color(0.0, 0.57, 0.27), Color.WHITE, Color(0.81, 0.17, 0.22)], "v": true},
	"GB": {"n": "Großbritannien", "c": [Color(0.0, 0.14, 0.49), Color(0.81, 0.08, 0.17), Color(0.0, 0.14, 0.49)], "v": false},
	"PL": {"n": "Polen", "c": [Color.WHITE, Color(0.86, 0.08, 0.24)], "v": false},
	"ES": {"n": "Spanien", "c": [Color(0.67, 0.08, 0.11), Color(0.98, 0.75, 0.0), Color(0.67, 0.08, 0.11)], "v": false},
	"US": {"n": "USA", "c": [Color(0.7, 0.13, 0.2), Color.WHITE, Color(0.24, 0.23, 0.43)], "v": false},
	"PT": {"n": "Portugal", "c": [Color(0.0, 0.4, 0.0), Color(1.0, 0.0, 0.0)], "v": true},
}


# shader for the menu background: dark navy with a crimson glow on the right and a soft vignette
const BG_SHADER := """
shader_type canvas_item;
uniform float alpha = 0.9;
void fragment() {
	vec2 uv = UV;
	vec3 navy = vec3(0.03, 0.045, 0.085);
	vec3 crimson = vec3(0.5, 0.06, 0.15);
	float g = smoothstep(0.3, 1.05, uv.x * 0.9 + (1.0 - uv.y) * 0.25);
	vec3 c = mix(navy, crimson, g * 0.9);
	c = mix(c, vec3(0.06, 0.12, 0.28), smoothstep(0.55, 1.0, uv.y) * (1.0 - uv.x) * 0.6);
	float v = smoothstep(1.2, 0.4, length((uv - vec2(0.5, 0.45)) * vec2(1.0, 1.3)));
	c *= mix(0.65, 1.0, v);
	COLOR = vec4(c, alpha);
}
"""


# top bar: grey translucent band, crimson-pink wedge on the left, white diagonal stripes on the right
class TopBar extends Control:
	func _draw() -> void:
		var w := size.x
		draw_rect(Rect2(0, 0, w, 96), Color(0.3, 0.32, 0.36, 0.55))
		var wedge := PackedVector2Array([Vector2(0, 0), Vector2(640, 0), Vector2(380, 230), Vector2(0, 560)])
		var cols := PackedColorArray([Color(0.96, 0.36, 0.5, 0.95), Color(0.97, 0.45, 0.58, 0.85), Color(0.9, 0.12, 0.26, 0.0), Color(0.9, 0.11, 0.24, 0.0)])
		draw_polygon(wedge, cols)
		var band := PackedVector2Array([Vector2(0, 0), Vector2(520, 0), Vector2(430, 96), Vector2(0, 96)])
		draw_colored_polygon(band, Color(0.92, 0.16, 0.32, 0.92))
		draw_line(Vector2(0, 96), Vector2(w, 96), Color(1, 1, 1, 0.08), 1.0)

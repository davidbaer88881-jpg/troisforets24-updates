# Driver's cockpit for the player's car: dash, steering wheel with buttons, display (live SubViewport),
# gloves, slim pillars (no glass in the line of sight) and a working rear-view mirror.
extends Node3D

const Gfx = preload("res://scripts/gfx.gd")
const DashDisplay = preload("res://scripts/dash_display.gd")

var car
var vis
var game
var eye := Vector3.ZERO
var cam_anchor: Node3D
var wheel_pivot: Node3D
var leds: Array = []
var dash_vp: SubViewport
var mirror_vp: SubViewport
var wheel_vis := 0.0
var cabin_lights: Array = []
var mirror_cam: Camera3D
var head := Vector3.ZERO
var passenger := false          # camera on the passenger side (AI drives)
var look_yaw := 0.0
var look_pitch := 0.0
var shake_t := 0.0
var pass_through_model := false
var side_vps: Array = []      # [SubViewport, Camera3D, mirror position, side]   # the GT3 model brings its own dash, wheel and cage


func build(c, v, g) -> void:
	car = c
	vis = v
	game = g
	eye = vis.driver_eye()                   # the real seat of the model (or the procedural body's)
	vis.chassis.add_child(self)
	# daylight coming in through the windscreen and side windows (the roof shades the cabin otherwise)
	for lp in [[Vector3(0.35, 0.28, 0.0), 1.6, 1.0], [Vector3(-0.15, 0.32, -0.25), 1.2, 0.55], [Vector3(0.1, 0.0, 0.0), 1.0, 0.35]]:
		var ol := OmniLight3D.new()
		ol.position = eye + lp[0]
		ol.omni_range = lp[1]
		ol.light_energy = 0.0
		ol.light_specular = 0.15
		ol.shadow_enabled = false
		ol.light_color = Color(1.0, 0.98, 0.95)
		ol.set_meta("k", lp[2])
		add_child(ol)
		cabin_lights.append(ol)
	var carbon := Gfx.mat(Color(0.05, 0.055, 0.065), 0.45, 0.3)
	var alcantara := Gfx.mat(Color(0.08, 0.08, 0.09), 0.95)
	var metal := Gfx.mat(Color(0.5, 0.52, 0.55), 0.3, 0.9)
	var gt: bool = car.spec["key"] == "gt3"
	var model: bool = vis.glb_used and (vis.steer_node != null or vis.model == "bmw")    # real 3D cockpit from the model
	var ez: float = eye.z
	if gt and model:
		pass_through_model = true
	elif gt:
		_gt3_interior(carbon, alcantara, metal)
	else:
		# dashboard cowl and tub
		_box(Vector3(0.55, 0.1, 1.5), Vector3(eye.x + 0.8, eye.y - 0.24, ez * 0.5), carbon, Vector3(0, 0, 0.18))
		_box(Vector3(0.35, 0.3, 1.5), Vector3(eye.x + 1.0, eye.y - 0.42, ez * 0.5), carbon)
		for side in [-1.0, 1.0]:
			_box(Vector3(1.9, 0.38, 0.06), Vector3(eye.x + 0.2, eye.y - 0.42, ez + side * 0.5), alcantara)
			# slim A-pillar well outside the central view
			var a := Vector3(eye.x + 0.95, eye.y - 0.18, ez + side * 0.66)
			var b := Vector3(eye.x + 0.15, eye.y + 0.33, ez + side * 0.6)
			_beam(a, b, 0.04, carbon)
		_box(Vector3(0.06, 0.05, 1.2), Vector3(eye.x + 0.15, eye.y + 0.34, ez), carbon)
	# rear-view mirror with a live camera
	mirror_vp = SubViewport.new()
	mirror_vp.size = Vector2i(512, 128)
	mirror_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(mirror_vp)
	_cheap_vp(mirror_vp)
	mirror_cam = Camera3D.new()
	mirror_cam.fov = 26.0
	mirror_cam.far = 260.0
	mirror_cam.cull_mask = MIRROR_MASK
	mirror_vp.add_child(mirror_cam)
	var mm := StandardMaterial3D.new()
	mm.albedo_texture = mirror_vp.get_texture()
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mm.uv1_scale = Vector3(-1, 1, 1)
	mm.uv1_offset = Vector3(1, 0, 0)
	var mq := QuadMesh.new()
	mq.size = Vector2(0.34, 0.085)
	var mirror := MeshInstance3D.new()
	mirror.mesh = mq
	mirror.material_override = mm
	mirror.position = Vector3(eye.x + 0.5, eye.y + 0.07, 0.0) if gt else Vector3(eye.x + 0.62, eye.y + 0.2, ez)
	mirror.rotation = Vector3(0, -PI / 2, 0)
	add_child(mirror)
	_box(Vector3(0.02, 0.1, 0.36), mirror.position + Vector3(0.012, 0, 0), carbon)
	# steering wheel
	wheel_pivot = Node3D.new()
	wheel_pivot.position = Vector3(eye.x + 0.42, eye.y - 0.22, ez) if gt else Vector3(eye.x + 0.48, eye.y - 0.24, ez)
	wheel_pivot.rotation = Vector3(0, 0, 0.32)   # tilted towards the driver
	add_child(wheel_pivot)
	var wb := Node3D.new()
	wheel_pivot.add_child(wb)
	_box_on(wb, Vector3(0.03, 0.15, 0.28), Vector3.ZERO, carbon)
	for side in [-1.0, 1.0]:
		var grip := CapsuleMesh.new()
		grip.radius = 0.028
		grip.height = 0.2
		var gm := MeshInstance3D.new()
		gm.mesh = grip
		gm.material_override = alcantara
		gm.position = Vector3(-0.005, -0.01, side * 0.155)
		wb.add_child(gm)
		# gloves + forearms
		var glove := SphereMesh.new()
		glove.radius = 0.045
		glove.height = 0.09
		var gl := MeshInstance3D.new()
		gl.mesh = glove
		gl.material_override = Gfx.mat(Color(0.12, 0.12, 0.14), 0.8)
		gl.position = Vector3(-0.03, 0.0, side * 0.16)
		wb.add_child(gl)
		var arm := CapsuleMesh.new()
		arm.radius = 0.045
		arm.height = 0.42
		var am := MeshInstance3D.new()
		am.mesh = arm
		am.material_override = Gfx.mat(Color(0.1, 0.12, 0.2), 0.8)
		am.position = Vector3(-0.2, -0.08, side * 0.2)
		am.rotation = Vector3(side * 0.25, 0, 1.25)
		wb.add_child(am)
	# coloured rotary encoders / buttons like on a real LMP / GT3 wheel
	var cols := [Color(0.9, 0.85, 0.1), Color(0.1, 0.8, 0.3), Color(0.2, 0.5, 1.0), Color(1.0, 0.4, 0.1), Color(0.7, 0.2, 0.9), Color(0.9, 0.9, 0.9)]
	var labels := ["RADIO", "PIT", "TC", "ABS", "BB", "FLASH"]
	for k in 6:
		var side := -1.0 if k % 2 == 0 else 1.0
		var row := k / 2
		var cm := CylinderMesh.new()
		cm.top_radius = 0.011
		cm.bottom_radius = 0.013
		cm.height = 0.012
		var btn := MeshInstance3D.new()
		btn.mesh = cm
		btn.material_override = Gfx.emissive(cols[k], 0.6)
		btn.position = Vector3(-0.018, 0.045 - row * 0.042, side * 0.095)
		btn.rotation.z = PI / 2
		wb.add_child(btn)
		var lb := Label3D.new()
		lb.text = labels[k]
		lb.font_size = 24
		lb.pixel_size = 0.0006
		lb.position = btn.position + Vector3(-0.004, -0.018, 0)
		lb.rotation.y = -PI / 2
		lb.modulate = Color(0.9, 0.9, 0.9)
		wb.add_child(lb)
	# shift lights on the wheel top
	for k in 12:
		var lm := Gfx.emissive(Color(0.1, 1.0, 0.3) if k < 4 else (Color(1.0, 0.1, 0.1) if k < 8 else Color(0.3, 0.5, 1.0)), 0.0)
		_box_on(wb, Vector3(0.006, 0.008, 0.014), Vector3(-0.017, 0.068, -0.0935 + k * 0.017), lm)
		leds.append(lm)
	# display: on the wheel (Hypercar) or on the dash (GT3)
	dash_vp = SubViewport.new()
	dash_vp.size = Vector2i(512, 300)
	dash_vp.transparent_bg = false
	dash_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(dash_vp)
	var dd := DashDisplay.new()
	dd.game = game
	dd.size = Vector2(512, 300)
	dash_vp.add_child(dd)
	var dmat := StandardMaterial3D.new()
	dmat.albedo_texture = dash_vp.get_texture()
	dmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var dq := QuadMesh.new()
	var disp := MeshInstance3D.new()
	disp.mesh = dq
	disp.material_override = dmat
	if gt and pass_through_model and vis.steer_node != null:
		# live data on the model's own dash screen right behind the steering wheel (Mercedes model)
		dq.size = Vector2(0.125, 0.08)
		disp.position = Vector3(0.152, 0.77, -0.40)
		disp.rotation = Vector3(0, -PI / 2, 0)
		disp.rotate_object_local(Vector3.RIGHT, -0.12)
		add_child(disp)
		wheel_pivot.visible = false
	elif gt:
		dq.size = Vector2(0.3, 0.176)
		disp.position = Vector3(eye.x + 0.6, eye.y - 0.2, ez + 0.34)
		disp.rotation = Vector3(0, -PI / 2, 0)
		disp.rotate_object_local(Vector3.RIGHT, -0.35)
		add_child(disp)
		_box(Vector3(0.03, 0.21, 0.34), disp.position + Vector3(0.02, 0, 0), carbon)
	else:
		# Hypercar: large display on the wheel plus a dash repeater above it (readable while driving)
		dq.size = Vector2(0.15, 0.088)
		disp.position = Vector3(-0.0165, -0.005, 0)
		disp.rotation = Vector3(0, -PI / 2, 0)
		wb.add_child(disp)
		var rep := MeshInstance3D.new()
		var rq := QuadMesh.new()
		rq.size = Vector2(0.3, 0.176)
		rep.mesh = rq
		rep.material_override = dmat
		rep.position = Vector3(eye.x + 0.78, eye.y - 0.1, ez)
		rep.rotation = Vector3(0, -PI / 2, 0)
		rep.rotate_object_local(Vector3.RIGHT, -0.3)
		add_child(rep)
	cam_anchor = Node3D.new()
	add_child(cam_anchor)
	apply_seat()
	_side_mirrors()
	visible = false


# GT3 interior as seen from the seat: padded A-pillars and roof header framing a wide windscreen,
# a long flat dash, centre switch panel, door cards and a welded roll cage around the driver.
func _gt3_interior(carbon: Material, alcantara: Material, _metal: Material) -> void:
	var cage := Gfx.mat(Color(0.62, 0.63, 0.66), 0.35, 0.7)
	var liner := Gfx.mat(Color(0.05, 0.05, 0.055), 0.95)
	var ez: float = eye.z
	# dash: sloping top under the windscreen, vertical face towards the driver, binnacle over the display
	_box(Vector3(0.44, 0.05, 1.44), Vector3(0.32, 0.82, 0.0), liner, Vector3(0, 0, 0.12))
	_box(Vector3(0.06, 0.3, 1.44), Vector3(0.13, 0.66, 0.0), carbon)
	_box(Vector3(0.2, 0.05, 0.44), Vector3(0.22, 0.86, ez + 0.02), liner)
	# centre console with a lit switch panel
	_box(Vector3(0.32, 0.36, 0.26), Vector3(-0.12, 0.52, 0.02), carbon)
	var sw_cols := [Color(1.0, 0.25, 0.1), Color(0.2, 0.8, 0.3), Color(0.95, 0.85, 0.1), Color(0.3, 0.55, 1.0)]
	for r in 3:
		for c in 4:
			_box(Vector3(0.012, 0.022, 0.03), Vector3(-0.285, 0.6 - r * 0.06, -0.07 + c * 0.05), Gfx.emissive(sw_cols[(r + c) % 4], 0.8))
	# padded A-pillars, roof header and roof liner (the outside roof is not visible from inside)
	for side in [-1.0, 1.0]:
		_beam(Vector3(0.48, 0.86, side * 0.6), Vector3(0.03, 1.12, side * 0.68), 0.09, liner)
		_beam(Vector3(0.44, 0.86, side * 0.55), Vector3(0.0, 1.1, side * 0.62), 0.05, cage)
		# door card, window frame and roof-rail tube
		_box(Vector3(1.3, 0.34, 0.04), Vector3(-0.3, 0.64, side * 0.74), carbon)
		_box(Vector3(1.3, 0.03, 0.06), Vector3(-0.3, 0.83, side * 0.73), liner)
		_beam(Vector3(0.0, 1.13, side * 0.6), Vector3(-1.0, 1.16, side * 0.58), 0.05, cage)
		# main hoop behind the seat
		_beam(Vector3(-1.0, 0.45, side * 0.6), Vector3(-1.0, 1.16, side * 0.58), 0.05, cage)
	_box(Vector3(0.14, 0.07, 1.4), Vector3(0.02, 1.135, 0.0), liner)
	_beam(Vector3(-0.0, 1.11, -0.6), Vector3(-0.0, 1.11, 0.6), 0.05, cage)
	_beam(Vector3(-1.0, 1.16, -0.58), Vector3(-1.0, 1.16, 0.58), 0.05, cage)
	_box(Vector3(0.42, 0.03, 1.36), Vector3(-0.14, 1.16, 0.0), liner, Vector3(0, 0, -0.2))
	_box(Vector3(0.95, 0.03, 1.3), Vector3(-0.8, 1.205, 0.0), liner)
	# door bars (X) on the driver's side, seat wings around the helmet
	_beam(Vector3(0.25, 0.42, ez * 1.7), Vector3(-0.95, 0.9, ez * 1.6), 0.045, cage)
	_beam(Vector3(0.25, 0.9, ez * 1.7), Vector3(-0.95, 0.42, ez * 1.6), 0.045, cage)
	for side in [-1.0, 1.0]:
		_box(Vector3(0.3, 0.32, 0.06), Vector3(eye.x - 0.12, eye.y - 0.02, ez + side * 0.2), alcantara)
	# single windscreen wiper parked at the base of the screen
	_box(Vector3(0.02, 0.015, 0.95), Vector3(0.47, 0.875, -0.05), liner, Vector3(0, 0.18, 0))


# cylinder-like bar between two points (square tube is enough at cockpit distance)
# seat position (U/J height, K/N fore-aft), remembered in the settings
func apply_seat() -> void:
	var sh: float = game.settings.get("seat_h", 0.0)
	var sx: float = game.settings.get("seat_x", 0.0)
	cam_anchor.position = eye + Vector3(sx, 0.03 + sh, 0)
	if passenger:
		cam_anchor.position = Vector3(eye.x - 0.08, eye.y + 0.02, -eye.z)
	cam_anchor.rotation = Vector3(0, -PI / 2, 0)          # camera -Z looks along the car's +X
	cam_anchor.rotate_object_local(Vector3.RIGHT, -0.05)  # eyes slightly down to the road


# Rounded mirror glass showing the camera picture (mirrored), with a slight vignette like real glass.
const MIRROR_SHADER := """
shader_type spatial;
render_mode unshaded, cull_disabled;
uniform sampler2D img : source_color, filter_linear;
uniform float aspect = 1.8;
uniform float radius = 0.22;
void fragment() {
	vec2 uv = UV;
	vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
	vec2 h = vec2(aspect, 1.0) * 0.5 - vec2(radius);
	vec2 q = abs(p) - h;
	float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
	if (d > 0.0) { discard; }
	vec3 c = texture(img, vec2(1.0 - uv.x, uv.y)).rgb;
	float edge = smoothstep(-0.02, 0.0, d);
	ALBEDO = mix(c * 0.96, vec3(0.05), edge);
}
"""


func _side_mirrors() -> void:
	for side in [-1.0, 1.0]:
		var centre: Vector3
		var n: Vector3
		var size: Vector2
		if pass_through_model and vis.steer_node != null:
			# mirror glass of the GT3 model, measured from the mesh: fills the whole housing
			centre = Vector3(0.0145 + 0.0065 * 0.406, 0.9102, (0.9479 - 0.0065 * 0.914) * side)
			n = Vector3(-0.914, 0.0, -0.406 * side).normalized()
			size = Vector2(0.18, 0.1)
		elif car.spec["key"] == "gt3":
			centre = Vector3(0.27, 1.0, 1.0 * side)
			n = Vector3(-0.92, 0.0, -0.39 * side).normalized()
			size = Vector2(0.16, 0.095)
		else:
			centre = Vector3(0.87, 0.84, 0.62 * side)
			n = Vector3(-0.92, 0.0, -0.39 * side).normalized()
			size = Vector2(0.16, 0.09)
		var vp := SubViewport.new()
		vp.size = Vector2i(int(160.0 * size.x / size.y), 160)
		vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
		_cheap_vp(vp)
		add_child(vp)
		var cm := Camera3D.new()
		cm.fov = 24.0
		cm.far = 220.0
		cm.cull_mask = MIRROR_MASK
		vp.add_child(cm)
		var sh := Shader.new()
		sh.code = MIRROR_SHADER
		var mm := ShaderMaterial.new()
		mm.shader = sh
		mm.set_shader_parameter("img", vp.get_texture())
		mm.set_shader_parameter("aspect", size.x / size.y)
		var q := QuadMesh.new()
		q.size = size
		var mi := MeshInstance3D.new()
		mi.mesh = q
		mi.material_override = mm
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		# quad faces +Z: turn it to face the driver, 3 mm in front of the glass
		mi.basis = Basis.looking_at(-n, Vector3.UP)
		mi.position = centre + n * 0.003
		add_child(mi)
		side_vps.append([vp, cm, centre, side])


func _beam(a: Vector3, b: Vector3, thick: float, m: Material) -> MeshInstance3D:
	var mi := _box(Vector3(thick, thick, a.distance_to(b)), (a + b) * 0.5, m)
	var dir := (b - a).normalized()
	var up := Vector3.UP if absf(dir.y) < 0.95 else Vector3.RIGHT
	mi.basis = Basis.looking_at(dir, up)
	return mi


func _box(size: Vector3, pos: Vector3, m: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi


func _box_on(parent: Node3D, size: Vector3, pos: Vector3, m: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi


# Mirrors are extra renders of the whole scene, so they are kept cheap: small, no grass/crowd/trees
# (render layer 2), no SSAO/GI/volumetrics, and only ONE mirror is redrawn per frame (round robin).
const MIRROR_MASK := 1
var active := false
var mirror_k := 0
var mirror_env: Environment
var env_t := 0.0


func _cheap_vp(vp: SubViewport) -> void:
	vp.msaa_3d = Viewport.MSAA_DISABLED
	vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
	vp.use_taa = false
	vp.positional_shadow_atlas_size = 0
	vp.mesh_lod_threshold = 6.0
	vp.use_debanding = false


func _mirror_vps() -> Array:
	var out: Array = [mirror_vp]
	for sv in side_vps:
		out.append(sv[0])
	return out


func set_active(on: bool) -> void:
	if on == active:
		return
	active = on
	visible = on
	dash_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS if on else SubViewport.UPDATE_DISABLED
	for o in _mirror_vps():
		var vp: SubViewport = o
		vp.render_target_update_mode = SubViewport.UPDATE_ONCE if on else SubViewport.UPDATE_DISABLED
	if on:
		_refresh_mirror_env()


# copy of the world environment without the expensive screen-space effects
func _refresh_mirror_env() -> void:
	var src: Environment = game.env
	if src == null:
		return
	mirror_env = src.duplicate()
	mirror_env.ssao_enabled = false
	mirror_env.ssil_enabled = false
	mirror_env.sdfgi_enabled = false
	mirror_env.ssr_enabled = false
	mirror_env.volumetric_fog_enabled = false
	mirror_env.glow_enabled = false
	mirror_cam.environment = mirror_env
	for sv in side_vps:
		var cm: Camera3D = sv[1]
		cm.environment = mirror_env


func update(dt: float, cam: Camera3D) -> void:
	# steering wheel turns with ~12:1 ratio
	var wb: Node3D = wheel_pivot.get_child(0)
	# smoothed: the wheel follows the steering, not every little force-feedback twitch
	var wheel_target: float = (car.steer * car.spec["steerMax"] + car.steer_pull() * 0.35) * 12.0
	wheel_vis += (wheel_target - wheel_vis) * minf(1.0, dt * 16.0)
	var wheel_angle: float = wheel_vis
	wb.rotation.x = wheel_angle
	# cabin light follows the daylight outside (sun height, clouds)
	var day: float = clampf(float(game.sun.light_energy) / 1.7, 0.0, 1.0) if game.sun.visible else 0.0
	for l in cabin_lights:
		var ol: OmniLight3D = l
		ol.light_energy = (0.08 + 1.1 * day) * float(ol.get_meta("k"))
	if pass_through_model:
		vis.steer_model(wheel_angle)
	var frac: float = clampf((car.rpm / car.spec["rpmMax"] - 0.72) / 0.24, 0.0, 1.0)
	var lit := int(frac * 12.0)
	var flash := frac >= 0.98 and int(Time.get_ticks_msec() / 70) % 2 == 0
	for k in leds.size():
		var lm: StandardMaterial3D = leds[k]
		lm.emission_energy_multiplier = (4.0 if k < lit else 0.0) if not flash else 6.0
	# head: g-forces lean the head, bumps and kerbs shake it
	var target := Vector3(-car.ay * 0.005, -absf(car.road_now) * 0.6 - car.heave * 0.5, car.ax * 0.004)
	head = head.lerp(target, minf(1.0, dt * 6.0))
	# vibration: road texture grows with speed, engine buzz, kerb hits, high-speed aero buffeting
	shake_t += dt
	var spd: float = absf(car.u)
	# frequencies stay well below the frame rate (high ones alias into random judder at 60 fps)
	var road_amp := 0.00015 + spd * 0.000012 + absf(car.road_now) * 0.03
	if car.surface == "grass" or car.surface == "gravel":
		road_amp += 0.0025
	var eng_amp: float = 0.00008 * (1.0 + float(car.throttle))
	var vib := Vector3(
		sin(shake_t * 9.0 + 0.7) * road_amp * 0.3,
		sin(shake_t * 13.0) * road_amp + sin(shake_t * 21.0 + 1.9) * road_amp * 0.4 + sin(shake_t * 17.0) * eng_amp,
		sin(shake_t * 11.0 + 2.6) * road_amp * 0.4)
	var ang: float = road_amp * 0.9
	var rot_shake := Basis(Vector3.FORWARD, sin(shake_t * 7.0 + 0.3) * ang) * Basis(Vector3.RIGHT, sin(shake_t * 10.0 + 1.1) * ang * 0.6)
	var xf: Transform3D = cam_anchor.global_transform.translated_local(head + vib)
	xf.basis = xf.basis * rot_shake
	if passenger or absf(look_yaw) > 0.001:
		xf.basis = xf.basis * Basis(Vector3.UP, look_yaw) * Basis(Vector3.RIGHT, look_pitch)
	cam.global_transform = xf
	# one mirror per frame (low quality: every second frame)
	var vps := _mirror_vps()
	var q: String = game.settings.get("quality", "high")
	if q != "low" or Engine.get_process_frames() % 2 == 0:
		mirror_k = (mirror_k + 1) % vps.size()
		var mv: SubViewport = vps[mirror_k]
		mv.render_target_update_mode = SubViewport.UPDATE_ONCE
	env_t += dt
	if env_t > 4.0:
		env_t = 0.0
		_refresh_mirror_env()
	mirror_cam.global_transform = Transform3D(cam_anchor.global_basis * Basis(Vector3.UP, PI), cam_anchor.global_position + cam_anchor.global_basis.y * 0.25)
	# door mirrors: cameras at the mirror housings looking back and slightly outwards
	var cb: Basis = vis.chassis.global_basis
	for sv in side_vps:
		var cm: Camera3D = sv[1]
		var mp: Vector3 = sv[2]
		var sd: float = sv[3]
		# a real mirror shows what is behind and a little outside the car
		cm.global_transform = Transform3D(cb * Basis(Vector3.UP, PI / 2 + sd * 0.12) * Basis(Vector3.RIGHT, -0.03), vis.chassis.to_global(mp + Vector3(-0.05, 0.0, sd * 0.06)))

# Online multiplayer.
#  - "code" (recommended): the host gets a fresh 5-letter code, friends type it in. The code is found through
#    a server channel (relay.gd). Like Gleisfieber, the game then connects the players DIRECTLY (ENet/UDP,
#    the host opens its router port by UPnP; same WLAN or Tailscale works anyway). Only if no direct
#    connection comes about does a player stay on the server channel - so nobody is left out.
#  - "ip": direct connection over ENet (UDP) in the same WLAN / Tailscale.
# Every computer simulates its own car and sends its state several times a second; the host also simulates
# the AI cars. Cars from other computers are drawn with dead reckoning + smooth correction.
extends Node

signal lobby_changed

const PORT := 24724
const MAX_PEERS := 16
const Profile = preload("res://scripts/profile.gd")
const Updater = preload("res://scripts/updater.gd")
const Relay = preload("res://scripts/relay.gd")
const STRIDE := 40               # bytes per car state (see _pack)
const TIMEOUT := 9.0          # seconds without a message: player gone
# race settings the host chooses in the lobby (same as for a normal race)
const CFG_KEYS := ["track", "duration", "start_hour", "time_scale", "weather", "wear", "damage", "ai_diff",
	"quali_limits", "rules", "n_gt3", "n_hy", "max_humans", "ai_on"]

var game
var mode := ""                 # "", "code", "ip"
var peer: ENetMultiplayerPeer
var relay: Node
var code := ""
var id := 0
var players := {}              # peer id -> {name, team, number, cls, c1, c2, c3, ver, ready}
var lobby_cfg := {}            # host's race settings (sent to everybody)
var online := false
var status := ""
var ready_peers := {}
var send_acc := 0.0
var corr := {}                     # car index -> Vector3 position error still to blend in
var corr_psi := {}                 # car index -> heading error still to blend in
var last_seen := {}            # relay: peer id -> seconds since the last message
var _ping_t := 0.0
var _wait_t := 0.0            # client: time waiting for the host to answer
var ext_ip := ""
var upnp_state := ""
var _upnp: UPNP
var _upnp_thread: Thread
# direct connections in a code lobby
var direct := false              # player: connected to the host over ENet (not the server channel)
var direct_port := 0             # host: the UDP port of the ENet server
var enet_pid := {}               # host: ENet peer id -> player id
var pid_enet := {}               # host: player id -> ENet peer id
var _try_addrs: Array = []       # player: addresses still to try for the direct connection
var _try_t := 0.0
var _tried := false
var _direct_info := {}
var _fwd_t := {}


func _ready() -> void:
	multiplayer.peer_connected.connect(func(_p): pass)
	multiplayer.peer_disconnected.connect(_on_enet_gone)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)
	relay = Relay.new()
	relay.name = "Relay"
	add_child(relay)
	relay.opened.connect(_relay_opened)
	relay.failed.connect(_relay_failed)
	relay.message.connect(_from_relay)
	relay.on_trace = _tr


func my_id() -> int:
	return id if online else 1


func is_host() -> bool:
	return online and id == 1


func status_text() -> String:
	return status


func _me() -> Dictionary:
	var p: Dictionary = Profile.current
	var s: Dictionary = game.settings
	var liv: Array = game.menu.LIVERIES[int(s["livery"]) % game.menu.LIVERIES.size()]
	var rd: bool = players.get(id, {}).get("ready", false) if online else false
	return {"name": String(p.get("name", "Fahrer")), "team": String(p.get("team", "Team")), "number": int(p.get("number", 24)),
		"cls": String(s["cls"]), "c1": _col(p.get("c1", liv[1])).to_html(), "c2": _col(p.get("c2", liv[2])).to_html(), "c3": Color(liv[3]).to_html(),
		"ver": Updater.installed_number(), "pid": id, "ready": rd or id == 1, "spec": bool(game.menu.spectate), "model": String(s.get("gt3_model", "amg"))}


static func _col(v) -> Color:
	if v is Color:
		return v
	if v is String and Color.html_is_valid(v):
		return Color.html(v)
	return Color.WHITE


func host_cfg_from_settings() -> void:
	for k in CFG_KEYS:
		lobby_cfg[k] = game.settings.get(k)


# ---------------------------------------------------------------- send / receive (both modes)
func _send(ev: String, data, to: int = 0) -> void:
	if mode == "code":
		if is_host():
			# players connected directly get it over ENet, the others through the server channel
			if to == 0:
				relay.send(ev, data, 0)
				for e in pid_enet.values():
					_rpc(int(e), ev, data, false)
			elif pid_enet.has(to):
				_rpc(int(pid_enet[to]), ev, data, false)
			else:
				relay.send(ev, data, to)
		elif direct:
			_rpc(1, ev, data, false)              # everything goes to the host, he passes it on
		else:
			relay.send(ev, data, to)
	elif mode == "ip" and peer != null:
		if to == 0:
			_m.rpc(ev, data)
		else:
			_m.rpc_id(to, ev, data)


func _send_fast(ev: String, data) -> void:
	if mode == "code":
		if is_host():
			if _relay_needed():
				relay.send(ev, data, 0)
			for e in pid_enet.values():
				_rpc(int(e), ev, data, true)
		elif direct:
			_rpc(1, ev, data, true)
		else:
			relay.send(ev, data, 0)
	elif mode == "ip" and peer != null:
		_mu.rpc(ev, data)


func _rpc(to: int, ev: String, data, fast: bool) -> void:
	if peer == null or multiplayer.multiplayer_peer == null:
		return
	if multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	if fast:
		_mu.rpc_id(to, ev, data)
	else:
		_m.rpc_id(to, ev, data)


@rpc("any_peer", "reliable")
func _m(ev: String, data) -> void:
	_from_enet(multiplayer.get_remote_sender_id(), ev, data)


@rpc("any_peer", "unreliable_ordered")
func _mu(ev: String, data) -> void:
	_from_enet(multiplayer.get_remote_sender_id(), ev, data)


# a message over ENet: in a code lobby the host knows the players by their lobby id, not the ENet id
func _from_enet(sender: int, ev: String, data) -> void:
	if mode != "code":
		_on_msg(sender, ev, data)
		return
	if not is_host():
		if sender == 1:
			_on_msg(1, ev, data)
		return
	if ev == "hello" and data is Dictionary and data.has("pid"):
		var pid := int(data["pid"])
		if pid > 1:
			enet_pid[sender] = pid
			pid_enet[pid] = sender
			_tr("Spieler %d direkt verbunden" % pid)
	if not enet_pid.has(sender):
		return
	var from: int = enet_pid[sender]
	# pass the player's car states on to everybody else (direct players and the server channel)
	if ev == "st":
		# to the server channel only as often as its message limit allows
		var now := Time.get_ticks_msec()
		if _relay_needed() and now - int(_fwd_t.get(from, 0)) > int(1000.0 / _relay_hz()):
			_fwd_t[from] = now
			relay.send(ev, Marshalls.raw_to_base64(data) if data is PackedByteArray else data, 0)
		for e in pid_enet.values():
			if int(e) != sender:
				_rpc(int(e), ev, data, true)
	_on_msg(from, ev, data)


func _tr(m: String) -> void:
	if game != null and game.crash_guard != null:
		game.crash_guard.trace("NET " + m)


func _from_relay(from: int, ev: String, data) -> void:
	if direct:
		return                                  # this player talks to the host directly now
	if is_host() and ev == "st" and not pid_enet.is_empty():
		for e in pid_enet.values():
			_rpc(int(e), ev, _unpack_buf(data), true)
	_on_msg(from, ev, data)


func _on_msg(from: int, ev: String, data) -> void:
	last_seen[from] = 0.0
	if ev != "st" and ev != "ping":
		_tr("<- %s von %d" % [ev, from])
	match ev:
		"hello":          # a player (re)announces himself; the host answers with the lobby
			if is_host() and data is Dictionary:
				_register(from, data)
		"lobby":          # host -> all: players + race settings
			if not is_host() and from == 1 and data is Dictionary and data.get("players") is Dictionary and data.get("cfg") is Dictionary:
				var pl: Dictionary = {}
				for k in data["players"].keys():
					pl[int(k)] = data["players"][k]
				players = _ints(pl)
				lobby_cfg = _ints(data["cfg"])
				if mode == "code" and not direct and not _tried and data.get("direct") is Dictionary:
					_start_direct(data["direct"])
				if not players.has(id) and mode == "code":
					status = "Verbinde …"
				else:
					status = "In der Lobby%s. Der Host stellt das Rennen ein und startet es." % (" (direkt verbunden)" if direct else "")
				lobby_changed.emit()
		"rejected":
			if data is Dictionary and int(data.get("to", id)) == id:
				status = String(data["why"])
				lobby_changed.emit()
				leave_keep_status()
		"bye":
			_peer_gone(from)
		"begin":
			# (the host repeats it for anybody who has not loaded yet: start only once)
			if from == 1 and not is_host() and (game == null or not game.is_online()) and data is Dictionary:
				_begin_race(_ints(data))
		"ready":
			if is_host():
				ready_peers[from] = true
		"go":
			if from == 1 and game != null and game.is_online() and game.state == "grid":
				game.lights_out_at = game.lights_t
				_go_seen = true
		"st":
			_states(_unpack_buf(data))
		"ping":
			pass


func _unpack_buf(data) -> PackedByteArray:
	if data is PackedByteArray:
		return data
	if data is String:
		return Marshalls.base64_to_raw(data)
	return PackedByteArray()


# ---------------------------------------------------------------- lobby: code (server)
func host_code() -> String:
	_tr("Lobby erstellen")
	leave()
	mode = "code"
	id = 1
	code = Relay.new_code()
	online = true
	players = {1: {}}
	players[1] = _me()
	host_cfg_from_settings()
	status = "Verbinde mit dem Server …"
	relay.open(code, id)
	_start_direct_server()
	lobby_changed.emit()
	return status


# ---------------------------------------------------------------- direct connections (code lobby)
# The host also runs an ENet server and opens the port in the router (UPnP), like Gleisfieber.
func _start_direct_server() -> void:
	peer = ENetMultiplayerPeer.new()
	direct_port = 0
	for p in range(PORT, PORT + 6):
		if peer.create_server(p, MAX_PEERS) == OK:
			direct_port = p
			break
	if direct_port == 0:
		peer = null
		_tr("Direkt-Server konnte nicht starten - nur über Server")
		return
	multiplayer.multiplayer_peer = peer
	_tr("Direkt-Server auf UDP %d" % direct_port)
	_open_router_port()


# where the host can be reached: home network / Tailscale addresses and the internet address (UPnP)
func _host_addresses() -> Array:
	var out: Array = []
	for a in IP.get_local_addresses():
		var s: String = a
		if not s.contains(".") or s.begins_with("127.") or s.begins_with("169.254"):
			continue
		var second := int(s.get_slice(".", 1))
		if s.begins_with("192.168.") or s.begins_with("10.") or (s.begins_with("172.") and second >= 16 and second <= 31) \
				or (s.begins_with("100.") and second >= 64 and second <= 127):
			out.append(s)
	if ext_ip != "" and ext_ip.contains("."):
		out.append(ext_ip)
	return out


# player: try the host's addresses one after the other (same home network first, then the internet
# address); the server channel keeps working meanwhile
func _start_direct(info: Dictionary) -> void:
	_tried = true
	_direct_info = info
	var mine: Array = []
	for a in IP.get_local_addresses():
		if String(a).contains("."):
			mine.append(String(a).get_slice(".", 0) + "." + String(a).get_slice(".", 1) + "." + String(a).get_slice(".", 2) + ".")
	var near: Array = []
	var far: Array = []
	for a in info.get("ips", []):
		var s := String(a)
		var same := false
		for pre in mine:
			if s.begins_with(pre):
				same = true
		if same or s.begins_with("100."):
			near.append(s)
		else:
			far.append(s)
	_try_addrs = near + far
	if OS.get_environment("TF24_TEST_LOCAL") != "":
		_try_addrs.push_front("127.0.0.1")     # automated tests: all games on one machine
	if _try_addrs.is_empty():
		_tr("Host hat keine erreichbare Adresse gemeldet - weiter über den Server")
		return
	_tr("Versuche Direktverbindung: %s" % str(_try_addrs))
	_try_next()


func _try_next() -> void:
	if peer != null:
		peer.close()
		peer = null
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	if direct or _try_addrs.is_empty() or not online or mode != "code":
		_try_t = 0.0
		if not direct and online:
			_tr("Keine Direktverbindung - weiter über den Server")
		return
	var addr: String = _try_addrs.pop_front()
	peer = ENetMultiplayerPeer.new()
	if peer.create_client(addr, int(_direct_info.get("port", PORT))) != OK:
		peer = null
		_try_t = 0.01
		return
	multiplayer.multiplayer_peer = peer
	_try_t = 3.0


func _direct_up() -> void:
	direct = true
	_try_t = 0.0
	_try_addrs = []
	_tr("Direkt mit dem Host verbunden")
	var me := _me()
	me["pid"] = id
	_rpc(1, "hello", me, false)
	# from now on everything runs over the direct line; the server channel is left
	relay.close()
	for k in last_seen.keys():
		last_seen[k] = 0.0
	status = "In der Lobby (direkt verbunden). Der Host stellt das Rennen ein und startet es."
	lobby_changed.emit()


# player: the direct line broke - carry on through the server channel (same lobby, same race)
func _direct_lost() -> void:
	direct = false
	if peer != null:
		peer.close()
	peer = null
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	_tr("Direktverbindung weg - weiter über den Server")
	if online and code != "":
		_reconnecting = true
		relay.open(code, id)


func _on_enet_gone(enet: int) -> void:
	if mode != "code":
		_peer_gone(enet)
		return
	if is_host() and enet_pid.has(enet):
		var pid: int = enet_pid[enet]
		enet_pid.erase(enet)
		pid_enet.erase(pid)
		_tr("Direktverbindung zu Spieler %d weg (er kann über den Server weitermachen)" % pid)


# players that are only reachable through the server channel (the host sends there only if needed)
func _relay_needed() -> bool:
	for k in players.keys():
		if int(k) != 1 and not pid_enet.has(int(k)):
			return true
	return false


func join_code(c: String) -> String:
	_tr("Beitreten mit Code " + c.strip_edges())
	leave()
	c = Relay.clean_code(c)
	if c.length() != 5:
		status = "Der Code hat 5 Zeichen (Buchstaben und Zahlen)."
		lobby_changed.emit()
		return status
	mode = "code"
	code = c
	id = 2 + randi() % 1000000000
	online = true
	status = "Verbinde mit Lobby %s …" % code
	relay.open(code, id)
	lobby_changed.emit()
	return status


func _relay_opened() -> void:
	_tr("Server verbunden (Host=%s)" % is_host())
	_reconnects = 0
	if _reconnecting:
		# back in the channel after a short drop: carry on where we were (lobby or race)
		_reconnecting = false
		for k in last_seen.keys():
			last_seen[k] = 0.0
		status = "Wieder verbunden."
		if game != null and game.is_online():
			game.show_msg("Wieder verbunden", 2.0, Color(0.3, 1.0, 0.4))
			_send("ping", 0)
		elif is_host():
			_broadcast_lobby()
		else:
			_send("hello", _me())
		lobby_changed.emit()
		return
	last_seen = {}
	if is_host():
		status = "Lobby offen! Gib deinen Freunden den Code: %s" % code
		_broadcast_lobby()
	else:
		status = "Suche Lobby %s …" % code
		_send("hello", _me())
		_ping_t = 2.0
		_wait_t = 0.0
	lobby_changed.emit()


# A dropped connection to the server (WLAN hiccup, server busy) is not the end: up to 6 tries to get
# back into the same lobby / race; only then the online session ends.
var _reconnects := 0
var _reconnecting := false
var _reconnect_t := -1.0


func _relay_failed(reason: String) -> void:
	_tr("Server-Fehler: " + reason)
	if online and mode == "code" and code != "" and _reconnects < 6:
		_reconnects += 1
		_reconnecting = true
		_reconnect_t = 1.0 + _reconnects * 1.5
		status = "Verbindung kurz weg – verbinde neu (%d/6) …" % _reconnects
		if game != null and game.is_online():
			game.show_msg(status, 2.0, Color(1.0, 0.7, 0.2))
		lobby_changed.emit()
		return
	_reconnecting = false
	status = reason
	var was := online
	leave_keep_status()
	if was and game != null and game.is_online():
		game.show_msg("Verbindung verloren: " + reason, 4.0, Color(1.0, 0.3, 0.25))


# ---------------------------------------------------------------- lobby: IP (ENet, same WLAN / Tailscale)
func host() -> String:
	leave()
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PEERS)
	if err != OK:
		status = "Lobby konnte nicht gestartet werden (Port %d belegt? Fehler %d)." % [PORT, err]
		return status
	multiplayer.multiplayer_peer = peer
	mode = "ip"
	id = 1
	online = true
	players = {1: _me()}
	host_cfg_from_settings()
	status = "Lobby läuft. Freunde im gleichen WLAN verbinden sich mit deiner IP-Adresse."
	lobby_changed.emit()
	_open_router_port()
	return status


func join(ip: String) -> String:
	leave()
	ip = ip.strip_edges().get_slice(" ", 0)
	if ip == "":
		status = "Bitte die IP-Adresse des Hosts eingeben."
		return status
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK:
		status = "Verbindung fehlgeschlagen (Fehler %d)." % err
		return status
	multiplayer.multiplayer_peer = peer
	mode = "ip"
	online = true
	status = "Verbinde mit %s …" % ip
	return status


func _on_connected() -> void:
	if mode == "code":
		if not direct:
			_direct_up()
		return
	id = multiplayer.get_unique_id()
	status = "Verbunden! Warte auf den Start durch den Host."
	_send("hello", _me(), 1)
	lobby_changed.emit()


func _on_failed() -> void:
	if mode == "code":
		if not direct:
			_try_t = 0.01                       # next address
		return
	status = "Host nicht erreichbar. Tipp: Mit Lobby-Code verbinden – das klappt überall."
	leave_keep_status()


func _on_server_gone() -> void:
	if mode == "code":
		if direct:
			_direct_lost()
		return
	status = "Der Host hat die Lobby geschlossen."
	leave_keep_status()
	if game != null and game.is_online():
		game.show_msg("Verbindung zum Host verloren", 4.0, Color(1.0, 0.3, 0.25))


func _open_router_port() -> void:
	if upnp_state == "busy":
		return
	upnp_state = "busy"
	ext_ip = ""
	_upnp_thread = Thread.new()
	_upnp_thread.start(_upnp_work)


func _upnp_work() -> void:
	var u := UPNP.new()
	var ok := false
	var ip := ""
	if u.discover(2500, 2, "InternetGatewayDevice") == UPNP.UPNP_RESULT_SUCCESS and u.get_gateway() != null and u.get_gateway().is_valid_gateway():
		var pt: int = direct_port if direct_port > 0 else PORT
		ok = u.add_port_mapping(pt, pt, "Trois Forets 24", "UDP", 0) == UPNP.UPNP_RESULT_SUCCESS
		ip = u.query_external_address()
	call_deferred("_upnp_done", u, ok, ip)


func _upnp_done(u: UPNP, ok: bool, ip: String) -> void:
	if _upnp_thread != null:
		_upnp_thread.wait_to_finish()
		_upnp_thread = null
	_upnp = u if ok else null
	ext_ip = ip if ok else ""
	upnp_state = "ok" if ok else "fail"
	_tr("Router-Freigabe (UPnP): %s %s" % [upnp_state, ext_ip])
	if is_host() and online:
		_broadcast_lobby()                 # tell the players the internet address
	lobby_changed.emit()


# ---------------------------------------------------------------- lobby (both modes)
func leave() -> void:
	if online:
		_tr("Lobby verlassen")
	status = ""
	leave_keep_status()


func leave_keep_status() -> void:
	_reconnects = 0
	_reconnecting = false
	_reconnect_t = -1.0
	if mode == "code" and relay != null:
		if relay.is_open():
			relay.send("bye", {})
		relay.close()
	if mode == "code":
		if direct:
			_rpc(1, "bye", {}, false)
		elif is_host():
			for e in pid_enet.values():
				_rpc(int(e), "bye", {}, false)
	if _upnp != null:
		# removing the router port can take a moment: not on the main thread
		var u := _upnp
		var pt: int = direct_port if direct_port > 0 else PORT
		WorkerThreadPool.add_task(func(): u.delete_port_mapping(pt, "UDP"))
		_upnp = null
		upnp_state = ""
	if peer != null:
		peer.close()
	direct = false
	direct_port = 0
	enet_pid = {}
	pid_enet = {}
	_try_addrs = []
	_try_t = 0.0
	_tried = false
	_direct_info = {}
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	peer = null
	mode = ""
	online = false
	players = {}
	ready_peers = {}
	corr = {}
	corr_psi = {}
	last_seen = {}
	code = ""
	lobby_changed.emit()


func _register(from: int, info: Dictionary) -> void:
	var mine := Updater.installed_number()
	if int(info.get("ver", 0)) != mine:
		_send("rejected", {"to": from, "why": "Andere Spielversion: Host hat Version %d, du hast %d. Im Hauptmenü auf UPDATE drücken, dann neu verbinden." % [mine, int(info.get("ver", 0))]}, from)
		return
	if game != null and game.is_online():
		_send("rejected", {"to": from, "why": "Das Rennen läuft schon – warte bis zur nächsten Lobby."}, from)
		return
	var cap := int(lobby_cfg.get("max_humans", MAX_PEERS))
	if not players.has(from) and players.size() >= cap:
		_send("rejected", {"to": from, "why": "Die Lobby ist voll (%d Fahrer)." % cap}, from)
		return
	players[from] = info
	_broadcast_lobby()


func _broadcast_lobby() -> void:
	if not is_host():
		return
	players[1] = _me()
	var ps := {}
	for k in players.keys():
		ps[str(k)] = players[k]
	var msg := {"players": ps, "cfg": lobby_cfg}
	if mode == "code" and direct_port > 0:
		msg["direct"] = {"port": direct_port, "ips": _host_addresses()}
	_send("lobby", msg)
	lobby_changed.emit()


# my class / ready flag changed in the lobby
func update_me() -> void:
	if not online:
		return
	if is_host():
		_broadcast_lobby()
	else:
		players[id] = _me()
		_send("hello", players[id], 1)
		lobby_changed.emit()


func set_ready(r: bool) -> void:
	if not online:
		return
	var me := _me()
	me["ready"] = r
	players[id] = me
	if is_host():
		_broadcast_lobby()
	else:
		_send("hello", me, 1)
		lobby_changed.emit()


func set_cfg(k: String, v) -> void:
	if not is_host():
		return
	lobby_cfg[k] = v
	game.settings[k] = v
	_broadcast_lobby()


func everyone_ready() -> bool:
	for k in players.keys():
		if int(k) != 1 and not bool(players[k].get("ready", false)):
			return false
	return players.size() >= 1


func _peer_gone(pid: int) -> void:
	if pid == 1 and not is_host() and online:
		status = "Der Host hat die Lobby geschlossen."
		leave_keep_status()
		if game != null and game.is_online():
			game.show_msg("Verbindung zum Host verloren", 4.0, Color(1.0, 0.3, 0.25))
		return
	if not players.has(pid):
		return
	players.erase(pid)
	ready_peers.erase(pid)
	last_seen.erase(pid)
	if is_host():
		_broadcast_lobby()
	if game != null and game.is_online():
		for c in game.cars:
			if c.has_meta("peer") and int(c.get_meta("peer")) == pid:
				c.retired = true
				c.u = 0.0
	lobby_changed.emit()


func _process(dt: float) -> void:
	if _reconnect_t >= 0.0:
		_reconnect_t -= dt
		if _reconnect_t < 0.0 and online and mode == "code":
			relay.open(code, id)
	if _try_t > 0.0:
		_try_t -= dt
		if _try_t <= 0.0 and not direct:
			_try_next()
	if mode != "code" or not (relay.is_open() or direct):
		return
	# keep-alive and timeouts (the server channel has no "disconnected" event)
	_ping_t -= dt
	if _ping_t <= 0.0:
		_ping_t = 2.0
		if is_host():
			if game == null or not game.is_online():
				_broadcast_lobby()
			else:
				_send("ping", 0)
				_host_start_care()
		else:
			if players.has(id) or (game != null and game.is_online()):
				_send("ping", 0)
				# a lost "ready" would keep everybody waiting on the grid: repeat it until the start
				if game != null and game.is_online() and game.state == "grid" and not _go_seen:
					_send("ready", 0, 1)
			else:
				_send("hello", _me())       # still waiting for the host's answer
	var gone: Array = []
	for k in last_seen.keys():
		last_seen[k] += dt
		if last_seen[k] > TIMEOUT:
			gone.append(k)
	for k in gone:
		# (a player leaving can end the session: last_seen is then emptied - never index into it here)
		last_seen.erase(k)
		_peer_gone(int(k))
		if not online:
			return
	if not is_host() and not players.has(id):
		_wait_t += dt
		if _wait_t > 10.0:
			status = "Keine Lobby mit dem Code %s gefunden. Code richtig? Ist die Lobby des Hosts offen?" % code
			leave_keep_status()


# ---------------------------------------------------------------- race start
func start_online_race() -> void:
	if not is_host():
		return
	_tr("Host startet das Rennen, %d Spieler" % players.size())
	players[1] = _me()
	for k in lobby_cfg.keys():
		game.settings[k] = lobby_cfg[k]
	var s: Dictionary = game.settings
	var grid: Array = []
	# humans first (in join order), then AI cars of the chosen classes
	var ids: Array = players.keys()
	ids.sort()
	var watchers: Array = []
	for pid in ids:
		var pl: Dictionary = players[pid]
		var e := {"cls": pl["cls"], "model": String(pl.get("model", "amg")), "team": [pl["team"], pl["c1"], pl["c2"], pl.get("c3", "ffffff"), int(pl["number"])], "peer": int(pid), "driver": pl["name"],
			"spec": bool(pl.get("spec", false))}
		if e["spec"]:
			watchers.append(e)          # spectators: a parked car at the end of the list, never on the grid
		else:
			grid.append(e)
	var ai_on: bool = s.get("ai_on", true) != false
	for k in (int(s.get("n_hy", 0)) if ai_on else 0):
		var t: Array = game._team("hyper", k)
		grid.append({"cls": "hyper", "team": [t[0], Color(t[1]).to_html(), Color(t[2]).to_html(), Color(t[3]).to_html(), t[4]], "peer": 0})
	for k in (int(s.get("n_gt3", 0)) if ai_on else 0):
		var t: Array = game._team("gt3", k)
		grid.append({"cls": "gt3", "model": game.ai_model(k), "team": [t[0], Color(t[1]).to_html(), Color(t[2]).to_html(), Color(t[3]).to_html(), t[4]], "peer": 0})
	grid.append_array(watchers)
	var cfg := {"grid": grid, "lights": 6.0 + randf() * 1.6}
	for k in CFG_KEYS:
		cfg[k] = s.get(k)
	ready_peers = {}
	_begin_cfg = cfg
	_grid_wait = 0.0
	_send("begin", cfg)
	_begin_race(cfg)


func _begin_race(cfg: Dictionary) -> void:
	_tr("Rennen wird geladen")
	# colours travel as html strings
	cfg = cfg.duplicate(true)
	var grid: Array = cfg["grid"]
	for g in grid:
		var gd: Dictionary = g
		var t: Array = gd["team"]
		gd["team"] = [t[0], Color.html(String(t[1])), Color.html(String(t[2])), Color.html(String(t[3])), int(t[4])]
		gd["player"] = false
		gd["peer"] = int(gd["peer"])
	game.start_online(cfg)


func send_ready() -> void:
	if not online:
		return
	_go_seen = false
	for k in game.cars.size():
		var c = game.cars[k]
		var g: Dictionary = game.online_grid[k]
		c.set_meta("peer", int(g.get("peer", 0)))
	if is_host():
		ready_peers[1] = true
	else:
		_send("ready", 0, 1)


func all_ready() -> bool:
	for pid in players.keys():
		if not ready_peers.has(pid):
			return false
	return true


func send_go() -> void:
	_go_sent_t = 0.0
	_send("go", 0)


# Messages through the server can get lost (short drops). The host therefore repeats the start for
# drivers that have not loaded yet, gives up waiting after 30 s (missing drivers are left out), and
# repeats "go" for a few seconds after the lights went out.
var _begin_cfg := {}
var _grid_wait := 0.0
var _go_sent_t := -1.0
var _go_seen := false


func _host_start_care() -> void:
	if game == null:
		return
	if game.state == "grid" and not all_ready():
		_grid_wait += 2.0
		for pid in players.keys():
			if int(pid) != 1 and not ready_peers.has(pid) and not _begin_cfg.is_empty():
				_send("begin", _begin_cfg, int(pid))
		if _grid_wait > 30.0:
			for pid in players.keys():
				if not ready_peers.has(pid):
					ready_peers[pid] = true
					for c in game.cars:
						if c.has_meta("peer") and int(c.get_meta("peer")) == int(pid):
							c.retired = true
			game.show_msg("Nicht alle Fahrer haben geladen – Start ohne sie", 3.0, Color(1.0, 0.7, 0.2))
	if _go_sent_t >= 0.0:
		_go_sent_t += 2.0
		_send("go", 0)
		if _go_sent_t > 8.0:
			_go_sent_t = -1.0


# ---------------------------------------------------------------- car states
# send rate: through the server the free plan allows 100 messages per second for everybody together,
# so fewer updates per player the more players there are (dead reckoning fills the gaps)
# messages delivered per second through the server = senders x receivers x rate: kept around 50
func _relay_hz() -> float:
	var n := maxi(2, players.size())
	return clampf(50.0 / float(n * (n - 1)), 3.0, 12.0)


func send_hz() -> float:
	if mode == "ip" or direct or (is_host() and not _relay_needed()):
		return 25.0
	# messages delivered per second = senders x receivers x rate: kept around 50 (half the limit)
	var n := maxi(2, players.size())
	return clampf(50.0 / float(n * (n - 1)), 3.0, 12.0)


func tick(dt: float) -> void:
	if not online or game.cars.is_empty():
		return
	send_acc += dt
	if send_acc < 1.0 / send_hz():
		return
	send_acc = 0.0
	var me := my_id()
	var host := is_host()
	var buf := PackedByteArray()
	for k in game.cars.size():
		var c = game.cars[k]
		var p: int = int(c.get_meta("peer", 0))
		if p == me or (p == 0 and host):
			buf.append_array(_pack(k, c))
	if buf.size() > 0:
		_send_fast("st", Marshalls.raw_to_base64(buf) if mode == "code" else buf)


# one car state in 40 bytes (was 72): positions/heading/track position as 32-bit floats, the rest as
# 16-bit values - plenty of precision for drawing the car and its gauges
func _pack(k: int, c) -> PackedByteArray:
	var b := PackedByteArray()
	b.resize(STRIDE)
	b.encode_u8(0, k)
	b.encode_u8(1, (1 if c.in_pit else 0) | (2 if c.retired else 0) | (clampi(int(c.gear) + 1, 0, 15) << 2))
	b.encode_float(2, c.x)
	b.encode_float(6, c.y)
	b.encode_float(10, c.z)
	b.encode_float(14, c.psi)
	b.encode_float(18, c.s)
	b.encode_half(22, c.u)
	b.encode_half(24, c.v)
	b.encode_half(26, c.r)
	b.encode_half(28, c.steer)
	b.encode_half(30, c.throttle)
	b.encode_half(32, c.brake)
	b.encode_half(34, c.lat)
	b.encode_u16(36, clampi(int(c.rpm), 0, 65535))
	b.encode_s16(38, clampi(int(c.lap), -32768, 32767))
	return b


func _states(buf: PackedByteArray) -> void:
	if game == null or game.cars.is_empty():
		return
	var n := buf.size() / STRIDE
	for q in n:
		var o := q * STRIDE
		var k := buf.decode_u8(o)
		if k < 0 or k >= game.cars.size():
			continue
		var c = game.cars[k]
		if not c.remote:
			continue
		var fl := buf.decode_u8(o + 1)
		var psi := buf.decode_float(o + 14)
		# a damaged / foreign packet must never put NaN or absurd values into a car (that would wreck
		# the physics and the renderer): check before using anything
		var px := buf.decode_float(o + 2)
		var py := buf.decode_float(o + 6)
		var pz := buf.decode_float(o + 10)
		var ps := buf.decode_float(o + 18)
		var pu := buf.decode_half(o + 22)
		var pv := buf.decode_half(o + 24)
		var pr := buf.decode_half(o + 26)
		if not (is_finite(px) and is_finite(py) and is_finite(pz) and is_finite(psi) and is_finite(ps) and is_finite(pu)
				and is_finite(pv) and is_finite(pr)) or absf(px) > 1e5 or absf(pz) > 1e5 or absf(py) > 1e4 or absf(pu) > 200.0:
			continue
		c.u = pu
		c.v = clampf(pv, -60.0, 60.0)
		c.r = clampf(pr, -20.0, 20.0)
		# the packet is already a little old when it arrives: move it forward by the typical latency, then
		# blend position and heading over the next frames instead of jumping (dead_reckon)
		var lag := 0.06
		var cp := cos(psi)
		var sp := sin(psi)
		var target := Vector3(px + (c.u * cp - c.v * sp) * lag, py, pz + (c.u * sp + c.v * cp) * lag)
		var err := target - Vector3(c.x, c.y, c.z)
		var perr := angle_difference(c.psi, psi + c.r * lag)
		if err.length() > 25.0:
			c.x = target.x
			c.y = target.y
			c.z = target.z
			c.psi = psi
			corr[k] = Vector3.ZERO
			corr_psi[k] = 0.0
		else:
			corr[k] = err
			corr_psi[k] = perr
		c.steer = _fin(buf.decode_half(o + 28), 1.5)
		c.throttle = _fin(buf.decode_half(o + 30), 1.0)
		c.brake = _fin(buf.decode_half(o + 32), 1.0)
		c.lat = _fin(buf.decode_half(o + 34), 20.0)
		c.rpm = buf.decode_u16(o + 36)
		c.lap = buf.decode_s16(o + 38)
		c.gear = ((fl >> 2) & 15) - 1
		c.s = ps
		c.in_pit = (fl & 1) != 0
		c.retired = (fl & 2) != 0


# numbers travel as JSON through the server and come back as floats (6 -> 6.0): whole numbers become
# int again, so settings, selectors and counters see the same types as in a normal race
static func _ints(v):
	if v is float and is_finite(v) and v == floor(v) and absf(v) < 1e9:
		return int(v)
	if v is Dictionary:
		var d := {}
		for k in v:
			d[k] = _ints(v[k])
		return d
	if v is Array:
		var a := []
		for e in v:
			a.append(_ints(e))
		return a
	return v


static func _fin(x: float, lim: float) -> float:
	return clampf(x, -lim, lim) if is_finite(x) else 0.0


# remote cars between packets: keep moving with their last speed, blend in the correction
func dead_reckon(c, dt: float) -> void:
	var k: int = c.get_meta("car_k", -1)
	if k < 0:
		k = game.cars.find(c)
		c.set_meta("car_k", k)
	var wv: Vector2 = c.world_vel()
	c.x += wv.x * dt
	c.z += wv.y * dt
	c.psi += c.r * dt
	if corr.has(k):
		var e: Vector3 = corr[k]
		var f := minf(1.0, dt * 6.0)
		c.x += e.x * f
		c.y += e.y * f
		c.z += e.z * f
		corr[k] = e * (1.0 - f)
	if corr_psi.has(k):
		var pe: float = corr_psi[k]
		var fp := minf(1.0, dt * 8.0)
		c.psi += pe * fp
		corr_psi[k] = pe * (1.0 - fp)
	c.idx = game.T.idx(c.s)

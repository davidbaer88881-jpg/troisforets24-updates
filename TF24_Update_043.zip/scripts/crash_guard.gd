# Crash report: while the game runs, a small marker file exists (with what the game was doing). A clean
# exit removes it. If it is still there at the next start, the last session ended with a crash: the end
# of that session's log (Godot keeps the logs of the last sessions) is written as a text file into the
# Downloads folder, so it can be sent to whoever fixes the game.
extends Node

const FLAG := "user://running.flag"
const TRACE := "user://trace.log"
const TRACE_PREV := "user://trace_prev.log"
const Updater = preload("res://scripts/updater.gd")

var game
var report_path := ""          # set when the last session crashed and a report was written
var _t := 0.0


var _trace: FileAccess
# watchdog: a second thread notices when the game stops responding (a hang looks like a crash to the
# player and leaves no error message) and writes that into the trace
var _frames := 0
var _wd: Thread
var _wd_run := true
var _mutex := Mutex.new()


func _ready() -> void:
	# the last session's step-by-step trace (written line by line, so it survives a crash)
	if FileAccess.file_exists(TRACE):
		DirAccess.rename_absolute(ProjectSettings.globalize_path(TRACE), ProjectSettings.globalize_path(TRACE_PREV))
	_trace = FileAccess.open(TRACE, FileAccess.WRITE)
	if FileAccess.file_exists(FLAG):
		report_path = _write_report(FileAccess.get_file_as_string(FLAG))
	_mark("start")
	trace("Start, Version %d" % Updater.installed_number())
	_wd = Thread.new()
	_wd.start(_watchdog)


func _watchdog() -> void:
	var last := -1
	var still_ms := 0
	var told := false
	while _wd_run:
		OS.delay_msec(500)
		var f := _frames
		if f == last:
			still_ms += 500
			if still_ms >= 3000 and not told:
				told = true
				trace("!!! Spiel reagiert seit 3 s nicht (Hänger) - letzter Schritt steht darüber")
			elif still_ms >= 15000 and told and still_ms % 15000 == 0:
				trace("!!! hängt immer noch (%d s)" % (still_ms / 1000))
		else:
			if told:
				trace("Spiel reagiert wieder (nach %.1f s)" % (still_ms / 1000.0))
			told = false
			still_ms = 0
			last = f


# one line of what the game is doing (menu pages, online steps, race start); flushed at once
func trace(msg: String) -> void:
	if OS.get_thread_caller_id() == OS.get_main_thread_id():
		print("[ablauf] ", msg)
	_mutex.lock()
	if _trace != null:
		_trace.store_line("%s  %s" % [Time.get_time_string_from_system(), msg])
		_trace.flush()
	_mutex.unlock()


func _process(dt: float) -> void:
	_frames += 1
	_t -= dt
	if _t <= 0.0:
		_t = 10.0
		_mark("")


# what the game is doing right now (part of a report should it crash)
func _mark(_why: String) -> void:
	var f := FileAccess.open(FLAG, FileAccess.WRITE)
	if f == null:
		return
	var st := "-"
	var onl := false
	if game != null:
		st = String(game.state)
		onl = game.net != null and game.net.online
	f.store_string("version=%d state=%s online=%s players=%d time=%s" % [Updater.installed_number(), st, onl,
			game.net.players.size() if game != null and game.net != null else 0, Time.get_datetime_string_from_system()])


func clean_exit() -> void:
	_wd_run = false
	if _wd != null and _wd.is_started():
		_wd.wait_to_finish()
		_wd = null
	if FileAccess.file_exists(FLAG):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(FLAG))


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_EXIT_TREE:
		clean_exit()


func _write_report(info: String) -> String:
	# newest log of an earlier session (the running session writes godot.log)
	var dir := "user://logs"
	var best := ""
	var best_t := 0
	var da := DirAccess.open(dir)
	if da == null:
		return ""
	for fn in da.get_files():
		if not fn.ends_with(".log") or fn == "godot.log":
			continue
		var t := FileAccess.get_modified_time(dir + "/" + fn)
		if t > best_t:
			best_t = t
			best = fn
	var lines: PackedStringArray = FileAccess.get_file_as_string(dir + "/" + best).split("\n") if best != "" else PackedStringArray()
	var tail := lines.slice(maxi(0, lines.size() - 400))
	var out := "Trois Forêts 24 - Absturzbericht\n%s\nSystem: %s %s, %s\nLog: %s\n\n" % [info, OS.get_name(), OS.get_version(),
			RenderingServer.get_video_adapter_name(), best]
	out += "--- Ablauf (letzte Schritte vor dem Absturz) ---\n"
	var tr := FileAccess.get_file_as_string(TRACE_PREV).split("\n")
	out += "\n".join(tr.slice(maxi(0, tr.size() - 120)))
	out += "\n--- Godot-Log ---\n"
	out += "\n".join(tail)
	var dl := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if dl == "":
		dl = OS.get_user_data_dir()
	var path := dl.path_join("TF24_Absturzbericht_%s.txt" % Time.get_datetime_string_from_system().replace(":", "-"))
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return ""
	f.store_string(out)
	return path

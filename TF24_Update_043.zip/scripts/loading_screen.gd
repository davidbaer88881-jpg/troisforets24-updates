# Loading screen (game start and track changes): the two cars in a studio light shot over a dark
# background with moving light streaks, the title, a progress bar with what is being built right now
# and changing tips.
extends Control

const Ui = preload("res://scripts/ui.gd")

const BG_SHADER := """
shader_type canvas_item;
uniform float t = 0.0;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void fragment() {
	vec2 uv = UV;
	// night sky to asphalt: deep blue-black on top, warm red glow low in the picture
	vec3 col = mix(vec3(0.012, 0.016, 0.03), vec3(0.06, 0.012, 0.016), smoothstep(0.25, 0.95, uv.y));
	col += vec3(0.55, 0.12, 0.04) * pow(max(0.0, 1.0 - abs(uv.y - 0.72) * 2.2), 6.0) * 0.35;
	// light streaks racing from right to left (tail lights at speed)
	for (int i = 0; i < 14; i++) {
		float fi = float(i);
		float y = 0.18 + hash(vec2(fi, 3.1)) * 0.7;
		float sp = 0.25 + hash(vec2(fi, 7.7)) * 0.6;
		float len = 0.12 + hash(vec2(fi, 1.3)) * 0.3;
		float x = fract(1.2 - t * sp * 0.35 - hash(vec2(fi, 9.2)));
		float d = abs(uv.y - y);
		float along = clamp((uv.x - (x * 1.6 - 0.3)) / len, 0.0, 1.0);
		float on = step(x * 1.6 - 0.3, uv.x) * step(uv.x, x * 1.6 - 0.3 + len);
		float w = 0.0012 + hash(vec2(fi, 5.5)) * 0.0022;
		float line = on * smoothstep(w * 3.0, 0.0, d) * (1.0 - along);
		vec3 lc = hash(vec2(fi, 2.2)) > 0.35 ? vec3(1.0, 0.16, 0.08) : vec3(1.0, 0.75, 0.35);
		col += lc * line * 0.9;
	}
	// film grain + vignette
	col += (hash(uv * 900.0 + t) - 0.5) * 0.025;
	vec2 c = uv - vec2(0.5, 0.55);
	col *= 1.0 - dot(c, c) * 1.25;
	COLOR = vec4(col, 1.0);
}
"""

const TIPS := [
	"Beim Start: Zündung (X), dann den Starter (Enter) halten.",
	"TAB öffnet die Boxen-Strategie – mit , und . wechselst du die Vorlage.",
	"Durchfahrtsstrafe? Fahr innerhalb von 3 Runden durch die Boxengasse.",
	"Die FPS-Sicherung hält das Spiel flüssig – Ziel-FPS unter Grafik einstellen.",
	"ESC → EINSTELLUNGEN: Grafik, Ton und Steuerung auch während der Fahrt.",
	"Im Leerlauf rollt das Auto nicht weg – erst Gang rein, dann los.",
	"Online: offene Lobbys deiner Freunde trittst du mit einem Klick bei.",
	"Boxenstopp: F fordert ihn an, die Crew arbeitet nach deiner Strategie.",
	"Regen: früher bremsen, sanft Gas geben, Regenreifen holen.",
]

var bg: ColorRect
var hero: TextureRect
var bar_fill: ColorRect
var bar_glow: ColorRect
var stage_lbl: Label
var pct_lbl: Label
var tip_lbl: Label
var progress := 0.0
var shown := 0.0
var _t := 0.0
var _tip_t := 0.0
var _tip_i := 0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	bg = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var sh := Shader.new()
	sh.code = BG_SHADER
	var sm := ShaderMaterial.new()
	sm.shader = sh
	bg.material = sm
	add_child(bg)
	# the hero shot (a plain PNG inside the game files)
	hero = TextureRect.new()
	hero.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	hero.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	hero.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hero.anchor_top = 0.3
	hero.anchor_bottom = 0.86
	hero.anchor_left = 0.04
	hero.anchor_right = 0.96
	var bytes := FileAccess.get_file_as_bytes("res://art/hero.png")
	if bytes.size() > 0:
		var img := Image.new()
		if img.load_png_from_buffer(bytes) == OK:
			hero.texture = ImageTexture.create_from_image(img)
	hero.modulate.a = 0.0
	add_child(hero)
	# title
	var tb := VBoxContainer.new()
	tb.position = Vector2(80, 60)
	tb.add_theme_constant_override("separation", -14)
	add_child(tb)
	var strip := ColorRect.new()
	strip.color = Ui.RED
	strip.custom_minimum_size = Vector2(120, 8)
	tb.add_child(strip)
	tb.add_child(_label("TROIS FORÊTS", "head", 44, Color(1, 1, 1, 0.85)))
	var big := _label("24", "head", 150, Color.WHITE)
	big.add_theme_color_override("font_shadow_color", Color(Ui.RED, 0.9))
	big.add_theme_constant_override("shadow_offset_x", 8)
	big.add_theme_constant_override("shadow_offset_y", 6)
	tb.add_child(big)
	tb.add_child(_label("STUNDEN · LANGSTRECKE · GT3 & HYPERCAR", "bold", 20, Color(1, 1, 1, 0.55)))
	# bottom: stage, percent, progress bar, tip
	var bot := VBoxContainer.new()
	bot.anchor_top = 1.0
	bot.anchor_bottom = 1.0
	bot.anchor_left = 0.0
	bot.anchor_right = 1.0
	bot.offset_left = 80
	bot.offset_right = -80
	bot.offset_top = -150
	bot.offset_bottom = -40
	bot.add_theme_constant_override("separation", 10)
	add_child(bot)
	var row := HBoxContainer.new()
	bot.add_child(row)
	stage_lbl = _label("STRECKE WIRD AUFGEBAUT …", "head", 30, Color.WHITE)
	stage_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(stage_lbl)
	pct_lbl = _label("0 %", "head", 30, Ui.GOLD)
	row.add_child(pct_lbl)
	var track := ColorRect.new()
	track.color = Color(1, 1, 1, 0.12)
	track.custom_minimum_size = Vector2(0, 6)
	bot.add_child(track)
	bar_glow = ColorRect.new()
	bar_glow.color = Color(Ui.RED, 0.35)
	bar_glow.position = Vector2(0, -4)
	bar_glow.size = Vector2(0, 14)
	track.add_child(bar_glow)
	bar_fill = ColorRect.new()
	bar_fill.color = Color(1.0, 0.18, 0.1)
	bar_fill.size = Vector2(0, 6)
	track.add_child(bar_fill)
	tip_lbl = _label("", "body", 19, Color(1, 1, 1, 0.6))
	bot.add_child(tip_lbl)
	_tip_i = randi() % TIPS.size()
	_show_tip()


func _label(t: String, kind: String, size: int, col: Color) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_override("font", Ui.font(kind))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	return l


func _show_tip() -> void:
	tip_lbl.text = "TIPP:  " + String(TIPS[_tip_i % TIPS.size()])
	_tip_i += 1


# p 0..1 and what is being done right now
func set_progress(p: float, what: String = "") -> void:
	progress = clampf(p, 0.0, 1.0)
	if what != "":
		stage_lbl.text = what.to_upper()


func begin(what: String = "Strecke wird aufgebaut …") -> void:
	progress = 0.0
	shown = 0.0
	_t = 0.0
	hero.modulate.a = 0.0
	set_progress(0.0, what)
	visible = true


func _process(dt: float) -> void:
	if not visible:
		return
	_t += dt
	(bg.material as ShaderMaterial).set_shader_parameter("t", _t)
	hero.modulate.a = minf(1.0, hero.modulate.a + dt * 1.5)
	# slow camera push on the cars
	var z := 1.0 + minf(_t, 20.0) * 0.003
	hero.pivot_offset = hero.size * 0.5
	hero.scale = Vector2(z, z)
	shown = move_toward(shown, progress, dt * 1.8)
	var w: float = (bar_fill.get_parent() as Control).size.x
	bar_fill.size.x = w * shown
	bar_glow.size.x = w * shown
	bar_glow.color.a = 0.25 + 0.15 * sin(_t * 6.0)
	pct_lbl.text = "%d %%" % int(round(shown * 100.0))
	_tip_t += dt
	if _tip_t > 4.5:
		_tip_t = 0.0
		_show_tip()

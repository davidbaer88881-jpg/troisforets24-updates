extends RefCounted
# Records every car 20x per second during a race and plays it back (any camera, any car, slow motion).
# Replays can be saved as a file (Downloads/TF24 Replays) and turned into a video by the game itself.

const DT := 0.05
const NF := 23                       # floats per car and frame (old files: 14)
const NF_OLD := 14
const MAX_FRAMES := 36000            # keeps the last 30 minutes (long races)
const LOST_KEYS := ["splitter", "wing", "mirror_l", "mirror_r", "wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"]
const MAGIC := "TF24REPLAY2"
const MAGIC_OLD := "TF24REPLAY1"
const SURFACES := ["asphalt", "curb", "pit", "runoff", "grass", "gravel"]

var frames: Array = []               # one PackedFloat32Array per car
var meta := PackedFloat32Array()     # per frame: hour, wet
var events := PackedFloat32Array()   # body damage: frame, car, amount (-1 = repaired), dir x, dir z
var nf := NF                         # layout of the loaded data
var count := 0
var t0 := 0.0                        # race time of the first stored frame
var grid: Array = []                 # per car: {"cls", "team", "name", "player"}
var track := ""
var info := {}                       # track name, date, result line
var _acc := 0.0


func begin(cars: Array, track_key: String) -> void:
	frames.clear()
	meta = PackedFloat32Array()
	events = PackedFloat32Array()
	nf = NF
	count = 0
	t0 = 0.0
	_acc = 0.0
	track = track_key
	grid.clear()
	for c in cars:
		frames.append(PackedFloat32Array())
		grid.append({"cls": String(c.spec["key"]), "model": String(c.spec.get("model", "")), "team": c.get_meta("team", []), "name": String(c.name), "player": bool(c.is_player), "num": int(c.num)})
	info = {"date": Time.get_datetime_string_from_system(false, true)}


func has_data() -> bool:
	return count > 20


func length() -> float:
	return maxf(0.0, (count - 1) * DT)


func record(cars: Array, dt: float, race_time: float, hour: float, wet: float) -> void:
	if frames.size() != cars.size():
		return
	_acc += dt
	if _acc < DT - 1e-4:
		return
	_acc -= DT
	if count == 0:
		t0 = race_time
	for k in cars.size():
		var c = cars[k]
		var mask := 0
		for b in LOST_KEYS.size():
			if c.lost.get(LOST_KEYS[b], false):
				mask |= 1 << b
		var flags := (1 if c.spin_r else 0) | (2 if c.lock_f else 0) | (4 if c.lock_r else 0) | (8 if c.hold else 0)
		var f: PackedFloat32Array = frames[k]
		f.append_array(PackedFloat32Array([c.x, c.y, c.z, c.psi, c.u, c.v, c.steer, c.pitch, c.roll, c.heave, c.brake, c.rpm, float(c.gear), float(mask),
			c.grade_pitch, c.slip_r, c.r, c.wheel_spin, c.load_var, c.road_now, float(maxi(0, SURFACES.find(c.surface))), c.flash, float(flags)]))
		frames[k] = f
	meta.append(hour)
	meta.append(wet)
	count += 1
	if count >= int(MAX_FRAMES * 1.25):
		var drop := count - MAX_FRAMES
		for k in frames.size():
			var f2: PackedFloat32Array = frames[k]
			frames[k] = f2.slice(drop * NF)
		meta = meta.slice(drop * 2)
		var ev := PackedFloat32Array()
		for i in range(0, events.size(), 5):
			if events[i] >= drop:
				ev.append_array(PackedFloat32Array([events[i] - drop, events[i + 1], events[i + 2], events[i + 3], events[i + 4]]))
		events = ev
		count -= drop
		t0 += drop * DT


# a dent (amount > 0) or a pit repair (amount < 0) of car k, shown again at the same moment in the replay
func add_event(k: int, amount: float, dir: Vector3) -> void:
	if frames.is_empty():
		return
	events.append_array(PackedFloat32Array([float(maxi(0, count - 1)), float(k), amount, dir.x, dir.z]))


func event_count() -> int:
	return events.size() / 5


# [frame, car, amount, dir] of event i
func event(i: int) -> Array:
	var o := i * 5
	return [events[o], int(events[o + 1]), events[o + 2], Vector3(events[o + 3], 0.0, events[o + 4])]


# writes the interpolated state at replay time t into the car objects; returns [hour, wet]
func apply(cars: Array, t: float) -> Vector2:
	if count < 2:
		return Vector2.ZERO
	var fi := clampf(t / DT, 0.0, float(count - 1) - 0.001)
	var i0 := int(fi)
	var a := fi - float(i0)
	var n := mini(cars.size(), frames.size())
	for k in n:
		var c = cars[k]
		var f: PackedFloat32Array = frames[k]
		var o0 := i0 * nf
		var o1 := o0 + nf
		if o1 + nf > f.size():
			continue
		c.x = lerpf(f[o0], f[o1], a)
		c.y = lerpf(f[o0 + 1], f[o1 + 1], a)
		c.z = lerpf(f[o0 + 2], f[o1 + 2], a)
		c.psi = lerp_angle(f[o0 + 3], f[o1 + 3], a)
		c.u = lerpf(f[o0 + 4], f[o1 + 4], a)
		c.v = lerpf(f[o0 + 5], f[o1 + 5], a)
		c.steer = lerpf(f[o0 + 6], f[o1 + 6], a)
		c.pitch = lerpf(f[o0 + 7], f[o1 + 7], a)
		c.roll = lerpf(f[o0 + 8], f[o1 + 8], a)
		c.heave = lerpf(f[o0 + 9], f[o1 + 9], a)
		c.brake = f[o0 + 10]
		c.rpm = lerpf(f[o0 + 11], f[o1 + 11], a)
		c.gear = int(f[o0 + 12])
		var mask := int(f[o0 + 13])
		for b in LOST_KEYS.size():
			c.lost[LOST_KEYS[b]] = (mask >> b) & 1 == 1
		if nf >= NF:
			c.grade_pitch = lerpf(f[o0 + 14], f[o1 + 14], a)
			c.slip_r = lerpf(f[o0 + 15], f[o1 + 15], a)
			c.r = lerpf(f[o0 + 16], f[o1 + 16], a)
			c.wheel_spin = lerpf(f[o0 + 17], f[o1 + 17], a)
			c.load_var = lerpf(f[o0 + 18], f[o1 + 18], a)
			c.road_now = lerpf(f[o0 + 19], f[o1 + 19], a)
			c.surface = SURFACES[clampi(int(f[o0 + 20]), 0, SURFACES.size() - 1)]
			c.flash = f[o0 + 21]
			var flags := int(f[o0 + 22])
			c.spin_r = flags & 1 != 0
			c.lock_f = flags & 2 != 0
			c.lock_r = flags & 4 != 0
			c.hold = flags & 8 != 0
		else:
			c.r = 0.0
			c.lock_f = false
			c.lock_r = false
			c.spin_r = false
			c.hold = false
	return Vector2(lerpf(meta[i0 * 2], meta[i0 * 2 + 2], a), meta[i0 * 2 + 1])


# ------------------------------------------------------------------ files
static func folder() -> String:
	var d := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if d == "":
		d = OS.get_user_data_dir()
	return d.path_join("TF24 Replays")


func save_file() -> String:
	DirAccess.make_dir_recursive_absolute(folder())
	var stamp := Time.get_datetime_string_from_system(false, true).replace(":", "-").replace(" ", "_")
	var path := folder().path_join("TF24_%s_%s.tf24replay" % [track, stamp])
	var fa := FileAccess.open_compressed(path, FileAccess.WRITE, FileAccess.COMPRESSION_ZSTD)
	if fa == null:
		return ""
	fa.store_pascal_string(MAGIC)
	fa.store_var({"track": track, "grid": grid, "info": info, "count": count, "t0": t0, "meta": meta, "frames": frames, "nf": nf, "events": events})
	fa.close()
	return path


func load_file(path: String) -> bool:
	var fa := FileAccess.open_compressed(path, FileAccess.READ, FileAccess.COMPRESSION_ZSTD)
	if fa == null:
		return false
	var magic := fa.get_pascal_string()
	if magic != MAGIC and magic != MAGIC_OLD:
		fa.close()
		return false
	var d = fa.get_var()
	fa.close()
	if not (d is Dictionary) or not d.has("frames"):
		return false
	track = String(d["track"])
	grid = d["grid"]
	info = d.get("info", {})
	count = int(d["count"])
	t0 = float(d.get("t0", 0.0))
	meta = d["meta"]
	frames = d["frames"]
	nf = int(d.get("nf", NF_OLD))
	var ev = d.get("events", PackedFloat32Array())
	events = ev if ev is PackedFloat32Array else PackedFloat32Array()
	if nf != NF and nf != NF_OLD:
		return false
	for f in frames:
		if not (f is PackedFloat32Array) or f.size() < count * nf:
			return false
	return count > 1 and frames.size() == grid.size() and meta.size() >= count * 2

# Steering-wheel / dashboard display in the style of a motorsport DDU (rendered into a SubViewport).
extends Control

const Gfx = preload("res://scripts/gfx.gd")

var game
var font: Font


func _ready() -> void:
	font = Gfx.ui_font()


func _process(_dt: float) -> void:
	queue_redraw()


func _box(r: Rect2, col: Color, title: String, value: String, vcol := Color.WHITE, vsize := 30) -> void:
	draw_rect(r, col)
	draw_rect(r, Color(1, 1, 1, 0.25), false, 1.0)
	if title != "":
		draw_string(font, r.position + Vector2(5, 14), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.75, 0.78, 0.82))
	draw_string(font, r.position + Vector2(0, r.size.y - 7), value, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, vsize, vcol)


func _draw() -> void:
	var W := size.x
	var H := size.y
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.025, 0.03))
	if game == null or game.player == null:
		return
	var c = game.player
	var spec: Dictionary = c.spec
	# shift lights
	var frac: float = clampf((c.rpm / spec["rpmMax"] - 0.72) / 0.24, 0.0, 1.0)
	var lit := int(frac * 12.0)
	for k in 12:
		var col := Color(0.12, 0.12, 0.14)
		if k < lit:
			col = Color(0.1, 0.9, 0.3) if k < 4 else (Color(1.0, 0.15, 0.1) if k < 8 else Color(0.3, 0.5, 1.0))
			if frac >= 0.98 and int(Time.get_ticks_msec() / 70) % 2 == 0:
				col = Color(0.3, 0.5, 1.0)
		draw_circle(Vector2(W * 0.5 - 154 + k * 28, 14), 9, col)
	var top := 30.0
	# left: tyre pressures & temperatures
	var cmp: Dictionary = c.cmp()
	var topt: float = cmp["topt"]
	var pf: float = 1.72 + float(c.setup["press_f"]) + (c.temp_f - 60.0) * 0.004
	var pr: float = 1.72 + float(c.setup["press_r"]) + (c.temp_r - 60.0) * 0.004
	draw_string(font, Vector2(8, top + 14), "TYRE PRESS", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.75, 0.78, 0.82))
	var tw := 62.0
	var th := 30.0
	var vals := [[pf, c.temp_f], [pf, c.temp_f + 1.5], [pr, c.temp_r], [pr, c.temp_r + 1.5]]
	for k in 4:
		var r := Rect2(8 + (k % 2) * (tw + 4), top + 20 + (k / 2) * (th + 4), tw, th)
		var v: Array = vals[k]
		_box(r, Gfx.temp_col(v[1], topt).darkened(0.35), "", "%.2f" % v[0], Color.WHITE, 22)
	draw_string(font, Vector2(8, top + 110), "TYRE TEMP", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.75, 0.78, 0.82))
	for k in 4:
		var r := Rect2(8 + (k % 2) * (tw + 4), top + 116 + (k / 2) * (th + 4), tw, th)
		var v: Array = vals[k]
		_box(r, Gfx.temp_col(v[1], topt), "", "%d" % int(v[1]), Color.WHITE, 22)
	# small setting boxes
	var y2 := top + 190.0
	_box(Rect2(8, y2, 62, 44), Color(0.1, 0.1, 0.12), "BIAS", "%.1f" % (float(c.setup["bias"]) * 100.0), Color.WHITE, 24)
	_box(Rect2(74, y2, 40, 44), Color(0.08, 0.35, 0.6) if c.tc_on else Color(0.2, 0.2, 0.2), "TC", str(int(c.setup["tc"])) if c.tc_on else "-", Color.WHITE, 24)
	_box(Rect2(118, y2, 40, 44), Color(0.55, 0.15, 0.15) if c.abs_on else Color(0.2, 0.2, 0.2), "ABS", str(int(c.setup["abs"])) if c.abs_on else "-", Color.WHITE, 24)
	# centre: speed, gear, rpm
	var cx := W * 0.5
	var spd := absf(c.u) * 3.6
	_box(Rect2(cx - 70, top + 6, 140, 46), Color(0.07, 0.07, 0.08), "SPEED", "%d" % int(spd), Color.WHITE, 34)
	var gear_txt := "N" if c.gear == 0 else ("R" if c.gear < 0 else str(c.gear))
	var gcol := Color(0.15, 0.95, 0.4)
	if c.limiter:
		gcol = Color(0.3, 0.6, 1.0)
	draw_string(font, Vector2(cx - 80, top + 170), gear_txt, HORIZONTAL_ALIGNMENT_CENTER, 160, 130, gcol)
	draw_string(font, Vector2(cx - 80, top + 200), "%d RPM" % int(c.rpm), HORIZONTAL_ALIGNMENT_CENTER, 160, 18, Color(0.8, 0.82, 0.86))
	var status := "PIT LIMITER" if c.limiter else ("WET" if c.wet > 0.3 else "DRY")
	_box(Rect2(cx - 70, H - 52, 140, 40), Color(0.15, 0.35, 0.8) if c.limiter else Color(0.1, 0.1, 0.12), "", status, Color.WHITE, 22)
	# right: lap info
	var rx := W - 168.0
	var info: Dictionary = game.lap_info()
	_box(Rect2(rx, top + 6, 160, 40), Color(0.07, 0.07, 0.08), "LAP", str(info["lap"]), Color.WHITE, 24)
	_box(Rect2(rx, top + 50, 160, 40), Color(0.07, 0.07, 0.08), "LAST", info["last"], Color.WHITE, 22)
	_box(Rect2(rx, top + 94, 160, 40), Color(0.07, 0.07, 0.08), "BEST", info["best"], Color(0.8, 0.5, 1.0), 22)
	var dv: float = info["delta"]
	var dcol := Color(0.1, 0.55, 0.2) if dv < 0.0 else Color(0.6, 0.12, 0.1)
	_box(Rect2(rx, top + 138, 160, 40), dcol if absf(dv) < 90.0 else Color(0.07, 0.07, 0.08), "DELTA", ("%+.2f" % dv) if absf(dv) < 90.0 else "-.--", Color.WHITE, 24)
	_box(Rect2(rx, top + 182, 76, 44), Color(0.07, 0.07, 0.08), "FUEL", "%.1f" % c.fuel, Color.WHITE, 22)
	_box(Rect2(rx + 84, top + 182, 76, 44), Color(0.07, 0.07, 0.08), "LAPS", "%.1f" % info["fuel_laps"], Color.WHITE, 22)
	_box(Rect2(rx, H - 52, 160, 40), Color(0.07, 0.07, 0.08), "", "P%d / %d" % [info["pos"], info["count"]], Color(1.0, 0.85, 0.2), 22)
	if c.total_damage() > 0.05:
		draw_string(font, Vector2(8, H - 14), "DAMAGE", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1.0, 0.3, 0.2))

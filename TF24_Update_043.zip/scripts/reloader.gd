# Applies a freshly installed update without restarting the program: the game scene is closed,
# every game script is re-read from the (newly mounted) update and recompiled, then the game starts again.
# Works when the game runs from the Godot editor as well as standalone.
extends Node

var pack := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().paused = false
	# close the running game first (scripts in use cannot be recompiled)
	var cur := get_tree().current_scene
	if cur != null:
		cur.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var ok := ProjectSettings.load_resource_pack(pack, true) if pack != "" else true
	# 1) give every changed script its new source, 2) recompile (a few passes: scripts depend on each other)
	var todo: Array = []
	var dir := DirAccess.open("res://scripts")
	if dir != null:
		for f in dir.get_files():
			var fs: String = f
			if not fs.ends_with(".gd") or fs == "reloader.gd":
				continue
			var path := "res://scripts/" + fs
			var src := FileAccess.get_file_as_string(path)
			if src == "" or not ResourceLoader.has_cached(path):
				continue
			var scr: GDScript = load(path)
			if scr == null or scr.source_code == src:
				continue
			scr.source_code = src
			todo.append(scr)
	var failed: Array = todo
	for _pass in 4:
		var again: Array = []
		for scr in failed:
			var g: GDScript = scr
			if g.reload(false) != OK:
				again.append(g)
		failed = again
		if failed.is_empty():
			break
	Engine.set_meta("update_loaded", pack.get_file())
	if not ok or not failed.is_empty():
		OS.alert("Das Update ist installiert, konnte aber nicht sofort geladen werden.\nBitte das Spiel einmal schließen und neu starten.", "Trois Forêts 24")
		get_tree().quit()
		return
	get_tree().change_scene_to_file("res://Main.tscn")
	queue_free()

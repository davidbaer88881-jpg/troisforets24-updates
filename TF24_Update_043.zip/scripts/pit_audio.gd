# Pit stop sounds, placed in 3D at the spot where the crew works: impact wrenches loosening and
# tightening the wheel nuts (air motor whine + hammer blows), the air jack firing and dumping, tyres
# bouncing on the concrete, the hub clunk of a new wheel, the dry-break fuel coupling and the fuel
# flowing, and the tools of a repair (ratchets, hammer, cordless driver, body panels).
# All sounds are synthesised once (in a worker thread) from physically inspired models: noise and
# impulse trains through resonators (metal = high, narrow modes; rubber/body = low, damped modes).
extends Node

const SR := 32000

var streams := {}
var ready_ok := false
var pool: Array = []
var pool_i := 0
var flow: AudioStreamPlayer3D
var flow_gain := 0.0
var flow_on := false
var muted := false
var _task := -1
var played := {}              # how often each sound ran (diagnostics)


func _ready() -> void:
	for k in 10:
		pool.append(_p3d())
	flow = _p3d()
	_task = WorkerThreadPool.add_task(_build)


func _p3d() -> AudioStreamPlayer3D:
	var p := AudioStreamPlayer3D.new()
	p.bus = "Car"
	p.unit_size = 4.0
	p.max_distance = 90.0
	p.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
	p.max_db = 3.0
	add_child(p)
	return p


func _process(dt: float) -> void:
	if not ready_ok and _task >= 0 and WorkerThreadPool.is_task_completed(_task):
		WorkerThreadPool.wait_for_task_completion(_task)
		_task = -1
		ready_ok = true
		flow.stream = streams["flow"]
	if not ready_ok:
		return
	flow_gain = move_toward(flow_gain, 1.0 if flow_on and not muted else 0.0, dt * 4.0)
	if flow_gain > 0.001:
		if not flow.playing:
			flow.play()
		flow.volume_db = linear_to_db(flow_gain * 0.8)
	elif flow.playing:
		flow.stop()


# one sound at a world position
func play(nm: String, pos: Vector3, vol: float = 1.0, pitch: float = 1.0) -> void:
	played[nm] = int(played.get(nm, 0)) + 1
	if not ready_ok or muted or not streams.has(nm):
		return
	var p: AudioStreamPlayer3D = pool[pool_i]
	pool_i = (pool_i + 1) % pool.size()
	p.stream = streams[nm]
	p.global_position = pos
	p.volume_db = linear_to_db(maxf(0.0001, vol))
	p.pitch_scale = pitch
	p.play()


func set_flow(on: bool, pos: Vector3) -> void:
	flow_on = on
	if on:
		flow.global_position = pos


func stop_all() -> void:
	flow_on = false
	for p in pool:
		(p as AudioStreamPlayer3D).stop()


# ---------------------------------------------------------------- synthesis (worker thread)
var rng := RandomNumberGenerator.new()


func _build() -> void:
	rng.seed = 7
	var s := {}
	s["gun_off"] = _gun(false)
	s["gun_on"] = _gun(true)
	s["jack_up"] = _jack(false)
	s["jack_down"] = _jack(true)
	s["tyre_drop"] = _tyre_drop()
	s["hub"] = _hub_clunk()
	s["coupling"] = _coupling()
	s["flow"] = _fuel_flow()
	s["ratchet"] = _ratchet()
	s["hammer"] = _hammer()
	s["driver"] = _driver()
	s["panel"] = _panel()
	streams = s


func _buf(sec: float) -> PackedFloat32Array:
	var b := PackedFloat32Array()
	b.resize(int(SR * sec))
	b.fill(0.0)
	return b


# band-pass resonator bank, one pass: [[freq, q, gain], ...]
func _res(x: PackedFloat32Array, modes: Array) -> PackedFloat32Array:
	var y := PackedFloat32Array()
	y.resize(x.size())
	y.fill(0.0)
	for m in modes:
		var w0: float = TAU * float(m[0]) / SR
		var al: float = sin(w0) / (2.0 * float(m[1]))
		var a0 := 1.0 + al
		var b0 := al / a0
		var a1 := -2.0 * cos(w0) / a0
		var a2 := (1.0 - al) / a0
		var g: float = m[2]
		var x1 := 0.0
		var x2 := 0.0
		var y1 := 0.0
		var y2 := 0.0
		for i in x.size():
			var xi := x[i]
			var yi := b0 * xi - b0 * x2 - a1 * y1 - a2 * y2
			x2 = x1
			x1 = xi
			y2 = y1
			y1 = yi
			y[i] += yi * g
	return y


func _mix(dst: PackedFloat32Array, src: PackedFloat32Array, at: int, g: float) -> void:
	for i in src.size():
		if at + i >= 0 and at + i < dst.size():
			dst[at + i] += src[i] * g


# one metal-on-metal blow: click + ringing steel (socket, nut, hub)
func _blow(len_s: float, bright: float) -> PackedFloat32Array:
	var x := _buf(len_s)
	for i in x.size():
		x[i] = rng.randf_range(-1.0, 1.0) * exp(-float(i) / (SR * 0.0012))
	return _norm(_res(x, [[1850.0 * bright, 9.0, 1.0], [3150.0 * bright, 12.0, 0.8], [4900.0 * bright, 10.0, 0.5], [620.0, 4.0, 0.5]]))


# scales a sound to peak 1 (so blows, thuds and air can be mixed with plain gains)
func _norm(x: PackedFloat32Array) -> PackedFloat32Array:
	var pk := 0.0001
	for v in x:
		pk = maxf(pk, absf(v))
	for i in x.size():
		x[i] /= pk
	return x


# impact wrench. Loosening: a burst of blows breaks the nut, then the air motor spins it off (free run,
# whine) and winds down when the trigger is released. Tightening: the nut runs on fast, then the
# hammer blows get harder and quicker until it is torqued, and the air exhausts.
func _gun(tighten: bool) -> AudioStreamWAV:
	var total := 0.95 if tighten else 0.85
	var out := _buf(total)
	# air motor: rotation ~ 150 Hz (9000 rpm) with vane harmonics, plus exhaust hiss
	var phase := 0.0
	var lp := 0.0
	var lp_h := 0.0
	var free_a := 0.08 if tighten else 0.2      # free run section
	var free_b := 0.42 if tighten else 0.72
	for i in out.size():
		var t := float(i) / SR
		var on := smoothstep(0.0, 0.015, t) * (1.0 - smoothstep(total - 0.12, total - 0.02, t))
		var free := smoothstep(free_a - 0.02, free_a + 0.02, t) * (1.0 - smoothstep(free_b - 0.03, free_b + 0.02, t))
		var f0 := 120.0 + 70.0 * free                 # spins up when the load is gone
		if t > total - 0.14:
			f0 *= maxf(0.3, 1.0 - (t - (total - 0.14)) * 4.0)   # winding down after the trigger
		phase += TAU * f0 / SR
		var whine := sin(phase) * 0.5 + sin(phase * 2.0) * 0.35 + sin(phase * 3.0) * 0.25 + sin(phase * 6.0 + 0.5) * 0.18 + sin(phase * 9.0) * 0.1
		var nz := rng.randf_range(-1.0, 1.0)
		lp += (nz - lp) * 0.45
		lp_h += ((nz - lp) - lp_h) * 0.5           # exhaust air: band-limited hiss (2-8 kHz)
		out[i] = (whine * (0.3 + 0.25 * free) + lp_h * 0.09) * on
	# hammer blows
	var t0 := 0.0 if not tighten else free_b - 0.02
	var t1 := free_a if not tighten else total - 0.12
	var rate := 26.0
	var tt := t0 + 0.01
	var k := 0
	while tt < t1:
		var prog := (tt - t0) / maxf(0.01, t1 - t0)
		var a := rng.randf_range(0.75, 1.0) * (0.9 + 0.4 * prog if tighten else 1.1 - 0.3 * prog)
		_mix(out, _blow(0.035, 1.0 + 0.04 * prog), int(tt * SR), a)
		tt += 1.0 / (rate + (8.0 * prog if tighten else 0.0)) * rng.randf_range(0.93, 1.07)
		k += 1
	# nut rattles in the socket after it comes off / the gun pulls away
	_mix(out, _blow(0.05, 1.35), int((total - 0.1) * SR), 0.35)
	return _wav(out)


# air jack: the lance couples (clunk), the cylinders fire with a sharp blast and the car rises with
# a creak; dropping: a long air dump, the body hits its bump stops and the springs rattle
func _jack(down: bool) -> AudioStreamWAV:
	var total := 1.3 if down else 0.9
	var out := _buf(total)
	var lp := 0.0
	var lp2 := 0.0
	for i in out.size():
		var t := float(i) / SR
		var nz := rng.randf_range(-1.0, 1.0)
		lp += (nz - lp) * 0.55
		lp2 += (lp - lp2) * 0.06
		var air := lp - lp2
		var env := minf(1.0, t * 120.0) * exp(-t * (2.6 if down else 4.5))
		out[i] = air * env * (2.2 if down else 1.8)
	var coupling := _blow(0.06, 0.55)
	_mix(out, coupling, 0, 0.5)
	# body: rises (low creak) or drops on to its tyres (thud + spring ring)
	var body := _buf(0.5)
	for i in body.size():
		var t := float(i) / SR
		body[i] = sin(TAU * 52.0 * t) * exp(-t * 14.0) + rng.randf_range(-1.0, 1.0) * exp(-t * 60.0) * 0.5
	var ring := _norm(_res(body, [[310.0, 18.0, 0.5], [740.0, 22.0, 0.25]]))
	if down:
		_mix(out, body, int(0.12 * SR), 1.1)
		_mix(out, ring, int(0.12 * SR), 0.7)
		_mix(out, body, int(0.32 * SR), 0.35)       # small rebound
	else:
		_mix(out, ring, int(0.08 * SR), 0.5)
	return _wav(out)


# a tyre dropped on concrete: dull rubber thud with a short bounce
func _tyre_drop() -> AudioStreamWAV:
	var out := _buf(0.6)
	for hit in [[0.0, 1.0], [0.22, 0.4], [0.36, 0.15]]:
		var x := _buf(0.18)
		for i in x.size():
			var t := float(i) / SR
			x[i] = rng.randf_range(-1.0, 1.0) * exp(-t * 90.0) + sin(TAU * 85.0 * t) * exp(-t * 28.0) * 1.5
		var y := _norm(_res(x, [[95.0, 1.5, 1.0], [240.0, 2.5, 0.6], [900.0, 2.0, 0.2]]))
		_mix(out, y, int(float(hit[0]) * SR), float(hit[1]))
	return _wav(out)


# new wheel slides on to the hub: metallic clunk of the rim on the centre lock + rubber
func _hub_clunk() -> AudioStreamWAV:
	var out := _buf(0.4)
	_mix(out, _blow(0.25, 0.42), 0, 1.0)
	var x := _buf(0.2)
	for i in x.size():
		var t := float(i) / SR
		x[i] = sin(TAU * 120.0 * t) * exp(-t * 35.0)
	_mix(out, x, 0, 0.9)
	return _wav(out)


# dry-break fuel coupling: hard clack, then a short burst of vented air
func _coupling() -> AudioStreamWAV:
	var out := _buf(0.5)
	_mix(out, _blow(0.08, 0.8), 0, 1.0)
	var lp := 0.0
	for i in range(int(0.03 * SR), out.size()):
		var t := float(i) / SR - 0.03
		var nz := rng.randf_range(-1.0, 1.0)
		lp += (nz - lp) * 0.3
		out[i] += (nz - lp) * exp(-t * 9.0) * 0.35
	return _wav(out)


# fuel rushing through the hose into the tank: low turbulent roar with gurgling bubbles (loop)
func _fuel_flow() -> AudioStreamWAV:
	var n := int(SR * 2.0)
	var x := PackedFloat32Array()
	x.resize(n)
	var lp := 0.0
	var am := 0.0
	var tgt := 0.5
	for i in n:
		if i % 900 == 0:
			tgt = rng.randf_range(0.3, 1.0)
		am += (tgt - am) * 0.003
		var nz := rng.randf_range(-1.0, 1.0)
		lp += (nz - lp) * 0.08
		x[i] = lp * am
	var y := _res(x, [[180.0, 3.0, 1.0], [420.0, 5.0, 0.6], [900.0, 4.0, 0.3]])
	# bubbles: short rising chirps
	var b := 0
	while b < n - 3000:
		var f0 := rng.randf_range(250.0, 600.0)
		var ln := rng.randi_range(600, 1600)
		var ph := 0.0
		for j in ln:
			var t := float(j) / SR
			ph += TAU * f0 * (1.0 + t * 8.0) / SR
			y[b + j] += sin(ph) * exp(-t * 60.0) * 0.25
		b += rng.randi_range(1200, 5000)
	# crossfade the ends so the loop is seamless
	var fade := 1600
	for i in fade:
		var w := float(i) / fade
		y[i] = y[i] * w + y[n - fade + i] * (1.0 - w)
	y.resize(n - fade)
	return _wav(y, true)


# ratchet: a quick series of pawl clicks
func _ratchet() -> AudioStreamWAV:
	var out := _buf(0.75)
	var t := 0.0
	for stroke in 3:
		var clicks := rng.randi_range(5, 8)
		for c in clicks:
			_mix(out, _blow(0.012, 1.9), int(t * SR), rng.randf_range(0.35, 0.55))
			t += rng.randf_range(0.022, 0.03)
		t += rng.randf_range(0.08, 0.12)
	return _wav(out)


# hammer on a bracket: two or three blows
func _hammer() -> AudioStreamWAV:
	var out := _buf(0.9)
	var t := 0.0
	for k in rng.randi_range(2, 3):
		var x := _buf(0.25)
		for i in x.size():
			var tt := float(i) / SR
			x[i] = rng.randf_range(-1.0, 1.0) * exp(-tt * 200.0) + sin(TAU * 70.0 * tt) * exp(-tt * 40.0)
		_mix(out, _norm(_res(x, [[880.0, 14.0, 1.0], [2350.0, 18.0, 0.6], [150.0, 2.0, 0.6]])), int(t * SR), rng.randf_range(0.7, 1.0))
		t += rng.randf_range(0.26, 0.34)
	return _wav(out)


# cordless driver / drill: electric motor whine that drops under load
func _driver() -> AudioStreamWAV:
	var out := _buf(0.7)
	var ph := 0.0
	for i in out.size():
		var t := float(i) / SR
		var load := smoothstep(0.25, 0.4, t)
		var f := 780.0 - 260.0 * load + sin(t * 40.0) * 8.0
		ph += TAU * f / SR
		var env := smoothstep(0.0, 0.04, t) * (1.0 - smoothstep(0.58, 0.68, t))
		out[i] = (sin(ph) * 0.4 + sin(ph * 2.0) * 0.25 + sin(ph * 3.0) * 0.12 + rng.randf_range(-1.0, 1.0) * 0.08) * env
	return _wav(out)


# body work: a carbon panel knocked and clipped in place
func _panel() -> AudioStreamWAV:
	var out := _buf(0.6)
	var t := 0.0
	for k in 3:
		var x := _buf(0.12)
		for i in x.size():
			x[i] = rng.randf_range(-1.0, 1.0) * exp(-float(i) / (SR * 0.01))
		_mix(out, _norm(_res(x, [[420.0, 4.0, 1.0], [1150.0, 5.0, 0.6], [2700.0, 3.0, 0.3]])), int(t * SR), rng.randf_range(0.5, 1.0))
		t += rng.randf_range(0.1, 0.2)
	_mix(out, _blow(0.02, 2.2), int((t + 0.02) * SR), 0.4)       # clip snaps in
	return _wav(out)


func _wav(buf: PackedFloat32Array, loop: bool = false) -> AudioStreamWAV:
	var peak := 0.0001
	for v in buf:
		peak = maxf(peak, absf(v))
	var k := 0.9 / peak
	var data := PackedByteArray()
	data.resize(buf.size() * 2)
	for i in buf.size():
		data.encode_s16(i * 2, int(clampf(buf[i] * k, -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = SR
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = buf.size()
	return w

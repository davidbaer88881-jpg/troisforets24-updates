# In-game updates: an update is a .zip with the changed project files (scripts/…, version.txt).
# It is copied to user://updates and mounted by boot.gd at the next start.
extends RefCounted

const UPDATE_DIR := "user://updates"
const PREFIX := "TF24_Update"


static func version_text() -> String:
	var f := FileAccess.open("res://version.txt", FileAccess.READ)
	var v := f.get_as_text().strip_edges() if f != null else "unbekannt"
	var mounted: String = Engine.get_meta("update_loaded", "")
	return v + ("" if mounted == "" else "   (Update aktiv: " + mounted + ")")


# update number from a file name "TF24_Update_012.zip" (-1 if none)
static func file_number(path: String) -> int:
	# only the number right after "Update_" counts ("TF24_Update_016 (1).zip" is update 16, not 240161)
	var f := path.get_file()
	var i := f.find("Update_")
	if i < 0:
		return -1
	var digits := ""
	for ch in f.substr(i + 7):
		if ch >= "0" and ch <= "9":
			digits += ch
		else:
			break
	return int(digits) if digits != "" else -1


# update number written inside the zip (version.txt "Version 21 · ..."), -1 if unknown
static func zip_number(path: String) -> int:
	var v := zip_version(path)
	var parts := v.split(" ")
	return int(parts[1]) if parts.size() > 1 and parts[1].is_valid_int() else file_number(path)


# number of the running version ("Version 11 · ..." in version.txt)
static func installed_number() -> int:
	var f := FileAccess.open("res://version.txt", FileAccess.READ)
	if f == null:
		return 0
	var parts := f.get_as_text().strip_edges().split(" ")
	return int(parts[1]) if parts.size() > 1 and parts[1].is_valid_int() else 0


# newest TF24_Update*.zip in Downloads and its sub folders (a few levels deep), "" if there is none
static func find_in_downloads() -> String:
	var dl := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	var best := ""
	var best_n := -1
	var queue: Array = [[dl, 0]]
	var visited := 0
	while not queue.is_empty() and visited < 400:
		var item: Array = queue.pop_front()
		var path: String = item[0]
		var depth: int = item[1]
		visited += 1
		var dir := DirAccess.open(path)
		if dir == null:
			continue
		for f in dir.get_files():
			var fs: String = f
			if fs.begins_with(PREFIX) and fs.ends_with(".zip"):
				var n := file_number(fs)
				if n > best_n:
					best_n = n
					best = path.path_join(fs)
		if depth < 3:
			for d in dir.get_directories():
				var ds: String = d
				if not ds.begins_with(".") and not ds.ends_with(".app"):
					queue.append([path.path_join(ds), depth + 1])
	return best


# an update newer than the running version, or ""
static func newer_update() -> String:
	var p := find_in_downloads()
	if p == "":
		return ""
	return p if file_number(p) > installed_number() else ""


static func zip_version(path: String) -> String:
	var zr := ZIPReader.new()
	if zr.open(path) != OK:
		return ""
	var v := ""
	if zr.file_exists("version.txt"):
		v = zr.read_file("version.txt").get_string_from_utf8().strip_edges()
	zr.close()
	return v


# returns "" on success, otherwise an error text
static func install(path: String) -> String:
	var zr := ZIPReader.new()
	if zr.open(path) != OK:
		return "Datei lässt sich nicht öffnen."
	var ok := zr.file_exists("scripts/main.gd")
	zr.close()
	if not ok:
		return "Das ist keine Update-Datei (scripts/main.gd fehlt)."
	DirAccess.make_dir_recursive_absolute(UPDATE_DIR)
	# stored under a clean name from the version inside the zip: the newest always sorts last
	var n := zip_number(path)
	var target := UPDATE_DIR + "/" + ("%s_%03d.zip" % [PREFIX, n] if n >= 0 else path.get_file())
	# the running game still reads from the old update, so it stays until the next start (cleanup())
	var err := DirAccess.copy_absolute(path, target)
	return "" if err == OK else "Kopieren fehlgeschlagen (Fehler %d)." % err


# at start: only the newest update is needed, older ones are deleted
static func cleanup() -> void:
	var dir := DirAccess.open(UPDATE_DIR)
	if dir == null:
		return
	var files: Array = []
	for f in dir.get_files():
		if String(f).ends_with(".zip"):
			files.append(String(f))
	var newest := _newest(files)
	var mounted: String = Engine.get_meta("update_loaded", "")
	for f in files:
		if f != newest and f != mounted:
			DirAccess.remove_absolute(UPDATE_DIR + "/" + f)


static func remove_all() -> void:
	var dir := DirAccess.open(UPDATE_DIR)
	if dir == null:
		return
	for f in dir.get_files():
		DirAccess.remove_absolute(UPDATE_DIR + "/" + String(f))


# load the installed update right now (no restart needed, also works when started from the Godot editor)
static func apply_now(tree: SceneTree) -> void:
	# the finished app (exported) runs compiled scripts that cannot be swapped while it runs:
	# it restarts itself and loads the update at the start. From the Godot editor: swap at once.
	if not OS.has_feature("editor"):
		restart(tree)
		return
	var dir := DirAccess.open(UPDATE_DIR)
	var pack := ""
	if dir != null:
		var files: Array = []
		for f in dir.get_files():
			if String(f).ends_with(".zip"):
				files.append(String(f))
		if not files.is_empty():
			pack = UPDATE_DIR + "/" + _newest(files)
	if pack == "":
		restart(tree)
		return
	var r := Node.new()
	r.set_script(load("res://scripts/reloader.gd"))
	r.set("pack", pack)
	tree.root.add_child(r)


static func restart(tree: SceneTree) -> void:
	OS.set_restart_on_exit(true, OS.get_cmdline_args())
	tree.quit()


# file with the highest update number (ties: the last by name)
static func _newest(files: Array) -> String:
	var best := ""
	var best_n := -2
	var sorted := files.duplicate()
	sorted.sort()
	for f in sorted:
		var n := file_number(String(f))
		if n >= best_n:
			best_n = n
			best = String(f)
	return best

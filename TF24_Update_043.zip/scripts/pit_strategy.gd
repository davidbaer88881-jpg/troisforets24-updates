extends RefCounted
# Pit strategy presets: what the crew does at a stop. Saved per driver profile, used offline and online.
# A preset is turned into the concrete pit plan (litres, tyres, repair ...) from the live race state
# (fuel in the tank, laps left, wet track), so the crew always works with the current numbers.

const Profile = preload("res://scripts/profile.gd")

const FUEL_MODES := [["Volltanken", "full"], ["Nicht tanken", "none"], ["Tank auf … Liter", "fixed"], ["Bis ins Ziel", "finish"], ["Für … Runden", "laps"]]
const TYRE_MODES := [["Automatisch", "auto"], ["Nicht wechseln", "keep"], ["Soft", "soft"], ["Medium", "medium"], ["Hard", "hard"], ["Regen", "wet"]]
const SET_MODES := [["Alle 4", "all"], ["Nur vorne", "front"], ["Nur hinten", "rear"]]
const REPAIR_MODES := [["Immer reparieren", "always"], ["Nie reparieren", "never"]]
const PAD_MODES := [["Bei Verschleiß (> 60 %)", "worn"], ["Nie wechseln", "never"], ["Immer wechseln", "always"]]


static func defaults() -> Array:
	return [
		{"name": "Standard", "fuel": "full", "fuel_l": 60.0, "laps": 10, "tyres": "auto", "set": "all", "repair": "always", "pads": "worn"},
		{"name": "Bis ins Ziel", "fuel": "finish", "fuel_l": 60.0, "laps": 10, "tyres": "auto", "set": "all", "repair": "always", "pads": "never"},
		{"name": "Nur Reifen", "fuel": "none", "fuel_l": 60.0, "laps": 10, "tyres": "auto", "set": "all", "repair": "never", "pads": "never"},
	]


static func list() -> Array:
	if Profile.current.is_empty():
		return defaults()
	if not Profile.current.has("pit_presets") or (Profile.current["pit_presets"] as Array).is_empty():
		Profile.current["pit_presets"] = defaults()
	return Profile.current["pit_presets"]


static func selected() -> int:
	return clampi(int(Profile.current.get("pit_preset", 0)), 0, list().size() - 1)


static func select(i: int) -> void:
	if Profile.current.is_empty():
		return
	Profile.current["pit_preset"] = clampi(i, 0, list().size() - 1)
	Profile.save_all()


static func current() -> Dictionary:
	return list()[selected()]


static func save() -> void:
	if not Profile.current.is_empty():
		Profile.save_all()


static func add(copy_from: Dictionary) -> int:
	var p := copy_from.duplicate()
	p["name"] = String(copy_from.get("name", "Strategie")) + " (Kopie)"
	var l := list()
	l.append(p)
	save()
	return l.size() - 1


static func remove(i: int) -> void:
	var l := list()
	if l.size() <= 1:
		return
	l.remove_at(i)
	Profile.current["pit_preset"] = clampi(selected(), 0, l.size() - 1)
	save()


static func label_of(options: Array, v) -> String:
	for o in options:
		if o[1] == v:
			return o[0]
	return str(v)


# the concrete plan for the next stop. ctx: fuel, cap, fuel_per_lap, fuel_to_finish, wet, compound, pad_wear, damage
static func plan(pr: Dictionary, ctx: Dictionary) -> Dictionary:
	var fuel: float = ctx["fuel"]
	var cap: float = ctx["cap"]
	var add := 0.0
	match String(pr.get("fuel", "full")):
		"full":
			add = cap - fuel
		"none":
			add = 0.0
		"fixed":
			add = float(pr.get("fuel_l", 60.0)) - fuel
		"finish":
			add = float(ctx["fuel_to_finish"])
		"laps":
			add = (float(pr.get("laps", 10)) + 0.5) * float(ctx["fuel_per_lap"]) - fuel
	add = clampf(snappedf(add, 1.0), 0.0, cap - fuel)
	var ty := String(pr.get("tyres", "auto"))
	var wet: bool = float(ctx["wet"]) > 0.45
	if ty == "keep":
		ty = ""
	elif ty == "auto":
		var cur := String(ctx["compound"])
		ty = "wet" if wet else (cur if cur != "wet" else "medium")
	var pads := String(pr.get("pads", "worn"))
	return {"fuel_add": add, "tyres": ty, "set": String(pr.get("set", "all")) if ty != "" else "all",
		"repair": String(pr.get("repair", "always")) == "always",
		"pads": pads == "always" or (pads == "worn" and float(ctx["pad_wear"]) > 0.6)}

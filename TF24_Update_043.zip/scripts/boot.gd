# Start scene: mounts the newest in-game update (a .zip from the "Updates" tab) over the project files
# BEFORE any game script is loaded, then opens the real game. Updates therefore never need Godot's
# editor: drop the file in, the game installs it and restarts.
extends Node

const UPDATE_DIR := "user://updates"


func _ready() -> void:
	var loaded := ""
	var dir := DirAccess.open(UPDATE_DIR)
	if dir != null:
		var files: Array = Array(dir.get_files())
		files.sort()
		for f in files:
			var fs: String = f
			if fs.ends_with(".zip") or fs.ends_with(".pck"):
				if ProjectSettings.load_resource_pack(UPDATE_DIR + "/" + fs, true):
					loaded = fs
				else:
					push_warning("Update konnte nicht geladen werden: " + fs)
	Engine.set_meta("update_loaded", loaded)
	get_tree().change_scene_to_file.call_deferred("res://Main.tscn")

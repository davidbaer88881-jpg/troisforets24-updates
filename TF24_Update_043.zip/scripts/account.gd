extends Node
# Online account (e-mail + password, Supabase): the driver profile is stored in the cloud and can be
# loaded on any computer. Local profiles keep working; an account is linked to one local profile
# ("cloud_uid") which is uploaded after every save and downloaded at sign-in.

const Profile = preload("res://scripts/profile.gd")

const URL := "https://jrbfbvlwngvjzddfuesu.supabase.co"
const KEY := "sb_publishable_Oh8bUHeWTKHi1qyqZF9YiQ_WHXwReEa"     # publishable key (safe in the client, data protected by RLS)
const FILE := "user://account.cfg"
const TABLE := "tf24_profiles"

var uid := ""
var email := ""
var access := ""
var refresh_tok := ""
var expires_at := 0.0
var status := ""                 # last message for the UI
var _push_t := -1.0
var _busy_push := false
var recovery := false            # signed in through a password-reset link: the next password typed in is saved

# The mails of the project (confirm address, reset password) lead to the Site URL http://localhost:3000.
# While such a mail is on its way the game listens there itself: clicking the link on this computer
# opens a small page that hands the login over to the game - no web site needed.
signal link_done(kind: String, ok: bool, msg: String)
const LINK_PORT := 3000
const LINK_WAIT := 1800.0        # listen for 30 minutes after a mail was sent
var _srv: TCPServer
var _peers: Array = []
var _srv_until := 0.0


func _ready() -> void:
	Engine.set_meta("account", self)
	var cf := ConfigFile.new()
	if cf.load(FILE) == OK:
		uid = cf.get_value("a", "uid", "")
		email = cf.get_value("a", "email", "")
		refresh_tok = cf.get_value("a", "refresh", "")


func signed_in() -> bool:
	return uid != "" and refresh_tok != ""


func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("a", "uid", uid)
	cf.set_value("a", "email", email)
	cf.set_value("a", "refresh", refresh_tok)
	cf.save(FILE)


# ------------------------------------------------------------------ http
func _request(method: int, path: String, body = null, auth := false, extra: PackedStringArray = PackedStringArray()) -> Dictionary:
	var http := HTTPRequest.new()
	http.timeout = 15.0
	add_child(http)
	var headers := PackedStringArray(["apikey: " + KEY, "Content-Type: application/json"])
	if auth and access != "":
		headers.append("Authorization: Bearer " + access)
	headers.append_array(extra)
	var data := "" if body == null else JSON.stringify(body)
	var err := http.request(URL + path, headers, method, data)
	if err != OK:
		http.queue_free()
		return {"ok": false, "code": 0, "data": null, "error": "Keine Internetverbindung"}
	var res: Array = await http.request_completed
	http.queue_free()
	var code: int = res[1]
	var txt: String = (res[3] as PackedByteArray).get_string_from_utf8()
	var parsed = JSON.parse_string(txt) if txt != "" else null
	if res[0] != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "code": 0, "data": null, "error": "Keine Internetverbindung"}
	return {"ok": code >= 200 and code < 300, "code": code, "data": parsed, "error": _err_text(code, parsed)}


func _err_text(code: int, d) -> String:
	if code >= 200 and code < 300:
		return ""
	var msg := ""
	if d is Dictionary:
		msg = String(d.get("msg", d.get("error_description", d.get("message", d.get("error", "")))))
	var low := msg.to_lower()
	if "invalid login" in low or "invalid_grant" in low or "invalid credentials" in low:
		return "E-Mail oder Passwort falsch."
	if "already registered" in low or "already exists" in low:
		return "Diese E-Mail hat schon ein Konto – bitte anmelden."
	if "password should be" in low or "weak" in low:
		return "Das Passwort muss mindestens 6 Zeichen haben."
	if "invalid" in low and "email" in low:
		return "Diese E-Mail-Adresse ist ungültig."
	if "not confirmed" in low:
		return "Bitte bestätige zuerst die E-Mail (Link im Postfach)."
	if "rate limit" in low or code == 429:
		return "Zu viele Versuche – bitte kurz warten."
	return "Fehler %d: %s" % [code, msg] if msg != "" else "Fehler %d" % code


func _take_session(d: Dictionary) -> void:
	access = String(d.get("access_token", ""))
	refresh_tok = String(d.get("refresh_token", refresh_tok))
	expires_at = Time.get_unix_time_from_system() + float(d.get("expires_in", 3600)) - 60.0
	var u: Dictionary = d.get("user", {})
	uid = String(u.get("id", uid))
	email = String(u.get("email", email))
	_save()


# ------------------------------------------------------------------ auth
func sign_up(mail: String, pw: String) -> Dictionary:
	var r := await _request(HTTPClient.METHOD_POST, "/auth/v1/signup", {"email": mail.strip_edges(), "password": pw})
	if not r["ok"]:
		return r
	var d: Dictionary = r["data"]
	if d.has("access_token"):
		_take_session(d)
		return r
	# an address that already has an account gets an answer without identities and no mail
	var ids = d.get("identities")
	if ids is Array and (ids as Array).is_empty():
		return _fail("Diese E-Mail hat schon ein Konto (auch Konten aus deinen anderen Apps zählen). "
				+ "Melde dich mit dem Passwort dazu an – oder drück PASSWORT VERGESSEN.")
	return _fail(_mail_sent_text("Bestätigungs-Mail"))


func sign_in(mail: String, pw: String) -> Dictionary:
	var r := await _request(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=password", {"email": mail.strip_edges(), "password": pw})
	if r["ok"]:
		recovery = false
		_take_session(r["data"])
	elif "bestätige" in String(r["error"]):
		# not confirmed yet: send the mail once more
		var rs := await _request(HTTPClient.METHOD_POST, "/auth/v1/resend", {"type": "signup", "email": mail.strip_edges()})
		r["error"] = _mail_sent_text("Bestätigungs-Mail") if rs["ok"] else String(rs["error"])
	return r


func reset_password(mail: String) -> Dictionary:
	var r := await _request(HTTPClient.METHOD_POST, "/auth/v1/recover", {"email": mail.strip_edges()})
	if r["ok"]:
		r["error"] = _mail_sent_text("Mail zum Zurücksetzen")
	return r


# signed in through the reset link: store the new password
func set_password(pw: String) -> Dictionary:
	if not await ensure_session():
		return _fail("Bitte den Link aus der Mail noch einmal öffnen.")
	var r := await _request(HTTPClient.METHOD_PUT, "/auth/v1/user", {"password": pw}, true)
	if r["ok"]:
		recovery = false
	return r


func _fail(msg: String) -> Dictionary:
	return {"ok": false, "code": 200, "data": null, "error": msg}


func _mail_sent_text(what: String) -> String:
	if listen_for_link():
		return what + " ist unterwegs! Öffne den Link in der Mail auf DIESEM Computer – das Spiel meldet dich dann " \
				+ "automatisch an. Keine Mail da? Schau im Spam-Ordner nach (Absender: Supabase)."
	return what + " ist unterwegs! Öffne den Link in der Mail und melde dich danach hier an. " \
			+ "Keine Mail da? Schau im Spam-Ordner nach (Absender: Supabase)."


func ensure_session() -> bool:
	if refresh_tok == "":
		return false
	if access != "" and Time.get_unix_time_from_system() < expires_at:
		return true
	var r := await _request(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=refresh_token", {"refresh_token": refresh_tok})
	if r["ok"]:
		_take_session(r["data"])
		return true
	if int(r["code"]) == 400 or int(r["code"]) == 401:
		sign_out()          # refresh token no longer valid
	return false


func sign_out() -> void:
	uid = ""
	email = ""
	access = ""
	refresh_tok = ""
	DirAccess.remove_absolute(ProjectSettings.globalize_path(FILE))


# ------------------------------------------------------------------ profile data
static func to_cloud(p: Dictionary) -> Dictionary:
	var d := p.duplicate(true)
	d.erase("pw")
	d["c1"] = (p["c1"] as Color).to_html(false)
	d["c2"] = (p["c2"] as Color).to_html(false)
	return d


const FLOAT_KEYS := ["dr", "sr", "km", "time", "saved_at", "gain", "best", "lap", "d_dr", "d_sr"]


# JSON turns every number into a float: counts, numbers and positions become whole numbers again
static func _ints(v, key: String = ""):
	if key in FLOAT_KEYS:
		return v            # real decimal values (ratings, distances, lap times) stay as they are
	if v is Dictionary:
		var o := {}
		for k in v.keys():
			o[k] = _ints(v[k], String(k))
		return o
	if v is Array:
		var a: Array = []
		for x in v:
			a.append(_ints(x, key))
		return a
	if v is float and not key in FLOAT_KEYS and key != "" and fmod(v, 1.0) == 0.0 and absf(v) < 1e9:
		return int(v)
	return v


static func from_cloud(d: Dictionary, into: Dictionary) -> Dictionary:
	d = _ints(d)
	for k in d.keys():
		if k == "c1" or k == "c2":
			into[k] = Color.html(String(d[k]))
		elif k != "pw":
			into[k] = d[k]
	if not into.has("pw"):
		into["pw"] = ""
	return into


func download() -> Dictionary:
	if not await ensure_session():
		return {"ok": false, "error": "Nicht angemeldet"}
	var r := await _request(HTTPClient.METHOD_GET, "/rest/v1/%s?user_id=eq.%s&select=data" % [TABLE, uid], null, true)
	if not r["ok"]:
		return r
	var rows: Array = r["data"] if r["data"] is Array else []
	return {"ok": true, "data": rows[0]["data"] if rows.size() > 0 else null}


func upload(p: Dictionary) -> bool:
	if not await ensure_session():
		return false
	p["saved_at"] = Time.get_unix_time_from_system()
	var row := {"user_id": uid, "data": to_cloud(p), "updated_at": Time.get_datetime_string_from_system(true) + "Z"}
	var r := await _request(HTTPClient.METHOD_POST, "/rest/v1/" + TABLE, [row], true,
		PackedStringArray(["Prefer: resolution=merge-duplicates,return=minimal"]))
	status = "Profil online gespeichert" if r["ok"] else String(r["error"])
	return r["ok"]


# called whenever profiles are saved: uploads the linked profile a moment later (one upload per burst)
func push_soon() -> void:
	_push_t = 2.0


func _process(dt: float) -> void:
	if _srv != null:
		_poll_link()
	if _push_t < 0.0:
		return
	_push_t -= dt
	if _push_t <= 0.0 and not _busy_push:
		_push_t = -1.0
		var p: Dictionary = Profile.current
		if signed_in() and not p.is_empty() and String(p.get("cloud_uid", "")) == uid:
			_busy_push = true
			await upload(p)
			_busy_push = false


# ------------------------------------------------------------------ mail links (http://localhost:3000)
func listen_for_link() -> bool:
	_srv_until = Time.get_unix_time_from_system() + LINK_WAIT
	if _srv != null and _srv.is_listening():
		return true
	_srv = TCPServer.new()
	if _srv.listen(LINK_PORT, "127.0.0.1") != OK:
		_srv = null
		return false
	return true


func _stop_link() -> void:
	if _srv != null:
		_srv.stop()
	_srv = null
	_peers.clear()


func _poll_link() -> void:
	var now := Time.get_unix_time_from_system()
	if now > _srv_until:
		_stop_link()
		return
	while _srv.is_connection_available():
		_peers.append({"p": _srv.take_connection(), "buf": "", "t": now})
	for q in _peers.duplicate():
		var peer: StreamPeerTCP = q["p"]
		peer.poll()
		var n := peer.get_available_bytes()
		if n > 0:
			var got: Array = peer.get_partial_data(n)
			q["buf"] += (got[1] as PackedByteArray).get_string_from_utf8()
		if "\r\n\r\n" in String(q["buf"]):
			_answer(peer, String(q["buf"]).get_slice("\r\n", 0))
			_peers.erase(q)
		elif now - float(q["t"]) > 10.0 or peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
			peer.disconnect_from_host()
			_peers.erase(q)
		if _srv == null:
			return


func _answer(peer: StreamPeerTCP, line: String) -> void:
	var target := line.get_slice(" ", 1)
	var path := target.get_slice("?", 0)
	if path == "/cb":
		var q := _params(target.get_slice("?", 1) if "?" in target else "")
		if q.has("access_token") and q.has("refresh_token"):
			_stop_link()
			# the page waits until the game has checked the login with the server
			var ok: bool = await _link_login(q)
			var txt := "Anmeldung über den Link hat nicht geklappt – bitte im Spiel neu versuchen."
			if ok:
				txt = "Link angenommen! Zurück ins Spiel und dort oben dein neues Passwort eingeben." if recovery \
						else "E-Mail bestätigt – du bist angemeldet! Du kannst dieses Fenster schließen und ins Spiel zurückgehen."
			_reply(peer, 200, "text/plain", txt)
			return
		var e := String(q.get("error_description", q.get("error", ""))).to_lower()
		var msg := "Dieser Link ist abgelaufen oder wurde schon benutzt. Fordere im Spiel einfach einen neuen an." \
				if ("expired" in e or "invalid" in e) else "Kein Anmelde-Link gefunden. Bitte den Link aus der Mail öffnen."
		link_done.emit("error", false, msg)
		_reply(peer, 200, "text/plain", msg)
	elif path == "/":
		_reply(peer, 200, "text/html", LINK_PAGE)
	else:
		_reply(peer, 404, "text/plain", "")


func _reply(peer: StreamPeerTCP, code: int, ctype: String, body: String) -> void:
	var data := body.to_utf8_buffer()
	var head := "HTTP/1.1 %d %s\r\nContent-Type: %s; charset=utf-8\r\nContent-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n" \
			% [code, "OK" if code == 200 else "Not Found", ctype, data.size()]
	peer.put_data(head.to_utf8_buffer())
	peer.put_data(data)
	peer.disconnect_from_host()


static func _params(qs: String) -> Dictionary:
	var d := {}
	for part in qs.split("&", false):
		d[part.get_slice("=", 0).uri_decode()] = part.get_slice("=", 1).replace("+", " ").uri_decode() if "=" in part else ""
	return d


func _link_login(q: Dictionary) -> bool:
	access = String(q["access_token"])
	refresh_tok = String(q["refresh_token"])
	expires_at = Time.get_unix_time_from_system() + float(q.get("expires_in", "3600")) - 60.0
	var r := await _request(HTTPClient.METHOD_GET, "/auth/v1/user", null, true)
	if not r["ok"] or not r["data"] is Dictionary:
		access = ""
		link_done.emit("error", false, "Anmeldung über den Link fehlgeschlagen: " + String(r["error"]))
		return false
	uid = String(r["data"].get("id", ""))
	email = String(r["data"].get("email", ""))
	_save()
	var kind := String(q.get("type", "signup"))
	recovery = kind == "recovery"
	link_done.emit(kind, true, "")
	return true


# the page behind the link: the login sits after the "#" (never sent to a server), the script hands it over
const LINK_PAGE := """<!doctype html><html lang="de"><head><meta charset="utf-8"><title>Trois Forêts 24</title></head>
<body style="background:#0b0f1a;color:#fff;font:20px -apple-system,Segoe UI,sans-serif;text-align:center;padding-top:16vh">
<div style="font-size:44px;font-weight:800;letter-spacing:2px">TROIS FORÊTS 24</div>
<p id="m" style="margin-top:28px;color:#f3c94b">Einen Moment …</p>
<script>
var h = location.hash.length > 1 ? location.hash.substring(1) : location.search.substring(1);
fetch('/cb?' + h).then(function (r) { return r.text(); })
  .then(function (t) { document.getElementById('m').textContent = t; })
  .catch(function () { document.getElementById('m').textContent = 'Das Spiel antwortet nicht – läuft es noch?'; });
</script></body></html>"""

# Trackside dressing: red/white tyre walls in the run-off of the slow corners, distance boards before the
# braking zones, floodlight masts on the main straight, marshal posts with a marshal, team flags and pit signs.
# Model files (props/*.bin = glTF binary) come from "Race Track Assets Pack" by Cherk (CC-BY 4.0);
# everything else is built here. Every item checks the space it needs, so nothing overlaps or floats.
extends RefCounted

const Gfx = preload("res://scripts/gfx.gd")

var W            # world builder
var T            # track
var tyre_zone := PackedByteArray()   # 1 = tyre wall on the left (bit 0) / right (bit 1) at this sample
var _mesh_cache := {}
var _used: Array = []                # [s, side, half_len] spots already taken next to the track
var spots := {}                      # kind -> [Vector2(s, lat)] (used by the camera views)


func build(world) -> void:
	W = world
	T = world.T
	_tyre_walls()
	_brake_boards()
	_floodmasts()
	_marshal_posts()
	_flags()
	_pit_signs()


# ---------------------------------------------------------------- model loading
# loads props/<name>.bin (glTF binary) and merges all its parts into one mesh; null if the file is missing
func model(name: String) -> ArrayMesh:
	if _mesh_cache.has(name):
		return _mesh_cache[name]
	var out: ArrayMesh = null
	var path := "res://props/%s.bin" % name
	if FileAccess.file_exists(path):
		var bytes := FileAccess.get_file_as_bytes(path)
		var doc := GLTFDocument.new()
		var st := GLTFState.new()
		if bytes.size() > 0 and doc.append_from_buffer(bytes, "", st) == OK:
			var scene: Node = doc.generate_scene(st)
			if scene != null:
				out = ArrayMesh.new()
				_merge(scene, Transform3D.IDENTITY, out)
				scene.free()
				if out.get_surface_count() == 0:
					out = null
	_mesh_cache[name] = out
	return out


func _merge(n: Node, parent_xf: Transform3D, out: ArrayMesh) -> void:
	var xf := parent_xf
	if n is Node3D:
		xf = parent_xf * (n as Node3D).transform
	var mesh: Mesh = null
	if n is MeshInstance3D:
		mesh = (n as MeshInstance3D).mesh
	elif n is ImporterMeshInstance3D:
		var im: ImporterMesh = (n as ImporterMeshInstance3D).mesh
		if im != null:
			mesh = im.get_mesh()
	if mesh != null:
		var nb := xf.basis.inverse().transposed()
		for si in mesh.get_surface_count():
			var arr: Array = mesh.surface_get_arrays(si)
			var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
			for k in v.size():
				v[k] = xf * v[k]
			arr[Mesh.ARRAY_VERTEX] = v
			if arr[Mesh.ARRAY_NORMAL] != null:
				var nr: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
				for k in nr.size():
					nr[k] = (nb * nr[k]).normalized()
				arr[Mesh.ARRAY_NORMAL] = nr
			arr[Mesh.ARRAY_TANGENT] = null
			for extra in [Mesh.ARRAY_BONES, Mesh.ARRAY_WEIGHTS]:
				arr[extra] = null
			out.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
			var m: Material = mesh.surface_get_material(si)
			if n is MeshInstance3D and (n as MeshInstance3D).get_surface_override_material(si) != null:
				m = (n as MeshInstance3D).get_surface_override_material(si)
			out.surface_set_material(out.get_surface_count() - 1, m)
	for c in n.get_children():
		_merge(c, xf, out)


# ---------------------------------------------------------------- space bookkeeping
func _spot(kind: String, s: float, lat: float) -> void:
	if not spots.has(kind):
		spots[kind] = []
	var l: Array = spots[kind]
	l.append(Vector2(s, lat))


func _free(s: float, side: float, half_len: float) -> bool:
	for u in _used:
		var a: Array = u
		if float(a[1]) != side:
			continue
		if absf(wrapf(s - float(a[0]), -T.length * 0.5, T.length * 0.5)) < half_len + float(a[2]):
			return false
	return true


func _take(s: float, side: float, half_len: float) -> void:
	_used.append([s, side, half_len])


func _in_stand(s: float, margin: float) -> bool:
	for zv in W.stand_zones:
		var zz: Array = zv
		if T.in_range(s, float(zz[0]) - margin, float(zz[1]) + margin):
			return true
	return false


func _near_list(s: float, list: Array, d: float) -> bool:
	for v in list:
		var x: float = v[0] if v is Array else float(v)
		if absf(wrapf(s - x, -T.length * 0.5, T.length * 0.5)) < d:
			return true
	return false


func _bar(i: int, side: float) -> float:
	return T.bar_r[i] if side > 0.0 else T.bar_l[i]


func _xf_at(s: float, lat: float, yoff: float, rot_y: float = 0.0, scl := Vector3.ONE) -> Transform3D:
	var i: int = T.idx(s)
	var p: Vector4 = T.point_at(s, lat)
	var b := Basis(Vector3(T.tx[i], 0, T.tz[i]).normalized(), Vector3.UP, Vector3(T.rx[i], 0, T.rz[i]).normalized())
	return Transform3D(b * Basis(Vector3.UP, rot_y).scaled(scl), Vector3(p.x, p.y + yoff, p.z))


# ---------------------------------------------------------------- tyre walls
# a single row of stacked red/white tyres in front of the barrier on the outside of every slow corner;
# the collision line of the barrier moves in by the depth of the tyres
func _tyre_walls() -> void:
	tyre_zone.resize(T.N)
	tyre_zone.fill(0)
	const DEPTH := 0.7
	var ext := int(30.0 / T.ds)
	var mark := PackedByteArray()
	mark.resize(T.N)
	for side in [-1.0, 1.0]:
		var sd: float = side
		mark.fill(0)
		for i in T.N:
			var k: float = T.kap[i]
			if absf(k) < 1.0 / 110.0:
				continue
			var outer := -1.0 if k > 0.0 else 1.0
			if outer != sd:
				continue
			for o in range(-ext, ext + 1):
				mark[(i + o + T.N) % T.N] = 1
		for i in T.N:
			if mark[i] == 0:
				continue
			if sd > 0.0 and T.pit_open[i] == 1:
				mark[i] = 0
			elif _bar(i, sd) - DEPTH < T.half_w + 2.5:
				mark[i] = 0     # no run-off: the tyres would stand on the kerb
		for i in T.N:
			if mark[i] == 1:
				tyre_zone[i] |= (1 if sd < 0.0 else 2)
	var xfs := [[], []]
	var red := Color(0.82, 0.07, 0.07)
	var white := Color(0.93, 0.93, 0.92)
	var pad_done: bool = T.has_meta("tyre_pad")
	for side in [-1.0, 1.0]:
		var sd: float = side
		var bit := 1 if sd < 0.0 else 2
		var stack := 0
		for i in T.N:
			if (tyre_zone[i] & bit) == 0:
				continue
			var bar: float = _bar(i, sd)
			# 0.66 m apart: three stacks per 2 m sample
			var per := maxi(1, int(roundf(T.ds / 0.66)))
			for q in per:
				var s: float = i * T.ds + q * T.ds / per
				var p: Vector4 = T.point_at(s, sd * (bar - DEPTH * 0.5))
				if stack % 40 == 0:
					_spot("tyres", s, sd * (bar - DEPTH * 0.5))
				var l: Array = xfs[stack % 2]
				l.append(Transform3D(Basis(Vector3.UP, float(stack) * 1.7), Vector3(p.x, p.y - 0.02, p.z)))
				stack += 1
			if not pad_done:
				if sd > 0.0:
					T.bar_r[i] = bar - DEPTH
				else:
					T.bar_l[i] = bar - DEPTH
	T.set_meta("tyre_pad", true)
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.85
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	for v in 2:
		var l: Array = xfs[v]
		if l.is_empty():
			continue
		var mesh := _tyre_stack(red if v == 0 else white, white if v == 0 else red)
		mesh.surface_set_material(0, m)
		W._chunked(mesh, l, [], 120.0, 0.0, 420.0, W.quality != "low", 1)


# four tyres on top of each other in alternating colours (one mesh = one stack)
func _tyre_stack(c0: Color, c1: Color) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	const SEG := 10
	const R := 0.33
	const H := 0.255
	for h in 4:
		var col := c0 if h % 2 == 0 else c1
		var y0 := h * H
		var y1 := y0 + H - 0.01
		for k in SEG:
			var a0 := TAU * k / SEG
			var a1 := TAU * (k + 1) / SEG
			# slightly bulged sidewall: two rings
			var pts := [[R * 0.93, y0], [R, (y0 + y1) * 0.5], [R * 0.93, y1]]
			for j in 2:
				var ra: float = pts[j][0]
				var rb: float = pts[j + 1][0]
				var ya: float = pts[j][1]
				var yb: float = pts[j + 1][1]
				var v00 := Vector3(cos(a0) * ra, ya, sin(a0) * ra)
				var v10 := Vector3(cos(a1) * ra, ya, sin(a1) * ra)
				var v01 := Vector3(cos(a0) * rb, yb, sin(a0) * rb)
				var v11 := Vector3(cos(a1) * rb, yb, sin(a1) * rb)
				var n0 := Vector3(cos(a0), 0.0, sin(a0))
				var n1 := Vector3(cos(a1), 0.0, sin(a1))
				for vv in [[v00, n0], [v01, n0], [v10, n1], [v10, n1], [v01, n0], [v11, n1]]:
					st.set_color(col * (0.9 if j == 0 else 1.0))
					st.set_normal(vv[1])
					st.add_vertex(vv[0])
	# top: dark hole in the middle, tyre ring around it
	var yt := 4 * H - 0.01
	for k in SEG:
		var a0 := TAU * k / SEG
		var a1 := TAU * (k + 1) / SEG
		var o0 := Vector3(cos(a0) * R * 0.93, yt, sin(a0) * R * 0.93)
		var o1 := Vector3(cos(a1) * R * 0.93, yt, sin(a1) * R * 0.93)
		var i0 := Vector3(cos(a0) * R * 0.55, yt, sin(a0) * R * 0.55)
		var i1 := Vector3(cos(a1) * R * 0.55, yt, sin(a1) * R * 0.55)
		var top := c1 if 3 % 2 == 1 else c0
		for vv in [[o0, top], [o1, top], [i0, top], [i0, top], [o1, top], [i1, top]]:
			st.set_color(vv[1])
			st.set_normal(Vector3.UP)
			st.add_vertex(vv[0])
		for vv in [i0, i1, Vector3(0, yt - 0.25, 0)]:
			st.set_color(Color(0.03, 0.03, 0.03))
			st.set_normal(Vector3.UP)
			st.add_vertex(vv)
	return st.commit()


# ---------------------------------------------------------------- distance boards
func _brake_boards() -> void:
	var vp: PackedFloat32Array = T.speed_profile({"cls": "boards", "mu": 1.75, "ClA": 3.4, "CdA": 0.93, "mass": 1030.0, "vmax": 94.0, "power": 500000.0})
	var pole := Gfx.mat(Color(0.25, 0.25, 0.26), 0.5, 0.6)
	var white := Gfx.mat(Color(0.95, 0.95, 0.95), 0.6)
	var last := -1e9
	for i: int in T.N:
		var s: float = i * T.ds
		if s - last < 450.0:
			continue
		var ahead: int = (i + int(300.0 / T.ds)) % T.N
		if not (vp[i] > 70.0 and vp[ahead] < vp[i] - 28.0):
			continue
		var entry := ahead
		for k in 160:
			var jj: int = (ahead - k + T.N) % T.N
			if vp[jj] >= vp[i] - 3.0:
				entry = jj
				break
		var side := -1.0 if T.kap[ahead] > 0.0 else 1.0
		if side > 0.0 and T.pit_open[T.idx(entry * T.ds - 220.0)] == 1:
			side = -1.0
		for d in [200, 150, 100, 50]:
			var se: float = entry * T.ds - d
			var ii: int = T.idx(se)
			var lat: float = side * (_bar(ii, side) - 0.9)
			var n: Node3D = W.node_at(se, lat)
			W.box(n, Vector3(0.08, 1.25, 0.08), Vector3(0, 0.62, 0), pole, false)
			_spot("board", se, lat)
			var mm := model("brake%d" % d)
			if mm != null:
				var mi := MeshInstance3D.new()
				mi.mesh = mm
				# the board faces the cars coming towards it
				mi.transform = Transform3D(Basis(Vector3.UP, -PI / 2).scaled(Vector3(1.6, 1.6, 1.6)), Vector3(0, 1.2, 0))
				mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				n.add_child(mi)
			else:
				W.box(n, Vector3(0.05, 0.8, 1.6), Vector3(0, 1.6, 0), white, false)
				W.label(n, str(d), Vector3(-0.04, 1.6, 0), 140, Color(0.05, 0.05, 0.05), Vector3(0, -PI / 2, 0), 0.005)
			_take(se, side, 2.0)
		last = s


# ---------------------------------------------------------------- floodlights on the main straight
func _floodmasts() -> void:
	var mm := model("floodmast")
	if mm == null:
		return
	var xfs: Array = []
	var s := -420.0
	while s < 560.0:
		var ss := fposmod(s, T.length)
		var i: int = T.idx(ss)
		if not _in_stand(ss, 18.0) and not _near_list(ss, [6.0], 15.0) and not _near_list(ss, T.def.get("bridges", []), 25.0) \
				and absf(T.kap[i]) < 1.0 / 400.0 and _free(ss, -1.0, 6.0):
			xfs.append(_xf_at(ss, -(T.bar_l[i] + 3.6), -0.3, PI / 2))
			_spot("mast", ss, -(T.bar_l[i] + 3.6))
			_take(ss, -1.0, 2.0)
		s += 85.0
	if not xfs.is_empty():
		W._chunked(mm, xfs, [], 300.0, 0.0, 1400.0, W.quality in ["high", "ultra"], 1)


# ---------------------------------------------------------------- marshal posts
func _marshal_posts() -> void:
	var steel := Gfx.mat(Color(0.62, 0.64, 0.66), 0.45, 0.7)
	var sheet := Gfx.mat(Color(0.72, 0.74, 0.76), 0.5, 0.6)
	sheet.cull_mode = BaseMaterial3D.CULL_DISABLED
	var panel := Gfx.mat(Color(0.9, 0.9, 0.9), 0.7)
	var fire := Gfx.mat(Color(0.85, 0.08, 0.06), 0.5)
	var aid := Gfx.mat(Color(0.05, 0.55, 0.25), 0.5)
	var orange := Gfx.mat(Color(1.0, 0.45, 0.05), 0.7)
	var skin := Gfx.mat(Color(0.85, 0.65, 0.52), 0.6)
	var yellow := Gfx.mat(Color(1.0, 0.85, 0.05), 0.6)
	yellow.cull_mode = BaseMaterial3D.CULL_DISABLED
	var corners: Array = []
	for c in T.def.get("corners", []):
		corners.append(c[0])
	var s := 150.0
	var n_post := 0
	while s < T.length - 60.0:
		var placed := false
		for tryk in 6:
			var ss: float = s + tryk * 25.0
			var i: int = T.idx(ss)
			var side := 1.0 if (n_post % 2 == 0) else -1.0
			for _sw in 2:
				if side > 0.0 and T.pit_open[i] == 1:
					side = -side
					continue
				var lat: float = side * (_bar(i, side) + 2.7)
				var p: Vector4 = T.point_at(ss, lat)
				var th: float = W.terrain_height(p.x, p.z)
				var ok: bool = not _in_stand(ss, 20.0) and not _near_list(ss, corners, 45.0) and not _near_list(ss, T.def.get("bridges", []), 30.0) \
						and not _near_list(ss, [6.0], 30.0) and _free(ss, side, 4.0) and th < p.y + 0.8 and th > p.y - 2.2 \
						and T.lN > 0 and not T.in_range(ss, T.pit_in - 30.0, T.pit_out + 30.0) and (tyre_zone[i] == 0)
				if ok:
					_spot("marshal", ss, lat)
					_marshal(ss, lat, side, maxf(p.y, th) + 0.45 - p.y, th - p.y, steel, sheet, panel, fire, aid, orange, skin, yellow)
					_take(ss, side, 4.0)
					placed = true
					break
				side = -side
			if placed:
				break
		n_post += 1
		s += 620.0


func _marshal(s: float, lat: float, side: float, floor_y: float, ground_y: float, steel, sheet, panel, fire, aid, orange, skin, yellow) -> void:
	var n: Node3D = W.node_at(s, lat)
	# local frame: -Z points to the track
	if side < 0.0:
		n.rotate_y(PI)
	var fy := floor_y
	var leg := fy - ground_y + 0.3
	W.box(n, Vector3(3.0, 0.08, 2.0), Vector3(0, fy, 0), Gfx.mat(Color(0.5, 0.52, 0.55), 0.6, 0.5))   # chequer-plate floor
	for x in [-1.45, 1.45]:
		for z in [-0.95, 0.95]:
			W.box(n, Vector3(0.08, leg, 0.08), Vector3(x, fy - leg * 0.5, z), steel, false)
			W.box(n, Vector3(0.08, 2.6 if z < 0.0 else 2.35, 0.08), Vector3(x, fy + (1.3 if z < 0.0 else 1.18), z), steel)
	W.box(n, Vector3(0.08, 2.6, 0.08), Vector3(0, fy + 1.3, -0.95), steel, false)
	# corrugated roof sloping to the back
	var roof: MeshInstance3D = W.box(n, Vector3(3.5, 0.05, 2.5), Vector3(0, fy + 2.5, 0), sheet)
	roof.rotation.x = -0.12
	for k in 9:
		var rr: MeshInstance3D = W.box(n, Vector3(0.05, 0.06, 2.5), Vector3(-1.6 + k * 0.4, fy + 2.54, 0), sheet, false)
		rr.rotation.x = -0.12
	# waist-high walls: corrugated back and sides, white front panel with safety signs
	W.box(n, Vector3(3.0, 1.0, 0.04), Vector3(0, fy + 0.55, 0.95), sheet)
	W.box(n, Vector3(0.04, 1.0, 1.9), Vector3(-1.48, fy + 0.55, 0), sheet)
	W.box(n, Vector3(0.04, 1.0, 1.9), Vector3(1.48, fy + 0.55, 0), sheet)
	W.box(n, Vector3(3.0, 1.0, 0.04), Vector3(0, fy + 0.55, -0.96), panel)
	W.box(n, Vector3(0.5, 0.65, 0.02), Vector3(-1.0, fy + 0.6, -0.99), fire, false)
	W.label(n, "FIRE", Vector3(-1.0, fy + 0.45, -1.005), 60, Color.WHITE, Vector3(0, PI, 0), 0.006)
	W.box(n, Vector3(0.5, 0.65, 0.02), Vector3(1.0, fy + 0.6, -0.99), aid, false)
	W.label(n, "+", Vector3(1.0, fy + 0.62, -1.005), 120, Color.WHITE, Vector3(0, PI, 0), 0.006)
	# marshal in orange overalls with a rolled yellow flag
	var body := MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.2
	cap.height = 1.25
	body.mesh = cap
	body.material_override = orange
	body.position = Vector3(0.35, fy + 0.68, 0.1)
	n.add_child(body)
	var head := MeshInstance3D.new()
	var sp := SphereMesh.new()
	sp.radius = 0.12
	sp.height = 0.24
	head.mesh = sp
	head.material_override = skin
	head.position = Vector3(0.35, fy + 1.45, 0.1)
	n.add_child(head)
	W.box(n, Vector3(0.02, 1.2, 0.02), Vector3(0.62, fy + 1.05, -0.05), steel, false)
	W.box(n, Vector3(0.01, 0.55, 0.7), Vector3(0.62, fy + 1.35, -0.42), yellow, false)
	# fire extinguisher at the post
	var ext := MeshInstance3D.new()
	var cy := CylinderMesh.new()
	cy.top_radius = 0.09
	cy.bottom_radius = 0.09
	cy.height = 0.5
	ext.mesh = cy
	ext.material_override = fire
	ext.position = Vector3(-1.1, fy + 0.3, 0.6)
	n.add_child(ext)


# ---------------------------------------------------------------- team flags along the main straight
func _flags() -> void:
	var img := Image.create(32, 128, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.96, 0.96, 0.96))
	for y in 128:
		for x in 32:
			if x < 7 or x > 24:
				var c := (int(x / 3.5) + int(y / 3.5)) % 2 == 0
				img.set_pixel(x, y, Color(0.04, 0.04, 0.05) if c else Color(0.96, 0.96, 0.96))
	img.generate_mipmaps()
	var tex := ImageTexture.create_from_image(img)
	var cloth := StandardMaterial3D.new()
	cloth.albedo_texture = tex
	cloth.roughness = 0.8
	cloth.cull_mode = BaseMaterial3D.CULL_DISABLED
	var pole := Gfx.mat(Color(0.75, 0.76, 0.78), 0.4, 0.7)
	var s := -260.0
	while s < 300.0:
		var ss := fposmod(s, T.length)
		var i: int = T.idx(ss)
		if not _in_stand(ss, 6.0) and not _near_list(ss, [6.0], 10.0) and absf(T.kap[i]) < 1.0 / 300.0 and _free(ss, -1.0, 2.5):
			var lat: float = -(T.bar_l[i] + 1.8)
			var n: Node3D = W.node_at(ss, lat)
			W.box(n, Vector3(0.05, 5.6, 0.05), Vector3(0, 2.6, 0), pole, false)
			var q := MeshInstance3D.new()
			var qm := QuadMesh.new()
			qm.size = Vector2(0.75, 2.6)
			q.mesh = qm
			q.material_override = cloth
			q.position = Vector3(0, 3.9, -0.4)
			q.rotation.y = PI / 2
			n.add_child(q)
			for f in [-1.0, 1.0]:
				W.label(n, "TROIS FORÊTS 24", Vector3(f * 0.012, 3.9, -0.4), 64, Color(0.85, 0.08, 0.1), Vector3(0, -f * PI / 2, PI / 2), 0.0055)
			_take(ss, -1.0, 1.0)
		s += 22.0


# ---------------------------------------------------------------- pit lane signs and cones
func _pit_signs() -> void:
	if T.lN == 0:
		return
	var pole := Gfx.mat(Color(0.3, 0.3, 0.32), 0.5, 0.6)
	var lim := model("limit60")
	if lim != null:
		for li in [T.lim_a]:
			var n: Node3D = W.lane_node(float(li) - 4.0, T.LANE_OUT + 1.3)
			W.box(n, Vector3(0.07, 1.4, 0.07), Vector3(0, 0.7, 0), pole, false)
			var mi := MeshInstance3D.new()
			mi.mesh = lim
			mi.transform = Transform3D(Basis(Vector3.UP, -PI / 2).scaled(Vector3(2.0, 2.0, 2.0)), Vector3(0, 1.3, 0))
			n.add_child(mi)
	# cones marking the garage corners of the own box
	var cone := model("cone")
	if cone != null and T.garage_ps.size() > 0:
		var bs: float = T.garage_ps[T.player_garage]
		for e in [-6.2, 6.2]:
			var n: Node3D = W.lane_node(bs + e, T.GARAGE_LAT + 0.45)
			var mi := MeshInstance3D.new()
			mi.mesh = cone
			n.add_child(mi)

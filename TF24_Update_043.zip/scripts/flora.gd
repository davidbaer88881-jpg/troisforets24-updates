# Vegetation for the Ardennes: Norway spruce and beech built from branch / leaf cards (alpha-cut textures
# painted at startup), with soft "round" crown normals, baked ambient occlusion, wind sway, light shining
# through the foliage and a near / far level of detail. Also the dense grass carpet along the track.
extends RefCounted

const Gfx = preload("res://scripts/gfx.gd")

const FOLIAGE_SHADER := """
shader_type spatial;
render_mode cull_disabled;
uniform sampler2D tex : source_color, filter_linear_mipmap, repeat_disable;
uniform float tsize = 256.0;
uniform float wind = 1.0;
uniform float flutter = 0.0;
void vertex() {
	vec3 o = MODEL_MATRIX[3].xyz;
	float h = max(VERTEX.y, 0.0);
	float sw = sin(TIME * 0.8 + o.x * 0.05 + o.z * 0.07) * 0.006 + sin(TIME * 1.9 + o.x * 0.21 + o.z * 0.13) * 0.003;
	VERTEX.x += sw * h * wind;
	VERTEX.z += sw * 0.6 * h * wind;
	VERTEX.y += sin(TIME * 5.0 + VERTEX.x * 2.3 + VERTEX.z * 1.7 + o.x) * flutter * 0.03 * wind;
}
void fragment() {
	vec4 t = texture(tex, UV);
	// keep the foliage dense in the distance: alpha shrinks in the mipmaps, push it back up
	vec2 fw = fwidth(UV) * tsize;
	float lod = log2(max(max(fw.x, fw.y), 1.0));
	ALPHA = clamp(t.a * (1.0 + lod * 0.45), 0.0, 1.0);
	ALPHA_SCISSOR_THRESHOLD = 0.5;
	vec3 c = t.rgb * COLOR.rgb;
	ALBEDO = c;
	ROUGHNESS = 0.82;
	SPECULAR = 0.22;
	NORMAL = FRONT_FACING ? NORMAL : -NORMAL;    // both sides use the crown normal
	BACKLIGHT = c * 0.55;
}
"""

const BARK_SHADER := """
shader_type spatial;
render_mode cull_disabled;
uniform sampler2D tex : source_color, filter_linear_mipmap, repeat_enable;
uniform float wind = 1.0;
void vertex() {
	vec3 o = MODEL_MATRIX[3].xyz;
	float h = max(VERTEX.y, 0.0);
	float sw = sin(TIME * 0.8 + o.x * 0.05 + o.z * 0.07) * 0.006 + sin(TIME * 1.9 + o.x * 0.21 + o.z * 0.13) * 0.003;
	VERTEX.x += sw * h * wind;
	VERTEX.z += sw * 0.6 * h * wind;
}
void fragment() {
	vec3 c = texture(tex, UV).rgb * COLOR.rgb;
	ALBEDO = c;
	ROUGHNESS = 0.95;
}
"""


# ---------------------------------------------------------------- painting helpers
static func _blend(img: Image, x: int, y: int, c: Color) -> void:
	var w := img.get_width()
	var h := img.get_height()
	if x < 0 or y < 0 or x >= w or y >= h:
		return
	img.set_pixel(x, y, c)


static func _line(img: Image, a: Vector2, b: Vector2, wa: float, wb: float, c: Color) -> void:
	var steps := int(maxf(2.0, a.distance_to(b) * 1.5))
	for k in steps + 1:
		var f := float(k) / steps
		var p := a.lerp(b, f)
		var r := lerpf(wa, wb, f) * 0.5
		var ri := int(ceilf(r))
		for dy in range(-ri, ri + 1):
			for dx in range(-ri, ri + 1):
				if dx * dx + dy * dy <= r * r + 0.3:
					_blend(img, int(p.x) + dx, int(p.y) + dy, c)


# transparent pixels get the average foliage colour, so the mipmaps do not darken the edges
static func _fill_bg(img: Image, c: Color) -> void:
	for y in img.get_height():
		for x in img.get_width():
			if img.get_pixel(x, y).a < 0.5:
				img.set_pixel(x, y, Color(c.r, c.g, c.b, 0.0))


# spruce branch seen from above: twig from the trunk (left) to the tip (right), side twigs, dense needles
static func spruce_branch() -> ImageTexture:
	var w := 256
	var h := 128
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 31
	var twigs: Array = []
	var main_a := Vector2(2, h * 0.5)
	var main_b := Vector2(w - 6, h * 0.5 + rnd.randf_range(-4, 4))
	twigs.append([main_a, main_b, 3.0])
	var nside := 14
	for k in nside:
		var f := 0.08 + 0.88 * float(k) / nside
		var base := main_a.lerp(main_b, f)
		var sd := -1.0 if k % 2 == 0 else 1.0
		var ln := (1.0 - f * 0.65) * h * rnd.randf_range(0.32, 0.46)
		var ang := sd * rnd.randf_range(0.55, 0.95)
		var tip := base + Vector2(cos(ang), sin(ang)) * ln
		twigs.append([base, tip, 1.6])
		# third-order twiglets
		for q in 2:
			var b2 := base.lerp(tip, 0.35 + q * 0.3)
			var a2 := ang + sd * 0.6 * (1.0 if q == 0 else -1.0) * 0.5
			twigs.append([b2, b2 + Vector2(cos(a2), sin(a2)) * ln * 0.4, 1.0])
	var greens := [Color(0.09, 0.19, 0.1), Color(0.12, 0.24, 0.12), Color(0.15, 0.29, 0.14), Color(0.11, 0.21, 0.13), Color(0.2, 0.34, 0.17)]
	# needles first (so the twigs stay visible as darker lines)
	for tw in twigs:
		var a: Vector2 = tw[0]
		var b: Vector2 = tw[1]
		var dirv := (b - a).normalized()
		var nrm := Vector2(-dirv.y, dirv.x)
		var n := int(a.distance_to(b) * 1.3)
		for k in n:
			var p := a.lerp(b, float(k) / maxf(1.0, n))
			for sd: float in [-1.0, 1.0]:
				var nl := rnd.randf_range(5.0, 9.0) * (1.0 - 0.4 * float(k) / maxf(1.0, n))
				var nd := (nrm * sd + dirv * rnd.randf_range(0.4, 0.9)).normalized()
				var col: Color = greens[rnd.randi() % greens.size()]
				# fresh light-green growth at the tips
				if float(k) / maxf(1.0, n) > 0.82 and rnd.randf() < 0.6:
					col = Color(0.3, 0.45, 0.2)
				col = col.lightened(rnd.randf_range(-0.1, 0.12))
				_line(img, p, p + nd * nl, 1.2, 0.8, col)
	for tw in twigs:
		_line(img, tw[0], tw[1], float(tw[2]), float(tw[2]) * 0.5, Color(0.22, 0.16, 0.1))
	_fill_bg(img, Color(0.12, 0.23, 0.12))
	return Gfx.image_tex(img)


# a cluster of beech leaves: overlapping ovals in many greens with a midrib, some light and shadow
static func leaf_cluster() -> ImageTexture:
	var s := 256
	var img := Image.create_empty(s, s, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 57
	var c0 := Vector2(s * 0.5, s * 0.5)
	# a few twigs radiating from the centre
	for k in 7:
		var a := rnd.randf() * TAU
		_line(img, c0, c0 + Vector2(cos(a), sin(a)) * s * 0.42, 2.0, 0.8, Color(0.25, 0.19, 0.12))
	var leaves := 300
	for k in leaves:
		var r := sqrt(rnd.randf()) * s * 0.44
		var a := rnd.randf() * TAU
		var p := c0 + Vector2(cos(a), sin(a)) * r
		var ln := rnd.randf_range(9.0, 15.0)
		var wd := ln * rnd.randf_range(0.48, 0.62)
		var rot := rnd.randf() * TAU
		var shade := rnd.randf_range(0.7, 1.15) * (1.0 - 0.25 * (1.0 - r / (s * 0.44)))
		var base := Color(0.23, 0.42, 0.12).lerp(Color(0.38, 0.52, 0.16), rnd.randf()) * shade
		var cr := cos(rot)
		var sr := sin(rot)
		var ext := int(ln) + 1
		for dy in range(-ext, ext + 1):
			for dx in range(-ext, ext + 1):
				var lx := dx * cr + dy * sr
				var ly := -dx * sr + dy * cr
				var e := (lx * lx) / (ln * ln * 0.25) + (ly * ly) / (wd * wd * 0.25)
				if e <= 1.0:
					var c := base.lightened(0.08 * (1.0 - e)) if ly < 0.0 else base.darkened(0.08 * e)
					if absf(ly) < 0.7 and absf(lx) < ln * 0.45:
						c = base.darkened(0.25)
					c.a = 1.0
					_blend(img, int(p.x) + dx, int(p.y) + dy, c)
	_fill_bg(img, Color(0.28, 0.45, 0.14))
	return Gfx.image_tex(img)


static func bark(spruce: bool) -> ImageTexture:
	var w := 64
	var h := 256
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	var n := Gfx.noise(77 if spruce else 78, 0.05, 4)
	var n2 := Gfx.noise(79, 0.4, 2)
	for y in h:
		for x in w:
			# stretched vertically: furrows; scales on spruce, smooth grey on beech
			var v := n.get_noise_2d(x * 3.0, y * 0.35) * 0.5 + 0.5
			var d := n2.get_noise_2d(x, y) * 0.5 + 0.5
			var c: Color
			if spruce:
				c = Color(0.36, 0.26, 0.19).lerp(Color(0.2, 0.15, 0.12), v) * (0.85 + d * 0.3)
			else:
				c = Color(0.55, 0.55, 0.52).lerp(Color(0.38, 0.38, 0.36), v * 0.6) * (0.9 + d * 0.2)
				if d > 0.78:
					c = c.lerp(Color(0.32, 0.42, 0.22), 0.5)        # moss
			img.set_pixel(x, y, c)
	return Gfx.image_tex(img)


# a realistic meadow: thin blades in many greens and some dry straw, darker at the roots
static func meadow_blades() -> ImageTexture:
	var w := 256
	var h := 256
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 91
	for k in 260:
		var x0 := rnd.randf_range(10.0, w - 10.0)
		var top := rnd.randf_range(0.35, 0.98) * h
		var lean := rnd.randf_range(-0.25, 0.25)
		var bend := rnd.randf_range(-12.0, 12.0)
		var wid := rnd.randf_range(1.4, 3.0)
		var g := Color(0.26, 0.44, 0.14).lerp(Color(0.42, 0.56, 0.2), rnd.randf())
		if rnd.randf() < 0.12:
			g = Color(0.6, 0.58, 0.36)                          # dry straw
		elif rnd.randf() < 0.2:
			g = Color(0.18, 0.32, 0.11)
		var prev := Vector2(x0, h - 1)
		var segs := 10
		for sgi in segs:
			var f := float(sgi + 1) / segs
			var p := Vector2(x0 + lean * top * f + bend * f * f, h - 1 - top * f)
			var col := g.darkened(0.45 * (1.0 - f)).lightened(0.1 * f)
			_line(img, prev, p, wid * (1.0 - f * 0.7 + 0.15), wid * (1.0 - f * 0.85), col)
			prev = p
	# seed heads on some stalks
	for k in 14:
		var p := Vector2(rnd.randf_range(20.0, w - 20.0), rnd.randf_range(10.0, h * 0.45))
		_line(img, p, p + Vector2(rnd.randf_range(-3, 3), 14), 3.0, 1.5, Color(0.62, 0.58, 0.4))
	_fill_bg(img, Color(0.3, 0.45, 0.16))
	return Gfx.image_tex(img)


# ---------------------------------------------------------------- mesh building
class Builder:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var uv := PackedVector2Array()
	var c := PackedColorArray()
	var idx := PackedInt32Array()

	func quad(p: Array, uvs: Array, nrm: Array, ao: Array) -> void:
		var b := v.size()
		for k in 4:
			v.append(p[k])
			n.append(nrm[k])
			uv.append(uvs[k])
			var a: float = ao[k]
			c.append(Color(a, a, a))
		idx.append_array([b, b + 1, b + 2, b, b + 2, b + 3])

	func add_to(mesh: ArrayMesh, m: Material) -> void:
		if v.is_empty():
			return
		var arr := []
		arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = v
		arr[Mesh.ARRAY_NORMAL] = n
		arr[Mesh.ARRAY_TEX_UV] = uv
		arr[Mesh.ARRAY_COLOR] = c
		arr[Mesh.ARRAY_INDEX] = idx
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		mesh.surface_set_material(mesh.get_surface_count() - 1, m)


# tapered trunk / branch cylinder
static func _cyl(b: Builder, a: Vector3, e: Vector3, r0: float, r1: float, seg: int, vlen: float) -> void:
	var ax := (e - a).normalized()
	var side := ax.cross(Vector3.FORWARD if absf(ax.z) < 0.9 else Vector3.RIGHT).normalized()
	var up2 := ax.cross(side).normalized()
	for k in seg:
		var a0 := TAU * k / seg
		var a1 := TAU * (k + 1) / seg
		var d0 := side * cos(a0) + up2 * sin(a0)
		var d1 := side * cos(a1) + up2 * sin(a1)
		var u0 := float(k) / seg
		var u1 := float(k + 1) / seg
		var vl := a.distance_to(e) / vlen
		b.quad([a + d0 * r0, a + d1 * r0, e + d1 * r1, e + d0 * r1], [Vector2(u0, vl), Vector2(u1, vl), Vector2(u1, 0), Vector2(u0, 0)],
			[d0, d1, d1, d0], [0.55, 0.55, 0.85, 0.85])


# drooping spruce branch card from the trunk outwards; normals point away from the crown axis
static func _branch_card(b: Builder, h: float, az: float, pitch: float, ln: float, wd: float, frac: float, crown_mid: float) -> void:
	var d := Vector3(cos(az) * cos(pitch), sin(pitch), sin(az) * cos(pitch))
	var s := Vector3(-sin(az), 0.0, cos(az))
	var root := Vector3(cos(az) * 0.15, h, sin(az) * 0.15)
	var mid := root + d * ln * 0.55
	var d2 := Vector3(d.x, d.y - 0.35, d.z).normalized()
	var tip := mid + d2 * ln * 0.45
	var w0 := wd * 0.25
	var w1 := wd * 0.5
	var pts := [root - s * w0, root + s * w0, mid + s * w1, mid - s * w1, tip + s * w1 * 0.8, tip - s * w1 * 0.8]
	var nr := []
	var ao := []
	for p in pts:
		var pv: Vector3 = p
		var radial := Vector3(pv.x, (pv.y - crown_mid) * 0.5 + 0.6, pv.z)
		nr.append(radial.normalized())
		var out := clampf(Vector2(pv.x, pv.z).length() / maxf(0.5, ln), 0.0, 1.0)
		ao.append(clampf((0.35 + 0.65 * out) * (0.55 + 0.45 * frac), 0.15, 1.0))
	b.quad([pts[0], pts[1], pts[2], pts[3]], [Vector2(0, 0.25), Vector2(0, 0.75), Vector2(0.55, 1), Vector2(0.55, 0)], [nr[0], nr[1], nr[2], nr[3]], [ao[0], ao[1], ao[2], ao[3]])
	b.quad([pts[3], pts[2], pts[4], pts[5]], [Vector2(0.55, 0), Vector2(0.55, 1), Vector2(1, 0.9), Vector2(1, 0.1)], [nr[3], nr[2], nr[4], nr[5]], [ao[3], ao[2], ao[4], ao[5]])


# Norway spruce, ~22 m: bare lower trunk, whorls of drooping branches, narrow pointed top
static func spruce_mesh(detail: bool, bark_m: Material, fol_m: Material) -> ArrayMesh:
	var H := 22.0
	var h0 := 2.2
	var tb := Builder.new()
	var fb := Builder.new()
	_cyl(tb, Vector3.ZERO, Vector3(0, H * 0.92, 0), 0.32, 0.04, 7 if detail else 5, 2.0)
	var whorls := 16 if detail else 7
	var per := 5 if detail else 4
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 5 if detail else 6
	for wi in whorls:
		var f := float(wi) / (whorls - 1)
		var h := lerpf(h0, H - 1.6, f)
		var ln := 3.4 * pow(1.0 - f, 0.85) + 0.45
		var pitch := lerpf(-0.42, -0.08, f)
		for k in per:
			var az := TAU * k / per + wi * 0.61 + rnd.randf_range(-0.2, 0.2)
			var sc := 1.0 if detail else 1.25
			_branch_card(fb, h + rnd.randf_range(-0.15, 0.15), az, pitch + rnd.randf_range(-0.08, 0.08), ln * sc * rnd.randf_range(0.9, 1.1), ln * 0.85 * sc, f, H * 0.45)
	# leader shoot: two crossed upright cards
	for k in 2:
		var az := k * PI * 0.5
		var s := Vector3(cos(az), 0, sin(az)) * 0.45
		var nn := Vector3(sin(az), 0.3, cos(az)).normalized()
		fb.quad([Vector3(0, H - 2.2, 0) - s, Vector3(0, H - 2.2, 0) + s, Vector3(0, H, 0) + s * 0.1, Vector3(0, H, 0) - s * 0.1],
			[Vector2(0.2, 0), Vector2(0.2, 1), Vector2(1, 0.6), Vector2(1, 0.4)], [nn, nn, nn, nn], [0.8, 0.8, 1.0, 1.0])
	var mesh := ArrayMesh.new()
	tb.add_to(mesh, bark_m)
	fb.add_to(mesh, fol_m)
	return mesh


# beech, ~18 m: trunk splitting into main limbs, a rounded crown of leaf-cluster cards
static func beech_mesh(detail: bool, bark_m: Material, fol_m: Material) -> ArrayMesh:
	var tb := Builder.new()
	var fb := Builder.new()
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 11 if detail else 12
	var fork := Vector3(0.1, 6.5, 0.0)
	_cyl(tb, Vector3.ZERO, fork, 0.38, 0.28, 8 if detail else 5, 3.0)
	var crown_c := Vector3(0, 12.0, 0)
	var blobs: Array = []
	var limbs := 5 if detail else 3
	for k in limbs:
		var az := TAU * k / limbs + rnd.randf_range(-0.3, 0.3)
		var tip := fork + Vector3(cos(az) * rnd.randf_range(2.5, 4.0), rnd.randf_range(5.0, 8.5), sin(az) * rnd.randf_range(2.5, 4.0))
		if detail:
			_cyl(tb, fork, tip, 0.2, 0.06, 5, 3.0)
		blobs.append([tip, rnd.randf_range(2.4, 3.2)])
	blobs.append([crown_c + Vector3(0, 2.5, 0), 3.0])
	blobs.append([crown_c + Vector3(0, -1.5, 0), 3.4])
	var per := 14 if detail else 6
	var csz := 2.6 if detail else 3.8
	for bl in blobs:
		var c: Vector3 = bl[0]
		var r: float = bl[1]
		for k in per:
			# cards on the blob surface, facing outwards (random tilt), normals from the crown centre
			var dir := Vector3(rnd.randf_range(-1, 1), rnd.randf_range(-0.6, 1), rnd.randf_range(-1, 1)).normalized()
			var p := c + dir * r * rnd.randf_range(0.55, 1.0)
			var t1 := dir.cross(Vector3.UP if absf(dir.y) < 0.9 else Vector3.RIGHT).normalized()
			t1 = t1.rotated(dir, rnd.randf() * TAU)
			var t2 := dir.cross(t1).normalized()
			var hs := csz * 0.5 * rnd.randf_range(0.85, 1.15)
			var pts := [p - t1 * hs - t2 * hs, p + t1 * hs - t2 * hs, p + t1 * hs + t2 * hs, p - t1 * hs + t2 * hs]
			var nr := []
			var ao := []
			for q in pts:
				var pv: Vector3 = q
				nr.append((pv - crown_c + Vector3(0, 1.5, 0)).normalized())
				var depth := clampf((pv - crown_c).length() / 6.5, 0.0, 1.0)
				ao.append(clampf(0.3 + 0.7 * depth * (0.7 + 0.3 * clampf((pv.y - 7.0) / 9.0, 0.0, 1.0)), 0.2, 1.0))
			fb.quad(pts, [Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)], nr, ao)
	var mesh := ArrayMesh.new()
	tb.add_to(mesh, bark_m)
	fb.add_to(mesh, fol_m)
	return mesh


# small grass clump for the meadow carpet: three crossed blade cards, normals up (lit like the ground)
static func grass_clump(fol_m: Material) -> ArrayMesh:
	var b := Builder.new()
	for k in 3:
		var a := k * PI / 3.0
		var s := Vector3(cos(a), 0, sin(a)) * 0.5
		var up := Vector3(0, 0.6, 0)
		b.quad([-s, s, s + up, -s + up], [Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0)],
			[Vector3.UP, Vector3.UP, Vector3.UP, Vector3.UP], [0.55, 0.55, 1.0, 1.0])
	var mesh := ArrayMesh.new()
	b.add_to(mesh, fol_m)
	return mesh


static func foliage_mat(tex: Texture2D, tsize: float, flutter: float) -> ShaderMaterial:
	var m := Gfx.shader_mat(FOLIAGE_SHADER)
	m.set_shader_parameter("tex", tex)
	m.set_shader_parameter("tsize", tsize)
	m.set_shader_parameter("flutter", flutter)
	return m


static func bark_mat(tex: Texture2D) -> ShaderMaterial:
	var m := Gfx.shader_mat(BARK_SHADER)
	m.set_shader_parameter("tex", tex)
	return m

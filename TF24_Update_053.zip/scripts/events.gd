# Daily events: three races a day at fixed times (12:00, 18:00, 21:00 local time). Track, class, length,
# weather and time of day follow from the date, so every player gets the same programme. Entry is open
# from 15 minutes before the start until 30 minutes after it. Points per finishing position (in class)
# go into the profile: points, starts, wins, podiums. The schedule can be exported to the calendar.
extends RefCounted

const TIMES := [[12, 0], [18, 0], [21, 0]]
const POINTS := [25, 18, 15, 12, 10, 8, 6, 4, 2, 1]
const OPEN_BEFORE := 15 * 60
const OPEN_AFTER := 30 * 60
const TRACK_NAMES := {"spa": "Spa-Francorchamps", "tf": "Circuit des Trois Forêts"}


static func _bias_sec() -> int:
	return int(Time.get_time_zone_from_system().get("bias", 60)) * 60


static func now() -> int:
	return int(Time.get_unix_time_from_system())


# events of one local calendar day (days = 0 today, 1 tomorrow ...)
static func for_day(days: int) -> Array:
	var local_now := now() + _bias_sec() + days * 86400
	var d := Time.get_datetime_dict_from_unix_time(local_now)
	var out: Array = []
	for k in TIMES.size():
		var tm: Array = TIMES[k]
		var dd := {"year": d["year"], "month": d["month"], "day": d["day"], "hour": tm[0], "minute": tm[1], "second": 0}
		var start := int(Time.get_unix_time_from_datetime_dict(dd)) - _bias_sec()
		var rng := RandomNumberGenerator.new()
		rng.seed = hash("tf24-%04d%02d%02d-%d" % [d["year"], d["month"], d["day"], k])
		var track: String = "spa" if rng.randf() < 0.6 else "tf"
		var cls: String = "gt3" if rng.randf() < 0.7 else "hyper"
		var dur: String = ["m20", "m20", "m45"][k]
		var weather: String = "dry" if rng.randf() < 0.7 else ("rain" if rng.randf() < 0.4 else "mixed")
		var hour: float = [13.0, 17.5, 20.5][k] if rng.randf() < 0.7 else rng.randf_range(10.0, 21.5)
		out.append({"id": "%04d%02d%02d-%d" % [d["year"], d["month"], d["day"], k], "start": start, "track": track, "cls": cls,
			"duration": dur, "weather": weather, "hour": snappedf(hour, 0.5), "ai": [105.0, 110.0, 115.0][k],
			"title": ["MITTAGS-SPRINT", "FEIERABEND-CUP", "NACHT-RENNEN"][k], "time": "%02d:%02d" % [tm[0], tm[1]]})
	return out


# the next n events that are not over yet
static func upcoming(n: int) -> Array:
	var out: Array = []
	var t := now()
	for day in 3:
		for ev in for_day(day):
			if int(ev["start"]) + OPEN_AFTER > t:
				out.append(ev)
				if out.size() >= n:
					return out
	return out


static func state(ev: Dictionary) -> String:
	var dt := int(ev["start"]) - now()
	if dt > OPEN_BEFORE:
		return "soon"
	if dt > -OPEN_AFTER:
		return "open"
	return "over"


static func countdown(ev: Dictionary) -> String:
	var dt := int(ev["start"]) - now()
	if dt <= 0:
		return "LÄUFT · Anmeldung offen"
	var h := dt / 3600
	var m := (dt % 3600) / 60
	if h > 0:
		return "in %d h %02d min" % [h, m]
	return "in %d min" % maxi(1, m)


# Drift show at La Source: every 3 hours (00:00, 03:00 ... 21:00 local time), watching is possible from
# the start for 20 minutes (the show itself runs about 2.5 minutes, it starts when you come in)
const DRIFT_EVERY := 3 * 3600
const DRIFT_OPEN := 20 * 60


# start (unix time) of the current show (if it is open) or of the next one
static func drift_next() -> int:
	var local := now() + _bias_sec()
	var cur := local - posmod(local, DRIFT_EVERY)
	if local - cur < DRIFT_OPEN:
		return cur - _bias_sec()
	return cur + DRIFT_EVERY - _bias_sec()


static func drift_open() -> bool:
	var st := drift_next()
	return now() >= st and now() < st + DRIFT_OPEN


static func drift_time_text(start: int) -> String:
	var d := Time.get_datetime_dict_from_unix_time(start + _bias_sec())
	return "%02d:%02d" % [d["hour"], d["minute"]]


static func drift_countdown() -> String:
	var st := drift_next()
	var dt := st - now()
	if dt <= 0:
		return "LÄUFT · noch %d min zum Einsteigen" % maxi(1, (st + DRIFT_OPEN - now()) / 60)
	var h := dt / 3600
	var m := (dt % 3600) / 60
	return ("in %d h %02d min" % [h, m]) if h > 0 else "in %d min" % maxi(1, m)


static func points_for(cls_pos: int, finished: bool) -> int:
	if not finished or cls_pos < 1:
		return 1                      # a start is always worth a point
	return (POINTS[cls_pos - 1] if cls_pos <= POINTS.size() else 0) + 2


# calendar file (.ics) with the events of the next 7 days, alarms 15 minutes before
static func write_calendar(path: String) -> bool:
	var lines := PackedStringArray(["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Trois Forets 24//Events//DE", "CALSCALE:GREGORIAN"])
	for day in 7:
		for ev in for_day(day):
			var st := Time.get_datetime_dict_from_unix_time(int(ev["start"]))
			var en := Time.get_datetime_dict_from_unix_time(int(ev["start"]) + (2700 if ev["duration"] == "m45" else 1500))
			var fmt := func(d: Dictionary) -> String: return "%04d%02d%02dT%02d%02d00Z" % [d["year"], d["month"], d["day"], d["hour"], d["minute"]]
			lines.append_array(PackedStringArray(["BEGIN:VEVENT", "UID:tf24-" + String(ev["id"]) + "@troisforets24", "DTSTAMP:" + fmt.call(st),
				"DTSTART:" + fmt.call(st), "DTEND:" + fmt.call(en),
				"SUMMARY:TF24 " + String(ev["title"]) + " · " + TRACK_NAMES.get(ev["track"], ev["track"]) + " (" + String(ev["cls"]).to_upper() + ")",
				"DESCRIPTION:Tägliches Trois Forêts 24 Event. Anmeldung im Spiel 15 Minuten vorher offen.",
				"BEGIN:VALARM", "TRIGGER:-PT15M", "ACTION:DISPLAY", "DESCRIPTION:TF24 Event startet gleich", "END:VALARM", "END:VEVENT"]))
	lines.append("END:VCALENDAR")
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string("\r\n".join(lines) + "\r\n")
	f.close()
	return true

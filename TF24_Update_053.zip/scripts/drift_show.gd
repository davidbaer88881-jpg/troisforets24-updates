extends RefCounted
# Drift show on the big tarmac run-off outside La Source (Spa), about 2.5 minutes:
#   entry -> tandem drift round the run-off -> donuts -> figure eights -> out onto the track ->
#   full-throttle fly-by up the start/finish straight, braking into the run-off -> burnout finale.
# The show cars are not simulated: every car follows its choreography (paths with a drift angle that
# follows the curvature), the driving values (speed, slip, revs, throttle) are derived from the motion,
# so wheels, smoke, brake glow and the engine / tyre sounds work exactly like in a race.

const DURATION := 150.0
const PHASES := [[0.0, "entry", "DRIFT-SHOW  ·  LA SOURCE", "Die Autos rollen auf die Fläche"],
	[12.0, "tandem", "TANDEM-DRIFT", "Vier Autos, ein Abstand – quer um die ganze Fläche"],
	[47.0, "donuts", "DONUTS", "Volle Drehzahl, jede Menge Rauch"],
	[77.0, "eights", "ACHTEN", "Paarweise um die Pylonen – Seitenwechsel im Drift"],
	[102.0, "exit", "RAUS AUF DIE STRECKE", "Gleich kommen sie mit Vollgas zurück"],
	[112.0, "flyby", "VOLLGAS-VORBEIFAHRT", "Mit über 250 km/h die Start-Ziel-Gerade hoch"],
	[136.0, "finale", "FINALE", "Burnouts vor der Tribüne"]]

var game
var T
var cars: Array = []
var t := 0.0
var done := false
var phase := -1
var side := -1.0
var st: Array = []          # per car: {path, d, v, pos, psi, beta, gain, prev, hold, hold_psi, burn}
var _tick := 0
var manual_t := 0.0         # the viewer switched the camera himself: no automatic cuts for a while
var _cut_t := 2.0
var _cut_k := 0
const CUTS := [["seat", 9.0], ["chase", 7.0], ["seat", 8.0], ["near", 6.0], ["seat", 7.0], ["tv", 6.0]]


static func grid(team_fn: Callable) -> Array:
	var out: Array = []
	var models := ["amg", "bmw", "amg", "bmw"]
	for k in 4:
		var tm: Array = team_fn.call("gt3", k + 2)
		out.append({"cls": "gt3", "model": models[k], "team": [tm[0], tm[1], tm[2], tm[3], tm[4]],
			"driver": ["Drift King", "Sideways Sam", "Rauch-Rudi", "Lisa Lenkwinkel"][k], "show": true, "orig": k < 2})
	return out


func setup(g, show_cars: Array) -> void:
	game = g
	T = g.T
	cars = show_cars
	var da: Array = T.def.get("drift_area", [185.0, 335.0, -1.0, 11.0, 34.0])
	side = da[2]
	for k in cars.size():
		var c = cars[k]
		c.ghost = 1e9                 # the show cars never collide with each other
		c.engine_on = true
		c.ignition = true
		c.hold = false
		c.gear = 2
		st.append({"path": {}, "d": 0.0, "v": 0.0, "pos": Vector2.ZERO, "psi": 0.0, "beta": 0.0, "gain": 5.0,
			"prev": Vector2.ZERO, "prev_psi": 0.0, "hold": false, "burn": false, "brake": 0.0})
	_phase(0)


# point in the run-off: s along the track, la metres out from the centreline (to the outside)
func W(s: float, la: float) -> Vector2:
	var p: Vector4 = T.point_at(s, side * la)
	return Vector2(p.x, p.z)


func tick(dt: float) -> void:
	if done:
		return
	t += dt
	var np := phase
	for k in PHASES.size():
		if t >= float(PHASES[k][0]):
			np = k
	if np != phase:
		_phase(np)
	if t >= DURATION:
		done = true
	_tick += 1
	for k in cars.size():
		_drive(k, dt)
	_director(dt)


# automatic camera: mostly the grandstand view, now and then close to one of the cars
func _director(dt: float) -> void:
	manual_t = maxf(0.0, manual_t - dt)
	_cut_t -= dt
	if manual_t > 0.0 or _cut_t > 0.0:
		return
	var name: String = PHASES[phase][1]
	var shot: Array = CUTS[_cut_k % CUTS.size()]
	_cut_k += 1
	_cut_t = shot[1]
	var kind: String = shot[0]
	if name == "flyby" and t < 128.0:
		kind = "tv"                       # up the straight: the TV cameras along the track
	var pick: int = (_cut_k * 3 + int(t)) % cars.size()
	game.focus = game.cars.find(cars[pick])
	game.cam_mode = {"seat": 6, "chase": 0, "near": 1, "tv": 4}[kind]
	game.cam_init = false


func _phase(p: int) -> void:
	phase = p
	var name: String = PHASES[p][1]
	game.show_msg(String(PHASES[p][2]), 3.5, Color(1.0, 0.55, 0.1), String(PHASES[p][3]))
	match name:
		"entry":
			# in a line from the track before La Source, straight onto the tandem loop
			var path := _path(_entry_pts() + _loop_pts(4), false)
			for k in cars.size():
				var s: Dictionary = st[k]
				s["path"] = path
				s["d"] = -18.0 * k
				s["v"] = 20.0
				var p0 := _sample(path, s["d"])
				s["pos"] = p0[0]
				s["psi"] = p0[1]
				s["prev"] = p0[0]
				s["prev_psi"] = p0[1]
				s["gain"] = 6.0
				_place(k, true)
		"tandem":
			pass                      # the entry path runs straight on into the loop
		"donuts":
			var anchors := [W(204.0, 24.0), W(228.0, 28.0), W(252.0, 28.0), W(278.0, 25.0)]
			for k in cars.size():
				var dir := 1.0 if k % 2 == 0 else -1.0
				_switch(k, _path(_circle(anchors[k], 5.2, dir, 1), true), 9.5)
		"eights":
			# two pairs, each round two pylons 13 m apart (the eights stay well inside the run-off)
			var a1 := W(206.0, 25.0)
			var a2 := a1 + (W(240.0, 25.0) - a1).normalized() * 13.0
			var a3 := W(256.0, 25.0)
			var a4 := a3 + (W(290.0, 25.0) - a3).normalized() * 13.0
			for k in cars.size():
				var pa: Vector2 = a1 if k < 2 else a3
				var pb: Vector2 = a2 if k < 2 else a4
				var e8 := _path(_eight(pa, pb), true)
				_switch(k, e8, 11.0, e8["len"] * 0.25 * (k % 2))
		"exit":
			for k in cars.size():
				var pts: Array = [st[k]["pos"], W(318.0, 14.0), W(340.0, 6.0)]
				for s2 in range(350, 470, 10):
					pts.append(W(float(s2), (-2.5 if k % 2 == 0 else 2.5) * side))
				_switch(k, _path(pts, false), 26.0)
				st[k]["gain"] = 2.0
		"flyby":
			for k in cars.size():
				var lane := (-2.6 if k % 2 == 0 else 2.6) * side
				var back := 45.0 * float(k / 2)
				var pts2: Array = []
				var s3 := -700.0 - back
				while s3 < 150.0:
					pts2.append(W(s3, lane))
					s3 += 12.0
				# braking into La Source and sliding onto the run-off, ending in a line for the finale
				pts2.append(W(170.0, lane * 0.5 + 3.0))
				pts2.append(W(192.0, 11.0 + k * 1.5))
				pts2.append(W(212.0, 18.0 + k * 1.2))
				pts2.append(_finale_spot(k) + _finale_dir() * -6.0)
				pts2.append(_finale_spot(k))
				var fp := _path(pts2, false)
				var s4: Dictionary = st[k]
				s4["path"] = fp
				s4["d"] = 0.0
				s4["v"] = 72.0
				var p1 := _sample(fp, 0.0)
				s4["pos"] = p1[0]
				s4["psi"] = p1[1]
				s4["prev"] = p1[0]
				s4["prev_psi"] = p1[1]
				s4["gain"] = 8.0
				s4["hold"] = false
				_place(k, true)
		"finale":
			for k in cars.size():
				var s5: Dictionary = st[k]
				s5["hold"] = true
				s5["hold_pos"] = _finale_spot(k)
				s5["hold_psi"] = _finale_dir().angle()
				s5["gain"] = 1.5


func _finale_spot(k: int) -> Vector2:
	return W(214.0 + k * 13.0, 27.0)


# the cars face the grandstand behind the run-off
func _finale_dir() -> Vector2:
	var a := W(250.0, 21.0)
	var b := W(250.0, 40.0)
	return (b - a).normalized()


func _switch(k: int, path: Dictionary, v: float, d0 := 0.0) -> void:
	var s: Dictionary = st[k]
	s["path"] = path
	s["v"] = v
	s["hold"] = false
	s["burn"] = false
	# start on the point of the new path nearest to the car (plus an offset for pairs), glide over
	var best := 0.0
	var bd := 1e18
	var pts: PackedVector2Array = path["pts"]
	var cum: PackedFloat32Array = path["cum"]
	for i in pts.size():
		var dd: float = (pts[i] as Vector2).distance_squared_to(s["pos"])
		if dd < bd:
			bd = dd
			best = cum[i]
	s["d"] = best + d0 if d0 > 0.0 else best
	s["gain"] = 1.6


func _entry_pts() -> Array:
	var pts: Array = []
	for s in range(40, 176, 12):
		pts.append(W(float(s), 0.0))
	pts.append(W(186.0, 6.0))
	return pts


# the tandem loop: round the whole run-off, close to the track first, back along the grandstand side
func _loop_pts(laps: int) -> Array:
	var ring := [[198.0, 15.0], [222.0, 15.5], [246.0, 17.0], [270.0, 17.0], [294.0, 16.0], [312.0, 19.0],
		[316.0, 27.0], [298.0, 32.0], [270.0, 32.5], [242.0, 32.5], [214.0, 31.5], [196.0, 25.0]]
	var out: Array = []
	for l in laps:
		for r in ring:
			out.append(W(float(r[0]), float(r[1])))
	out.append(W(198.0, 13.0))
	return out


func _circle(c: Vector2, r: float, dir: float, turns: int) -> Array:
	var pts: Array = []
	var n := 40 * turns
	for i in n + 1:
		var a := dir * TAU * float(i) / 40.0
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	return pts


# figure eight: round the first pylon one way, round the second the other way, crossing in the middle
func _eight(a: Vector2, b: Vector2) -> Array:
	var m := (a + b) * 0.5
	var r := a.distance_to(b) * 0.5
	var pts: Array = []
	var a0 := (m - a).angle()
	var b0 := (m - b).angle()
	for i in 41:
		pts.append(a + Vector2.from_angle(a0 + TAU * float(i) / 40.0) * r)
	for i in range(1, 41):
		pts.append(b + Vector2.from_angle(b0 - TAU * float(i) / 40.0) * r)
	return pts


# Catmull-Rom through the points, then sampled every 0.5 m (arc length)
func _path(pts_in: Array, loop: bool) -> Dictionary:
	var dense := PackedVector2Array()
	var n := pts_in.size()
	for i in n - (0 if loop else 1):
		var p0: Vector2 = pts_in[(i - 1 + n) % n] if (loop or i > 0) else pts_in[i]
		var p1: Vector2 = pts_in[i]
		var p2: Vector2 = pts_in[(i + 1) % n]
		var p3: Vector2 = pts_in[(i + 2) % n] if (loop or i + 2 < n) else p2
		var seg := maxi(2, int(p1.distance_to(p2) / 0.5))
		for j in seg:
			var u := float(j) / seg
			var u2 := u * u
			var u3 := u2 * u
			dense.append(0.5 * ((2.0 * p1) + (-p0 + p2) * u + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * u2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * u3))
	if not loop:
		dense.append(pts_in[n - 1])
	var cum := PackedFloat32Array()
	cum.resize(dense.size())
	var acc := 0.0
	for i in dense.size():
		if i > 0:
			acc += dense[i].distance_to(dense[i - 1])
		cum[i] = acc
	return {"pts": dense, "cum": cum, "len": maxf(acc, 0.01), "loop": loop}


# position, direction of travel and curvature (1/m, + = turning right) at distance d
func _sample(path: Dictionary, d: float) -> Array:
	var pts: PackedVector2Array = path["pts"]
	var cum: PackedFloat32Array = path["cum"]
	var L: float = path["len"]
	if path["loop"]:
		d = fposmod(d, L)
	var dd := clampf(d, 0.0, L)
	var i := cum.bsearch(dd)
	i = clampi(i, 1, pts.size() - 1)
	var f := (dd - cum[i - 1]) / maxf(0.001, cum[i] - cum[i - 1])
	var p: Vector2 = pts[i - 1].lerp(pts[i], f)
	if d < 0.0:
		# before the start of an open path: on the straight extension backwards
		var dir0 := (pts[1] - pts[0]).normalized()
		p = pts[0] + dir0 * d
	var j0 := clampi(i - 6, 0, pts.size() - 1)
	var j1 := clampi(i + 6, 0, pts.size() - 1)
	var ang := (pts[mini(i, pts.size() - 1)] - pts[i - 1]).angle()
	var a0 := (pts[mini(j0 + 1, pts.size() - 1)] - pts[j0]).angle()
	var a1 := (pts[j1] - pts[maxi(j1 - 1, 0)]).angle()
	var curv := angle_difference(a0, a1) / maxf(0.5, cum[j1] - cum[j0])
	return [p, ang, curv]


func _drive(k: int, dt: float) -> void:
	var c = cars[k]
	var s: Dictionary = st[k]
	var name: String = PHASES[phase][1]
	var target: Vector2
	var tpsi: float
	var drifting := false
	var beta_t := 0.0
	var thr := 0.85
	var brk := 0.0
	if s["hold"]:
		# finale: parked in a line, burnouts with the front brakes on
		target = s["hold_pos"]
		tpsi = s["hold_psi"]
		var burn: bool = t > 138.0 + k * 0.6 and t < DURATION - 2.5
		s["burn"] = burn
		thr = 1.0 if burn else 0.15
	else:
		var path: Dictionary = s["path"]
		var v: float = s["v"]
		if name == "flyby":
			# full throttle up the straight, hard braking for La Source, slide onto the run-off
			var L: float = path["len"]
			var left: float = L - float(s["d"])
			var vmax := sqrt(maxf(0.0, 2.0 * 14.0 * maxf(0.0, left - 80.0))) + 12.0
			v = minf(72.0, vmax)
			if left < 6.0:
				v = 0.0
			brk = 1.0 if v < float(s["v"]) - 0.5 else 0.0
			thr = 0.0 if brk > 0.0 else 1.0
			s["v"] = maxf(v, 0.0)
		elif name == "entry" and float(s["d"]) > 70.0:
			v = 15.0
			s["v"] = v
		s["d"] = float(s["d"]) + v * dt
		var smp := _sample(path, s["d"])
		target = smp[0]
		var curv: float = smp[2]
		var on_area: bool = name in ["tandem", "donuts", "eights"] or (name == "entry" and float(s["d"]) > 95.0) \
			or (name == "flyby" and float(path["len"]) - float(s["d"]) < 80.0)
		if on_area and absf(curv) > 0.004:
			drifting = true
			beta_t = signf(curv) * clampf(0.3 + absf(curv) * 4.0, 0.3, 1.05)
		tpsi = smp[1]
	# drift angle eases in and out (sign changes in the eights flick the car over)
	s["beta"] = lerpf(s["beta"], beta_t, minf(1.0, dt * 3.0))
	var gain: float = s["gain"]
	s["gain"] = minf(6.0, gain + dt * 1.5)
	var pos: Vector2 = s["pos"]
	# follow the choreography, but never faster than a car can drive: after a change of programme the
	# car drives over to its new line instead of sliding there
	var to := target - pos
	var gap := to.length()
	var vlim: float = (4.0 if s["hold"] else float(s["v"])) + 7.0
	if gap > 0.0001:
		pos += to / gap * minf(gap * (1.0 - exp(-dt * gain)), vlim * dt)
	var want_psi: float = tpsi + float(s["beta"])
	if gap > 3.0 and not s["hold"]:
		want_psi = to.angle()              # on the way over: nose where it goes
		s["beta"] = lerpf(s["beta"], 0.0, minf(1.0, dt * 3.0))
		drifting = false
	var psi: float = s["psi"]
	psi += angle_difference(psi, want_psi) * (1.0 - exp(-dt * 7.0))
	s["pos"] = pos
	s["psi"] = psi
	_apply(k, dt, drifting, thr, brk)


func _place(k: int, full: bool) -> void:
	var c = cars[k]
	var s: Dictionary = st[k]
	var p: Vector2 = s["pos"]
	c.x = p.x
	c.z = p.y
	c.psi = s["psi"]
	c.u = 0.0
	c.v = 0.0
	c.r = 0.0
	_locate(c, full)


func _apply(k: int, dt: float, drifting: bool, thr: float, brk: float) -> void:
	var c = cars[k]
	var s: Dictionary = st[k]
	var pos: Vector2 = s["pos"]
	var prev: Vector2 = s["prev"]
	var vel := (pos - prev) / maxf(dt, 1e-4)
	var psi: float = s["psi"]
	var fwd := Vector2(cos(psi), sin(psi))
	var rgt := Vector2(-sin(psi), cos(psi))
	c.x = pos.x
	c.z = pos.y
	c.psi = psi
	c.u = lerpf(c.u, vel.dot(fwd), minf(1.0, dt * 10.0))
	c.v = lerpf(c.v, vel.dot(rgt), minf(1.0, dt * 10.0))
	c.r = angle_difference(float(s["prev_psi"]), psi) / maxf(dt, 1e-4)
	s["prev"] = pos
	s["prev_psi"] = psi
	var spd := vel.length()
	var beta: float = s["beta"]
	c.steer = clampf(-beta * 0.9, -1.0, 1.0) if drifting else clampf(c.r * 0.08, -0.5, 0.5)
	c.throttle = thr
	c.brake = brk
	c.slip_r = beta if drifting else 0.0
	c.slip_f = beta * 0.25 if drifting else 0.0
	c.spin_r = drifting or bool(s["burn"])
	c.lock_f = brk > 0.5 and spd > 30.0
	# revs: high and lively in the drift, gears up the straight, limiter bouncing at the burnout
	var rmax: float = c.spec["rpmMax"]
	var rpm_t: float
	if s["burn"]:
		rpm_t = rmax * (0.96 + 0.04 * sin(t * 40.0))
		c.gear = 1
	elif drifting:
		rpm_t = rmax * (0.78 + 0.12 * sin(t * 2.3 + k) + 0.05 * sin(t * 9.0 + k * 2.0))
		c.gear = 2 if spd < 14.0 else 3
	else:
		var g := clampi(1 + int(spd / 12.5), 1, 6)
		c.gear = g
		var lo := 12.5 * (g - 1)
		rpm_t = lerpf(rmax * 0.55, rmax * 0.97, clampf((spd - lo) / 12.5, 0.0, 1.0)) if thr > 0.3 else rmax * 0.45
	c.rpm = lerpf(c.rpm, rpm_t, minf(1.0, dt * 12.0))
	c.wheel_spin = (30.0 if s["burn"] else (12.0 if drifting else 0.0))
	c.hold = false
	_locate(c, false)
	var vis = game.visuals[game.cars.find(c)] if game.cars.has(c) else null
	if vis != null:
		vis.force_smoke = bool(s["burn"])


# track position of the car: a local search around the last index (a full search only after a jump)
func _locate(c, full: bool) -> void:
	if full:
		T.locate_global(c.x, c.z)
		c.idx = T.loc_i
	else:
		var best: int = c.idx
		var bd := 1e18
		for o in range(-24, 25):
			var i := posmod(int(c.idx) + o, T.N)
			var dx: float = c.x - T.px[i]
			var dz: float = c.z - T.pz[i]
			var d := dx * dx + dz * dz
			if d < bd:
				bd = d
				best = i
		c.idx = best
	var i2: int = c.idx
	var ddx: float = c.x - T.px[i2]
	var ddz: float = c.z - T.pz[i2]
	c.s = T.wrap_s(i2 * T.ds + ddx * T.tx[i2] + ddz * T.tz[i2])
	c.lat = ddx * T.rx[i2] + ddz * T.rz[i2]
	c.y = T.height_at(c.s)
	c.grade_pitch = atan(T.grade[i2] * cos(c.psi - T.head[i2]))
	c.surface = "asphalt" if absf(c.lat) < T.half_w else "runoff"
	c.in_pit = false
	c.near_lane = false

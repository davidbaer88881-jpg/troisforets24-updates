# Main menu in the style of a modern endurance sim: top bar with crimson wedge and navigation,
# login / profiles, event cards, race weekend, pit garage (setup), settings, driver profile, online lobby.
# Settings persist to user://settings.cfg, profiles to user://profiles.cfg.
extends Control

signal start_race
signal track_changed
signal quality_changed

const Updater = preload("res://scripts/updater.gd")
const Gfx = preload("res://scripts/gfx.gd")
const Ui = preload("res://scripts/ui.gd")
const Profile = preload("res://scripts/profile.gd")
const CarPhysics = preload("res://scripts/car_physics.gd")
const TrackDefs = preload("res://scripts/track_defs.gd")

const LIVERIES := [
	["Weiß / Blau", Color(0.91, 0.91, 0.91), Color(0.0, 0.34, 1.0), Color(1.0, 0.18, 0.18)],
	["Schwarz / Cyan", Color(0.07, 0.07, 0.07), Color(0.0, 0.9, 1.0), Color.WHITE],
	["Gelb / Schwarz", Color(1.0, 0.8, 0.0), Color(0.07, 0.07, 0.07), Color.WHITE],
	["Rot / Weiß", Color(0.84, 0.08, 0.1), Color.WHITE, Color(0.07, 0.07, 0.07)],
	["Grün / Gelb", Color(0.05, 0.43, 0.23), Color(1.0, 0.83, 0.0), Color.WHITE],
	["Pink / Schwarz", Color(1.0, 0.43, 0.78), Color(0.1, 0.1, 0.1), Color.WHITE],
	["Silber / Neon", Color(0.75, 0.77, 0.8), Color(0.8, 1.0, 0.1), Color(0.07, 0.07, 0.07)],
	["Orange / Blau", Color(1.0, 0.45, 0.05), Color(0.05, 0.2, 0.5), Color.WHITE],
]

const TRACK_INFO := {
	"spa": {"title": "CIRCUIT DE SPA-FRANCORCHAMPS", "loc": "STAVELOT, BELGIEN", "flag": "BE", "opened": "1921", "km": "7.004", "corners": 19},
	"tf": {"title": "CIRCUIT DES TROIS FORÊTS", "loc": "ARDENNEN, FRANKREICH", "flag": "FR", "opened": "2024", "km": "7.6", "corners": 16},
}

const STEER_MODES := {
	"easy": {"steer_strength": 0.85, "steer_speed": 0.8, "steer_speed_sens": 1.4, "steer_curve": 2.0, "steer_deadzone": 0.08},
	"soft": {"steer_strength": 0.8, "steer_speed": 0.7, "steer_speed_sens": 1.3, "steer_curve": 2.0, "steer_deadzone": 0.08},
	"normal": {"steer_strength": 1.0, "steer_speed": 1.0, "steer_speed_sens": 1.0, "steer_curve": 1.6, "steer_deadzone": 0.07},
	"direct": {"steer_strength": 1.15, "steer_speed": 1.45, "steer_speed_sens": 0.75, "steer_curve": 1.3, "steer_deadzone": 0.05},
	"race": {"steer_strength": 1.3, "steer_speed": 1.9, "steer_speed_sens": 0.5, "steer_curve": 1.0, "steer_deadzone": 0.04},
}

var settings := {
	"track": "spa", "cls": "gt3", "livery": 0, "duration": "m20", "start_hour": 14.0, "time_scale": 8.0,
	"weather": "dry", "field": "own", "wear": 1.0, "ai_diff": 90.0, "opponents": 11, "damage": 1.0,
	"abs": true, "tc": true, "auto_gear": true, "steer_assist": true, "racing_line": false, "radar": true,
	"steer_mode": "normal", "steer_strength": 1.0, "steer_speed": 1.0, "steer_speed_sens": 1.0, "steer_curve": 1.6, "steer_deadzone": 0.07,
	"quality": "high", "fov": 68.0, "session": "race", "quali_min": 15, "quali_limits": true, "rules": true, "vol_music": 0.6, "auto_update": true, "ui_scale": 1.25,
	"wk_practice": false, "practice_min": 15, "wk_quali": true, "wk_race": true, "n_hy": 0, "n_gt3": 11,
	"vol_master": 0.9, "vol_engine": 1.0, "radio_voice": true, "radio_on": true,
	"setup_hyper": CarPhysics.default_setup("hyper"), "setup_gt3": CarPhysics.default_setup("gt3"),
}

var game                       # main.gd (set before the menu enters the tree)
var page := "home"
var history: Array = []
var bg: ColorRect
var topbar: Control
var title_lbl: Label
var back_btn: Button
var nav_box: HBoxContainer
var chip: HBoxContainer
var content: Control
var desc_title: Label
var desc_text: Label
var settings_tab := "gameplay"
var garage_tab := "standard"
var adv_tab := "sessions"
var edit_new := false
var upd_status: Label
var online_status: Label
var lobby_box: VBoxContainer


func _ready() -> void:
	load_settings()
	Profile.load_all()
	Updater.cleanup()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var th := Theme.new()
	th.default_font = Ui.font("body")
	th.default_font_size = 18
	theme = th
	bg = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var sm := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = Ui.BG_SHADER
	sm.shader = sh
	bg.material = sm
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	topbar = Ui.TopBar.new()
	topbar.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	topbar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(topbar)
	# logo + back + section title in the wedge
	var left := HBoxContainer.new()
	left.position = Vector2(30, 20)
	left.add_theme_constant_override("separation", 14)
	add_child(left)
	# the logo is a button: home when logged in, otherwise back to the sign-in page
	var logo := Button.new()
	logo.text = "TF24"
	logo.flat = true
	logo.add_theme_font_override("font", Ui.font("head"))
	logo.add_theme_font_size_override("font_size", 50)
	logo.add_theme_color_override("font_color", Color.WHITE)
	logo.add_theme_color_override("font_hover_color", Color(1, 0.85, 0.9))
	logo.add_theme_color_override("font_pressed_color", Color(1, 0.7, 0.8))
	logo.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	logo.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	logo.tooltip_text = "Zum Hauptmenü"
	logo.pressed.connect(_logo_pressed)
	left.add_child(logo)
	var back := Button.new()
	back_btn = back
	back.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	back.text = "‹"
	back.flat = true
	back.add_theme_font_override("font", Ui.font("head"))
	back.add_theme_font_size_override("font_size", 46)
	back.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
	back.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	back.pressed.connect(go_back)
	left.add_child(back)
	var sep := ColorRect.new()
	sep.color = Color(1, 1, 1, 0.7)
	sep.custom_minimum_size = Vector2(2, 44)
	left.add_child(sep)
	title_lbl = Ui.label("HAUPTMENÜ", "bold", 30, Color.WHITE)
	left.add_child(title_lbl)
	nav_box = HBoxContainer.new()
	nav_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	nav_box.offset_left = -440
	nav_box.offset_right = 440
	nav_box.offset_top = 24
	nav_box.offset_bottom = 76
	nav_box.alignment = BoxContainer.ALIGNMENT_CENTER
	nav_box.add_theme_constant_override("separation", 22)
	add_child(nav_box)
	chip = HBoxContainer.new()
	chip.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	chip.offset_left = -470
	chip.offset_right = -30
	chip.offset_top = 20
	chip.offset_bottom = 76
	chip.alignment = BoxContainer.ALIGNMENT_END
	chip.add_theme_constant_override("separation", 8)
	add_child(chip)
	content = Control.new()
	content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	content.offset_top = 112
	content.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(content)
	var lp := Profile.last_profile()
	if not lp.is_empty() and String(lp.get("pw", "")) == "":
		Profile.login(lp)       # no password: straight in, "Abmelden" is in the profile
	go("home" if Profile.logged_in() else "login", false)
	if Profile.logged_in() and game != null and game.account.signed_in() and String(Profile.current.get("cloud_uid", "")) == game.account.uid:
		_acc_sync_down()
	_auto_update.call_deferred()


# ---------------------------------------------------------------- automatic updates (GitHub)
const UPDATE_FEED := "https://raw.githubusercontent.com/davidbaer88881-jpg/troisforets24-updates/main/"
var _upd_banner: PanelContainer
var online_update := {}          # newest update on GitHub when it is newer than this game: {"version", "file"}


func _banner(t: String) -> void:
	if _upd_banner == null or not is_instance_valid(_upd_banner):
		_upd_banner = Ui.panel(Color(0.04, 0.05, 0.09, 0.95), 10, Ui.GOLD, 2)
		_upd_banner.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
		_upd_banner.offset_left = -360
		_upd_banner.offset_right = 360
		_upd_banner.offset_top = -110
		_upd_banner.offset_bottom = -40
		_upd_banner.add_child(Ui.label("", "bold", 22, Color.WHITE))
		add_child(_upd_banner)
	var l: Label = _upd_banner.get_child(0)
	l.text = t
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER


func _http_get(url: String, to_file: String = "") -> Array:
	var http := HTTPRequest.new()
	http.timeout = 30.0
	if to_file != "":
		http.download_file = to_file
	add_child(http)
	var err := http.request(url + "?t=" + str(Time.get_unix_time_from_system()))
	if err != OK:
		http.queue_free()
		return [false, ""]
	var res: Array = await http.request_completed
	http.queue_free()
	var ok: bool = res[0] == HTTPRequest.RESULT_SUCCESS and int(res[1]) == 200
	return [ok, (res[3] as PackedByteArray).get_string_from_utf8() if to_file == "" else ""]


# at start: is there a newer update online? -> UPDATE button in the menu (and with "automatisch" it installs itself)
func _auto_update() -> void:
	var r: Array = await _http_get(UPDATE_FEED + "latest.json")
	if not r[0]:
		return                      # offline or no feed yet: just play
	var d = JSON.parse_string(String(r[1]))
	if not (d is Dictionary):
		return
	var ver := int(d.get("version", 0))
	var file := String(d.get("file", ""))
	if ver <= Updater.installed_number() or file == "":
		online_update = {}
		return
	online_update = {"version": ver, "file": file}
	if page == "home" or page == "settings":
		_rebuild()                  # shows the UPDATE button
	# automatic: each version is tried once per session (never a reload loop)
	if bool(settings.get("auto_update", true)) and int(Engine.get_meta("tf24_auto_tried", 0)) < ver:
		Engine.set_meta("tf24_auto_tried", ver)
		await install_online_update()


# one click: download the update from the internet and load it at once (no restart, nothing else to do)
func install_online_update() -> void:
	if online_update.is_empty() or (game != null and game.state != "menu"):
		return
	var ver := int(online_update["version"])
	var file := String(online_update["file"])
	_banner("Update %d wird geladen …" % ver)
	DirAccess.make_dir_recursive_absolute(Updater.UPDATE_DIR)
	var tmp := "user://update_download.zip"
	var g: Array = await _http_get(UPDATE_FEED + file, tmp)
	if not g[0]:
		_banner("Update %d konnte nicht geladen werden – später nochmal." % ver)
		get_tree().create_timer(4.0).timeout.connect(_banner_hide)
		return
	var err := Updater.install(ProjectSettings.globalize_path(tmp))
	if err != "":
		_banner("Update %d fehlerhaft: %s" % [ver, err])
		get_tree().create_timer(4.0).timeout.connect(_banner_hide)
		return
	DirAccess.remove_absolute(ProjectSettings.globalize_path(tmp))
	_banner("Update %d wird installiert – das Spiel startet kurz neu …" % ver if not OS.has_feature("editor") else "Update %d wird installiert …" % ver)
	await get_tree().create_timer(0.8).timeout
	Updater.apply_now(get_tree())


func _banner_hide() -> void:
	if _upd_banner != null and is_instance_valid(_upd_banner):
		_upd_banner.queue_free()


# newer profile online (played on another computer)? take it over
func _acc_sync_down() -> void:
	var acc = game.account
	var d: Dictionary = await acc.download()
	if d.get("ok", false) and d["data"] != null:
		var cloud: Dictionary = d["data"]
		if float(cloud.get("saved_at", 0.0)) > float(Profile.current.get("saved_at", 0.0)) + 1.0:
			acc.from_cloud(cloud, Profile.current)
			Profile.save_all()
			_rebuild()


# ---------------------------------------------------------------- navigation
func go(p: String, push: bool = true) -> void:
	if push and page != p:
		history.append(page)
	page = p
	_rebuild()


func _logo_pressed() -> void:
	history.clear()
	go("home" if Profile.logged_in() else "login", false)


func go_back() -> void:
	if page == "login" and not Profile.logged_in():
		return
	if not Profile.logged_in() and page != "login":
		history.clear()
		go("login", false)
		return
	if history.is_empty():
		go("home", false)
		return
	page = history.pop_back()
	_rebuild()


func refresh() -> void:
	_rebuild()


func _rebuild() -> void:
	for ch in content.get_children():
		ch.queue_free()
	if back_btn != null:
		# on the sign-in page there is nothing to go back to: the arrow is greyed out
		var dead: bool = page == "login" and not Profile.logged_in()
		back_btn.disabled = dead
		back_btn.modulate.a = 0.3 if dead else 1.0
	_build_nav()
	_build_chip()
	desc_title = null
	desc_text = null
	match page:
		"login":
			_page_login()
		"profile_edit":
			_page_profile_edit()
		"weekend":
			_page_weekend()
		"advanced":
			_page_advanced()
		"garage":
			_page_garage()
		"settings":
			_page_settings()
		"profile":
			_page_profile()
		"online":
			_page_online()
		_:
			_page_home()


func _section_name() -> String:
	return {"home": "HAUPTMENÜ", "weekend": "RENNWOCHENENDE", "advanced": "RENNWOCHENENDE", "garage": "PIT GARAGE",
		"settings": "EINSTELLUNGEN", "profile": "PROFIL", "profile_edit": "PROFIL", "online": "ONLINE", "login": "ANMELDEN"}.get(page, "MENÜ")


func _build_nav() -> void:
	title_lbl.text = _section_name()
	for ch in nav_box.get_children():
		ch.queue_free()
	if page == "login" or (page == "profile_edit" and not Profile.logged_in()):
		return
	var items := [["HAUPTMENÜ", "home"], ["EINZELSPIELER", "weekend"], ["ONLINE", "online"], ["PROFIL", "profile"], ["EINSTELLUNGEN", "settings"]]
	var cur := page
	if cur in ["advanced", "garage"]:
		cur = "weekend"
	if cur == "profile_edit":
		cur = "profile"
	for it in items:
		var b := Ui.nav(it[0], cur == it[1])
		b.pressed.connect(go.bind(it[1]))
		nav_box.add_child(b)


func _build_chip() -> void:
	for ch in chip.get_children():
		ch.queue_free()
	if not Profile.logged_in() or page == "login":
		return
	var p: Dictionary = Profile.current
	var pc := Ui.panel(Color(0.1, 0.12, 0.18, 0.85), 6, Color(1, 1, 1, 0.15), 1)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 8)
	pc.add_child(hb)
	hb.add_child(Ui.Avatar.new().setup(p["c1"], p["c2"], 38.0, int(p.get("icon", 0)), int(p.get("number", 24))))
	hb.add_child(Ui.label(String(p["name"]).to_upper(), "bold", 20))
	var dr := Profile.dr_tier(p["dr"])
	var sr := Profile.sr_tier(p["sr"])
	hb.add_child(_mini_rank("DR", dr))
	hb.add_child(_mini_rank("SR", sr))
	pc.gui_input.connect(_chip_click)
	pc.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	chip.add_child(pc)


func _chip_click(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.pressed:
		go("profile")


func _mini_rank(kind: String, tier: Array) -> Control:
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 0)
	var k := Ui.panel(Color(0.95, 0.95, 0.96), 2, Color(0, 0, 0, 0), 0)
	var kl := Ui.label(kind, "head", 15, Color(0.1, 0.1, 0.12))
	k.add_child(kl)
	hb.add_child(k)
	var t := Ui.panel(Ui.Badge.tier_col(tier[0]), 2, Color(0, 0, 0, 0), 0)
	t.add_child(Ui.label(Profile.short_rank(tier), "head", 15, Color(0.08, 0.06, 0.04)))
	hb.add_child(t)
	return hb


# a column centred at the top of the content area
func _column(w: float, top: float = 10.0) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.anchor_left = 0.5
	v.anchor_right = 0.5
	v.offset_left = -w * 0.5
	v.offset_right = w * 0.5
	v.offset_top = top
	v.add_theme_constant_override("separation", 14)
	content.add_child(v)
	return v


func _scroll_column(w: float, h: float, top: float = 10.0) -> VBoxContainer:
	var sc := ScrollContainer.new()
	sc.anchor_left = 0.5
	sc.anchor_right = 0.5
	sc.offset_left = -w * 0.5
	sc.offset_right = w * 0.5
	sc.offset_top = top
	sc.offset_bottom = top + h
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 2)
	sc.add_child(v)
	return v


# ---------------------------------------------------------------- login / profiles
var login_sel := 0
var login_pw: LineEdit
var login_msg: Label


func _page_login() -> void:
	var col := _column(780, 24)
	col.add_child(Ui.label("WILLKOMMEN BEI", "bold", 26, Ui.MUTED))
	col.add_child(Ui.label("TROIS FORÊTS 24", "head", 84))
	# online account: same e-mail and password on every computer
	var ap := Ui.panel(Color(0.06, 0.08, 0.14, 0.94), 10, Color(1, 1, 1, 0.16), 1)
	var av := VBoxContainer.new()
	av.add_theme_constant_override("separation", 10)
	ap.add_child(av)
	av.add_child(Ui.label("MIT E-MAIL ANMELDEN", "head", 34))
	var info := Ui.label("Dein Fahrerprofil mit Rängen und Ergebnissen wird online gespeichert. Melde dich auf jedem Computer mit derselben E-Mail an.", "body", 16, Ui.MUTED)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(730, 0)
	av.add_child(info)
	acc_mail = Ui.line_edit(String(game.account.email) if game != null else "", "E-Mail-Adresse", 730)
	av.add_child(acc_mail)
	acc_pw = Ui.line_edit("", "Passwort (mindestens 6 Zeichen)", 730, true)
	acc_pw.text_submitted.connect(func(_t): _acc_login())
	av.add_child(acc_pw)
	var ah := HBoxContainer.new()
	ah.add_theme_constant_override("separation", 12)
	var bl := Ui.primary("ANMELDEN", 26, 260)
	bl.pressed.connect(_acc_login)
	ah.add_child(bl)
	var bs := Ui.outline("KONTO ERSTELLEN", 20, 240)
	bs.pressed.connect(_acc_signup)
	ah.add_child(bs)
	var br := Ui.outline("PASSWORT VERGESSEN", 16, 200)
	br.pressed.connect(_acc_reset)
	ah.add_child(br)
	av.add_child(ah)
	acc_msg = Ui.label("", "bold", 18, Ui.GOLD)
	acc_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	acc_msg.custom_minimum_size = Vector2(730, 0)
	av.add_child(acc_msg)
	col.add_child(ap)
	# local profiles (only on this computer)
	col.add_child(Ui.label("ODER LOKALES PROFIL  ·  nur auf diesem Computer", "bold", 20, Ui.MUTED))
	if Profile.profiles.is_empty():
		var b := Ui.outline("NEUES LOKALES PROFIL ERSTELLEN", 20, 420)
		b.pressed.connect(_new_profile)
		col.add_child(b)
		return
	var lp := Profile.last_profile()
	login_sel = maxi(0, Profile.profiles.find(lp))
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 8)
	col.add_child(list)
	for k in Profile.profiles.size():
		var p: Dictionary = Profile.profiles[k]
		var pc := Ui.panel(Color(0.08, 0.1, 0.16, 0.92) if k != login_sel else Color(0.2, 0.08, 0.13, 0.95), 6, Color.WHITE if k == login_sel else Color(1, 1, 1, 0.12), 2 if k == login_sel else 1)
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 16)
		pc.add_child(hb)
		hb.add_child(Ui.Avatar.new().setup(p["c1"], p["c2"], 56.0, int(p.get("icon", 0)), int(p.get("number", 24))))
		var vb := VBoxContainer.new()
		vb.add_child(Ui.label(String(p["name"]).to_upper(), "head", 30))
		var extra := ""
		if String(p.get("email", "")) != "":
			extra = "   ·   online: " + String(p["email"])
		elif String(p["pw"]) != "":
			extra = "   ·   Passwort"
		vb.add_child(Ui.label(String(p["team"]) + "   ·   #" + str(p["number"]) + extra, "body", 16, Ui.MUTED))
		Ui.hexpand(vb)
		hb.add_child(vb)
		hb.add_child(Ui.Flag.new().setup(p["country"], 44))
		hb.add_child(_mini_rank("DR", Profile.dr_tier(p["dr"])))
		pc.gui_input.connect(_login_pick.bind(k))
		pc.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		list.add_child(pc)
	var sel: Dictionary = Profile.profiles[login_sel]
	login_pw = null
	if String(sel["pw"]) != "":
		login_pw = Ui.line_edit("", "Passwort", 760, true)
		login_pw.text_submitted.connect(func(_t): _do_login())
		col.add_child(login_pw)
	login_msg = Ui.label("", "bold", 18, Ui.PINK)
	col.add_child(login_msg)
	var hb2 := HBoxContainer.new()
	hb2.add_theme_constant_override("separation", 12)
	var b2 := Ui.outline("MIT PROFIL STARTEN", 20, 300)
	b2.pressed.connect(_do_login)
	hb2.add_child(b2)
	var b3 := Ui.outline("NEUES PROFIL", 20, 220)
	b3.pressed.connect(_new_profile)
	hb2.add_child(b3)
	col.add_child(hb2)


# ---------------------------------------------------------------- online account
var acc_mail: LineEdit
var acc_pw: LineEdit
var acc_msg: Label
var link_pending := false        # the next new profile is linked to the signed-in account
var _acc_busy := false


func _acc_check() -> bool:
	var m := acc_mail.text.strip_edges()
	if not ("@" in m and "." in m.get_slice("@", 1)):
		acc_msg.text = "Bitte gib eine gültige E-Mail-Adresse ein."
		return false
	if acc_pw.text.length() < 6:
		acc_msg.text = "Das Passwort muss mindestens 6 Zeichen haben."
		return false
	return true


func _acc_login() -> void:
	if _acc_busy or not _acc_check():
		return
	_acc_busy = true
	acc_msg.text = "Anmelden …"
	var r: Dictionary = await game.account.sign_in(acc_mail.text, acc_pw.text)
	_acc_busy = false
	if not r["ok"]:
		acc_msg.text = String(r["error"])
		return
	await _acc_finish()


func _acc_signup() -> void:
	if _acc_busy or not _acc_check():
		return
	_acc_busy = true
	acc_msg.text = "Konto wird erstellt …"
	var r: Dictionary = await game.account.sign_up(acc_mail.text, acc_pw.text)
	_acc_busy = false
	if not r["ok"]:
		acc_msg.text = String(r["error"])
		return
	await _acc_finish()


func _acc_reset() -> void:
	var m := acc_mail.text.strip_edges()
	if not "@" in m:
		acc_msg.text = "Gib oben deine E-Mail-Adresse ein, dann schicke ich dir einen Link zum Zurücksetzen."
		return
	var r: Dictionary = await game.account.reset_password(m)
	acc_msg.text = "E-Mail zum Zurücksetzen ist unterwegs – schau in dein Postfach." if r["ok"] else String(r["error"])


# signed in: load the profile from the cloud (new computer), or link a local one / create a new one
func _acc_finish() -> void:
	var acc = game.account
	acc_msg.text = "Profil wird geladen …"
	var d: Dictionary = await acc.download()
	if not d["ok"]:
		acc_msg.text = String(d.get("error", "Profil konnte nicht geladen werden."))
		return
	var local: Dictionary = {}
	for p in Profile.profiles:
		if String(p.get("cloud_uid", "")) == acc.uid:
			local = p
	if d["data"] != null:
		if local.is_empty():
			local = Profile.make("Fahrer", "Team", "DE", 24, Color.RED, Color.WHITE, "")
			Profile.profiles.append(local)
		var cloud: Dictionary = d["data"]
		if local.get("saved_at", 0.0) <= float(cloud.get("saved_at", 0.0)) or not local.has("saved_at"):
			acc.from_cloud(cloud, local)
	elif local.is_empty() and not Profile.profiles.is_empty():
		# first sign-in: the highlighted local profile (with its ranks and results) goes online
		local = Profile.profiles[login_sel]
	if local.is_empty():
		link_pending = true
		edit_new = true
		acc_msg.text = ""
		go("profile_edit")
		return
	local["cloud_uid"] = acc.uid
	local["email"] = acc.email
	local["pw"] = ""
	Profile.login(local)
	history.clear()
	go("home", false)


func _login_pick(ev: InputEvent, k: int) -> void:
	if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
		login_sel = k
		Profile.last_id = String(Profile.profiles[k]["id"])
		_rebuild()
		if ev.double_click:
			_do_login()


func _do_login() -> void:
	var p: Dictionary = Profile.profiles[login_sel]
	var pw := login_pw.text if login_pw != null else ""
	if not Profile.check_password(p, pw):
		login_msg.text = "Falsches Passwort."
		return
	Profile.login(p)
	history.clear()
	go("home", false)


func _new_profile() -> void:
	edit_new = true
	go("profile_edit")


# profile editor (new profile or edit the current one)
var ed := {}


func _page_profile_edit() -> void:
	var p: Dictionary = {} if edit_new else Profile.current
	ed = {"name": p.get("name", ""), "team": p.get("team", ""), "country": p.get("country", "DE"), "number": p.get("number", 24),
		"livery": settings["livery"], "icon": int(p.get("icon", 0)), "c1": p.get("c1", Ui.ICON_COLORS[0]), "c2": p.get("c2", Ui.ICON_COLORS[2])}
	var col := _column(900, 20)
	col.add_child(Ui.label("NEUES FAHRERPROFIL" if edit_new else "PROFIL BEARBEITEN", "head", 56))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 14)
	col.add_child(grid)
	var e_name := Ui.line_edit(ed["name"], "z. B. David Bärnreuther", 560)
	var e_team := Ui.line_edit(ed["team"], "z. B. Team Traindorf Racing", 560)
	var e_num := Ui.line_edit(str(ed["number"]), "1 – 999", 160)
	var e_pw := Ui.line_edit("", "leer lassen = kein Passwort" if edit_new else "leer lassen = unverändert", 560, true)
	grid.add_child(Ui.label("FAHRERNAME", "bold", 22, Ui.MUTED))
	grid.add_child(e_name)
	grid.add_child(Ui.label("TEAMNAME", "bold", 22, Ui.MUTED))
	grid.add_child(e_team)
	grid.add_child(Ui.label("STARTNUMMER", "bold", 22, Ui.MUTED))
	grid.add_child(e_num)
	var countries: Array = []
	for k in Ui.FLAGS.keys():
		countries.append([String(Ui.FLAGS[k]["n"]), k])
	grid.add_child(Ui.label("LAND", "bold", 22, Ui.MUTED))
	var flag_row := HBoxContainer.new()
	var flag := Ui.Flag.new().setup(ed["country"], 44)
	flag_row.add_child(flag)
	var _lf1 := func(v):
		ed["country"] = v
		flag.setup(v, 44)
		flag.queue_redraw()
	var csel := Ui.Selector.new().setup(countries, ed["country"], _lf1, 20, 220)
	flag_row.add_child(csel)
	grid.add_child(flag_row)
	var livs: Array = []
	for k in LIVERIES.size():
		livs.append([LIVERIES[k][0], k])
	grid.add_child(Ui.label("TEAMFARBEN", "bold", 22, Ui.MUTED))
	grid.add_child(Ui.Selector.new().setup(livs, ed["livery"], func(v): ed["livery"] = v, 20, 220))
	# profile icon: motif + two colours, preview updates live
	grid.add_child(Ui.label("PROFIL-ICON", "bold", 22, Ui.MUTED))
	icon_row = HBoxContainer.new()
	icon_row.add_theme_constant_override("separation", 8)
	grid.add_child(icon_row)
	_fill_icon_row()
	for ck in ["c1", "c2"]:
		grid.add_child(Ui.label("ICON-FARBE " + ("1" if ck == "c1" else "2"), "bold", 22, Ui.MUTED))
		var sw := HBoxContainer.new()
		sw.add_theme_constant_override("separation", 6)
		for swc in Ui.ICON_COLORS:
			var b := Button.new()
			b.custom_minimum_size = Vector2(36, 36)
			var on: bool = Color(ed[ck]).is_equal_approx(swc)
			b.add_theme_stylebox_override("normal", Ui.box(swc, 18, Color.WHITE if on else Color(1, 1, 1, 0.2), 3 if on else 1))
			b.add_theme_stylebox_override("hover", Ui.box(swc.lightened(0.15), 18, Color.WHITE, 2))
			b.add_theme_stylebox_override("pressed", Ui.box(swc, 18, Color.WHITE, 3))
			b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
			b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
			b.pressed.connect(_pick_icon_color.bind(ck, swc, sw))
			sw.add_child(b)
		grid.add_child(sw)
	grid.add_child(Ui.label("PASSWORT (OPTIONAL)", "bold", 22, Ui.MUTED))
	grid.add_child(e_pw)
	var msg := Ui.label("", "bold", 18, Ui.PINK)
	col.add_child(msg)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	var save := Ui.primary("SPEICHERN", 26, 300)
	var _lf2 := func():
		var nm := e_name.text.strip_edges()
		if nm.length() < 2:
			msg.text = "Bitte gib einen Fahrernamen ein."
			return
		var team := e_team.text.strip_edges()
		if team == "":
			team = nm + " Racing"
		var lv: Array = LIVERIES[int(ed["livery"])]
		settings["livery"] = int(ed["livery"])
		save_settings()
		if edit_new:
			var np := Profile.make(nm, team, ed["country"], int(e_num.text) if e_num.text.is_valid_int() else 24, ed["c1"], ed["c2"], e_pw.text)
			np["icon"] = int(ed["icon"])
			if link_pending and game.account.signed_in():
				np["cloud_uid"] = game.account.uid
				np["email"] = game.account.email
				np["pw"] = ""
			link_pending = false
			Profile.add(np)
		else:
			var cp: Dictionary = Profile.current
			cp["name"] = nm
			cp["team"] = team
			cp["country"] = ed["country"]
			cp["number"] = clampi(int(e_num.text) if e_num.text.is_valid_int() else 24, 1, 999)
			cp["c1"] = ed["c1"]
			cp["c2"] = ed["c2"]
			cp["icon"] = int(ed["icon"])
			if e_pw.text != "":
				Profile.set_password(cp, e_pw.text)
			Profile.save_all()
		edit_new = false
		history.clear()
		go("profile" if Profile.logged_in() else "home", false)
	save.pressed.connect(_lf2)
	hb.add_child(save)
	var cancel := Ui.outline("ABBRECHEN", 20, 200)
	var _lf3 := func():
		edit_new = false
		if Profile.logged_in():
			go_back()
		else:
			go("login", false)
	cancel.pressed.connect(_lf3)
	hb.add_child(cancel)
	col.add_child(hb)


var icon_row: HBoxContainer


func _fill_icon_row() -> void:
	for ch in icon_row.get_children():
		ch.queue_free()
	for k in Ui.ICONS.size():
		var av := Ui.Avatar.new().setup(ed["c1"], ed["c2"], 62.0, k, int(ed["number"]))
		av.selected = k == int(ed["icon"])
		av.tooltip_text = Ui.ICONS[k]
		av.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		av.gui_input.connect(_pick_icon.bind(k))
		icon_row.add_child(av)


func _pick_icon(ev: InputEvent, k: int) -> void:
	if ev is InputEventMouseButton and ev.pressed and ev.button_index == MOUSE_BUTTON_LEFT:
		ed["icon"] = k
		_fill_icon_row()


func _pick_icon_color(ck: String, col: Color, row: HBoxContainer) -> void:
	ed[ck] = col
	_fill_icon_row()
	for b in row.get_children():
		var bb: Button = b
		var sb: StyleBoxFlat = bb.get_theme_stylebox("normal")
		var on: bool = sb.bg_color.is_equal_approx(col)
		bb.add_theme_stylebox_override("normal", Ui.box(sb.bg_color, 18, Color.WHITE if on else Color(1, 1, 1, 0.2), 3 if on else 1))


# ---------------------------------------------------------------- home: event cards
func _page_home() -> void:
	var nu := Updater.newer_update()
	var col := _column(1560, 10)
	if not online_update.is_empty():
		var ob := Ui.accent("⬇  UPDATE %d VERFÜGBAR  –  JETZT UPDATEN" % int(online_update["version"]), 22)
		ob.pressed.connect(install_online_update)
		col.add_child(ob)
	elif nu != "":
		var ub := Ui.accent("⬇  NEUES UPDATE %d VERFÜGBAR  –  JETZT UPDATEN" % Updater.file_number(nu), 22)
		ub.pressed.connect(_install_update.bind(nu))
		col.add_child(ub)
	var tabs := HBoxContainer.new()
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	tabs.add_theme_constant_override("separation", 26)
	for t in [["NÄCHSTES", "home"], ["EINZELSPIELER", "weekend"], ["ONLINE", "online"]]:
		var nb := Ui.nav(t[0], t[1] == "home", 22)
		nb.pressed.connect(go.bind(t[1]))
		tabs.add_child(nb)
	col.add_child(tabs)
	var extra := HBoxContainer.new()
	extra.alignment = BoxContainer.ALIGNMENT_CENTER
	extra.add_theme_constant_override("separation", 16)
	var vb := Ui.outline("STRECKE ANSEHEN", 18, 280)
	vb.pressed.connect(func(): game.start_viewer())
	extra.add_child(vb)
	var rb := Ui.outline("REPLAY ÖFFNEN", 18, 280)
	rb.pressed.connect(_open_replay)
	extra.add_child(rb)
	col.add_child(extra)
	var cards := HBoxContainer.new()
	cards.alignment = BoxContainer.ALIGNMENT_CENTER
	cards.add_theme_constant_override("separation", 26)
	col.add_child(cards)
	var tr: String = settings["track"]
	cards.add_child(_event_card(true, ["SR BRONZE", "GT3"], "SCHNELLES RENNEN", TRACK_INFO["spa"]["title"], "spa", "20 MIN", "KEINE", "SOFORT STARTEN", _quick_race))
	cards.add_child(_event_card(false, ["HY", "GT3"], "RENNWOCHENENDE", TRACK_INFO[tr]["title"], tr, _event_len_text(), "KEINE", "EINRICHTEN", go.bind("weekend")))
	cards.add_child(_event_card(false, ["ONLINE", "LAN"], "MEHRSPIELER", "MIT FREUNDEN PER IP", tr, "FREI", "KEINE", "LOBBY ÖFFNEN", go.bind("online")))
	cards.add_child(_event_card(true, ["PROFIL"], "MEINE KARRIERE", String(Profile.current.get("name", "")).to_upper(), tr, "%d RENNEN" % int(Profile.current.get("stats", {}).get("races", 0)), "-", "PROFIL ANSEHEN", go.bind("profile")))


func _open_replay() -> void:
	var fd := FileDialog.new()
	fd.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	fd.access = FileDialog.ACCESS_FILESYSTEM
	fd.use_native_dialog = true
	fd.title = "Replay öffnen"
	fd.filters = PackedStringArray(["*.tf24replay ; TF24 Replay"])
	var dir: String = load("res://scripts/replay.gd").folder()
	DirAccess.make_dir_recursive_absolute(dir)
	fd.current_dir = dir
	fd.file_selected.connect(func(path: String): game.play_replay_file(path))
	add_child(fd)
	fd.popup_centered(Vector2i(900, 600))


func _event_len_text() -> String:
	var parts: Array = []
	if settings["wk_practice"]:
		parts.append("T")
	if settings["wk_quali"]:
		parts.append("Q")
	parts.append(_dur_name(settings["duration"]))
	return " + ".join(parts)


func _dur_name(d: String) -> String:
	return {"l3": "3 RUNDEN", "m20": "20 MIN", "m45": "45 MIN", "m90": "90 MIN", "h6": "6 STD", "h24": "24 STD"}.get(d, "20 MIN")


func _event_card(light: bool, badges: Array, title: String, sub: String, track: String, dur: String, swap: String, action: String, cb: Callable) -> Control:
	var pc := Ui.panel(Color(0.96, 0.96, 0.97, 0.97) if light else Color(0.05, 0.07, 0.15, 0.96), 10, Color(1, 1, 1, 0.5), 2)
	pc.custom_minimum_size = Vector2(360, 700)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	pc.add_child(v)
	var bh := HBoxContainer.new()
	for b in badges:
		var bc := Ui.panel(Ui.RED if b in ["GT3", "HY", "SR BRONZE"] else Color(0.15, 0.35, 0.8), 2, Color(0, 0, 0, 0), 0)
		if b == "GT3":
			bc = Ui.panel(Ui.GT, 2, Color(0, 0, 0, 0), 0)
		elif b == "HY":
			bc = Ui.panel(Ui.HY, 2, Color(0, 0, 0, 0), 0)
		elif b == "SR BRONZE":
			bc = Ui.panel(Color(0.66, 0.48, 0.3), 2, Color(0, 0, 0, 0), 0)
		bc.add_child(Ui.label(b, "head", 16, Color.WHITE))
		bh.add_child(bc)
	v.add_child(bh)
	var tl := Ui.label(title, "head", 62 if title.length() <= 12 else 50, Ui.RED if light else Color.WHITE)
	tl.autowrap_mode = TextServer.AUTOWRAP_WORD
	tl.custom_minimum_size = Vector2(320, 0)
	tl.add_theme_constant_override("line_spacing", -14)
	v.add_child(tl)
	var sl := Ui.label(sub, "bold", 22, Color(0.1, 0.1, 0.12) if light else Color(0.85, 0.87, 0.9))
	sl.autowrap_mode = TextServer.AUTOWRAP_WORD
	sl.custom_minimum_size = Vector2(320, 0)
	v.add_child(sl)
	var act := Ui.accent(action, 18)
	act.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	act.pressed.connect(cb)
	v.add_child(act)
	var ctrl: Array = Array(TrackDefs.spa()["ctrl"]) if track == "spa" else TrackDefs.trois_forets()["ctrl"]
	var ol := Ui.Outline.new().setup(ctrl, Color(0.1, 0.1, 0.12) if light else Color.WHITE, 4.0)
	ol.custom_minimum_size = Vector2(320, 240)
	ol.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(ol)
	var dk := Color(0.1, 0.1, 0.12) if light else Color.WHITE
	var mt := Color(0.35, 0.37, 0.42) if light else Ui.MUTED
	v.add_child(Ui.label("Streckenlänge", "body", 15, mt))
	v.add_child(Ui.label(String(TRACK_INFO[track]["km"]) + " KM", "head", 40, dk))
	var g := GridContainer.new()
	g.columns = 2
	g.add_theme_constant_override("h_separation", 50)
	g.add_child(Ui.label("Eventdauer", "body", 15, mt))
	g.add_child(Ui.label("Fahrerwechsel", "body", 15, mt))
	g.add_child(Ui.label(dur, "head", 30, Ui.RED if light else dk))
	g.add_child(Ui.label(swap, "head", 30, Ui.RED if light else dk))
	v.add_child(g)
	return pc


func _quick_race() -> void:
	settings["track"] = "spa"
	settings["duration"] = "m20"
	settings["wk_practice"] = false
	settings["wk_quali"] = false
	settings["wk_race"] = true
	_on_start()


# ---------------------------------------------------------------- race weekend
func _page_weekend() -> void:
	var tr: String = settings["track"]
	var info: Dictionary = TRACK_INFO[tr]
	var col := _column(1500, 0)
	col.add_theme_constant_override("separation", 8)
	# header: track outline, flag, name, location, facts, track switch
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 24)
	col.add_child(head)
	var ctrl: Array = Array(TrackDefs.spa()["ctrl"]) if tr == "spa" else TrackDefs.trois_forets()["ctrl"]
	var ol := Ui.Outline.new().setup(ctrl, Ui.RED, 5.0)
	ol.custom_minimum_size = Vector2(150, 120)
	head.add_child(ol)
	var vl := ColorRect.new()
	vl.color = Color(1, 1, 1, 0.3)
	vl.custom_minimum_size = Vector2(2, 120)
	head.add_child(vl)
	var hv := VBoxContainer.new()
	hv.add_theme_constant_override("separation", 0)
	var tline := HBoxContainer.new()
	tline.add_theme_constant_override("separation", 16)
	tline.add_child(Ui.Flag.new().setup(info["flag"], 70))
	tline.add_child(Ui.label(info["title"], "head", 60))
	hv.add_child(tline)
	hv.add_child(Ui.label(info["loc"], "head", 40, Color(1, 1, 1, 0.5)))
	hv.add_child(Ui.label("Eröffnet %s     %s km     %d Kurven" % [info["opened"], info["km"], info["corners"]], "body2", 18, Color(0.85, 0.87, 0.9)))
	Ui.hexpand(hv)
	head.add_child(hv)
	var tracks: Array = []
	for d in TrackDefs.all():
		tracks.append([String(d["short"]), d["id"]])
	var tsv := VBoxContainer.new()
	tsv.add_child(Ui.label("STRECKE", "bold", 16, Ui.MUTED))
	tsv.add_child(Ui.Selector.new().setup(tracks, tr, _on_track, 22, 180))
	head.add_child(tsv)
	# session options
	var so := HBoxContainer.new()
	so.add_theme_constant_override("separation", 20)
	so.add_child(Ui.label("SESSION-OPTIONEN", "head", 34))
	var adv := Ui.outline("FORTGESCHRITTENE OPTIONEN", 18)
	adv.pressed.connect(go.bind("advanced"))
	so.add_child(adv)
	col.add_child(so)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 18)
	row.alignment = BoxContainer.ALIGNMENT_BEGIN
	col.add_child(row)
	row.add_child(_session_card("TRAINING", "wk_practice", "practice_min", [["10 MIN", 10], ["15 MIN", 15], ["20 MIN", 20], ["30 MIN", 30], ["60 MIN", 60]], "PRIVAT"))
	row.add_child(_session_card("QUALIFYING", "wk_quali", "quali_min", [["10 MIN", 10], ["15 MIN", 15], ["20 MIN", 20], ["30 MIN", 30]], "PRIVAT"))
	row.add_child(_session_card("RENNEN", "wk_race", "duration", [["3 RUNDEN", "l3"], ["20 MIN", "m20"], ["45 MIN", "m45"], ["90 MIN", "m90"], ["6 STD.", "h6"], ["24 STD.", "h24"]], "STEHEND"))
	# car block
	var vline := ColorRect.new()
	vline.color = Color(1, 1, 1, 0.3)
	vline.custom_minimum_size = Vector2(2, 200)
	row.add_child(vline)
	row.add_child(_car_block())
	# start grid
	var gl := HBoxContainer.new()
	gl.add_theme_constant_override("separation", 18)
	gl.add_child(Ui.label("START-GRID", "head", 34))
	var fill := Ui.outline("FILL GRID", 16)
	var _lf4 := func():
		if settings["cls"] == "gt3":
			settings["n_gt3"] = 23
		else:
			settings["n_hy"] = 23
		_rebuild()
	fill.pressed.connect(_lf4)
	gl.add_child(fill)
	col.add_child(gl)
	var grow := HBoxContainer.new()
	grow.add_theme_constant_override("separation", 14)
	grow.add_child(_class_card("HY", "HYPERCAR", "n_hy", Ui.HY))
	grow.add_child(_class_card("GT3", "LMGT3", "n_gt3", Ui.GT))
	var gi := Ui.label("Deine Klasse wird automatisch mit dir aufgefüllt.\nAI-Stärke: %d %%   ·   Wetter: %s" % [int(settings["ai_diff"]), {"dry": "Trocken", "rain": "Regen", "mixed": "Wechselhaft"}.get(settings["weather"], "Trocken")], "body", 16, Ui.MUTED)
	gi.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	grow.add_child(gi)
	col.add_child(grow)
	# bottom bar
	var bot := HBoxContainer.new()
	bot.add_theme_constant_override("separation", 40)
	var ev := VBoxContainer.new()
	ev.add_child(Ui.label("Eventdauer", "body", 16, Ui.MUTED))
	ev.add_child(Ui.label(_event_len_text(), "head", 38))
	bot.add_child(ev)
	var rg := VBoxContainer.new()
	rg.add_child(Ui.label("Regeln", "body", 16, Ui.MUTED))
	rg.add_child(Ui.Selector.new().setup([["DEFAULT", true], ["OHNE TRACK LIMITS", false]], settings["quali_limits"], _setter("quali_limits"), 26, 230))
	bot.add_child(rg)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bot.add_child(spacer)
	var setup := Ui.outline("AUTO-SETUP", 22, 220)
	setup.pressed.connect(go.bind("garage"))
	bot.add_child(setup)
	var st := Ui.primary("RENNWOCHENENDE STARTEN", 28, 420)
	st.pressed.connect(go.bind("garage"))
	bot.add_child(st)
	col.add_child(bot)


func _session_card(title: String, on_key: String, dur_key: String, durs: Array, typ: String) -> Control:
	var on: bool = settings[on_key]
	var pc := Ui.panel(Color(0.04, 0.06, 0.12, 0.85) if on else Color(0.04, 0.06, 0.12, 0.4), 10, Color(1, 1, 1, 0.85) if on else Color(1, 1, 1, 0.25), 2)
	pc.custom_minimum_size = Vector2(300, 200)
	pc.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	pc.add_child(v)
	var hb := HBoxContainer.new()
	var tl := Ui.label(title, "head", 38, Color.WHITE if on else Color(1, 1, 1, 0.45))
	Ui.hexpand(tl)
	hb.add_child(tl)
	if title != "RENNEN":
		var _lf5 := func(x):
			settings[on_key] = x
			_rebuild()
		hb.add_child(Ui.Pill.new().setup(on, _lf5))
	else:
		hb.add_child(Ui.label("✓", "head", 30))
	v.add_child(hb)
	v.add_child(WeatherIcons.new().setup(settings["weather"]))
	var g := GridContainer.new()
	g.columns = 2
	g.add_theme_constant_override("h_separation", 30)
	g.add_child(Ui.label("Start" if title == "RENNEN" else "Typ", "body", 16, Ui.MUTED))
	g.add_child(Ui.label("Dauer", "body", 16, Ui.MUTED))
	g.add_child(Ui.label(typ, "head", 26))
	g.add_child(Ui.Selector.new().setup(durs, settings[dur_key], _setter(dur_key), 24, 100))
	v.add_child(g)
	return pc


func _class_card(short: String, long: String, key: String, c: Color) -> Control:
	var mine: bool = (settings["cls"] == "gt3") == (short == "GT3")
	var n: int = settings[key]
	var pc := Ui.panel(Color(0.04, 0.06, 0.12, 0.85), 8, Color(1, 1, 1, 0.85) if n > 0 or mine else Color(1, 1, 1, 0.25), 2)
	pc.custom_minimum_size = Vector2(250, 120)
	var v := VBoxContainer.new()
	pc.add_child(v)
	var hb := HBoxContainer.new()
	var sl := Ui.label(short, "head", 54, c if (n > 0 or mine) else Color(1, 1, 1, 0.35))
	Ui.hexpand(sl)
	hb.add_child(sl)
	if mine:
		hb.add_child(Ui.label("DU", "head", 20, Ui.GOLD))
	v.add_child(hb)
	var hb2 := HBoxContainer.new()
	var ll := Ui.label(long, "bold", 22, Color(1, 1, 1, 0.75))
	Ui.hexpand(ll)
	hb2.add_child(ll)
	var counts: Array = []
	for k in 24:
		counts.append([str(k), k])
	var _lf6 := func(x):
		settings[key] = int(x)
		settings["opponents"] = int(settings["n_hy"]) + int(settings["n_gt3"])
	hb2.add_child(Ui.Selector.new().setup(counts, n, _lf6, 24, 44))
	v.add_child(hb2)
	return pc


func _car_block() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	var p: Dictionary = Profile.current
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 16)
	var logo := ClassLogo.new()
	logo.cls = settings["cls"]
	logo.custom_minimum_size = Vector2(110, 110)
	hb.add_child(logo)
	var vline := ColorRect.new()
	vline.color = Color(1, 1, 1, 0.3)
	vline.custom_minimum_size = Vector2(2, 110)
	hb.add_child(vline)
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", -8)
	tv.add_child(Ui.label(String(p.get("team", "DEIN TEAM")).to_upper(), "head", 40))
	tv.add_child(Ui.label("#" + str(p.get("number", 24)), "head", 48))
	tv.add_child(Ui.label("MERCEDES-AMG LMGT3" if settings["cls"] == "gt3" else "HYPERCAR PROTOTYP", "bold", 22, Color(0.85, 0.87, 0.9)))
	hb.add_child(tv)
	v.add_child(hb)
	var lv: Array = LIVERIES[int(settings["livery"])]
	v.add_child(CarShowcase.new().setup(settings["cls"], [lv[1], lv[2], lv[3]], int(p.get("number", 24)), Vector2i(470, 190), false))
	var sel := HBoxContainer.new()
	var _lf7 := func(x):
		settings["cls"] = x
		_rebuild()
	sel.add_child(Ui.Selector.new().setup([["LMGT3", "gt3"], ["HYPERCAR", "hyper"]], settings["cls"], _lf7, 20, 120))
	var livs: Array = []
	for k in LIVERIES.size():
		livs.append([String(LIVERIES[k][0]).to_upper(), k])
	if settings["cls"] == "gt3" and ResourceLoader.exists("res://models/gt3.glb"):
		livs = [["ORIGINAL-LACKIERUNG", int(settings["livery"])]]
	var _lf8 := func(x):
		settings["livery"] = int(x)
		_rebuild()
	sel.add_child(Ui.Selector.new().setup(livs, settings["livery"], _lf8, 18, 170))
	v.add_child(sel)
	return v


# ---------------------------------------------------------------- advanced options (list with ‹ › values)
func _page_advanced() -> void:
	var col := _column(820, 0)
	var tabs := HBoxContainer.new()
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	tabs.add_theme_constant_override("separation", 20)
	for t in [["SCHWIERIGKEITSGRAD", "difficulty"], ["SESSIONS", "sessions"], ["WETTER", "weather"]]:
		var b := Ui.nav(t[0], adv_tab == t[1], 22)
		var _lf9 := func():
			adv_tab = t[1]
			_rebuild()
		b.pressed.connect(_lf9)
		tabs.add_child(b)
	col.add_child(tabs)
	var list := _scroll_column(820, 760, 70)
	match adv_tab:
		"sessions":
			_list_head(list, "TRAINING", ("%d MIN" % int(settings["practice_min"])) if settings["wk_practice"] else "AUS")
			_list_row(list, "Training", _pill("wk_practice"))
			_list_row(list, "Trainingsdauer", _sel("practice_min", [["10 mins", 10], ["15 mins", 15], ["20 mins", 20], ["30 mins", 30], ["1 hrs", 60]]))
			_list_head(list, "QUALIFYING", ("%d MIN" % int(settings["quali_min"])) if settings["wk_quali"] else "AUS")
			_list_row(list, "Qualifying", _pill("wk_quali"))
			_list_row(list, "Qualifyingdauer", _sel("quali_min", [["10 mins", 10], ["15 mins", 15], ["20 mins", 20], ["30 mins", 30]]))
			_list_row(list, "Track Limits (gestrichene Runden, Strafen)", _pill("quali_limits"))
			_list_head(list, "RENNEN", _dur_name(settings["duration"]))
			_list_row(list, "Renndauer", _sel("duration", [["3 Runden", "l3"], ["20 mins", "m20"], ["45 mins", "m45"], ["90 mins", "m90"], ["6 hrs", "h6"], ["24 hrs", "h24"]]))
			_list_row(list, "Starterfeld", _sel("field", [["Nur meine Klasse", "own"], ["Gemischt", "mixed"]]))
		"weather":
			_list_head(list, "WETTER & TAGESZEIT", "")
			_list_row(list, "Wetter", _sel("weather", [["Trocken", "dry"], ["Regen", "rain"], ["Wechselhaft", "mixed"]]))
			_list_row(list, "Startzeit", _sel("start_hour", [["10:30 AM", 10.5], ["2:00 PM", 14.0], ["7:30 PM", 19.5], ["9:30 PM Dämmerung", 21.5], ["1:00 AM Nacht", 1.0], ["4:30 AM Morgengrauen", 4.5]]))
			_list_row(list, "Real-Road-Zeitskalierung", _sel("time_scale", [["Normal (1×)", 1.0], ["8×", 8.0], ["24×", 24.0], ["60×", 60.0]]))
		_:
			_list_head(list, "SCHWIERIGKEITSGRAD", "")
			_list_row(list, "KI-Stärke", _sel("ai_diff", [["50 %", 50.0], ["70 %", 70.0], ["80 %", 80.0], ["90 %", 90.0], ["100 %", 100.0], ["110 %", 110.0], ["120 %", 120.0]]))
			_list_row(list, "Reifen- & Spritverbrauch", _sel("wear", [["Realistisch", 1.0], ["2×", 2.0], ["4×", 4.0]]))
			_list_row(list, "Schaden", _sel("damage", [["Realistisch", 1.0], ["Reduziert", 0.5], ["Aus", 0.0]]))
	var back := Ui.outline("ZURÜCK ZUM RENNWOCHENENDE", 18, 320)
	back.pressed.connect(go_back)
	back.anchor_left = 0.5
	back.anchor_right = 0.5
	back.offset_left = -160
	back.offset_right = 160
	back.offset_top = 850
	content.add_child(back)


func _list_head(list: VBoxContainer, t: String, right: String) -> void:
	list.add_child(Ui.spacer(14))
	var hb := HBoxContainer.new()
	var l := Ui.label(t, "head", 38, Color(1, 1, 1, 0.55))
	Ui.hexpand(l)
	hb.add_child(l)
	hb.add_child(Ui.label(right, "head", 38, Color(1, 1, 1, 0.55)))
	list.add_child(hb)
	var ln := ColorRect.new()
	ln.color = Color(1, 1, 1, 0.15)
	ln.custom_minimum_size = Vector2(0, 1)
	list.add_child(ln)


# one settings row: label left, control right, hover highlight, description on the right panel
func _list_row(list: VBoxContainer, label_text: String, ctrl: Control, desc: String = "") -> void:
	var pc := PanelContainer.new()
	var normal := Ui.box(Color(0, 0, 0, 0), 0)
	var hover := Ui.box(Color(1, 1, 1, 0.1), 0)
	pc.add_theme_stylebox_override("panel", normal)
	var hb := HBoxContainer.new()
	pc.add_child(hb)
	var l := Ui.label(label_text, "body2", 18)
	Ui.hexpand(l)
	l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(l)
	hb.add_child(ctrl)
	var _lf10 := func():
		pc.add_theme_stylebox_override("panel", hover)
		if desc_title != null:
			desc_title.text = label_text.to_upper()
			desc_text.text = desc if desc != "" else "Einstellung: " + label_text
	pc.mouse_entered.connect(_lf10)
	pc.mouse_exited.connect(func(): pc.add_theme_stylebox_override("panel", normal))
	list.add_child(pc)
	var ln := ColorRect.new()
	ln.color = Color(1, 1, 1, 0.07)
	ln.custom_minimum_size = Vector2(0, 1)
	list.add_child(ln)


func _pill(key: String, cb: Callable = Callable()) -> Control:
	var hb := HBoxContainer.new()
	var st := Ui.label("On" if settings[key] else "Off", "body2", 17)
	hb.add_child(st)
	var _lf11 := func(x):
		settings[key] = x
		st.text = "On" if x else "Off"
		if cb.is_valid():
			cb.call(x)
	hb.add_child(Ui.Pill.new().setup(settings[key], _lf11))
	return hb


func _sel(key: String, items: Array, cb: Callable = Callable(), w: float = 210.0) -> Control:
	var _lf12 := func(x):
		settings[key] = x
		if cb.is_valid():
			cb.call(x)
	return Ui.Selector.new().setup(items, settings[key], _lf12, 19, w)


func _slider_ctrl(key: String, lo: float, hi: float, step: float, fmt: String, cb: Callable = Callable()) -> Control:
	var hb := HBoxContainer.new()
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = step
	s.value = float(settings[key])
	s.custom_minimum_size = Vector2(200, 24)
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var lbl := Ui.label(fmt % float(settings[key]), "bold", 18)
	lbl.custom_minimum_size = Vector2(70, 0)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	var _lf13 := func(x):
		settings[key] = x
		lbl.text = fmt % x
		if cb.is_valid():
			cb.call(x)
	s.value_changed.connect(_lf13)
	hb.add_child(s)
	hb.add_child(lbl)
	return hb


# ---------------------------------------------------------------- pit garage (car setup, then drive)
func _page_garage() -> void:
	var cls: String = settings["cls"]
	var su: Dictionary = settings["setup_" + cls]
	var p: Dictionary = Profile.current
	var tr: String = settings["track"]
	var info: Dictionary = TRACK_INFO[tr]
	var tabs := HBoxContainer.new()
	tabs.anchor_left = 0.5
	tabs.anchor_right = 0.5
	tabs.offset_left = -500
	tabs.offset_right = 500
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	tabs.add_theme_constant_override("separation", 22)
	for t in [["STANDARD", "standard"], ["ANTRIEBSSTRANG", "drive"], ["RÄDER & BREMSEN", "wheels"], ["AUFHÄNGUNG", "susp"], ["CHASSIS & AERO", "aero"]]:
		var b := Ui.nav(t[0], garage_tab == t[1], 22)
		var _lf14 := func():
			garage_tab = t[1]
			_rebuild()
		b.pressed.connect(_lf14)
		tabs.add_child(b)
	content.add_child(tabs)
	var root := HBoxContainer.new()
	root.anchor_left = 0.5
	root.anchor_right = 0.5
	root.offset_left = -780
	root.offset_right = 780
	root.offset_top = 70
	root.add_theme_constant_override("separation", 30)
	content.add_child(root)
	# left: track / team, setup values
	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(520, 0)
	left.add_theme_constant_override("separation", 6)
	root.add_child(left)
	var tl := HBoxContainer.new()
	tl.add_theme_constant_override("separation", 12)
	tl.add_child(Ui.Flag.new().setup(info["flag"], 48))
	var tn := Ui.label(info["title"], "head", 44)
	tn.autowrap_mode = TextServer.AUTOWRAP_WORD
	tn.custom_minimum_size = Vector2(460, 0)
	tl.add_child(tn)
	left.add_child(tl)
	left.add_child(Ui.label("#%d %s" % [int(p.get("number", 24)), String(p.get("team", "")).to_upper()], "head", 48, Color(1, 1, 1, 0.45)))
	left.add_child(Ui.spacer(10))
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 2)
	left.add_child(list)
	var comps: Array = []
	for ck in ["soft", "medium", "hard", "wet"]:
		comps.append([String(CarPhysics.COMPOUNDS[ck]["name"]), ck])
	var put := func(k: String): return func(x): su[k] = x
	match garage_tab:
		"drive":
			_list_row(list, "Getriebeübersetzung", Ui.Selector.new().setup([["Kurz", 0], ["Mittel", 1], ["Lang", 2]], su["gearing"], put.call("gearing"), 19, 160), "Kurz = mehr Beschleunigung, Lang = mehr Topspeed auf der Kemmel-Geraden.")
			_list_row(list, "Traktionskontrolle", _num_sel(su, "tc", 0, 10, 1, "%d"), "0 = aus. Höher = weniger Durchdrehen, aber langsamer aus engen Kurven.")
		"wheels":
			_list_row(list, "Reifenmischung", Ui.Selector.new().setup(comps, su["compound"], put.call("compound"), 19, 160), "Soft: viel Grip, hoher Verschleiß · Hard: lange Stints · Regen nur bei Nässe.")
			_list_row(list, "Reifendruck vorne", _num_sel(su, "press_f", -0.4, 0.4, 0.05, "%+.2f bar"), "Niedriger Druck = mehr Temperatur und Verschleiß.")
			_list_row(list, "Reifendruck hinten", _num_sel(su, "press_r", -0.4, 0.4, 0.05, "%+.2f bar"))
			_list_row(list, "Bremsbalance vorne", _num_sel(su, "bias", 0.5, 0.68, 0.005, "%.3f"), "Mehr vorne = stabiler, aber blockierende Vorderräder.")
			_list_row(list, "ABS", _num_sel(su, "abs", 0, 10, 1, "%d"), "0 = aus. Beim GT3 Pflicht, beim Hypercar optional.")
		"susp":
			_list_row(list, "Federhärte", _num_sel(su, "spring", 1, 10, 1, "%d"), "Weicher schluckt Curbs besser, kostet etwas Abtrieb.")
			_list_row(list, "Stabilisator vorne", _num_sel(su, "arb_f", 1, 10, 1, "%d"), "Härter vorne = mehr Untersteuern.")
			_list_row(list, "Stabilisator hinten", _num_sel(su, "arb_r", 1, 10, 1, "%d"), "Härter hinten = mehr Übersteuern.")
		"aero":
			_list_row(list, "Heckflügel", _num_sel(su, "wing", 1, 10, 1, "%d"), "Mehr Flügel = mehr Abtrieb in Pouhon und Blanchimont, weniger Topspeed.")
		_:
			_list_row(list, "Reifenmischung", Ui.Selector.new().setup(comps, su["compound"], put.call("compound"), 19, 160))
			_list_row(list, "Heckflügel", _num_sel(su, "wing", 1, 10, 1, "%d"))
			_list_row(list, "Bremsbalance vorne", _num_sel(su, "bias", 0.5, 0.68, 0.005, "%.3f"))
			_list_row(list, "Getriebeübersetzung", Ui.Selector.new().setup([["Kurz", 0], ["Mittel", 1], ["Lang", 2]], su["gearing"], put.call("gearing"), 19, 160))
	var rs := Ui.outline("STANDARD-SETUP LADEN", 16, 240)
	var _lf15 := func():
		settings["setup_" + cls] = CarPhysics.default_setup(cls)
		_rebuild()
	rs.pressed.connect(_lf15)
	left.add_child(Ui.spacer(8))
	left.add_child(rs)
	# centre: car from above with tyre labels
	var mid := VBoxContainer.new()
	mid.custom_minimum_size = Vector2(300, 0)
	var lv: Array = LIVERIES[int(settings["livery"])]
	var frame := Ui.panel(Color(0.04, 0.06, 0.12, 0.85), 8, Color(1, 1, 1, 0.12), 1)
	frame.add_child(CarShowcase.new().setup(cls, [lv[1], lv[2], lv[3]], int(p.get("number", 24)), Vector2i(300, 520), true))
	mid.add_child(frame)
	var tl2 := GridContainer.new()
	tl2.columns = 2
	tl2.add_theme_constant_override("h_separation", 60)
	var cname := String(CarPhysics.COMPOUNDS[su["compound"]]["name"])
	for k in ["Vorne links", "Vorne rechts", "Hinten links", "Hinten rechts"]:
		var tv := VBoxContainer.new()
		tv.add_child(Ui.label(k, "body", 14, Ui.MUTED))
		tv.add_child(Ui.label("● " + cname + " · Neu", "bold", 18, CarPhysics.COMPOUNDS[su["compound"]]["col"]))
		tl2.add_child(tv)
	mid.add_child(tl2)
	root.add_child(mid)
	# right: session, weather, fuel, electronics, buttons
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(560, 0)
	right.add_theme_constant_override("separation", 10)
	root.add_child(right)
	var sh := HBoxContainer.new()
	sh.add_theme_constant_override("separation", 14)
	var h := fposmod(float(settings["start_hour"]), 24.0)
	sh.add_child(Ui.label("%d:%02d %s" % [int(h) % 12 if int(h) % 12 != 0 else 12, int((h - int(h)) * 60.0), "VORM." if h < 12.0 else "NACHM."], "head", 40))
	var first := "TRAINING" if settings["wk_practice"] else ("QUALIFYING" if settings["wk_quali"] else "RENNEN")
	var ses := Ui.panel(Color(0.95, 0.95, 0.96), 4, Ui.RED, 3)
	ses.add_child(Ui.label(first + "   " + _first_len(), "head", 30, Ui.RED))
	sh.add_child(ses)
	right.add_child(sh)
	right.add_child(WeatherIcons.new().setup(settings["weather"], true))
	var fuel := Ui.panel(Color(0.05, 0.07, 0.12, 0.85), 8, Color(1, 1, 1, 0.12), 1)
	var fv := VBoxContainer.new()
	fuel.add_child(fv)
	fv.add_child(Ui.label("KRAFTSTOFF", "head", 30))
	var cap: float = CarPhysics.SPECS[cls]["fuelCap"]
	fv.add_child(_num_sel(su, "fuel", 10.0, cap, 1.0, "%d L an Bord", 260.0))
	# fuel calculator: laps, weight and what the weight costs per lap
	var calc := Ui.label("", "body", 15, Ui.MUTED)
	calc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	calc.custom_minimum_size = Vector2(300, 0)
	fv.add_child(calc)
	var tm := Timer.new()
	tm.wait_time = 0.25
	tm.autostart = true
	var _lfc := func():
		var trk_len: float = game.T.length if game != null and game.T != null else 7000.0
		var per: float = trk_len / 1000.0 * (0.47 if cls == "gt3" else 0.43) * float(settings["wear"])
		var f: float = su["fuel"]
		calc.text = "≈ %.1f Runden  ·  %d kg Sprit  ·  ≈ +%.1f s/Runde gegenüber fast leer" % [f / per, int(f * CarPhysics.FUEL_KG), (f - 5.0) * CarPhysics.FUEL_KG * 0.03 * trk_len / 7000.0]
	tm.timeout.connect(_lfc)
	fv.add_child(tm)
	_lfc.call()
	right.add_child(fuel)
	var el := Ui.panel(Color(0.05, 0.07, 0.12, 0.85), 8, Color(1, 1, 1, 0.12), 1)
	var ev := VBoxContainer.new()
	el.add_child(ev)
	ev.add_child(Ui.label("ELEKTRONIK", "head", 30))
	var eg := GridContainer.new()
	eg.columns = 4
	eg.add_theme_constant_override("h_separation", 14)
	eg.add_child(Ui.label("Bremsbala", "body2", 17))
	eg.add_child(_num_sel(su, "bias", 0.5, 0.68, 0.005, "%.3f", 110.0))
	eg.add_child(Ui.label("Bord-TK", "body2", 17))
	eg.add_child(_num_sel(su, "tc", 0, 10, 1, "%d", 50.0))
	eg.add_child(Ui.label("ABS", "body2", 17))
	eg.add_child(_num_sel(su, "abs", 0, 10, 1, "%d", 110.0))
	eg.add_child(Ui.label("Flügel", "body2", 17))
	eg.add_child(_num_sel(su, "wing", 1, 10, 1, "%d", 50.0))
	ev.add_child(eg)
	right.add_child(el)
	right.add_child(Ui.spacer(30))
	var bh := HBoxContainer.new()
	bh.alignment = BoxContainer.ALIGNMENT_END
	bh.add_theme_constant_override("separation", 14)
	var bk := Ui.outline("ZURÜCK", 24, 180)
	bk.pressed.connect(go_back)
	bh.add_child(bk)
	var go_btn := Ui.primary("LOSFAHREN", 30, 260)
	go_btn.pressed.connect(_on_start)
	bh.add_child(go_btn)
	right.add_child(bh)


func _first_len() -> String:
	if settings["wk_practice"]:
		return "%d:00" % int(settings["practice_min"])
	if settings["wk_quali"]:
		return "%d:00" % int(settings["quali_min"])
	return _dur_name(settings["duration"])


# numeric ‹ value › selector for a setup value
func _num_sel(d: Dictionary, k: String, lo: float, hi: float, step: float, fmt: String, w: float = 160.0) -> Control:
	var items: Array = []
	var v := lo
	var guard := 0
	while v <= hi + step * 0.5 and guard < 400:
		var vv: float = snappedf(v, step)
		items.append([fmt % vv, vv])
		v += step
		guard += 1
	var cur: float = snappedf(float(d[k]), step)
	var best = items[0][1]
	for it in items:
		if absf(float(it[1]) - cur) < absf(float(best) - cur):
			best = it[1]
	var is_int := step >= 1.0 and fmod(lo, 1.0) == 0.0 and k != "fuel"
	return Ui.Selector.new().setup(items, best, func(x): d[k] = int(x) if is_int else float(x), 19, w)


# ---------------------------------------------------------------- settings
func _page_settings() -> void:
	var tabs := HBoxContainer.new()
	tabs.anchor_left = 0.5
	tabs.anchor_right = 0.5
	tabs.offset_left = -500
	tabs.offset_right = 500
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	tabs.add_theme_constant_override("separation", 26)
	for t in [["GAMEPLAY", "gameplay"], ["REGELN", "rules"], ["STEUERUNG", "controls"], ["GRAFIK", "graphics"], ["SOUND", "sound"], ["UPDATES", "updates"]]:
		var b := Ui.nav(t[0], settings_tab == t[1], 26)
		var _lf16 := func():
			settings_tab = t[1]
			_rebuild()
		b.pressed.connect(_lf16)
		tabs.add_child(b)
	content.add_child(tabs)
	var list := _scroll_column(820, 780, 80)
	list.get_parent().offset_left = -720
	list.get_parent().offset_right = 100
	# description panel on the right
	var dp := VBoxContainer.new()
	dp.anchor_left = 0.5
	dp.anchor_right = 0.5
	dp.offset_left = 150
	dp.offset_right = 560
	dp.offset_top = 90
	content.add_child(dp)
	desc_title = Ui.label("", "head", 38, Color(1, 1, 1, 0.6))
	dp.add_child(desc_title)
	var dpanel := Ui.panel(Color(0.04, 0.05, 0.09, 0.7), 2, Color(1, 1, 1, 0.12), 1)
	desc_text = Ui.label("Fahre mit der Maus über eine Einstellung, um hier eine Erklärung zu sehen.", "body", 17)
	desc_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_text.custom_minimum_size = Vector2(380, 0)
	dpanel.add_child(desc_text)
	dp.add_child(dpanel)
	match settings_tab:
		"controls":
			_list_head(list, "LENKUNG", "")
			_list_row(list, "Lenkmodus", Ui.Selector.new().setup([["Sehr einfach", "easy"], ["Sanft", "soft"], ["Normal", "normal"], ["Direkt", "direct"], ["Rennen", "race"], ["Eigene", "custom"]], settings["steer_mode"], _on_steer_mode, 19, 190),
				"Sehr einfach = Fahrhilfe hält das Auto stabil, es bricht kaum aus. Sanft = ruhig, Rennen = sehr direkt. Verstellst du einen Wert unten, wird es „Eigene“.")
			_list_row(list, "Lenkstärke (Einschlag)", _slider_ctrl("steer_strength", 0.5, 1.6, 0.05, "%.2fx", _steer_custom), "Wie weit die Räder bei voller Lenkung einschlagen.")
			_list_row(list, "Empfindlichkeit", _slider_ctrl("steer_speed", 0.4, 2.5, 0.05, "%.2fx", _steer_custom), "Wie schnell die Lenkung bei Tastendruck reagiert und wieder gerade wird.")
			_list_row(list, "Weniger Lenkung bei Tempo", _slider_ctrl("steer_speed_sens", 0.0, 1.6, 0.05, "%.2fx", _steer_custom), "Höher = ruhiger bei hoher Geschwindigkeit, niedriger = direkter.")
			_list_row(list, "Gamepad: Lenkkurve", _slider_ctrl("steer_curve", 1.0, 2.6, 0.1, "%.1f", _steer_custom), "1 = linear. Höher = feinere Lenkung um die Mitte.")
			_list_row(list, "Gamepad: Totzone", _slider_ctrl("steer_deadzone", 0.0, 0.2, 0.01, "%.2f", _steer_custom), "Bereich in der Stick-Mitte, der ignoriert wird.")
			_list_head(list, "TASTATUR", "")
			for kv in [["Gas / Bremse", "W / S  (↑ / ↓, Leertaste)"], ["Lenken", "A / D  (← / →)"], ["Schalten", "E / Q, Maustasten"], ["Pit-Limiter", "L"],
					["Boxenmenü", "Tab  (1/2 Sprit, 0 bis Ziel, 3 Reifen, 4 Satz, 5 Rep., 7 Druck, 8 Flügel, 9 Bremsen)"], ["Box anfordern / Funk annehmen", "F"], ["Kamera", "C"],
					["Zurück auf die Strecke", "R"], ["TC / ABS / Getriebe", "T / B / G"], ["Ideallinie", "I"], ["Ton aus", "M"], ["Sitzposition", "U / J  K / N"], ["Pause", "Esc / P"]]:
				_list_row(list, kv[0], Ui.label(kv[1], "bold", 18, Ui.MUTED))
		"rules":
			_list_head(list, "RENNLEITUNG", "")
			_list_row(list, "Rennregeln & Strafen", _pill("rules"), "Flaggen, Durchfahrts- und Stop-&-Go-Strafen wie in der WEC. Aus = nur Track Limits und Boxengassen-Tempo (+5 s).")
			_list_row(list, "Track Limits", _pill("quali_limits"), "Alle vier Räder hinter der weißen Linie = neben der Strecke.")
			_list_head(list, "FLAGGEN", "")
			for kv in [["Grün", "Strecke frei, Gefahrenstelle vorbei."],
					["Gelb", "Gefahr vor dir (langsames oder stehendes Auto). Nicht überholen!"],
					["Doppelt Gelb", "Auto steht auf der Fahrbahn. Nicht überholen, langsam fahren."],
					["Blau", "Ein schnelleres Auto will überrunden. Mach zügig Platz."],
					["Schwarz-Weiß", "Verwarnung für unsportliches Fahren."],
					["Schwarz-Orange", "Auto zu stark beschädigt (z. B. Rad verloren): an die Box zur Reparatur."],
					["Schwarz", "Disqualifiziert."],
					["Full Course Yellow (FCY)", "Nach einem schweren Unfall: ganze Strecke max. 80 km/h, nicht überholen. L = 80-km/h-Limiter."],
					["Karierte Flagge", "Rennende."]]:
				_list_row(list, kv[0], _rule_text(kv[1]))
			_list_head(list, "STRAFEN", "")
			for kv in [["Frühstart", "Durchfahrtsstrafe. Wer vor dem Erlöschen der Ampel losrollt, wird bestraft."],
					["Boxengasse zu schnell (über 60 km/h)", "Durchfahrtsstrafe. Limiter mit L einschalten!"],
					["Boxenein-/ausfahrtslinie überfahren", "Durchfahrtsstrafe."],
					["Überholen unter Gelb", "Du hast 10 s Zeit, den Platz zurückzugeben. Sonst Durchfahrt (Doppelt Gelb: Stop & Go)."],
					["Blaue Flaggen ignoriert", "Erst Verwarnung, dann Durchfahrtsstrafe."],
					["Zu schnell unter FCY", "Länger als 2 Sekunden über 86 km/h: Durchfahrtsstrafe."],
					["Kollision verursacht", "Leicht: Verwarnung, beim 2. Mal +5 s. Schwer: Durchfahrt. Sehr schwer: Stop & Go."],
					["Abkürzen / Track Limits", "Großzügig: erst deutlich neben der weißen Linie zählt es. 5 Verwarnungen = +5 s, über 2 s Vorteil = sofort +5 s."],
					["Unsicheres Losfahren aus der Box", "Deine Crew hält dich fest, bis die Boxengasse frei ist."]]:
				_list_row(list, kv[0], _rule_text(kv[1]))
			_list_head(list, "BOXENSTOPP", "")
			for kv in [["Tanken und Reifen", "Wie in der WEC nicht gleichzeitig: erst tanken, dann Reifen wechseln."],
					["Reifenkontingent", "Begrenzte Trockenreifen-Sätze pro Rennen (20 Min: 2 · 6 h: 14 · 24 h: 40). Regenreifen sind frei."],
					["Sprit und Gewicht", "Jeder Liter wiegt 0,74 kg. Voller Tank = langsamer in Kurven, beim Bremsen und Beschleunigen."],
					["Boxenmenü (Tab)", "1/2 Sprit · 0 Sprit bis ins Ziel · 3 Mischung · 4 Satz · 5 Reparatur · 7 Reifendruck · 8 Heckflügel · 9 Bremsbeläge · F anfordern"]]:
				_list_row(list, kv[0], _rule_text(kv[1]))
			_list_head(list, "STRAFE ANTRETEN", "")
			for kv in [["Durchfahrt", "Einmal durch die Boxengasse fahren, ohne anzuhalten."],
					["Stop & Go", "An deiner Box anhalten und 10 Sekunden stehen. Die Crew darf nicht arbeiten."],
					["Frist", "Innerhalb von 3 Runden – sonst schwarze Flagge. Offene Strafen bei Rennende: +25 s / +35 s."]]:
				_list_row(list, kv[0], _rule_text(kv[1]))
		"graphics":
			_list_head(list, "GRAFIK", "")
			_list_row(list, "Grafikqualität", _sel("quality", [["Ultra", "ultra"], ["Hoch", "high"], ["Mittel", "medium"], ["Niedrig", "low"]], func(_x): quality_changed.emit()),
				"Ultra: GI, SSIL, die meisten Bäume. Bei Ruckeln eine Stufe runter.")
			_list_row(list, "Anzeigengröße (HUD)", _sel("ui_scale", [["100 %", 1.0], ["125 %", 1.25], ["150 %", 1.5], ["175 %", 1.75]]))
			_list_row(list, "Sichtfeld (FOV)", _slider_ctrl("fov", 50.0, 90.0, 1.0, "%d°"), "Im Cockpit realistisch: 55–70°.")
			_list_row(list, "Ideallinie anzeigen", _pill("racing_line"))
			_list_row(list, "Radar", _pill("radar"), "Zeigt Autos neben dir an.")
		"sound":
			_list_head(list, "SOUND", "")
			_list_row(list, "Gesamtlautstärke", _slider_ctrl("vol_master", 0.0, 1.0, 0.05, "%.2f", func(_x): _apply_volume()))
			_list_row(list, "Motor", _slider_ctrl("vol_engine", 0.0, 1.5, 0.05, "%.2f"))
			_list_row(list, "Menümusik", _slider_ctrl("vol_music", 0.0, 1.0, 0.05, "%.2f"), "Eigener Racing-Soundtrack in den Menüs. 0 = aus.")
			_list_row(list, "Boxenfunk", _pill("radio_on"), "Meldungen deines Renningenieurs.")
			_list_row(list, "Funk vorlesen (Sprachausgabe)", _pill("radio_voice"), "Liest die Funkmeldungen mit der Mac-Stimme vor.")
		"updates":
			_list_head(list, "UPDATES", "")
			_list_row(list, "Installiert", Ui.label(Updater.version_text(), "bold", 17, Ui.MUTED))
			_list_row(list, "Automatisch aktualisieren", _pill("auto_update"), "Beim Start schaut das Spiel online nach neuen Updates und installiert sie sofort.")
			if not online_update.is_empty():
				var ub2 := Ui.accent("UPDATE %d JETZT INSTALLIEREN" % int(online_update["version"]), 18)
				ub2.pressed.connect(install_online_update)
				_list_row(list, "Neues Update online", ub2)
			var chk := Ui.outline("JETZT NACH UPDATES SUCHEN", 16)
			var _lfu := func():
				upd_status.text = "Suche nach Updates …"
				await _auto_update()
				if is_instance_valid(upd_status):
					upd_status.text = "Du hast die neueste Version." if online_update.is_empty() else "Update %d gefunden." % int(online_update["version"])
			chk.pressed.connect(_lfu)
			_list_row(list, "Online-Updates", chk)
			var nu := Updater.newer_update()
			if nu != "":
				var b := Ui.accent("UPDATE %d INSTALLIEREN" % Updater.file_number(nu), 18)
				b.pressed.connect(_install_update.bind(nu))
				_list_row(list, "Neues Update gefunden", b)
			var pick := Ui.outline("DATEI WÄHLEN …", 16)
			pick.pressed.connect(_pick_update)
			_list_row(list, "Update-Datei auswählen", pick)
			var rm := Ui.outline("ENTFERNEN", 16)
			rm.pressed.connect(_remove_updates)
			_list_row(list, "Updates entfernen (Grundversion)", rm)
			upd_status = Ui.label("", "bold", 18, Ui.GOLD)
			list.add_child(upd_status)
			_list_head(list, "CREDITS", "")
			var cr := Ui.label("GT3-Modell: „Mercedes-AMG GT3 Red Bull Racing“ von VTX (Sketchfab), CC-BY-NC-SA 4.0\nStreckenteile: „Race Track Assets Pack“ von Cherk (Sketchfab), CC-BY 4.0 – verkleinert, Werbung ersetzt", "body", 15, Ui.MUTED)
			cr.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			list.add_child(cr)
		_:
			_list_head(list, "SCHWIERIGKEITSGRAD", "")
			_list_row(list, "Antiblockiersystem", _pill("abs"), "ABS auch im Hypercar. Der GT3 hat immer ABS.")
			_list_row(list, "Traktionskontrolle", _pill("tc"))
			_list_row(list, "Automatisches Schalten", _pill("auto_gear"), "Automatisiertes Schalten. Aus = mit E/Q selbst schalten.")
			_list_row(list, "Gegenlenken", _pill("steer_assist"), "Hilft beim Abfangen, wenn das Heck ausbricht.")
			_list_row(list, "Track Limits", _pill("quali_limits"), "Verwarnungen, +5 s Strafen und gestrichene Qualifying-Runden.")
	list.add_child(Ui.spacer(20))
	var sv := Ui.outline("STANDARD WIEDERHERSTELLEN", 18, 300)
	var _lf17 := func():
		if settings_tab == "controls":
			_on_steer_mode("normal")
		_rebuild()
	sv.pressed.connect(_lf17)
	list.add_child(sv)


func _rule_text(t: String) -> Label:
	var l := Ui.label(t, "body", 16, Ui.MUTED)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(420, 0)
	return l


func _on_steer_mode(mode) -> void:
	settings["steer_mode"] = mode
	if STEER_MODES.has(mode):
		var m: Dictionary = STEER_MODES[mode]
		for k in m.keys():
			settings[k] = m[k]
	save_settings()
	call_deferred("_rebuild")


func _steer_custom(_x) -> void:
	var m: Dictionary = STEER_MODES.get(settings["steer_mode"], {})
	for k in m.keys():
		if absf(float(m[k]) - float(settings[k])) > 0.001:
			settings["steer_mode"] = "custom"
			return


func _apply_volume() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, float(settings["vol_master"]))))


# ---------------------------------------------------------------- profile
func _page_profile() -> void:
	var p: Dictionary = Profile.current
	if p.is_empty():
		go("login", false)
		return
	var st: Dictionary = p["stats"]
	var col := _column(1300, 20)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 26)
	col.add_child(top)
	top.add_child(Ui.Avatar.new().setup(p["c1"], p["c2"], 150.0, int(p.get("icon", 0)), int(p.get("number", 24))))
	var vl := ColorRect.new()
	vl.color = Color(1, 1, 1, 0.3)
	vl.custom_minimum_size = Vector2(2, 150)
	top.add_child(vl)
	var nv := VBoxContainer.new()
	var nl := HBoxContainer.new()
	nl.add_theme_constant_override("separation", 20)
	nl.add_child(Ui.Flag.new().setup(p["country"], 96))
	nl.add_child(Ui.label(String(p["name"]).to_upper(), "head", 92))
	nv.add_child(nl)
	nv.add_child(Ui.label(String(p["team"]).to_upper() + "   ·   #" + str(p["number"]) + "   ·   seit " + String(p.get("created", "")), "bold", 24, Ui.MUTED))
	Ui.hexpand(nv)
	top.add_child(nv)
	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 8)
	var eb := Ui.outline("PROFIL BEARBEITEN", 18, 220)
	var _lf18 := func():
		edit_new = false
		go("profile_edit")
	eb.pressed.connect(_lf18)
	bv.add_child(eb)
	# online account status
	if String(Profile.current.get("cloud_uid", "")) != "" and game.account.signed_in():
		bv.add_child(Ui.label("Online gespeichert: " + String(game.account.email), "body", 16, Ui.MUTED))
	else:
		var ob := Ui.outline("ONLINE SPEICHERN (E-MAIL)", 16, 260)
		ob.pressed.connect(func(): go("login"))
		bv.add_child(ob)
	var lo := Ui.outline("ABMELDEN", 18, 220)
	var _lf19 := func():
		if String(Profile.current.get("cloud_uid", "")) != "":
			game.account.sign_out()
		Profile.logout()
		history.clear()
		go("login", false)
	lo.pressed.connect(_lf19)
	bv.add_child(lo)
	top.add_child(bv)
	col.add_child(Ui.spacer(10))
	var mid := HBoxContainer.new()
	mid.add_theme_constant_override("separation", 40)
	col.add_child(mid)
	var cs := VBoxContainer.new()
	cs.add_child(Ui.label("KARRIERE-STATISTIK", "head", 40))
	var tiles := GridContainer.new()
	tiles.columns = 4
	tiles.add_theme_constant_override("h_separation", 10)
	tiles.add_theme_constant_override("v_separation", 10)
	for t in [[st["races"], "RENNEN"], [st["class_wins"], "KLASSENSIEGE"], [st["podiums"], "PODIUMS"], [st["fastest_laps"], "FASTEST LAPS"],
			[st["poles"], "POLES"], [st["laps"], "RUNDEN"], ["%d" % int(st["km"]), "KILOMETER"], [st["clean"], "SAUBERE RENNEN"]]:
		var tc := Ui.panel(Color(0.04, 0.06, 0.12, 0.9), 2, Color(1, 1, 1, 0.08), 1)
		tc.custom_minimum_size = Vector2(170, 150)
		var tv := VBoxContainer.new()
		tv.alignment = BoxContainer.ALIGNMENT_CENTER
		var n := Ui.label(str(t[0]), "head", 72)
		n.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		tv.add_child(n)
		var l := Ui.label(t[1], "head", 22, Color(1, 1, 1, 0.7))
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		tv.add_child(l)
		tc.add_child(tv)
		tiles.add_child(tc)
	cs.add_child(tiles)
	mid.add_child(cs)
	for r in [["FAHRERRANG", Profile.dr_tier(p["dr"]), "DR %d" % int(p["dr"])], ["SICHERHEITSRANG", Profile.sr_tier(p["sr"]), "SR %.1f" % float(p["sr"])]]:
		var rv := VBoxContainer.new()
		rv.add_child(Ui.label(r[0], "head", 40))
		var tier: Array = r[1]
		var b := Ui.Badge.new().setup(tier[0], tier[1], tier[2])
		b.custom_minimum_size = Vector2(170, 230)
		rv.add_child(b)
		rv.add_child(Ui.label(r[2], "bold", 20, Ui.MUTED))
		mid.add_child(rv)
	# latest results
	var rh := HBoxContainer.new()
	var rl := Ui.label("LETZTE ERGEBNISSE", "head", 34)
	Ui.hexpand(rl)
	rh.add_child(rl)
	col.add_child(rh)
	var rr := HBoxContainer.new()
	rr.add_theme_constant_override("separation", 22)
	col.add_child(rr)
	var hist: Array = p["history"]
	if hist.is_empty():
		rr.add_child(Ui.label("Noch keine Ergebnisse – fahr dein erstes Rennen!", "body", 20, Ui.MUTED))
	for k in mini(4, hist.size()):
		var e: Dictionary = hist[k]
		var card := Ui.panel(Color(0.04, 0.06, 0.12, 0.85), 4, Color(1, 1, 1, 0.1), 1)
		card.custom_minimum_size = Vector2(300, 0)
		var cv := VBoxContainer.new()
		card.add_child(cv)
		var sname: String = {"race": "RENNEN", "quali": "QUALIFYING", "practice": "TRAINING"}.get(String(e.get("session", "race")), "RENNEN")
		cv.add_child(Ui.label(sname + ": " + String(e.get("track_name", "")).to_upper(), "head", 22))
		cv.add_child(Ui.label(String(e.get("date", "")) + "   ·   " + ("GT3" if e.get("cls", "") == "gt3" else "HYPERCAR"), "body", 15, Ui.MUTED))
		var ctrl: Array = Array(TrackDefs.spa()["ctrl"]) if e.get("track", "spa") == "spa" else TrackDefs.trois_forets()["ctrl"]
		var ol := Ui.Outline.new().setup(ctrl, Color.WHITE, 3.0)
		ol.custom_minimum_size = Vector2(280, 110)
		cv.add_child(ol)
		var res := HBoxContainer.new()
		res.add_theme_constant_override("separation", 10)
		res.add_child(Ui.label("P%d" % int(e.get("cls_pos", e.get("pos", 0))), "head", 38))
		res.add_child(Ui.label("/ %d" % int(e.get("cls_field", e.get("field", 0))), "bold", 20, Ui.MUTED))
		var ddr: float = e.get("d_dr", 0.0)
		var dsr: float = e.get("d_sr", 0.0)
		res.add_child(Ui.label("DR %+d" % int(ddr), "bold", 18, Ui.GREEN if ddr >= 0.0 else Ui.PINK))
		res.add_child(Ui.label("SR %+.1f" % dsr, "bold", 18, Ui.GREEN if dsr >= 0.0 else Ui.PINK))
		cv.add_child(res)
		cv.add_child(Ui.label("Beste Runde " + Ui.fmt_time(float(e.get("best", -1.0))), "body", 15, Ui.MUTED))
		rr.add_child(card)


# ---------------------------------------------------------------- online
func _page_online() -> void:
	var net = game.net if game != null else null
	var col := _column(1400, 10)
	col.add_child(Ui.label("ONLINE-MEHRSPIELER", "head", 60))
	var od := Ui.label("Einer erstellt eine Lobby und bekommt einen Code. Die anderen geben den Code ein – fertig. Kein IP, keine Router-Einstellung. Alle brauchen dieselbe Spielversion.", "body", 18, Ui.MUTED)
	od.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	od.custom_minimum_size = Vector2(1400, 0)
	col.add_child(od)
	var in_lobby: bool = net != null and net.online
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 22)
	col.add_child(row)
	# ---- left: create / join (or the code when in a lobby)
	var lp := Ui.panel(Color(0.04, 0.06, 0.12, 0.92), 10, Color(1, 1, 1, 0.45), 2)
	lp.custom_minimum_size = Vector2(440, 380)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 10)
	lp.add_child(lv)
	row.add_child(lp)
	if in_lobby and net.mode == "code" and net.is_host():
		lv.add_child(Ui.label("DEIN LOBBY-CODE", "head", 34, Ui.RED))
		lv.add_child(Ui.label(net.code if net.relay.is_open() else "…", "head", 110, Color.WHITE))
		lv.add_child(Ui.label("Sag deinen Freunden diesen Code.\nBei jeder neuen Lobby gibt es einen neuen.", "body", 16, Ui.MUTED))
		var cp := Ui.outline("CODE KOPIEREN", 18, 260)
		cp.pressed.connect(func(): DisplayServer.clipboard_set(net.code))
		lv.add_child(cp)
	elif in_lobby:
		lv.add_child(Ui.label("VERBUNDEN" if net.players.has(net.id) or net.is_host() else "VERBINDE …", "head", 40, Ui.RED))
		if net.mode == "code":
			lv.add_child(Ui.label("Lobby " + net.code, "head", 60))
		else:
			lv.add_child(Ui.label("Direkt (WLAN)", "head", 40))
			var ipl: Array = _local_ips()
			if net.is_host():
				lv.add_child(Ui.label("Deine IP: " + ", ".join(ipl), "body", 16, Ui.MUTED))
	else:
		lv.add_child(Ui.label("LOBBY ERSTELLEN", "head", 38, Ui.RED))
		lv.add_child(Ui.label("Du bist der Host und stellst das Rennen ein.", "body", 16, Ui.MUTED))
		var hb := Ui.primary("LOBBY ERSTELLEN", 24, 400)
		hb.pressed.connect(func(): net.host_code())
		lv.add_child(hb)
		lv.add_child(Ui.spacer(14))
		lv.add_child(Ui.label("MIT CODE BEITRETEN", "head", 38, Ui.RED))
		var ce := Ui.line_edit("", "Code, z. B. K7M2Q", 400)
		ce.max_length = 8
		ce.add_theme_font_size_override("font_size", 30)
		lv.add_child(ce)
		var jb := Ui.primary("BEITRETEN", 24, 400)
		var _lfj := func():
			net.join_code(ce.text)
		jb.pressed.connect(_lfj)
		ce.text_submitted.connect(func(_t): _lfj.call())
		lv.add_child(jb)
		# direct connection in the same WLAN stays available
		var adv := HBoxContainer.new()
		adv.add_theme_constant_override("separation", 8)
		var ipe := Ui.line_edit(String(settings.get("last_ip", "")), "WLAN: IP des Hosts", 220)
		adv.add_child(ipe)
		var ib := Ui.outline("PER IP", 15, 90)
		var _lfi := func():
			settings["last_ip"] = ipe.text.strip_edges()
			save_settings()
			net.join(ipe.text)
		ib.pressed.connect(_lfi)
		adv.add_child(ib)
		var ih := Ui.outline("IP-LOBBY", 15, 100)
		ih.pressed.connect(func(): net.host())
		adv.add_child(ih)
		lv.add_child(adv)
	# ---- middle: players
	var mp := Ui.panel(Color(0.04, 0.06, 0.12, 0.92), 10, Color(1, 1, 1, 0.45), 2)
	mp.custom_minimum_size = Vector2(440, 380)
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 8)
	mp.add_child(mv)
	row.add_child(mp)
	mv.add_child(Ui.label("FAHRER IN DER LOBBY", "head", 34, Ui.RED))
	lobby_box = VBoxContainer.new()
	lobby_box.add_theme_constant_override("separation", 6)
	mv.add_child(lobby_box)
	if in_lobby:
		lobby_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
		var mine := HBoxContainer.new()
		mine.add_theme_constant_override("separation", 10)
		mine.add_child(Ui.label("Deine Klasse:", "bold", 17, Ui.MUTED))
		var _lfc := func(x):
			settings["cls"] = x
			save_settings()
			net.update_me()
		mine.add_child(Ui.Selector.new().setup([["GT3", "gt3"], ["Hypercar", "hyper"]], settings["cls"], _lfc, 18, 170))
		mv.add_child(mine)
		if not net.is_host() and net.players.has(net.id):
			var rd: bool = bool(net.players[net.id].get("ready", false))
			var rb: Button = Ui.primary("ICH BIN BEREIT", 22, 400) if not rd else Ui.outline("BEREIT  (zurücknehmen)", 18, 400)
			rb.pressed.connect(func(): net.set_ready(not rd))
			mv.add_child(rb)
	# ---- right: race settings (host edits, the others see them)
	var rp := Ui.panel(Color(0.04, 0.06, 0.12, 0.92), 10, Color(1, 1, 1, 0.45), 2)
	rp.custom_minimum_size = Vector2(470, 380)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 6)
	rp.add_child(rv)
	row.add_child(rp)
	rv.add_child(Ui.label("RENNEINSTELLUNGEN", "head", 34, Ui.RED))
	if not in_lobby:
		var hint := Ui.label("Der Host stellt hier Strecke, Dauer, Wetter, Tageszeit und Gegner ein – genau wie bei einem normalen Rennen.", "body", 17, Ui.MUTED)
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		hint.custom_minimum_size = Vector2(430, 0)
		rv.add_child(hint)
	else:
		var cfg: Dictionary = net.lobby_cfg
		var edit: bool = net.is_host()
		var tracks: Array = []
		for d in TrackDefs.all():
			tracks.append([String(d["short"]), d["id"]])
		var rows := [
			["Strecke", "track", tracks],
			["Dauer", "duration", [["3 Runden", "l3"], ["20 Min", "m20"], ["45 Min", "m45"], ["90 Min", "m90"], ["6 Std", "h6"], ["24 Std", "h24"]]],
			["Wetter", "weather", [["Trocken", "dry"], ["Regen", "rain"], ["Wechselhaft", "mixed"]]],
			["Startzeit", "start_hour", [["10:30", 10.5], ["14:00", 14.0], ["19:30", 19.5], ["21:30 Dämmerung", 21.5], ["01:00 Nacht", 1.0], ["04:30 Morgen", 4.5]]],
			["Zeitraffer", "time_scale", [["1×", 1.0], ["8×", 8.0], ["24×", 24.0], ["60×", 60.0]]],
			["KI GT3", "n_gt3", [["0", 0], ["3", 3], ["6", 6], ["11", 11], ["17", 17], ["23", 23]]],
			["KI Hypercars", "n_hy", [["0", 0], ["3", 3], ["6", 6], ["11", 11]]],
			["KI-Stärke", "ai_diff", [["50 %", 50.0], ["70 %", 70.0], ["80 %", 80.0], ["90 %", 90.0], ["100 %", 100.0], ["110 %", 110.0]]],
			["Schaden", "damage", [["Realistisch", 1.0], ["Reduziert", 0.5], ["Aus", 0.0]]],
			["Verbrauch", "wear", [["Realistisch", 1.0], ["2×", 2.0], ["4×", 4.0]]],
			["Regeln & Strafen", "rules", [["An", true], ["Aus", false]]],
		]
		for r in rows:
			var hb2 := HBoxContainer.new()
			var l := Ui.label(String(r[0]), "bold", 16, Ui.MUTED)
			l.custom_minimum_size = Vector2(170, 0)
			hb2.add_child(l)
			var key: String = r[1]
			var items: Array = r[2]
			var cur = cfg.get(key, settings.get(key))
			if edit:
				var _lfs := func(x):
					net.set_cfg(key, x)
				hb2.add_child(Ui.Selector.new().setup(items, cur, _lfs, 16, 250))
			else:
				var shown := str(cur)
				for it in items:
					if str(it[1]) == str(cur):
						shown = String(it[0])
				hb2.add_child(Ui.label(shown, "bold", 17))
			rv.add_child(hb2)
	# ---- status + actions
	online_status = Ui.label(net.status_text() if net != null else "", "bold", 20, Ui.GOLD)
	online_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	online_status.custom_minimum_size = Vector2(1400, 0)
	col.add_child(online_status)
	var bh := HBoxContainer.new()
	bh.add_theme_constant_override("separation", 14)
	if in_lobby:
		var leave := Ui.outline("LOBBY VERLASSEN", 20, 240)
		leave.pressed.connect(func(): net.leave())
		bh.add_child(leave)
	if in_lobby and net.is_host():
		var n_ready := 0
		for k in net.players.keys():
			if int(k) == 1 or bool(net.players[k].get("ready", false)):
				n_ready += 1
		var all_in: bool = net.everyone_ready()
		var start := Ui.primary("WEITER  →  RENNEN STARTEN" if all_in else "WARTE AUF ALLE (%d/%d BEREIT)" % [n_ready, net.players.size()], 24, 460)
		start.disabled = not all_in
		var _lfs2 := func():
			save_settings()
			net.start_online_race()
		start.pressed.connect(_lfs2)
		bh.add_child(start)
	col.add_child(bh)
	if net != null and not net.lobby_changed.is_connected(_on_lobby_changed):
		net.lobby_changed.connect(_on_lobby_changed)
	_online_sig = _lobby_signature()
	_refresh_lobby()


var _online_sig := ""


# rebuild the page only when something visible changed (the host re-sends the lobby every 2 s)
func _lobby_signature() -> String:
	var net = game.net
	return JSON.stringify([net.online, net.mode, net.code, net.id, net.relay.is_open(), net.players, net.lobby_cfg, net.status])


func _on_lobby_changed() -> void:
	if page != "online" or game == null:
		return
	var sig := _lobby_signature()
	if sig == _online_sig:
		return
	_online_sig = sig
	_rebuild()


func _refresh_lobby() -> void:
	if lobby_box == null or not is_instance_valid(lobby_box) or game == null:
		return
	for ch in lobby_box.get_children():
		ch.queue_free()
	var players: Dictionary = game.net.players
	if players.is_empty():
		lobby_box.add_child(Ui.label("Noch niemand verbunden.", "body", 17, Ui.MUTED))
		return
	var ids: Array = players.keys()
	ids.sort()
	for pid in ids:
		var pl: Dictionary = players[pid]
		if pl.is_empty():
			continue
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 10)
		var cb := Ui.panel(Ui.GT if pl.get("cls", "gt3") == "gt3" else Ui.HY, 2, Color(0, 0, 0, 0), 0)
		cb.add_child(Ui.label("GT3" if pl.get("cls", "gt3") == "gt3" else "HY", "head", 15))
		hb.add_child(cb)
		var nm := Ui.label("#%d %s" % [int(pl.get("number", 0)), String(pl.get("name", "?"))], "bold", 19)
		Ui.hexpand(nm)
		hb.add_child(nm)
		if int(pid) == 1:
			hb.add_child(Ui.label("HOST", "head", 16, Ui.GOLD))
		elif bool(pl.get("ready", false)):
			hb.add_child(Ui.label("BEREIT", "head", 16, Color(0.3, 1.0, 0.45)))
		else:
			hb.add_child(Ui.label("wartet", "body", 15, Ui.MUTED))
		lobby_box.add_child(hb)


func _local_ips() -> Array:
	var out: Array = []
	for a in IP.get_local_addresses():
		var s: String = a
		if s.contains(".") and not s.begins_with("127.") and not s.begins_with("169.254"):
			var second := int(s.get_slice(".", 1))
			if s.begins_with("100.") and second >= 64 and second <= 127:
				out.append(s + "  (Tailscale)")
			elif s.begins_with("192.168.") or s.begins_with("10.") or (s.begins_with("172.") and second >= 16 and second <= 31):
				out.append(s + "  (WLAN)")
			else:
				out.append(s)
	return out if not out.is_empty() else ["(keine Netzwerkverbindung)"]


# ---------------------------------------------------------------- actions
func _setter(key: String) -> Callable:
	return func(v): settings[key] = v


func _on_track(x) -> void:
	settings["track"] = x
	save_settings()
	track_changed.emit()
	_rebuild()


func _on_start() -> void:
	settings["opponents"] = int(settings["n_hy"]) + int(settings["n_gt3"])
	save_settings()
	start_race.emit()


func _pick_update() -> void:
	var fd := FileDialog.new()
	fd.access = FileDialog.ACCESS_FILESYSTEM
	fd.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	fd.filters = PackedStringArray(["*.zip ; Trois Forêts Update"])
	fd.current_dir = OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	fd.use_native_dialog = true
	fd.file_selected.connect(_install_update)
	add_child(fd)
	fd.popup_centered_ratio(0.6)


func _install_update(path: String) -> void:
	var err := Updater.install(path)
	if err != "":
		if upd_status != null and is_instance_valid(upd_status):
			upd_status.text = "Fehler: " + err
		OS.alert("Update fehlgeschlagen: " + err, "Trois Forêts 24")
		return
	if upd_status != null and is_instance_valid(upd_status):
		upd_status.text = "Update installiert – wird geladen …"
	save_settings()
	Profile.save_all()
	get_tree().create_timer(0.3).timeout.connect(Updater.apply_now.bind(get_tree()))


func _remove_updates() -> void:
	Updater.remove_all()
	if upd_status != null and is_instance_valid(upd_status):
		upd_status.text = "Updates entfernt – das Spiel startet neu …"
	get_tree().create_timer(1.0).timeout.connect(Updater.restart.bind(get_tree()))


# ---------------------------------------------------------------- persistence
func save_settings() -> void:
	var cf := ConfigFile.new()
	for k in settings.keys():
		cf.set_value("game", k, settings[k])
	cf.save("user://settings.cfg")


func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://settings.cfg") != OK:
		return
	for k in cf.get_section_keys("game"):
		var v = cf.get_value("game", k)
		if not settings.has(k):
			settings[k] = v
			continue
		if typeof(v) == typeof(settings[k]) or (typeof(settings[k]) == TYPE_FLOAT and typeof(v) == TYPE_INT):
			if v is Dictionary:
				var d: Dictionary = settings[k]
				for kk in d.keys():
					if (v as Dictionary).has(kk):
						d[kk] = v[kk]
			else:
				settings[k] = v
	if settings["opponents"] > 0 and int(settings["n_hy"]) + int(settings["n_gt3"]) == 0:
		settings["n_gt3"] = settings["opponents"]


# ---------------------------------------------------------------- small drawn widgets
class WeatherIcons extends Control:
	var w := "dry"
	var temps := false

	func setup(weather: String, with_temps: bool = false) -> WeatherIcons:
		w = weather
		temps = with_temps
		custom_minimum_size = Vector2(260, 60 if with_temps else 36)
		return self

	func _draw() -> void:
		var seq: Array
		match w:
			"rain":
				seq = ["rain", "rain", "cloud", "rain", "rain"]
			"mixed":
				seq = ["sun", "part", "cloud", "rain", "rain"]
			_:
				seq = ["sun", "part", "part", "sun", "part"]
		var uk = load("res://scripts/ui.gd")
		for k in seq.size():
			var c := Vector2(20 + k * 48, 18)
			var s: String = seq[k]
			if s == "sun" or s == "part":
				draw_circle(c + Vector2(-4, -2), 8, Color(1.0, 0.85, 0.25))
				for r in 8:
					var a := r * TAU / 8.0
					draw_line(c + Vector2(-4, -2) + Vector2(cos(a), sin(a)) * 11, c + Vector2(-4, -2) + Vector2(cos(a), sin(a)) * 14, Color(1.0, 0.85, 0.25), 2.0)
			if s != "sun":
				draw_circle(c + Vector2(4, 4), 8, Color.WHITE)
				draw_circle(c + Vector2(12, 6), 6, Color.WHITE)
				draw_circle(c + Vector2(-4, 7), 6, Color.WHITE)
				draw_rect(Rect2(c + Vector2(-4, 6), Vector2(16, 7)), Color.WHITE)
			if s == "rain":
				for d in 3:
					draw_line(c + Vector2(-2 + d * 6, 16), c + Vector2(-5 + d * 6, 22), Color(0.5, 0.75, 1.0), 2.0)
			if temps:
				var t: int = {"rain": 14, "cloud": 18, "part": 24, "sun": 25}.get(s, 22)
				draw_string(uk.font("bold"), Vector2(c.x - 18, 56), "%d°C" % t, HORIZONTAL_ALIGNMENT_CENTER, 40, 17, Color.WHITE)


# class emblem (round badge)
class ClassLogo extends Control:
	var cls := "gt3"

	func _draw() -> void:
		var R := minf(size.x, size.y) * 0.5
		var cen := size * 0.5
		draw_arc(cen, R - 4, 0, TAU, 64, Color.WHITE, 5.0, true)
		var uk = load("res://scripts/ui.gd")
		if cls == "gt3":
			# three-pointed star
			for k in 3:
				var a := -PI / 2 + k * TAU / 3.0
				var tip := cen + Vector2(cos(a), sin(a)) * (R - 8)
				var l := cen + Vector2(cos(a + 2.6), sin(a + 2.6)) * R * 0.18
				var r := cen + Vector2(cos(a - 2.6), sin(a - 2.6)) * R * 0.18
				draw_colored_polygon(PackedVector2Array([cen, l, tip]), Color(0.85, 0.87, 0.9))
				draw_colored_polygon(PackedVector2Array([cen, tip, r]), Color(0.6, 0.62, 0.66))
		else:
			draw_string(uk.font("head"), Vector2(0, cen.y + 18), "HY", HORIZONTAL_ALIGNMENT_CENTER, size.x, 50, Color.WHITE)


# side view of the car in the livery colours
class CarPreview extends Control:
	var c1 := Color.WHITE
	var c2 := Color.BLUE
	var cls := "gt3"

	func _draw() -> void:
		var w := size.x
		var h := size.y
		var base := h * 0.78
		var body := PackedVector2Array([Vector2(w * 0.04, base - h * 0.12), Vector2(w * 0.1, base - h * 0.3), Vector2(w * 0.38, base - h * 0.36),
			Vector2(w * 0.5, base - h * 0.62), Vector2(w * 0.68, base - h * 0.62), Vector2(w * 0.84, base - h * 0.42), Vector2(w * 0.97, base - h * 0.4),
			Vector2(w * 0.98, base - h * 0.1), Vector2(w * 0.02, base - h * 0.04)])
		if cls != "gt3":
			body = PackedVector2Array([Vector2(w * 0.02, base - h * 0.08), Vector2(w * 0.2, base - h * 0.3), Vector2(w * 0.45, base - h * 0.34),
				Vector2(w * 0.55, base - h * 0.58), Vector2(w * 0.66, base - h * 0.58), Vector2(w * 0.8, base - h * 0.36), Vector2(w * 0.99, base - h * 0.32),
				Vector2(w * 0.99, base - h * 0.08)])
		draw_colored_polygon(body, c1)
		draw_polyline(body + PackedVector2Array([body[0]]), Color(0, 0, 0, 0.5), 2.0, true)
		draw_line(Vector2(w * 0.06, base - h * 0.22), Vector2(w * 0.95, base - h * 0.26), c2, h * 0.07)
		draw_colored_polygon(PackedVector2Array([Vector2(w * 0.52, base - h * 0.58), Vector2(w * 0.66, base - h * 0.58), Vector2(w * 0.76, base - h * 0.42), Vector2(w * 0.46, base - h * 0.4)]), Color(0.08, 0.1, 0.14))
		# rear wing
		draw_rect(Rect2(w * 0.86, base - h * 0.62, w * 0.12, h * 0.05), Color(0.1, 0.1, 0.1))
		draw_line(Vector2(w * 0.92, base - h * 0.58), Vector2(w * 0.92, base - h * 0.42), Color(0.1, 0.1, 0.1), 3.0)
		for x in [0.2, 0.8]:
			draw_circle(Vector2(w * x, base - h * 0.06), h * 0.17, Color(0.05, 0.05, 0.06))
			draw_circle(Vector2(w * x, base - h * 0.06), h * 0.1, Color(0.6, 0.62, 0.66))
		draw_rect(Rect2(0, base + h * 0.08, w, 3), Color(1, 1, 1, 0.08))


# car from above with tyre labels at the corners (pit garage)
class CarTop extends Control:
	var c1 := Color.WHITE
	var c2 := Color.BLUE
	var num := 24
	var tyre := "M"

	func _draw() -> void:
		var w := size.x
		var h := size.y
		var cx := w * 0.5
		var body := Rect2(cx - 62, 40, 124, h - 80)
		draw_rect(Rect2(0, 0, w, h), Color(0.04, 0.06, 0.12, 0.85))
		draw_rect(Rect2(0, 0, w, h), Color(1, 1, 1, 0.12), false, 1.0)
		draw_rect(body, c1)
		draw_circle(Vector2(cx, 46), 62, c1)
		draw_rect(Rect2(cx - 12, 30, 24, h - 70), c2)
		draw_rect(Rect2(cx - 48, h * 0.4, 96, 90), Color(0.08, 0.1, 0.14))
		draw_rect(Rect2(cx - 70, h - 60, 140, 18), Color(0.1, 0.1, 0.1))
		var uk = load("res://scripts/ui.gd")
		draw_rect(Rect2(cx - 26, h * 0.24, 52, 40), Color.WHITE)
		draw_string(uk.font("head"), Vector2(cx - 26, h * 0.24 + 34), str(num), HORIZONTAL_ALIGNMENT_CENTER, 52, 32, Color(0.05, 0.05, 0.05))
		for k in 4:
			var tx := cx + (-1.0 if k % 2 == 0 else 1.0) * 66.0
			var ty: float = h * (0.2 if k < 2 else 0.78)
			draw_rect(Rect2(tx - 12, ty - 30, 24, 60), Color(0.05, 0.05, 0.06))
			var lx := 30.0 if k % 2 == 0 else w - 30.0
			draw_circle(Vector2(lx, ty - 8), 15, Color(1.0, 0.83, 0.1))
			draw_circle(Vector2(lx, ty - 8), 11, Color(0.08, 0.08, 0.1))
			draw_string(uk.font("head"), Vector2(lx - 15, ty), tyre, HORIZONTAL_ALIGNMENT_CENTER, 30, 18, Color(1.0, 0.83, 0.1))
			draw_string(uk.font("bold"), Vector2(lx - 30, ty + 30), "Neu", HORIZONTAL_ALIGNMENT_CENTER, 60, 18, Color.WHITE)


# the real car model, lit like a studio shot: slowly turning (event screen) or from above (pit garage)
class CarShowcase extends SubViewportContainer:
	var vp: SubViewport
	var pivot: Node3D
	var cam: Camera3D
	var t := 0.0
	var top := false
	var cls := "gt3"
	var livery: Array = []
	var number := 24

	func setup(c: String, liv: Array, num: int, px: Vector2i, top_view: bool) -> CarShowcase:
		cls = c
		livery = liv
		number = num
		top = top_view
		stretch = true
		custom_minimum_size = Vector2(px)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		vp = SubViewport.new()
		vp.own_world_3d = true
		vp.transparent_bg = true
		vp.size = px
		vp.msaa_3d = Viewport.MSAA_4X
		vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		add_child(vp)
		return self

	func _ready() -> void:
		var env := Environment.new()
		env.background_mode = Environment.BG_CLEAR_COLOR
		env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		env.ambient_light_color = Color(0.55, 0.6, 0.72)
		env.ambient_light_energy = 0.7
		env.tonemap_mode = Environment.TONE_MAPPER_AGX
		var we := WorldEnvironment.new()
		we.environment = env
		vp.add_child(we)
		for l in [[Vector3(-50, 35, 0), 2.2, Color(1.0, 0.97, 0.92)], [Vector3(-20, -140, 0), 0.9, Color(0.75, 0.82, 1.0)], [Vector3(-10, 80, 0), 1.2, Color(1.0, 0.45, 0.55)]]:
			var dl := DirectionalLight3D.new()
			dl.rotation_degrees = l[0]
			dl.light_energy = l[1]
			dl.light_color = l[2]
			vp.add_child(dl)
		pivot = Node3D.new()
		vp.add_child(pivot)
		var CarVisual = load("res://scripts/car_visual.gd")
		var v = CarVisual.new()
		pivot.add_child(v)
		v.setup(cls, livery, number, "high", true)
		cam = Camera3D.new()
		cam.fov = 30.0 if not top else 26.0
		vp.add_child(cam)
		cam.current = true
		_place()

	func _process(dt: float) -> void:
		if not is_visible_in_tree():
			return
		t += dt
		_place()

	func _place() -> void:
		if cam == null:
			return
		if top:
			cam.position = Vector3(0.0, 11.5, 0.0)
			cam.look_at(Vector3(0.0, 0.0, 0.0), Vector3(1, 0, 0))
		else:
			var a := 0.6 + t * 0.25
			cam.position = Vector3(cos(a) * 7.2, 1.9, sin(a) * 7.2)
			cam.look_at(Vector3(0.0, 0.5, 0.0), Vector3.UP)

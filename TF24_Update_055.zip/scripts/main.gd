# Game controller: environment & time of day, weather, race flow, input, cameras, pit stops, damage, HUD.
extends Node3D

const Gfx = preload("res://scripts/gfx.gd")
const TrackDefs = preload("res://scripts/track_defs.gd")
const Track = preload("res://scripts/track.gd")
const Human = preload("res://scripts/human.gd")
const CarPhysics = preload("res://scripts/car_physics.gd")
const AIDriver = preload("res://scripts/ai_driver.gd")
const Finale = preload("res://scripts/finale.gd")
const DriftShow = preload("res://scripts/drift_show.gd")
const Events = preload("res://scripts/events.gd")
const WorldBuilder = preload("res://scripts/world_builder.gd")
const CarVisual = preload("res://scripts/car_visual.gd")
const Cockpit = preload("res://scripts/cockpit.gd")
const PitStrategy = preload("res://scripts/pit_strategy.gd")
const PitStop = preload("res://scripts/pit_stop.gd")
const Hud = preload("res://scripts/hud.gd")
const Menu = preload("res://scripts/menu.gd")
const AudioSynth = preload("res://scripts/audio_synth.gd")
const Ui = preload("res://scripts/ui.gd")
const Profile = preload("res://scripts/profile.gd")
const Net = preload("res://scripts/net.gd")

const DT := 1.0 / 240.0
const TEAMS := {
	"hyper": [["Aurora Racing", Color(0.84, 0.08, 0.1), Color(0.07, 0.07, 0.07), Color.WHITE, 7], ["Nordlicht Motorsport", Color(0.05, 0.17, 0.33), Color(0.25, 0.82, 1.0), Color.WHITE, 8],
		["Ferra Corse", Color(0.95, 0.95, 0.95), Color(0.76, 0.07, 0.12), Color(0.07, 0.07, 0.07), 50], ["Kestrel Engineering", Color(0.1, 0.1, 0.1), Color(1.0, 0.8, 0.0), Color.WHITE, 6],
		["Valmont Works", Color(0.06, 0.42, 0.24), Color.WHITE, Color(0.07, 0.07, 0.07), 36], ["Lumen Hyper", Color(0.35, 0.17, 0.63), Color(1.0, 0.48, 0.71), Color.WHITE, 12],
		["Solaris Prototypes", Color(1.0, 0.45, 0.0), Color(0.1, 0.1, 0.1), Color.WHITE, 2], ["Polarstern", Color(0.85, 0.87, 0.9), Color(0.1, 0.3, 0.8), Color(0.9, 0.1, 0.1), 15]],
	"gt3": [["Veloce GT", Color(1.0, 0.42, 0.0), Color(0.07, 0.07, 0.07), Color.WHITE, 91], ["Brennwald Racing", Color(0.16, 0.18, 0.21), Color(0.61, 0.9, 0.39), Color.WHITE, 77],
		["Iron Fox", Color(0.72, 0.74, 0.76), Color(0.9, 0.22, 0.27), Color(0.07, 0.07, 0.07), 54], ["Tannenhof GT", Color(0.07, 0.19, 0.36), Color(1.0, 0.82, 0.4), Color.WHITE, 88],
		["Cobalt Motorsport", Color(0.0, 0.47, 0.71), Color.WHITE, Color(0.01, 0.02, 0.37), 21], ["Zenit GT", Color(1.0, 0.84, 0.04), Color(0.0, 0.0, 0.0), Color.WHITE, 46],
		["Rotor Racing", Color(0.42, 0.46, 0.49), Color(1.0, 0.0, 0.43), Color.WHITE, 33], ["Bergwerk GT", Color(0.25, 0.15, 0.08), Color(0.95, 0.6, 0.2), Color.WHITE, 60],
		["Kranich Racing", Color(0.95, 0.95, 0.92), Color(0.1, 0.55, 0.3), Color(0.07, 0.07, 0.07), 81], ["Eisvogel", Color(0.0, 0.55, 0.65), Color(1.0, 0.5, 0.0), Color.WHITE, 98],
		["Falkner GT", Color(0.12, 0.12, 0.3), Color(0.9, 0.9, 0.9), Color(0.9, 0.2, 0.2), 27], ["Morgenrot", Color(0.75, 0.15, 0.25), Color(1.0, 0.85, 0.6), Color.WHITE, 85],
		["Vulkan GT", Color(0.15, 0.15, 0.15), Color(1.0, 0.25, 0.0), Color.WHITE, 63], ["Seewind", Color(0.6, 0.8, 0.95), Color(0.05, 0.2, 0.45), Color.WHITE, 44],
		["Graf Racing", Color(0.5, 0.0, 0.1), Color(0.85, 0.75, 0.4), Color.WHITE, 95], ["Alpen GT", Color(0.95, 0.95, 0.95), Color(0.2, 0.2, 0.2), Color(0.85, 0.1, 0.1), 31]],
}

var settings: Dictionary
var pit_audio                    # 3D sounds of the crew at work (pit_audio.gd)
var crash_guard                  # crash report of the last session (crash_guard.gd)
var T
var world
var world_root: Node3D
var built_track := ""
var built_quality := ""
var garage_slot := 0              # online: own garage (0 = the base garage, see Track.set_player_slot)
var built_slot := 0

var env: Environment
var sky_mat: ShaderMaterial
var sky_hor := Color(0.66, 0.76, 0.86)
var sun: DirectionalLight3D
var moon: DirectionalLight3D
var camera: Camera3D
var rain: GPUParticles3D
var menu
var net
var session_queue: Array = []
var online_grid: Array = []
var show_grid: Array = []          # drift show: the show cars (+ the spectator)
var drift_show = null
var show_seats: Array = []         # drift show: places on the grandstand at La Source [eye position, look point]
var show_seat := 0
var show_yaw := 0.0                # looking around from the seat (mouse / A D W S)
var show_pitch := 0.0
var show_free_t := 0.0             # > 0: the viewer looks around himself, the eyes do not follow the cars
var recorded := false
var hud
var audio
var loading: Control             # loading_screen.gd
var overlay: Control

var cars: Array = []
var visuals: Array = []
var drivers: Array = []
var player
var player_vis
var cockpit
var order: Array = []
var pit_stops := {}           # car -> PitStop
var pits_leaving: Array = []  # finished / called-off stops: the crew walks back into the garage
var pit_late := false         # box called while the car was already coming down the pit lane
var player_pit = null
var pit_plan := {"fuel_add": 75.0, "tyres": "medium", "set": "all", "repair": true, "requested": false}
# crew radio: messages from the pit wall, an optional suggestion the driver accepts with F
var radio_txt := ""
var radio_t := 0.0
var radio_suggest := {}
var radio_flags := {}
var passenger_ai = null          # AI driving the player car in passenger mode
var finale                       # watching the others after the finish + podium ceremony
var event_id := ""              # daily event being driven (events.gd)
var radio_check_t := 0.0
var fuel_line := -1.0         # fuel at the last line crossing
var fuel_per_lap := -1.0
var tyre_sets_left := 4.0     # tyre allocation for the race (dry sets; rain tyres are free)
var last_dmg := 0.0
var pit_ready := false        # crew prepared for the player's stop (box called in time)
var pit_menu_open := false
var tick_n := 0                     # physics step counter (AI / slipstream run at a lower rate)
var pit_custom := false             # the plan was changed by hand in the pit panel (preset not followed)
var _preset_t := 0.0
var debris: Array = []

var state := "menu"
var paused := false
var started := false
var race_time := 0.0
var hour := 19.5
var duration_sec := 1200.0
var laps_target := 0
var chequered := false
var lights_t := 0.0
var lights_out_at := 6.0
var lights_n := 0
var cam_mode := 0
var cam_pos := Vector3.ZERO
var cam_init := false
var shake := 0.0
var hud_visible := true
var hint_t := 15.0
var msg := ""
var msg_t := 0.0
var msg_col := Color(1.0, 0.83, 0.0)
var msg_sub := ""                     # small explanation under the message (what to do now)
var blue_flag := false
var order_t := 0.0
var wet := 0.0
var rain_on := false
var tv_spots: Array = []
var tv_cur := Vector3.ZERO
var tv_kind := "cam"                  # TV director: "cam" (trackside camera) or "heli" (helicopter)
var tv_t := 0.0                       # time in the current shot
var tv_blind := 0.0                   # how long the trackside camera has not seen the car
var tv_cams := 0                      # trackside shots since the last helicopter shot
var tv_aim := Vector3.ZERO
var tv_fov := 40.0
var tv_heli := Vector3.ZERO
var tv_side := 1.0
var tv_car = null
var seat_look := Vector3.ZERO     # grandstand camera: where the spectator is looking
var menu_t := 0.0
var input_steer := 0.0
var input_thr := 0.0
var input_brk := 0.0
var pad_prev := {}
var reset_hold := 0.0
var sectors_best := [-1.0, -1.0, -1.0]
var sectors_cur := [-1.0, -1.0, -1.0]
var sector_start := 0.0
var sector_idx := 0
var overall_best_sec := [-1.0, -1.0, -1.0]
var penalty := 0.0
var sound_off := false      # M key
# track limits (player): current excursion and warnings
var tl_off := false
var tl_t0 := 0.0
var tl_i0 := 0
var tl_via_pit := false
var tl_strikes := 0
var tl_ref := PackedFloat32Array()
var pit_served := false        # a stop was done: no new stop until the car has left the pit lane
var session := "race"
var quali_len := 900.0
var quali_order: Array = []
var acc := 0.0
var rules = preload("res://scripts/rules.gd").new()
var account: Node
var social: Node                   # friends, open lobbies, join requests
var replay = preload("res://scripts/replay.gd").new()
var replay_t := 0.0
var replay_speed := 1.0
var replay_play := true
var replay_from := ""            # "results", "pause", "menu", "movie"
var replay_file := ""            # last saved / loaded replay file
var replay_end := -1.0           # movie export: stop here
var replay_snap: Array = []
var cam_corr := Vector3.ZERO          # smoothed chase-camera correction (walls, garages, ground)
var replay_debris: Array = []         # parts flying off while the replay plays
var replay_bodies: Array = []         # dented bodies of the live race, back after the replay
var replay_ev := 0                    # next damage event of the replay to show
var replay_last_t := -100.0
var video_pid := -1              # running movie export (second game instance)
var video_conv_pid := -1         # running MP4 conversion
var video_avi := ""
var replay_dir_t := 0.0          # movie: automatic camera director
var focus := -1                  # car the replay camera follows
var view_pos := Vector3.ZERO     # track viewer (free camera)
var view_yaw := 0.0
var view_pitch := -0.5
var view_speed := 40.0
var view_tour := false
var view_tour_s := 0.0
var view_drag := false


func _ready() -> void:
	finale = Finale.new()
	add_child(finale)
	rules.setup(self)
	_setup_environment()
	camera = Camera3D.new()
	camera.doppler_tracking = Camera3D.DOPPLER_TRACKING_IDLE_STEP
	camera.far = 7000.0
	camera.near = 0.05
	add_child(camera)
	camera.make_current()
	audio = AudioSynth.new()
	add_child(audio)
	pit_audio = preload("res://scripts/pit_audio.gd").new()
	add_child(pit_audio)
	crash_guard = preload("res://scripts/crash_guard.gd").new()
	crash_guard.game = self
	add_child(crash_guard)
	if crash_guard.report_path != "":
		_crash_notice.call_deferred(crash_guard.report_path)
	var ui := CanvasLayer.new()
	add_child(ui)
	hud = Hud.new()
	hud.game = self
	hud.visible = false
	ui.add_child(hud)
	net = Net.new()
	net.name = "Net"          # fixed name: RPCs find the same node on every computer
	net.game = self
	add_child(net)
	account = preload("res://scripts/account.gd").new()
	account.name = "Account"
	add_child(account)
	social = preload("res://scripts/social.gd").new()
	social.name = "Social"
	social.game = self
	social.acc = account
	add_child(social)
	menu = Menu.new()
	menu.game = self
	ui.add_child(menu)
	settings = menu.settings
	# sound: quiet on a fresh install (defaults), always the saved volume from the first moment on, and
	# softly faded in instead of starting at full blast
	var vol_db := linear_to_db(maxf(0.0001, float(settings.get("vol_master", 0.25))))
	AudioServer.set_bus_volume_db(0, -60.0)
	var fade := create_tween()
	fade.tween_method(func(db: float): AudioServer.set_bus_volume_db(0, db), -60.0, vol_db, 2.5).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_SINE)
	menu.start_race.connect(_on_start)
	menu.track_changed.connect(_on_track_changed)
	menu.quality_changed.connect(_on_quality_changed)
	menu.race_settings_closed.connect(_close_race_settings)
	# tear-free, but a slow frame does not halve the frame rate (adaptive vsync where available)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ADAPTIVE)
	_apply_window.call_deferred()
	_setup_music()
	# the app icon (Dock / task bar) - from the game files, so an update can change it
	var ib := FileAccess.get_file_as_bytes("res://art/icon_mac.png")
	if ib.size() > 0:
		var ii := Image.new()
		if ii.load_png_from_buffer(ib) == OK:
			DisplayServer.set_icon(ii)
			_mac_app_icon(ib)
	# loading screen on its own layer above menu and HUD
	var ll := CanvasLayer.new()
	ll.layer = 60
	add_child(ll)
	loading = preload("res://scripts/loading_screen.gd").new()
	ll.add_child(loading)
	loading.start_intro(String(settings.get("quality", "low")))
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.visible = false
	ui.add_child(overlay)
	_apply_quality()
	# video export: the game was started again with a replay file and records it as a movie
	var movie_file := ""
	var movie_from := 0.0
	var movie_len := 300.0
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--tf24-replay="):
			movie_file = a.substr(14)
		elif a.begins_with("--tf24-from="):
			movie_from = float(a.substr(12))
		elif a.begins_with("--tf24-len="):
			movie_len = float(a.substr(11))
	if movie_file != "" and replay.load_file(movie_file):
		settings["track"] = replay.track
	else:
		movie_file = ""
	await get_tree().process_frame
	await get_tree().process_frame
	await _build_world(movie_file == "")
	if movie_file != "":
		replay_file = movie_file
		_spawn_replay_cars()
		start_replay("movie")
		replay_t = clampf(movie_from, 0.0, replay.length())
		replay_end = minf(replay.length(), replay_t + movie_len)
		cam_mode = 4


# ---------------------------------------------------------------- menu music (own track, music/menu_theme.ogg)
var music: AudioStreamPlayer
var music_vol := 0.0


func _setup_music() -> void:
	music = AudioStreamPlayer.new()
	add_child(music)
	var st: AudioStreamOggVorbis = null
	if FileAccess.file_exists("res://music/menu_theme.ogg"):
		st = AudioStreamOggVorbis.load_from_file("res://music/menu_theme.ogg")
	elif ResourceLoader.exists("res://music/menu_theme.ogg"):
		st = load("res://music/menu_theme.ogg") as AudioStreamOggVorbis     # exported game
	if st == null:
		return
	st.loop = true
	music.stream = st
	music.volume_db = -80.0
	music.play()


# fades in while in the menus, out when the race weekend starts
func _update_music(dt: float) -> void:
	if music == null or music.stream == null:
		return
	var want: float = float(settings.get("vol_music", 0.6)) if (state == "menu" or (loading != null and loading.visible and state != "race")) and not sound_off else 0.0
	music_vol = move_toward(music_vol, want, dt * (0.6 if want > music_vol else 0.9))
	music.volume_db = linear_to_db(maxf(0.0001, music_vol * 0.8))
	if music_vol <= 0.001 and music.playing:
		music.stream_paused = true
	elif music_vol > 0.001 and music.stream_paused:
		music.stream_paused = false


# ---------------------------------------------------------------- environment & quality
func _setup_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	sky_mat = Gfx.sky_material()
	var sky := Sky.new()
	sky.sky_material = sky_mat
	sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_AGX
	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.glow_bloom = 0.04
	env.glow_hdr_threshold = 1.1
	env.fog_enabled = true
	env.fog_density = 0.0003
	env.fog_aerial_perspective = 0.5
	env.fog_sky_affect = 0.25
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.06
	env.adjustment_saturation = 1.08
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 320.0
	sun.shadow_blur = 1.2
	add_child(sun)
	moon = DirectionalLight3D.new()
	moon.light_color = Color(0.6, 0.7, 1.0)
	moon.shadow_enabled = true
	moon.directional_shadow_max_distance = 160.0
	add_child(moon)
	# rain streaks around the camera
	rain = GPUParticles3D.new()
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(40, 18, 40)
	pm.direction = Vector3(0.1, -1, 0)
	pm.spread = 3.0
	pm.initial_velocity_min = 22.0
	pm.initial_velocity_max = 28.0
	pm.gravity = Vector3(0, -9.8, 0)
	rain.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.02, 0.7)
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rm.albedo_color = Color(0.8, 0.85, 0.9, 0.35)
	rm.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	q.material = rm
	rain.draw_pass_1 = q
	rain.amount = 6000
	rain.lifetime = 1.4
	rain.visibility_aabb = AABB(Vector3(-60, -40, -60), Vector3(120, 80, 120))
	rain.emitting = false
	add_child(rain)


func _apply_quality() -> void:
	var q: String = settings["quality"]
	var vp := get_viewport()
	var lv := perf_level                 # FPS guard: 0 = as chosen, higher = lighter (see _perf_guard)
	var no_msaa := lv >= 3
	vp.msaa_3d = Viewport.MSAA_DISABLED if no_msaa else (Viewport.MSAA_4X if q == "ultra" else (Viewport.MSAA_2X if q in ["high", "medium"] else Viewport.MSAA_DISABLED))
	vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if (q == "low" or no_msaa) else Viewport.SCREEN_SPACE_AA_DISABLED
	var sc: float = (0.8 if q == "low" else 1.0) * float(PERF_SCALE[lv])
	vp.scaling_3d_scale = sc
	# below full resolution: AMD FSR upscaling keeps the picture sharp
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_FSR if sc < 0.99 else Viewport.SCALING_3D_MODE_BILINEAR
	vp.fsr_sharpness = 0.35
	vp.mesh_lod_threshold = 1.0 + lv * 1.5
	vp.positional_shadow_atlas_size = 4096 if q == "ultra" and lv == 0 else (1024 if lv >= 4 else 2048)
	RenderingServer.directional_shadow_atlas_set_size(1024 if (q == "low" or lv >= 4) else (4096 if q == "ultra" and lv == 0 else 2048), true)
	RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_LOW if (q in ["low", "medium"] or lv >= 2) else RenderingServer.SHADOW_QUALITY_SOFT_HIGH)
	env.ssao_enabled = q != "low" and lv < 2
	env.ssao_radius = 1.2
	env.ssao_intensity = 1.6
	env.ssil_enabled = q == "ultra" and lv < 1
	env.sdfgi_enabled = q == "ultra" and lv < 1
	env.volumetric_fog_enabled = q == "ultra" and lv < 1       # by far the most expensive effect: only on Ultra
	env.volumetric_fog_density = 0.002
	env.volumetric_fog_length = 160.0
	env.glow_enabled = q != "low" and lv < 3
	sun.directional_shadow_max_distance = _shadow_dist() * (1.0 if lv < 3 else (0.7 if lv < 5 else 0.5))
	# 4 shadow cascades draw every shadow caster up to four times: only on Ultra
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if q == "ultra" and lv < 2 else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.shadow_enabled = true


# the last session crashed: say so and where the report is
func _crash_notice(path: String) -> void:
	var d := AcceptDialog.new()
	d.title = "Das Spiel ist beim letzten Mal abgestürzt"
	d.dialog_text = "Ein Absturzbericht liegt in deinem Downloads-Ordner:\n%s\n\nSchick die Datei an den Entwickler, dann lässt sich der Fehler finden." % path.get_file()
	d.ok_button_text = "OK"
	d.add_button("ORDNER ÖFFNEN", true, "show")
	d.custom_action.connect(func(_a): OS.shell_show_in_file_manager(path))
	add_child(d)
	d.popup_centered()


# macOS: the icon of the app itself (Finder, Dock when the game is closed, Launchpad). The exported app
# carries the icon of the day it was built; this puts the current one from the game files on the app
# (like "Get Info -> paste icon"), once per icon and app location, in the background.
const APP_ICON_VERSION := 43


func _mac_app_icon(png: PackedByteArray) -> void:
	if OS.get_name() != "macOS":
		return
	var exe := OS.get_executable_path()
	var at := exe.find(".app/Contents/MacOS/")
	if at < 0:
		return
	var app := exe.substr(0, at + 4)
	var mark := "%d|%s" % [APP_ICON_VERSION, app]
	if FileAccess.file_exists("user://app_icon.txt") and FileAccess.get_file_as_string("user://app_icon.txt") == mark:
		return
	var png_path := ProjectSettings.globalize_path("user://app_icon.png")
	var f := FileAccess.open("user://app_icon.png", FileAccess.WRITE)
	if f == null:
		return
	f.store_buffer(png)
	f.close()
	var q := func(t: String) -> String: return "'" + t.replace("\\", "\\\\").replace("'", "\\'") + "'"
	var js := "ObjC.import('AppKit');var img=$.NSImage.alloc.initWithContentsOfFile(%s);img.isNil()?'no':($.NSWorkspace.sharedWorkspace.setIconForFileOptions(img,%s,0)?'ok':'fail')" % [q.call(png_path), q.call(app)]
	var pid := OS.create_process("/usr/bin/osascript", ["-l", "JavaScript", "-e", js])
	if pid > 0:
		var mf := FileAccess.open("user://app_icon.txt", FileAccess.WRITE)
		if mf != null:
			mf.store_string(mark)
			mf.close()


# which model cars wear the real livery (garage settings)
func _sync_liveries() -> void:
	CarVisual.player_original = bool(settings.get("livery_original", true))
	CarVisual.ai_original = String(settings.get("ai_livery", "team")) == "original"


# ---------------------------------------------------------------- FPS guard
# Holds the chosen frame rate (default 60 FPS): when frames get slow (busy grandstands, big start
# fields) the 3D picture is drawn at a lower resolution (FSR upscaled) and expensive effects switch off
# step by step; when there is headroom again, quality comes back one step at a time.
const PERF_SCALE := [1.0, 0.9, 0.8, 0.72, 0.65, 0.58, 0.5]
var perf_level := 0
var perf_ft := 1.0 / 60.0
var perf_up_t := 0.0
var perf_cool := 0.0
var perf_slow := 0
var perf_raised_t := 99.0
var perf_block := 0.0
var perf_grace := 3.0
var win_t := 0.0


func _perf_guard(raw: float) -> void:
	win_t += raw
	if win_t > 0.3:
		win_t = 0.0
		_keep_fullscreen()
	var on: bool = settings.get("fps_guard", true)
	if loading.visible or state == "menu":
		perf_grace = 3.0               # right after loading, shader warm-up stutter is not real load
	if not on or state == "menu" or loading.visible:
		if perf_level != 0 and (not on or state == "menu"):
			perf_level = 0
			_apply_quality()
		return
	perf_grace -= raw
	if raw > 0.25 or perf_grace > 0.0:
		return                         # a hitch (loading, window switch) says nothing about the load
	perf_ft = lerpf(perf_ft, raw, 0.08)
	perf_cool -= raw
	perf_block -= raw
	perf_raised_t += raw
	perf_slow = perf_slow + 1 if raw > 1.0 / (float(settings.get("fps_target", 60)) * 0.6) else 0
	if perf_cool > 0.0:
		return
	var tgt: float = float(settings.get("fps_target", 60))
	if (perf_ft > 1.0 / (tgt * 0.9) or perf_slow >= 3) and perf_level < PERF_SCALE.size() - 1:
		perf_level += 1
		perf_cool = 0.5
		perf_up_t = 0.0
		perf_slow = 0
		if perf_raised_t < 4.0:
			perf_block = 30.0           # the better step was too much: stay here for a while
		_apply_quality()
		return
	# headroom (or running at the screen's refresh cap): try one step better now and then
	if perf_ft < 1.0 / (tgt * 0.97) and perf_level > 0 and perf_block <= 0.0:
		perf_up_t += raw
		if perf_up_t > 6.0:
			perf_level -= 1
			perf_up_t = 0.0
			perf_cool = 2.0
			perf_raised_t = 0.0
			_apply_quality()
	else:
		perf_up_t = 0.0


# ---------------------------------------------------------------- window
# Full screen stays full screen: ESC (pause / back) must not drop the game out of it.
# F11 or Cmd+Ctrl+F switches between full screen and window (remembered).
func _apply_window() -> void:
	var want: bool = settings.get("fullscreen", true)
	var mode := DisplayServer.window_get_mode()
	var is_fs := mode == DisplayServer.WINDOW_MODE_FULLSCREEN or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN
	if want and not is_fs:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
	elif not want and is_fs:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_MAXIMIZED)


func _keep_fullscreen() -> void:
	if settings.get("fullscreen", true):
		_apply_window()


func toggle_fullscreen() -> void:
	settings["fullscreen"] = not settings.get("fullscreen", true)
	menu.save_settings()
	_apply_window()


func _input(ev: InputEvent) -> void:
	if ev is InputEventKey and ev.pressed and not ev.echo:
		var k: InputEventKey = ev
		if k.physical_keycode == KEY_F11 or (k.physical_keycode == KEY_F and k.meta_pressed and k.ctrl_pressed):
			toggle_fullscreen()
			get_viewport().set_input_as_handled()


func _shadow_dist() -> float:
	return {"low": 150.0, "medium": 200.0, "high": 240.0}.get(settings["quality"], 320.0)


func _on_quality_changed() -> void:
	perf_level = 0
	_apply_quality()


func _on_track_changed() -> void:
	_build_world()


var _building := false


func _build_world(hold := false) -> void:
	# one build at a time (the build takes several frames now): a second request waits for the first
	while _building:
		await get_tree().process_frame
	if built_track == settings["track"] and built_quality == settings["quality"] and built_slot == garage_slot and world_root != null:
		return
	_building = true
	if crash_guard != null:
		crash_guard.trace("Strecke bauen: %s / %s" % [settings["track"], settings["quality"]])
	loading.begin("Strecke wird vorbereitet …")
	menu.visible = false
	await get_tree().process_frame
	await get_tree().process_frame
	_clear_race()
	if world_root:
		world_root.queue_free()
	var def: Dictionary = TrackDefs.spa() if settings["track"] == "spa" else TrackDefs.trois_forets()
	loading.set_progress(0.02, "Streckenverlauf %s …" % String(def.get("name", "")))
	await get_tree().process_frame
	T = Track.new()
	T.build(def)
	T.set_player_slot(garage_slot)       # online: the own garage (lines, BOX sign, team garage) is built there
	built_slot = garage_slot
	world = WorldBuilder.new()
	world_root = await world.build(T, self, settings["quality"], loading.set_progress)
	built_track = settings["track"]
	built_quality = settings["quality"]
	tv_spots.clear()
	# TV cameras: for every stretch the position (side, distance, height) that sees the most of it
	loading.set_progress(0.92, "TV-Kameras werden aufgestellt …")
	await get_tree().process_frame
	var s := 0.0
	var tv_n := 0
	while s < T.length:
		tv_n += 1
		if tv_n % 12 == 0:
			loading.set_progress(0.92 + 0.08 * s / T.length)
			await get_tree().process_frame
		var best := Vector3.ZERO
		var best_score := -1.0
		for side: float in [-1.0, 1.0]:
			var i: int = T.idx(s)
			# never behind the pit buildings (they line the right side between pit entry and exit)
			if side > 0.0 and T.wrap_s(s - T.pit_in + 60.0) < T.wrap_s(T.pit_out - T.pit_in) + 120.0:
				continue
			for extra: float in [4.0, 10.0]:
				for h: float in [6.0, 10.0, 15.0]:
					var p: Vector4 = T.point_at(s, side * ((T.bar_r[i] if side > 0.0 else T.bar_l[i]) + extra))
					var cam := Vector3(p.x, maxf(world.terrain_height(p.x, p.z), p.y) + h, p.z)
					var score := 0.0
					var ds := -90.0
					while ds <= 90.0:
						var q: Vector4 = T.point_at(fposmod(s + ds, T.length), T.line_d[T.idx(fposmod(s + ds, T.length))])
						if world.line_clear(cam, Vector3(q.x, q.y + 1.0, q.z)):
							score += 1.0
						ds += 15.0
					score -= h * 0.01 + extra * 0.005
					if score > best_score:
						best_score = score
						best = cam
		if best_score > 2.0:
			tv_spots.append(best)
		s += 140.0
	loading.set_progress(1.0, "Bereit")
	await get_tree().create_timer(0.35).timeout
	_building = false
	if crash_guard != null:
		crash_guard.trace("Strecke fertig")
	if hold:
		await loading.hold_for_input()        # game start: the intro runs until a key or click
	loading.visible = false
	menu.visible = state == "menu"


# ---------------------------------------------------------------- race setup
func _clear_race() -> void:
	if pit_audio != null:
		pit_audio.stop_all()
	CarPhysics.fcy_speed = 0.0
	for v in visuals:
		v.queue_free()
	for ps in pit_stops.values():
		ps.queue_free()
	for ps in pits_leaving:
		ps.queue_free()
	pits_leaving.clear()
	if player_pit != null:
		player_pit.queue_free()
	for d in debris + replay_debris:
		var dn: Node3D = d["node"]
		dn.queue_free()
	replay_debris.clear()
	replay_bodies.clear()
	if cockpit:
		cockpit = null
	visuals.clear()
	cars.clear()
	drivers.clear()
	pit_stops.clear()
	drift_show = null
	debris.clear()
	player = null
	player_vis = null
	player_pit = null


func _on_start() -> void:
	quali_order.clear()
	online_grid = []
	garage_slot = 0
	_queue_weekend()
	if built_track != settings["track"] or built_quality != settings["quality"] or built_slot != garage_slot:
		await _build_world()
	_start_race()


# race weekend: optional practice and qualifying, then the race
func _queue_weekend() -> void:
	session_queue = []
	if settings.get("wk_practice", false) and not menu.spectate:
		session_queue.append("practice")
	if settings.get("wk_quali", true) and not menu.spectate:
		session_queue.append("quali")
	session_queue.append("race")
	session = session_queue.pop_front()


# online race: same grid on every computer, sent by the host
func start_online(cfg: Dictionary) -> void:
	if crash_guard != null:
		crash_guard.trace("Online-Rennen startet: %d Autos" % (cfg.get("grid", []) as Array).size())
	for k in ["track", "cls", "duration", "start_hour", "time_scale", "weather", "wear", "damage", "ai_diff", "quali_limits", "rules"]:
		if cfg.has(k):
			settings[k] = cfg[k]
	online_grid = cfg["grid"]
	quali_order.clear()
	session_queue = []
	session = "race"
	# every human driver gets his own garage (the host the base one): same numbering on every computer
	var slots := _garage_slots(online_grid)
	garage_slot = 0
	for k in online_grid.size():
		if int(online_grid[k].get("peer", 0)) == net.my_id() and slots[k] >= 0:
			garage_slot = slots[k]
	if built_track != settings["track"] or built_quality != settings["quality"] or built_slot != garage_slot:
		await _build_world()
	lights_out_override = float(cfg.get("lights", 7.0)) if net.is_host() else 1e9
	_start_race()
	net.send_ready()


var lights_out_override := -1.0


func _timed() -> bool:
	return session == "quali" or session == "practice"


func is_online() -> bool:
	return not online_grid.is_empty()


# team k of a class; once the list runs out, extra teams get their own colours and numbers
func _team(cls: String, k: int) -> Array:
	var list: Array = TEAMS[cls]
	var base: Array = list[k % list.size()]
	if k < list.size():
		return base
	var round_no: int = k / list.size()
	var c1: Color = base[1]
	var c2: Color = base[2]
	var h := fposmod(c1.h + 0.37 * round_no + 0.11 * k, 1.0)
	var nc1 := Color.from_hsv(h, clampf(c1.s + 0.2, 0.45, 0.95), clampf(c1.v, 0.35, 0.95))
	var nc2 := Color.from_hsv(fposmod(h + 0.5, 1.0), clampf(c2.s, 0.0, 0.9), clampf(1.0 - c2.v, 0.1, 0.95))
	return [String(base[0]) + " #" + str(round_no + 1), nc1, nc2, base[3], (int(base[4]) + 13 * round_no) % 99 + 1]


func _start_race() -> void:
	_sync_liveries()
	_clear_race()
	audio.muted = sound_off        # back from the menu: sound on again (unless switched off with M)
	audio.reset()
	var dur := {"l3": [0.0, 3], "m20": [1200.0, 0], "m45": [2700.0, 0], "m90": [5400.0, 0], "h6": [21600.0, 0], "h24": [86400.0, 0]}
	var dd: Array = dur.get(settings["duration"], [1200.0, 0])
	duration_sec = dd[0]
	laps_target = dd[1]
	recorded = false
	if _timed():
		quali_len = float(settings["practice_min" if session == "practice" else "quali_min"]) * 60.0
		duration_sec = 1e9
		laps_target = 0
	var grid: Array = []
	if is_online():
		grid = online_grid.duplicate(true)
	elif not show_grid.is_empty():
		grid = show_grid.duplicate(true)
		grid.append(my_entry())             # the spectator (parked out of sight)
	else:
		var n_hy: int = settings.get("n_hy", 0)
		var n_gt: int = settings.get("n_gt3", settings["opponents"])
		if settings.get("field", "own") == "own" and n_hy + n_gt == 0:
			n_gt = settings["opponents"]
		if settings.get("ai_on", true) == false and not menu.spectate:
			n_hy = 0                         # alone on track
			n_gt = 0
		for k in n_hy:
			grid.append({"cls": "hyper", "team": _team("hyper", k)})
		for k in n_gt:
			grid.append({"cls": "gt3", "team": _team("gt3", k), "model": ai_model(k)})
		if menu.spectate:
			grid.append(my_entry())          # the spectator's car is parked: no gap in the field
		else:
			grid.insert(mini(3, n_hy) if settings["cls"] == "hyper" else mini(n_hy + 3, grid.size()), my_entry())
	# race after a qualifying: grid in qualifying order
	if session == "race" and quali_order.size() == grid.size():
		grid.sort_custom(func(a, b): return quali_order.find(_grid_key(a)) < quali_order.find(_grid_key(b)))
	var slots := _garage_slots(grid)
	var wet_start := 1.0 if settings["weather"] == "rain" else 0.0
	wet = wet_start
	rain_on = settings["weather"] == "rain"
	for k in grid.size():
		var g: Dictionary = grid[k]
		var key: String = g["cls"]
		var model := String(g.get("model", "amg")) if key == "gt3" else ""
		var spec: Dictionary = CarPhysics.spec_for(key, model)
		var mine: bool = g.get("player", false) if not is_online() else int(g.get("peer", 0)) == net.my_id()
		var su: Dictionary = settings["setup_" + key].duplicate() if mine else CarPhysics.default_setup(key)
		if not mine and wet_start > 0.5:
			su["compound"] = "wet"
		if not mine and session == "race":
			# AI teams fuel like real ones: enough for the race (or a full stint) plus two laps reserve
			var lap_est: float = T.length / (52.0 if key == "hyper" else 46.0)
			var laps_est: float = float(laps_target) if laps_target > 0 else duration_sec / lap_est
			var per: float = T.length / 1000.0 * (0.43 if key == "hyper" else 0.47) * float(settings["wear"])
			su["fuel"] = clampf((laps_est + 2.0) * per, 15.0, spec["fuelCap"])
		var c = CarPhysics.new(spec, T, su)
		c.place(-14.0 - k * 9.0, 3.2 if k % 2 else -3.2)
		c.lap = -1
		c.cp = true
		c.wear_mul = settings["wear"]
		c.fuel_mul = settings["wear"]
		c.damage_mul = settings["damage"]
		var team: Array = g["team"]
		c.set_meta("team", team)
		c.name = team[0]
		c.num = team[4]
		c.driver = String(g.get("driver", ""))
		if c.driver != "":
			c.name = c.driver
		var gpeer: int = g.get("peer", 0)
		c.is_player = g.get("player", false) if not is_online() else gpeer == net.my_id()
		c.remote = is_online() and not c.is_player and (gpeer != 0 or not net.is_host())
		c.wet = wet
		c.trace.resize(T.N)
		c.trace.fill(-1.0)
		var v = CarVisual.new()
		var friend: bool = is_online() and gpeer != 0 and not c.is_player
		if bool(g.get("show", false)):
			v.full_model = true
			v.own_original = 1 if bool(g.get("orig", false)) else 0
		if friend:
			# a friend: his real car with the full model and the livery he picked, plus his name above it
			c.set_meta("human", true)
			v.full_model = true
			v.own_original = 1 if bool(g.get("orig", true)) else 0
		add_child(v)
		v.setup(key, [team[1], team[2], team[3]], team[4], settings["quality"], c.is_player, model)
		if friend and not bool(g.get("spec", false)):
			_name_tag(v, c.name, int(team[4]))
		_seat_driver(c, v, team)
		cars.append(c)
		visuals.append(v)
		if c.is_player:
			player = c
			player_vis = v
			if settings.get("manual_start", true):
				# the engine is off: ignition (X), then hold the starter (Enter)
				c.engine_on = false
				c.ignition = false
				c.rpm = 0.0
				c.engine_started.connect(_on_engine_started)
			drivers.append(null)
			c.auto_shift = settings["auto_gear"]
			c.tc_on = settings["tc"] and int(su["tc"]) > 0
			c.abs_on = settings["abs"] or key == "gt3"
			if c.abs_on and int(c.setup["abs"]) == 0:
				c.setup["abs"] = 5
			if c.tc_on == false and settings["tc"]:
				c.tc_on = int(c.setup["tc"]) > 0
		elif c.remote:
			drivers.append(null)
		elif bool(g.get("show", false)):
			drivers.append(null)               # drift show: driven by the choreography
			c.set_meta("scripted", true)
		else:
			var ai = AIDriver.new(c, settings["ai_diff"])
			# own garage: the humans have the first ones, the AI teams the next ones
			ai.box_ps = _box_for_slot(slots[k])
			drivers.append(ai)
		c.set_meta("grid_key", _grid_key(g))
		c.set_meta("box_ps", T.box_ps if c.is_player else _box_for_slot(slots[k]))
		if not _timed() and not c.remote and not c.is_player and not is_online() and settings.get("manual_start", true):
			# a quiet grid: the others fire up their engines once the player's engine runs
			c.engine_on = false
			c.ignition = false
			c.rpm = 0.0
		if _timed() and not c.remote:
			# everybody starts in the own garage box; the AI leaves the pits spread over the session
			var bs: float = T.box_ps if c.is_player else drivers[k].box_ps
			# every car starts inside its garage, nose towards the pit lane
			c.place_lane(bs, T.GARAGE_LAT + 4.6)
			var gq := clampi(int(bs), 0, T.lN - 1)
			c.psi = atan2(-T.lrz[gq], -T.lrx[gq])
			if not c.is_player:
				c.engine_on = false          # silent garages: the AI starts its engine just before leaving
				c.rpm = 0.0
			c.cp = false
			c.limiter = c.is_player
			if not c.is_player:
				drivers[k].pit_state = "out"
				drivers[k].react_t = 2.0 + k * randf_range(2.5, 6.0) + randf() * 0.08 * quali_len
	# spectators (Zuschauer): their car never takes part - parked out of sight in the own garage
	for k in grid.size():
		var gk: Dictionary = grid[k]
		if bool(gk.get("spec", false)) or (not is_online() and bool(gk.get("player", false)) and menu.spectate):
			_make_spectator(cars[k], visuals[k])
	cockpit = Cockpit.new()
	cockpit.build(player, player_vis, self)
	replay.begin(cars, settings["track"])
	pit_plan = {"fuel_add": player.spec["fuelCap"], "tyres": player.compound, "set": "all", "repair": true, "requested": false,
		"press_f": float(player.setup["press_f"]), "press_r": float(player.setup["press_r"]), "wing": int(player.setup["wing"]), "pads": false}
	pit_custom = false
	apply_pit_preset()
	tyre_sets_left = float({"l3": 2, "m20": 2, "m45": 3, "m90": 5, "h6": 14, "h24": 40}.get(settings["duration"], 4))
	radio_txt = ""
	radio_t = 0.0
	radio_suggest = {}
	radio_flags = {}
	fuel_line = -1.0
	fuel_per_lap = -1.0
	last_dmg = 0.0
	pit_ready = false
	# no tyre warmers: cold out of the garage, a little warmer on the grid
	for c in cars:
		c.temp_f = 34.0 if _timed() else 55.0
		c.temp_r = c.temp_f
	if settings["racing_line"]:
		world.build_racing_line(player.spec)
	elif world.line_mesh:
		world.line_mesh.visible = false
	race_time = 0.0
	hour = settings["start_hour"]
	started = false
	chequered = false
	lights_t = 0.0
	lights_n = 0
	lights_out_at = 6.0 + randf() * 1.6
	if lights_out_override > 0.0:
		lights_out_at = lights_out_override
		lights_out_override = -1.0
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, float(settings.get("vol_master", 0.9)))))
	audio.engine_gain = float(settings.get("vol_engine", 1.0))
	sectors_best = [-1.0, -1.0, -1.0]
	sectors_cur = [-1.0, -1.0, -1.0]
	overall_best_sec = [-1.0, -1.0, -1.0]
	sector_idx = 0
	penalty = 0.0
	rules.reset()
	tl_off = false
	tl_strikes = 0
	tl_ref = PackedFloat32Array()
	# starting from the box is not a pit stop: the crew only works once the car has left the pits
	pit_served = _timed()
	if finale.mode != "":
		finale.mode = "podium"
		finale.on_done = Callable()
		finale._end()
	passenger_ai = null
	state = "grid"
	paused = false
	cam_mode = 0
	cam_init = false
	hint_t = 15.0
	menu.visible = false
	overlay.visible = false
	hud.visible = true
	hud.prepare_minimap()
	order = racing_cars()
	if _timed():
		state = "race"
		started = true
		for c in cars:
			c.hold = false
		show_msg(("Training" if session == "practice" else "Qualifying") + " · Start aus der Garage · Limiter AN", 5.0)
	else:
		show_msg("Startaufstellung – warte auf die Ampel", 3.0)
	if player.spectator:
		finale.start_watch(self, _spectator_results, true)
	if not show_grid.is_empty():
		_begin_drift_show()


func show_msg(t: String, dur := 2.0, col := Color(1.0, 0.83, 0.0), sub := "") -> void:
	msg = t
	msg_t = dur + (1.5 if sub != "" else 0.0)
	msg_col = col
	msg_sub = sub


# ---------------------------------------------------------------- input
func _unhandled_input(ev: InputEvent) -> void:
	if state == "replay":
		_replay_input(ev)
		return
	if state == "viewer":
		_viewer_input(ev)
		return
	if state == "menu" or player == null:
		return
	if drift_show != null and ev is InputEventMouseMotion and (ev.button_mask & (MOUSE_BUTTON_MASK_LEFT | MOUSE_BUTTON_MASK_RIGHT)) != 0:
		show_yaw = clampf(show_yaw - ev.relative.x * 0.004, -1.6, 1.6)
		show_pitch = clampf(show_pitch - ev.relative.y * 0.004, -0.6, 0.5)
		show_free_t = 6.0
		return
	if (passenger_ai != null or cam_mode == 5) and ev is InputEventMouseMotion and (ev.button_mask & (MOUSE_BUTTON_MASK_LEFT | MOUSE_BUTTON_MASK_RIGHT)) != 0:
		cockpit.look_yaw = clampf(cockpit.look_yaw - ev.relative.x * 0.004, -2.4, 2.4)
		cockpit.look_pitch = clampf(cockpit.look_pitch - ev.relative.y * 0.004, -0.7, 0.6)
		return
	if ev is InputEventMouseButton and ev.pressed and not paused and passenger_ai == null:
		if ev.button_index == MOUSE_BUTTON_RIGHT:
			player.shift(1)
		elif ev.button_index == MOUSE_BUTTON_LEFT:
			player.shift(-1)
	if not (ev is InputEventKey) or not ev.pressed or ev.echo:
		return
	var kc: int = ev.physical_keycode
	if drift_show != null and not paused and state == "race":
		# drift show: you sit on the grandstand - change places, look around, nothing else
		if kc in [KEY_LEFT, KEY_RIGHT, KEY_T] and not show_seats.is_empty():
			show_seat = posmod(show_seat + (-1 if kc == KEY_LEFT else 1), show_seats.size())
			show_free_t = 0.0
			cam_init = false
			show_msg("Platz %d von %d" % [show_seat + 1, show_seats.size()], 1.2, Color(1.0, 0.7, 0.25))
			return
		if kc == KEY_F:
			show_free_t = 0.0                    # back to following the cars
			return
		if not (kc in [KEY_ESCAPE, KEY_P, KEY_M, KEY_H]):
			return
	if finale.mode != "" and not paused:
		if finale.handle_key(kc) or not (kc in [KEY_ESCAPE, KEY_P, KEY_M, KEY_H]):
			return
	if menu.in_race:
		if kc == KEY_ESCAPE:
			_close_race_settings()
		return
	if kc == KEY_ESCAPE or kc == KEY_P:
		_toggle_pause()
		return
	if paused:
		return
	if kc == KEY_F1 or kc == KEY_V:
		_toggle_passenger()
		return
	if passenger_ai != null and kc in [KEY_E, KEY_SHIFT, KEY_Q, KEY_CTRL, KEY_L, KEY_X, KEY_R]:
		return              # the AI drives: no gear, limiter, engine or reset keys
	match kc:
		KEY_E, KEY_SHIFT:
			player.shift(1)
		KEY_Q, KEY_CTRL:
			player.shift(-1)
		KEY_C:
			cam_mode = (cam_mode + 1) % 5
			cam_init = false
			show_msg(["Kamera: Verfolger", "Kamera: Nah", "Kamera: Cockpit", "Kamera: Motorhaube", "Kamera: TV"][cam_mode], 1.2)
		KEY_L:
			player.limiter = not player.limiter
			if CarPhysics.fcy_speed > 0.0 and not player.near_lane:
				show_msg("FCY-Limiter " + ("AN · 80 km/h" if player.limiter else "AUS"), 1.4, Color(1.0, 0.85, 0.1))
			else:
				var lk: float = player.pit_cap * 3.6 if player.pit_cap > 0.0 else T.pit_limit * 3.6
				show_msg("Pit-Limiter " + (("AN · %d km/h" % int(round(lk))) if player.limiter else "AUS"), 1.4, Color(0.3, 0.6, 1.0))
		KEY_TAB:
			pit_menu_open = not pit_menu_open
		KEY_COMMA, KEY_PERIOD:
			if pit_menu_open:
				# next / previous saved strategy
				var n: int = PitStrategy.list().size()
				PitStrategy.select((PitStrategy.selected() + (1 if kc == KEY_PERIOD else n - 1)) % n)
				pit_custom = false
				apply_pit_preset()
				show_msg("Strategie: " + String(PitStrategy.current()["name"]), 1.4, Color(0.3, 0.6, 1.0))
		KEY_BACKSPACE:
			if pit_menu_open and pit_custom:
				pit_custom = false
				apply_pit_preset()
				show_msg("Wieder nach Strategie „%s“" % String(PitStrategy.current()["name"]), 1.4, Color(0.3, 0.6, 1.0))
		KEY_1:
			if pit_menu_open:
				pit_custom = true
				pit_plan["fuel_add"] = maxf(0.0, pit_plan["fuel_add"] - 5.0)
		KEY_2:
			if pit_menu_open:
				pit_custom = true
				pit_plan["fuel_add"] = minf(player.spec["fuelCap"], pit_plan["fuel_add"] + 5.0)
		KEY_3:
			if pit_menu_open:
				pit_custom = true
				var opts := ["", "soft", "medium", "hard", "wet"]
				pit_plan["tyres"] = opts[(opts.find(pit_plan["tyres"]) + 1) % opts.size()]
		KEY_4:
			if pit_menu_open:
				pit_custom = true
				var sets := ["all", "front", "rear"]
				pit_plan["set"] = sets[(sets.find(pit_plan["set"]) + 1) % sets.size()]
		KEY_5:
			if pit_menu_open:
				pit_custom = true
				pit_plan["repair"] = not pit_plan["repair"]
		KEY_7:
			if pit_menu_open:
				# tyre pressure for the new tyres (both axles), cycles -0.3 … +0.3 bar
				var pv: float = snappedf(float(pit_plan["press_f"]) + 0.1, 0.1)
				if pv > 0.31:
					pv = -0.3
				pit_plan["press_f"] = pv
				pit_plan["press_r"] = pv
		KEY_8:
			if pit_menu_open:
				pit_plan["wing"] = (int(pit_plan["wing"]) + 1) % 11
		KEY_9:
			if pit_menu_open:
				pit_custom = true
				pit_plan["pads"] = not pit_plan["pads"]
		KEY_0:
			if pit_menu_open:
				pit_custom = true
				pit_plan["fuel_add"] = snappedf(fuel_to_finish(), 1.0)
				show_msg("Sprit bis ins Ziel: +%d L" % int(pit_plan["fuel_add"]), 1.6, Color(0.3, 0.6, 1.0))
		KEY_6, KEY_F:
			_radio_answer()
		KEY_X:
			if not player.engine_on:
				player.ignition = not player.ignition
				audio.beep(660.0 if player.ignition else 330.0, 0.08)
				show_msg("Zündung AN · jetzt ENTER gedrückt halten zum Starten" if player.ignition else "Zündung AUS", 2.5, Color(1.0, 0.85, 0.1))
			else:
				player.engine_on = false
				player.ignition = false
				player.off_rpm = player.rpm
				show_msg("Motor AUS · X Zündung, dann ENTER halten", 2.5)
		KEY_R:
			_reset_player()
		KEY_T:
			player.tc_on = not player.tc_on
			show_msg("Traktionskontrolle " + ("AN" if player.tc_on else "AUS"), 1.2)
		KEY_B:
			player.abs_on = not player.abs_on
			show_msg("ABS " + ("AN" if player.abs_on else "AUS"), 1.2)
		KEY_G:
			player.auto_shift = not player.auto_shift
			show_msg("Automatik" if player.auto_shift else "Manuell schalten", 1.2)
		KEY_I:
			if world.line_mesh == null:
				world.build_racing_line(player.spec)
			else:
				world.line_mesh.visible = not world.line_mesh.visible
		KEY_O:
			settings["radar"] = not settings["radar"]
		KEY_U, KEY_J, KEY_K, KEY_N:
			# seat adjustment in the cockpit view
			if cockpit != null:
				# the seat is set per class: the single-seater hypercar sits completely differently from a GT3
				var hy: bool = player.spec["key"] == "hyper"
				var kh := "seat_h_hyper" if hy else "seat_h"
				var kx := "seat_x_hyper" if hy else "seat_x"
				if kc == KEY_U or kc == KEY_J:
					settings[kh] = clampf(float(settings.get(kh, 0.0)) + (0.015 if kc == KEY_U else -0.015), -0.08 if hy else -0.15, 0.1 if hy else 0.12)
				else:
					settings[kx] = clampf(float(settings.get(kx, 0.0)) + (0.02 if kc == KEY_K else -0.02), -0.06 if hy else -0.2, 0.2 if hy else 0.25)
				cockpit.apply_seat()
				menu.save_settings()
		KEY_M:
			sound_off = not sound_off
			audio.muted = sound_off or paused
		KEY_H:
			hud_visible = not hud_visible


func _read_input(dt: float) -> void:
	var steer_t := 0.0
	var thr := 0.0
	var brk := 0.0
	var pad := false
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		steer_t -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		steer_t += 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		thr = 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN) or Input.is_physical_key_pressed(KEY_SPACE):
		brk = 1.0
	for dev in Input.get_connected_joypads():
		var ax := Input.get_joy_axis(dev, JOY_AXIS_LEFT_X)
		var dz: float = settings.get("steer_deadzone", 0.07)
		if absf(ax) > dz:
			steer_t = signf(ax) * pow((absf(ax) - dz) / (1.0 - dz), float(settings.get("steer_curve", 1.6)))
			pad = true
		var rt := Input.get_joy_axis(dev, JOY_AXIS_TRIGGER_RIGHT)
		var lt := Input.get_joy_axis(dev, JOY_AXIS_TRIGGER_LEFT)
		if rt > 0.02:
			thr = rt
			pad = true
		if lt > 0.02:
			brk = lt
			pad = true
		for b in [JOY_BUTTON_RIGHT_SHOULDER, JOY_BUTTON_LEFT_SHOULDER, JOY_BUTTON_Y, JOY_BUTTON_X, JOY_BUTTON_START, JOY_BUTTON_BACK]:
			var key := "%d:%d" % [dev, b]
			var now := Input.is_joy_button_pressed(dev, b)
			if now and not pad_prev.get(key, false):
				match b:
					JOY_BUTTON_RIGHT_SHOULDER:
						player.shift(1)
					JOY_BUTTON_LEFT_SHOULDER:
						player.shift(-1)
					JOY_BUTTON_Y:
						cam_mode = (cam_mode + 1) % 5
						cam_init = false
					JOY_BUTTON_X:
						player.limiter = not player.limiter
					JOY_BUTTON_START:
						_toggle_pause()
					JOY_BUTTON_BACK:
						_reset_player()
			pad_prev[key] = now
	var u: float = maxf(0.0, player.u)
	var sens: float = settings.get("steer_speed", 1.0)
	if pad:
		input_steer += (steer_t - input_steer) * minf(1.0, dt * 18.0 * sens)
		input_thr = thr
		input_brk = brk
	else:
		var rate := 4.5 if steer_t == 0.0 else (6.0 if signf(steer_t) != signf(input_steer) and input_steer != 0.0 else 2.6)
		input_steer = move_toward(input_steer, steer_t, rate * sens * dt)
		input_thr += (thr - input_thr) * minf(1.0, dt * 9.0)
		input_brk += (brk - input_brk) * minf(1.0, dt * 12.0)
	var ssens: float = settings.get("steer_speed_sens", 1.0)
	# Kurvenhilfe: the steering is cut back less at speed (the extra grip keeps the car from spinning)
	var ca: float = float(settings.get("corner_assist", 0.5))
	var scale := 1.0 / (1.0 + pow(u / (34.0 if pad else 29.0), 2.0) * 1.05 * ssens * (1.0 - 0.35 * ca))
	var st: float = input_steer * scale * float(settings.get("steer_strength", 1.0))
	if settings["steer_assist"]:
		st += clampf(player.slip_r * 0.9 / player.spec["steerMax"], -0.5, 0.5)
	player.steer = clampf(st, -1.0, 1.0)
	player.throttle = input_thr
	player.brake = input_brk
	var start_btn := Input.is_physical_key_pressed(KEY_ENTER) or Input.is_physical_key_pressed(KEY_KP_ENTER)
	for dev in Input.get_connected_joypads():
		if Input.is_joy_button_pressed(dev, JOY_BUTTON_A):
			start_btn = true
			player.ignition = true
	player.starter = start_btn and not player.engine_on
	if player.starter and not player.ignition and not radio_flags.has("ign"):
		radio_flags["ign"] = true
		show_msg("Erst die Zündung an: X drücken", 2.0, Color(1.0, 0.85, 0.1))


func _reset_player() -> void:
	if state != "race" or player_pit != null:
		return
	var i: int = player.idx
	player.place(player.s, clampf(T.line_d[i], -4.0, 4.0))
	player.gear = 1
	reset_hold = 3.0
	show_msg("Zurück auf die Strecke – 3 s", 2.0, Color(1.0, 0.3, 0.25))


func _toggle_pause() -> void:
	if state == "menu" or state == "results":
		return
	paused = not paused
	audio.muted = paused or sound_off
	if paused:
		var btns := [["WEITER", _toggle_pause], ["EINSTELLUNGEN", _open_race_settings], ["REPLAY", start_replay.bind("pause")], ["NEUSTART", _restart], ["HAUPTMENÜ", _to_menu]]
		if _timed():
			btns.insert(1, ["SESSION BEENDEN · ERGEBNIS", _end_session])
		_show_overlay("PAUSE", btns, null)
	else:
		overlay.visible = false


# settings during a race (pause menu): controls, pit strategies, graphics and sound apply at once
func _open_race_settings() -> void:
	overlay.visible = false
	menu.in_race = true
	menu.visible = true
	menu.go("settings", false)


func _close_race_settings() -> void:
	if not menu.in_race:
		return
	menu.in_race = false
	menu.visible = false
	menu.save_settings()
	_apply_quality()
	if paused:
		paused = false
		_toggle_pause()


func _restart() -> void:
	paused = false
	audio.muted = sound_off
	_start_race()


# ---------------------------------------------------------------- drift show
# started from the menu (settings already switched to Spa by the menu): the show cars + the spectator
func start_drift_show() -> void:
	online_grid = []
	quali_order.clear()
	session_queue = []
	session = "race"
	garage_slot = 0
	show_grid = DriftShow.grid(_team)
	menu.spectate = true
	if built_track != settings["track"] or built_quality != settings["quality"] or built_slot != garage_slot:
		await _build_world()
	_start_race()


func _begin_drift_show() -> void:
	var show_cars: Array = []
	for c in cars:
		if c.has_meta("scripted"):
			show_cars.append(c)
	drift_show = DriftShow.new()
	drift_show.setup(self, show_cars)
	# no start procedure: the show runs straight away
	state = "race"
	started = true
	chequered = false
	duration_sec = 1e9
	# the grandstand at La Source, right in front of the run-off
	var seats: Array = world.seats
	var centre: Vector2 = drift_show.W(255.0, 24.0)
	var best := -1
	var bd := 1e18
	for k in seats.size():
		var sp: Vector3 = seats[k]["pos"]
		var d := Vector2(sp.x, sp.z).distance_squared_to(centre)
		if d < bd:
			bd = d
			best = k
	show_seats = []
	show_seat = 0
	show_yaw = 0.0
	show_pitch = 0.0
	show_free_t = 0.0
	if best >= 0:
		finale.seat_i = best - 1
		finale.next_seat(1)
		# places along the stand (it follows the curve of La Source), all in the same row
		var sd: Dictionary = seats[best]
		var look_pt := Vector3(centre.x, T.height_at(255.0), centre.y)
		if sd.has("s0"):
			var a0: float = float(sd["s0"]) + 8.0
			var a1: float = float(sd["s1"]) - 8.0
			var span: float = fposmod(a1 - a0, T.length)
			for f in [0.5, 0.0, 0.25, 0.75, 1.0]:
				var sq: float = T.wrap_s(a0 + span * f)
				var pq: Vector4 = T.point_at(sq, float(sd["lat"]))
				show_seats.append([Vector3(pq.x, pq.y + float(sd["h"]), pq.z), look_pt])
		else:
			show_seats.append([sd["pos"], look_pt])
	finale.dir_t = 1e9
	cam_mode = 6
	cam_init = false
	show_msg("DRIFT-SHOW  ·  LA SOURCE", 4.0, Color(1.0, 0.55, 0.1), "Tribüne Gold 7  ·  ←/→ Platz wechseln  ·  Maus / WASD umschauen")


# drift show: eyes on the grandstand - they follow the watched car, or look where the viewer wants
func _show_camera(dt: float, c) -> void:
	cam_mode = 6
	var seat: Array = show_seats[show_seat]
	var eye: Vector3 = seat[0]
	# W A S D also look around (held keys)
	var kx := 0.0
	if Input.is_physical_key_pressed(KEY_A):
		kx -= 1.0
	if Input.is_physical_key_pressed(KEY_D):
		kx += 1.0
	var ky := 0.0
	if Input.is_physical_key_pressed(KEY_W):
		ky += 1.0
	if Input.is_physical_key_pressed(KEY_S):
		ky -= 1.0
	if kx != 0.0 or ky != 0.0:
		show_yaw = clampf(show_yaw - kx * 1.2 * dt, -1.6, 1.6)
		show_pitch = clampf(show_pitch + ky * 0.8 * dt, -0.6, 0.5)
		show_free_t = 6.0
	show_free_t = maxf(0.0, show_free_t - dt)
	var target: Vector3 = seat[1] + Vector3(0, 1.0, 0)
	if c != null and not c.spectator:
		target = Vector3(c.x, c.y + 0.8, c.z)
	var base_dir := (target - eye).normalized()
	var look_dir := base_dir
	if show_free_t > 0.0:
		look_dir = Basis(Vector3.UP, show_yaw) * base_dir
		look_dir = look_dir.rotated(look_dir.cross(Vector3.UP).normalized(), show_pitch)
	else:
		# after a while without input the eyes slowly come back to the cars
		show_yaw = lerpf(show_yaw, 0.0, minf(1.0, dt * 2.0))
		show_pitch = lerpf(show_pitch, 0.0, minf(1.0, dt * 2.0))
		look_dir = Basis(Vector3.UP, show_yaw) * base_dir
		look_dir = look_dir.rotated(look_dir.cross(Vector3.UP).normalized(), show_pitch)
	var want := eye + look_dir * 60.0
	if not cam_init:
		seat_look = want
		cam_init = true
	seat_look = seat_look.lerp(want, 1.0 - exp(-dt * 5.0))
	camera.global_position = eye
	camera.look_at(seat_look, Vector3.UP)
	var fd: float = eye.distance_to(target)
	var fz := clampf(1250.0 / maxf(15.0, fd), 14.0, 48.0)
	camera.fov = lerpf(camera.fov, 55.0 if show_free_t > 0.0 else fz, minf(1.0, dt * 3.0))


func _drift_show_end() -> void:
	state = "results"
	hud.visible = false
	_show_overlay("DRIFT-SHOW · DANKE FÜRS ZUSCHAUEN", [["NOCHMAL ANSEHEN", _restart], ["HAUPTMENÜ", _to_menu]], null,
		"Die nächste Show gibt es in drei Stunden – im Hauptmenü unter Tages-Events anmelden")


func _to_menu() -> void:
	paused = false
	audio.muted = true
	state = "menu"
	overlay.visible = false
	hud.visible = false
	_clear_race()
	online_grid = []
	if not show_grid.is_empty():
		menu.spectate = false
	show_grid = []
	event_id = ""
	menu.restore_after_event()
	menu.visible = true
	menu.go("home", false)


func _show_overlay(title: String, buttons: Array, table, subtitle: String = "") -> void:
	for ch in overlay.get_children():
		ch.queue_free()
	var bg := ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var sm := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = Ui.BG_SHADER
	sm.shader = sh
	sm.set_shader_parameter("alpha", 0.86)
	bg.material = sm
	overlay.add_child(bg)
	var bar := Ui.TopBar.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(bar)
	var logo := Ui.label("TF24   |   " + title, "head", 40)
	logo.position = Vector2(30, 24)
	overlay.add_child(logo)
	var box := VBoxContainer.new()
	box.anchor_left = 0.5
	box.anchor_right = 0.5
	box.offset_left = -560
	box.offset_right = 560
	box.offset_top = 130
	box.add_theme_constant_override("separation", 12)
	overlay.add_child(box)
	box.add_child(Ui.label(title, "head", 72))
	if subtitle != "":
		box.add_child(Ui.label(subtitle, "bold", 24, Ui.MUTED))
	if table != null:
		var sc := ScrollContainer.new()
		sc.custom_minimum_size = Vector2(1120, 560 if table is VBoxContainer else 0)
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		box.add_child(sc)
		sc.add_child(table)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	box.add_child(hb)
	for k in buttons.size():
		var bb: Array = buttons[k]
		var bt: Button = Ui.primary(bb[0], 24) if k == 0 else Ui.outline(bb[0], 20)
		bt.custom_minimum_size.x = 260
		bt.pressed.connect(bb[1])
		hb.add_child(bt)
	overlay.visible = true


# results table in the timing-screen style: pos, class, number, driver/team, laps/best, gap
func _results_table(sorted: Array, timed: bool) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 2)
	var head := HBoxContainer.new()
	for h in [["POS", 60], ["KL.", 70], ["NR", 70], ["FAHRER / TEAM", 470], ["RUNDEN" if not timed else "RUNDEN", 110], ["BESTE RUNDE", 170], ["ABSTAND", 150]]:
		var l := Ui.label(h[0], "bold", 18, Ui.MUTED)
		l.custom_minimum_size = Vector2(h[1], 0)
		head.add_child(l)
	v.add_child(head)
	var pole: float = -1.0
	var fastest: float = 1e9
	for c in sorted:
		if c.best > 0.0:
			fastest = minf(fastest, c.best)
	if timed and sorted.size() > 0:
		pole = sorted[0].best
	var leader = sorted[0] if sorted.size() > 0 else null
	for k in sorted.size():
		var c = sorted[k]
		var row := PanelContainer.new()
		var col := Color(0.9, 0.11, 0.24, 0.35) if c.is_player else (Color(0.06, 0.08, 0.13, 0.9) if k % 2 == 0 else Color(0.09, 0.11, 0.17, 0.9))
		row.add_theme_stylebox_override("panel", Ui.box(col, 2))
		var hb := HBoxContainer.new()
		row.add_child(hb)
		var gap := ""
		if k > 0:
			if timed:
				gap = "" if c.best < 0.0 or pole < 0.0 else "+%.3f" % (c.best - pole)
			elif c.retired:
				gap = "DNF"
			elif maxi(0, c.lap) < leader.lap:
				gap = "+%d Rd." % (leader.lap - maxi(0, c.lap))
			else:
				gap = "+%.1f s" % maxf(0.0, (c.finish_time - leader.finish_time)) if c.finished and leader.finished else ""
		var cl := Ui.panel(Ui.GT if c.spec["key"] == "gt3" else Ui.HY, 2, Color(0, 0, 0, 0), 0)
		cl.add_child(Ui.label("GT3" if c.spec["key"] == "gt3" else "HY", "head", 16))
		var cells := [[str(k + 1), 60, "head"], [cl, 70, ""], ["#%d" % c.num, 70, "bold"],
			[c.name + ((" (DSQ)" if c.has_meta("dsq") else " (DNF)") if c.retired else "") + ("  +%d s Strafe" % int(penalty) if c.is_player and penalty > 0.0 else ""), 470, "bold"],
			[str(maxi(0, c.lap)), 110, "bold"], [Hud.fmt(c.best) if c.best > 0.0 else "-", 170, "bold"], [gap, 150, "bold"]]
		for cell in cells:
			if cell[0] is Control:
				var wrap := Control.new()
				wrap.custom_minimum_size = Vector2(cell[1], 26)
				wrap.add_child(cell[0])
				hb.add_child(wrap)
			else:
				var fl := Ui.label(String(cell[0]), cell[2], 22, Color(0.8, 0.55, 1.0) if cell[1] == 170 and c.best > 0.0 and absf(c.best - fastest) < 0.0005 else Color.WHITE)
				fl.custom_minimum_size = Vector2(cell[1], 0)
				fl.clip_text = true
				hb.add_child(fl)
		v.add_child(row)
	return v


# ---------------------------------------------------------------- race logic
func progress(c) -> float:
	if _timed():
		return -_qkey(c)
	var p: float = c.lap * T.length + c.s
	var pen: float = penalty if c.is_player else 0.0
	if c.finished:
		p += 1e7 - (c.finish_time + pen) * 100.0
	elif pen > 0.0:
		p -= pen * maxf(30.0, absf(c.u))
	if c.retired:
		p -= 1e6
	return p


func _physics_tick() -> void:
	# AI drivers think at 120 Hz (half of the cars each physics step); the car physics stays at 240 Hz
	tick_n += 1
	if drift_show != null and tick_n % 2 == 0:
		drift_show.tick(DT * 2.0)
		if drift_show.done and state == "race":
			_drift_show_end()
	for k in cars.size():
		if drivers[k] != null and (k + tick_n) % 2 == 0:
			drivers[k].update(DT * 2.0, cars, started)
	if passenger_ai != null and not paused:
		passenger_ai.update(DT, cars, started)
	player.corner_assist = float(settings.get("corner_assist", 0.5))
	player.easy = settings["steer_mode"] == "easy"      # stability assist for "Sehr einfach"
	var creep: bool = rules.player_free_on_grid()
	if not started and not creep:
		player.brake = 1.0
	if reset_hold > 0.0:
		reset_hold -= DT
		player.throttle = 0.0
		player.brake = 1.0
		player.hold = true
	elif player_pit == null and started and rules.stopgo_t < 0.0 and state == "race":
		player.hold = false
	for c in cars:
		if not started:
			c.hold = not (c.is_player and creep)
		if c.remote:
			net.dead_reckon(c, DT)
		elif c.has_meta("scripted"):
			pass                                 # drift show car: moved by the choreography
		else:
			c.step(DT)
	if started:
		CarPhysics.collide_cars(cars)
		if tick_n % 4 == 0:
			CarPhysics.update_draft(cars, T.length, DT * 4.0)       # slipstream changes slowly: 60 Hz is plenty
	if state == "grid":
		rules.grid_tick()
	rules.tick(DT)
	for c in cars:
		if c.s > T.length * 0.45 and c.s < T.length * 0.55:
			c.cp = true
		if c.prev_s > T.length - 250.0 and c.s < 250.0 and c.cp:
			_cross_line(c)
		if c.is_player:
			_sectors(c)
		_track_limits(c)
		_pit_clock(c)
		c.prev_s = c.s
	if player.lap_start >= 0.0:
		player.trace[player.idx] = race_time - player.lap_start
	if started and state == "race":
		replay.record(cars, DT, race_time, hour, wet)
	if started:
		race_time += DT
	hour += DT * settings["time_scale"] / 3600.0


# how long a pit stop takes: standing time and the whole visit of the pit lane, for every car
func _pit_clock(c) -> void:
	if not started or c.spectator:
		return
	if c.in_pit:
		c.lane_t += DT
		if absf(c.u) < 0.5:
			c.stand_t += DT
	elif c.lane_t > 0.0:
		if c.lane_t > 4.0 and session == "race":
			c.last_stand = c.stand_t
			c.last_lane = c.lane_t
			c.last_stop_at = race_time
			if c.is_player and c.stand_t > 0.5:
				show_msg("BOXENSTOPP  ·  Standzeit %.1f s" % c.stand_t, 3.0, Color(0.3, 1.0, 0.4), "Zeit in der Boxengasse insgesamt: %.1f s" % c.lane_t)
		c.lane_t = 0.0
		c.stand_t = 0.0


func _cross_line(c) -> void:
	c.lap += 1
	c.cp = false
	if c.lap >= 1 and c.lap_start >= 0.0:
		var lt: float = race_time - c.lap_start
		c.last = lt
		if c.lap_invalid:
			if c.is_player:
				show_msg("Runde  " + Hud.fmt(lt) + "  (ungültig)", 2.0, Color(1.0, 0.3, 0.25))
		elif c.best < 0.0 or lt < c.best:
			c.best = lt
			if c.is_player:
				c.best_trace = c.trace.duplicate()
				show_msg("Persönliche Bestzeit  " + Hud.fmt(lt), 2.5, Color(0.6, 0.35, 1.0))
		elif c.is_player:
			show_msg("Runde  " + Hud.fmt(lt), 2.0)
	c.lap_start = race_time
	c.lap_invalid = false
	if c.is_player:
		c.trace.fill(-1.0)
		_radio_lap()
		rules.on_lap()
	if chequered and not c.finished:
		c.finished = true
		c.finish_time = race_time
		if c.is_player:
			_finish()
	elif not chequered and c.lap >= 1 and ((laps_target > 0 and c.lap >= laps_target) or (laps_target == 0 and race_time >= duration_sec)):
		chequered = true
		c.finished = true
		c.finish_time = race_time
		if c.is_player:
			_finish()
		else:
			show_msg("Zielflagge für " + c.name, 3.0)


func _sectors(c) -> void:
	var b1: float = T.length / 3.0
	var b2: float = T.length * 2.0 / 3.0
	var crossed := -1
	if sector_idx == 0 and c.prev_s < b1 and c.s >= b1 and c.s < b1 + 200.0:
		crossed = 0
	elif sector_idx == 1 and c.prev_s < b2 and c.s >= b2 and c.s < b2 + 200.0:
		crossed = 1
	elif sector_idx == 2 and c.prev_s > T.length - 250.0 and c.s < 250.0:
		crossed = 2
	if c.prev_s > T.length - 250.0 and c.s < 250.0 and crossed != 2:
		sector_idx = 0
		sector_start = race_time
		sectors_cur = [-1.0, -1.0, -1.0]
		return
	if crossed < 0:
		return
	var st := race_time - sector_start
	sectors_cur[crossed] = st
	if c.lap >= 0 and (sectors_best[crossed] < 0.0 or st < sectors_best[crossed]):
		sectors_best[crossed] = st
	if c.lap >= 0 and (overall_best_sec[crossed] < 0.0 or st < overall_best_sec[crossed]):
		overall_best_sec[crossed] = st
	sector_start = race_time
	sector_idx = (crossed + 1) % 3
	if crossed == 2:
		sectors_cur = [-1.0, -1.0, -1.0]


func _finish() -> void:
	rules.on_finish()
	state = "results"
	if player.retired:
		show_msg("Rennen vorbei für dich  ·  " + ("disqualifiziert" if player.has_meta("dsq") else "ausgefallen"), 3.0, Color(1.0, 0.45, 0.3))
	else:
		show_msg("🏁  ZIELFLAGGE!", 3.0, Color(0.3, 1.0, 0.4))
	_record_session()
	if not _timed():
		_park_player()
	if not _timed() and _others_running():
		# the others are still racing: TV pictures of them, then the podium
		get_tree().create_timer(2.5).timeout.connect(func(): finale.start_watch(self, _show_results))
	elif not _timed():
		get_tree().create_timer(2.5).timeout.connect(func():
			finale.game = self
			finale.on_done = _show_results
			finale.start_podium())
	else:
		get_tree().create_timer(2.5).timeout.connect(_show_quali_results)


func racing_cars() -> Array:
	return cars.filter(func(c): return not c.spectator)


func _make_spectator(c, v) -> void:
	c.spectator = true
	c.retired = true
	c.set_meta("retired_shown", true)
	c.place_lane(T.box_ps, T.GARAGE_LAT + 6.5)
	c.hold = true
	c.engine_on = false
	c.rpm = 0.0
	v.visible = false


# spectator: after the podium the results of the race (no own result, nothing recorded)
func _spectator_results() -> void:
	state = "results"
	_show_results()


# race over for the player: the car goes back into its garage and stays there (no cool-down lap,
# no driving on); the session runs on for the others
func _park_player() -> void:
	passenger_ai = null
	player.place_lane(T.box_ps, T.GARAGE_LAT + 4.6)
	var gq := clampi(int(T.box_ps), 0, T.lN - 1)
	player.psi = atan2(-T.lrz[gq], -T.lrx[gq])
	player.throttle = 0.0
	player.brake = 1.0
	player.steer = 0.0
	player.hold = true
	player.engine_on = false
	player.rpm = 0.0
	player.limiter = false
	if player_pit != null:
		player_pit.queue_free()
		player_pit = null


func _finish_retired() -> void:
	if state == "race" and player != null and player.retired:
		_finish()


func _others_running() -> bool:
	for c in cars:
		if not c.is_player and not c.finished and not c.retired:
			return true
	return false


func _show_results() -> void:
	var sorted := racing_cars()
	sorted.sort_custom(func(a, b): return progress(a) > progress(b))
	var pos := sorted.find(player) + 1
	var sub := "%s   ·   Platz %d von %d   ·   Beste Runde %s" % [String(T.def["name"]), pos, sorted.size(), Hud.fmt(player.best)]
	if player.spectator:
		sub = "%s   ·   als Zuschauer   ·   Sieger: %s" % [String(T.def["name"]), String(sorted[0].name) if not sorted.is_empty() else "-"]
	if not last_record.is_empty():
		sub += "   ·   DR %+d   SR %+.1f" % [int(last_record.get("d_dr", 0.0)), float(last_record.get("d_sr", 0.0))]
	hud.visible = false
	replay.info["result"] = sub
	var btns: Array = [["NOCHMAL", _restart], ["REPLAY ANSEHEN", start_replay.bind("results")], ["HAUPTMENÜ", _to_menu]]
	if is_online() and net.online:
		# online: back to the lobby together; the host can restart the race for everybody
		btns = [["ZURÜCK IN DIE LOBBY", to_lobby], ["REPLAY ANSEHEN", start_replay.bind("results")], ["HAUPTMENÜ (Lobby verlassen)", _leave_online]]
		if net.is_host():
			btns.push_front(["NEUSTART MIT ALLEN", _restart_online])
		else:
			sub += "   ·   Der Host kann das Rennen für alle neu starten"
	_show_overlay("ERGEBNIS · RENNEN", btns, _results_table(sorted, false), sub)


# online: everybody back to the lobby (host: the others who are done come along)
func to_lobby() -> void:
	if finale.mode != "":
		finale.mode = "podium"
		finale.on_done = Callable()
		finale._end()
	paused = false
	audio.muted = true
	state = "menu"
	overlay.visible = false
	hud.visible = false
	_clear_race()
	online_grid = []
	menu.visible = true
	menu.go("online", false)
	if net.is_host():
		net.send_lobby_back()


func _restart_online() -> void:
	if not net.is_host():
		return
	overlay.visible = false
	paused = false
	audio.muted = sound_off
	online_grid = []
	net.start_online_race()


func _leave_online() -> void:
	net.leave()
	_to_menu()


# ---------------------------------------------------------------- pit stops & damage
func estimate_stop() -> float:
	var fuel_t: float = clampf(float(pit_plan["fuel_add"]), 0.0, player.spec["fuelCap"] - player.fuel) / 4.5
	var tyre_t: float = 0.0 if pit_plan["tyres"] == "" else (7.5 if pit_plan["set"] == "all" else 4.5)
	var rep: float = player.repair_time() if pit_plan["repair"] else 0.0
	var extra := 32.0 if pit_plan["pads"] else (3.0 if int(pit_plan["wing"]) != int(player.setup["wing"]) else 0.0)
	var prep := 0.0 if pit_plan["requested"] else 3.0
	# WEC: refuelling first, then the tyres (never at the same time)
	return 0.9 + 0.5 + maxf(maxf(fuel_t + tyre_t, extra), maxf(rep, 2.0)) + 0.9 + prep


func _player_plan() -> Dictionary:
	var p := {"fuel_add": pit_plan["fuel_add"], "tyres": pit_plan["tyres"], "set": pit_plan["set"], "repair": pit_plan["repair"],
		"press_f": pit_plan["press_f"], "press_r": pit_plan["press_r"], "wing": pit_plan["wing"], "pads": pit_plan["pads"]}
	if not _tyres_allowed(p):
		p["tyres"] = ""
	return p


func _tyre_cost(p: Dictionary) -> float:
	if String(p["tyres"]) == "" or String(p["tyres"]) == "wet":
		return 0.0
	return 1.0 if String(p["set"]) == "all" else 0.5


func _tyres_allowed(p: Dictionary) -> bool:
	return session != "race" or _tyre_cost(p) <= tyre_sets_left + 0.01


func _use_tyre_sets(p: Dictionary) -> void:
	if session == "race":
		tyre_sets_left = maxf(0.0, tyre_sets_left - _tyre_cost(p))


# the selected pit strategy -> concrete plan for the next stop (unless changed by hand in the pit panel)
func apply_pit_preset() -> void:
	if pit_custom or player == null:
		return
	var per: float = fuel_per_lap if fuel_per_lap > 0.5 else T.length / 1000.0 * (0.47 if player.spec["key"] == "gt3" else 0.43)
	var p := PitStrategy.plan(PitStrategy.current(), {"fuel": player.fuel, "cap": float(player.spec["fuelCap"]), "fuel_per_lap": per,
		"fuel_to_finish": fuel_to_finish(), "wet": wet, "compound": player.compound, "pad_wear": player.pad_wear, "damage": player.total_damage()})
	for k in p:
		pit_plan[k] = p[k]


# litres needed to reach the finish (plus 1.5 laps reserve) minus what is in the tank
func fuel_to_finish() -> float:
	var per: float = fuel_per_lap if fuel_per_lap > 0.5 else T.length / 1000.0 * (0.47 if player.spec["key"] == "gt3" else 0.43)
	var laps_left := 0.0
	if laps_target > 0:
		laps_left = float(laps_target - player.lap)
	else:
		var lap_t: float = player.best if player.best > 0.0 else (player.last if player.last > 0.0 else T.length / 45.0)
		laps_left = maxf(0.0, duration_sec - race_time) / lap_t + 1.0
	return clampf((laps_left + 1.5) * per - player.fuel, 0.0, player.spec["fuelCap"] - player.fuel)


func _update_pits(dt: float) -> void:
	_preset_t -= dt
	if _preset_t <= 0.0 and (player_pit == null or player_pit.standby):
		_preset_t = 1.0
		apply_pit_preset()
	# player: stop in the own box to start the service
	if not player.in_pit:
		pit_served = false
	if (player_pit == null or player_pit.standby) and player.in_pit and not player.retired and not player.finished and not pit_served:
		var to_box: float = absf(player.ps - T.box_ps)
		if player.near_lane and to_box < 6.0 and absf(player.u) < 1.0 and player.plat > T.BOX_LAT - 3.0 and rules.wants_stopgo():
			# stop & go: stand 10 s, the crew must not work on the car
			rules.begin_stopgo()
			pit_served = true
		elif player.near_lane and to_box < 6.0 and absf(player.u) < 1.0 and player.plat > T.BOX_LAT - 3.0 and rules.stopgo_t < 0.0 \
				and (pit_ready or pit_plan["requested"] or player.lap >= 1):
			# unannounced stops only once a lap has been driven; before that the crew stays in the garage
			var plan := _player_plan()
			plan["ready"] = pit_ready
			plan["repair"] = pit_plan["repair"] and player.total_damage() > 0.01
			_use_tyre_sets(plan)
			if player_pit == null:
				player_pit = _spawn_pit(player, player_vis, plan, Color(0.05, 0.3, 0.9))
			else:
				player_pit.begin(player, plan)
			player.hold = true
			if pit_ready:
				show_msg("Boxenstopp", 1.5)
			else:
				radio("Wir waren nicht vorbereitet – Reifen werden geholt! Ruf die Box nächstes Mal vorher an (F).")
			pit_plan["requested"] = false
			pit_ready = false
			pit_late = false
			pit_custom = false              # the next stop follows the strategy again
		# called in: the crew walks out and waits in the box with everything ready
		if pit_plan["requested"] and not pit_late and player_pit == null and player.near_lane and player.in_pit and T.box_ps - player.ps < 160.0 and T.box_ps - player.ps > 8.0:
			var bp: Vector4 = T.lane_point(T.box_ps, T.BOX_LAT)
			var plan2 := _player_plan()
			plan2["ready"] = true
			player_pit = PitStop.new()
			add_child(player_pit)
			player_pit.prepare(player, player_vis, plan2, Color(0.05, 0.3, 0.9), Transform3D(Basis(Vector3.UP, -bp.w), Vector3(bp.x, bp.y, bp.z)))
			pit_ready = true
			radio("Box ist frei, wir sind bereit. Limiter rein und in die gelbe Box!")
		var in_zone: bool = player.near_lane and player.ps > T.lim_a and player.ps < T.lim_b
		var lane_kmh: float = player.pit_cap * 3.6 if player.pit_cap > 0.0 else T.pit_limit * 3.6
		if player.u * 3.6 > lane_kmh + 2.0 and in_zone and not player.limiter and started and session == "race":
			player.limiter = true
			if rules.active():
				rules.pit_speeding()
			else:
				penalty += 5.0
				show_msg("Strafe: Geschwindigkeit in der Boxengasse +5 s", 3.0, Color(1.0, 0.3, 0.25))
	if player_pit != null and player_pit.standby and not player.in_pit and player.ps > T.box_ps + 20.0:
		# drove through without stopping: the crew goes back in
		_pit_leave(player_pit)
		player_pit = null
		pit_ready = false
	# safe release: the crew holds the car while another car comes down the pit lane
	if player_pit != null and player_pit.done and _lane_traffic():
		player.hold = true
		if not radio_flags.has("hold"):
			radio_flags["hold"] = true
			show_msg("WARTEN … Auto in der Boxengasse!", 1.5, Color(1.0, 0.65, 0.1))
	elif player_pit != null and player_pit.done:
		radio_flags.erase("hold")
		player.hold = false
		_pit_leave(player_pit)
		player_pit = null
		pit_served = true
		radio_flags.erase("cold")
		radio_flags.erase("warm")
		radio_flags.erase("fuel2")
		radio_flags.erase("fuel1")
		radio_flags.erase("wear")
		last_dmg = player.total_damage()
		show_msg("LOS! LOS! LOS!  ·  Standzeit %.1f s" % player.stand_t, 2.5, Color(0.3, 1.0, 0.4), "Limiter am Ausgang ausschalten (L)")
		audio.beep(880.0, 0.4)
	if player_pit != null:
		player_pit.step(dt)
		pit_audio.muted = audio.muted
		for e in player_pit.events:
			if e is Array:
				pit_audio.play(String(e[0]), e[1], 1.0, randf_range(0.96, 1.04))
			else:
				audio.pit_event(String(e))
		player_pit.events.clear()
		pit_audio.set_flow(player_pit.fueling and not player_pit.done, player_pit.fuel_pos)
	else:
		pit_audio.set_flow(false, Vector3.ZERO)
	# AI stops: the crew walks out when the car comes down the pit lane, not before
	for k in cars.size():
		var ai = drivers[k]
		if ai == null:
			continue
		var ac = cars[k]
		if ai.pit_state == "planned" and not ai.emit_pit and not pit_stops.has(ac) and ac.in_pit and ac.near_lane \
				and ai.box_ps - ac.ps < 160.0 and ai.box_ps - ac.ps > 6.0:
			var bp: Vector4 = T.lane_point(ai.box_ps, T.BOX_LAT)
			var pps = PitStop.new()
			add_child(pps)
			pps.prepare(ac, visuals[k], _ai_plan(k), Color(0.3, 0.3, 0.35), Transform3D(Basis(Vector3.UP, -bp.w), Vector3(bp.x, bp.y, bp.z)))
			pit_stops[ac] = pps
		if ai.emit_pit:
			ai.emit_pit = false
			var plan := _ai_plan(k)
			var ps = pit_stops.get(ac)
			if ps != null and ps.standby:
				ps.begin(ac, plan)
			else:
				if ps != null:
					_pit_leave(ps)
				ps = _spawn_pit(ac, visuals[k], plan, Color(0.3, 0.3, 0.35))
				pit_stops[ac] = ps
			ai.service = ps.duration
	# cars driven on another computer (friends online, on a client also the host's AI): their crew comes
	# out when the car stops in its own box and goes back in when it drives off
	if is_online():
		for k in cars.size():
			var rc = cars[k]
			if not rc.remote or rc.spectator or rc.retired:
				continue
			var rps = pit_stops.get(rc)
			if rps == null:
				if rc.in_pit and absf(rc.u) < 0.4 and _at_own_box(rc):
					var rplan := {"fuel_add": 0.0, "view_fuel_t": 9.0, "tyres": rc.compound, "set": "all", "repair": false, "ready": true}
					var nps = _spawn_pit(rc, visuals[k], rplan, Color(0.3, 0.3, 0.35) if not rc.has_meta("human") else Color(0.1, 0.55, 0.25))
					nps.remote_view = true
					pit_stops[rc] = nps
			elif rps.remote_view and (absf(rc.u) > 2.0 or not rc.in_pit):
				_pit_leave(rps)
				pit_stops.erase(rc)
	for c in pit_stops.keys():
		var ps = pit_stops[c]
		# the AI changed its mind (or was already past the box): the waiting crew goes back in
		if ps.standby and (not c.in_pit or c.retired or c.ps > _box_of(c) + 20.0):
			_pit_leave(ps)
			pit_stops.erase(c)
			continue
		ps.step(dt)
		if ps.done:
			_pit_leave(ps)
			pit_stops.erase(c)
	for ps in pits_leaving.duplicate():
		ps.step(dt)
		if ps.gone:
			pits_leaving.erase(ps)
			ps.queue_free()


# a remote car standing on the box spot of its own garage
func _at_own_box(c) -> bool:
	if not c.has_meta("box_pt"):
		var bp: Vector4 = T.lane_point(float(c.get_meta("box_ps", T.box_ps)), T.BOX_LAT)
		c.set_meta("box_pt", Vector2(bp.x, bp.z))
	var pt: Vector2 = c.get_meta("box_pt")
	return Vector2(c.x, c.z).distance_to(pt) < 5.0


func _ai_plan(k: int) -> Dictionary:
	var ac = cars[k]
	var plan := {"fuel_add": ac.spec["fuelCap"], "tyres": ac.compound if wet < 0.5 else "wet", "repair": drivers[k].pit_plan.get("repair", false), "ready": true, "pads": ac.pad_wear > 0.7}
	if wet < 0.3 and ac.compound == "wet":
		plan["tyres"] = "medium"
	return plan


func _pit_leave(ps) -> void:
	if ps == null:
		return
	ps.leave()
	ps.events.clear()
	pits_leaving.append(ps)


func _box_of(c) -> float:
	var k := cars.find(c)
	if k >= 0 and drivers[k] != null:
		return float(drivers[k].box_ps)
	return T.box_ps



# everybody gets a driver in the seat: the player the one from the profile, the others in team colours
# passenger mode: the AI drives the own car, the camera sits on the passenger side, look around freely
func _toggle_passenger() -> void:
	if passenger_ai == null:
		var ai = AIDriver.new(player, maxf(100.0, float(settings["ai_diff"])))
		ai.box_ps = T.box_ps
		ai.react_t = 0.0
		if player.near_lane and player.in_pit:
			ai.pit_state = "out"
		if not player.engine_on:
			player.ignition = true
			player.engine_on = true
			player.rpm = float(player.spec["rpmIdle"]) * 2.4
			audio.start_flare()
		player.limiter = false
		passenger_ai = ai
		cam_mode = 2
		cockpit.passenger = true
		show_msg("BEIFAHRER · umsehen A/D/W/S · V zurück", 4.0, Color(0.3, 0.8, 1.0))
	else:
		passenger_ai = null
		cockpit.passenger = false
		cockpit.look_yaw = 0.0
		cockpit.look_pitch = 0.0
		input_thr = 0.0
		input_brk = 0.0
		show_msg("Du fährst wieder selbst", 2.0)
	cockpit.apply_seat()
	cam_init = false


func _passenger_look(dt: float) -> void:
	var yaw := 0.0
	var pitch := 0.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		yaw += 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		yaw -= 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		pitch += 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		pitch -= 1.0
	cockpit.look_yaw = clampf(cockpit.look_yaw + yaw * dt * 1.6, -2.4, 2.4)
	cockpit.look_pitch = clampf(cockpit.look_pitch + pitch * dt * 1.2, -0.7, 0.6)


func _seat_driver(c, v, _team: Array) -> void:
	v.add_driver(driver_look(c))


# the player's driver from the profile, everybody else in the team colours
func driver_look(c) -> Dictionary:
	if c.is_player:
		return Human.driver_look(Profile.current.get("driver", {}))
	var team: Array = c.get_meta("team", ["", Color(0.8, 0.1, 0.1), Color.WHITE, Color.BLACK, 0])
	var n := int(c.num)
	return {"suit": team[1], "accent": team[2], "stripe": team[3], "helmet": team[2], "helmet2": team[1],
		"skin": [Color(0.93, 0.76, 0.64), Color(0.77, 0.55, 0.4), Color(0.55, 0.37, 0.25)][n % 3],
		"visor": ["dark", "gold", "blue", "dark"][n % 4], "pattern": ["stripes", "split", "chevron"][n % 3],
		"helmet_model": "gp" if n % 3 != 1 else "classic"}


# the other cars on the grid start their engines one after another, shortly after the player's
func _grid_engines() -> void:
	for c in cars:
		if c.is_player or c.remote or c.engine_on or c.retired:
			continue
		if not c.has_meta("ign_at"):
			c.set_meta("ign_at", lights_t + randf_range(0.2, 2.4))
		elif lights_t >= float(c.get_meta("ign_at")):
			c.ignition = true
			c.engine_on = true
			c.rpm = float(c.spec["rpmIdle"]) * 2.0


func _on_engine_started() -> void:
	audio.start_flare()
	radio_flags.erase("ign")
	show_msg("Motor läuft", 1.5, Color(0.3, 1.0, 0.4))


func _greens_off() -> void:
	if world == null:
		return
	for m in world.green_lights:
		var gm: StandardMaterial3D = m
		gm.emission_energy_multiplier = 0.0


func _lane_traffic() -> bool:
	for c in cars:
		if c == player or not c.near_lane or not c.in_pit or c.hold:
			continue
		var d: float = player.ps - c.ps
		if d > -4.0 and d < 28.0 and c.u > 2.5:
			return true
	return false


# ---------------------------------------------------------------- crew radio
func radio(t: String, suggest: Dictionary = {}) -> void:
	if not settings.get("radio_on", true):
		return
	radio_txt = t
	radio_t = 7.0 if suggest.is_empty() else 12.0
	radio_suggest = suggest
	audio.radio()
	if bool(ProjectSettings.get_setting("audio/general/text_to_speech", false)) and settings.get("radio_voice", true):
		var voices := DisplayServer.tts_get_voices_for_language("de")
		if voices.size() > 0:
			DisplayServer.tts_stop()
			DisplayServer.tts_speak(t.replace("(F)", "").replace("F =", ""), voices[0], 70, 1.0, 1.08)


# F: accept the crew's suggestion (and call the box) / call or cancel the box
func _radio_answer() -> void:
	if not radio_suggest.is_empty() and radio_t > 0.0:
		for k in radio_suggest.keys():
			pit_plan[k] = radio_suggest[k]
		radio_suggest = {}
		pit_plan["requested"] = true
		pit_late = _pit_call_late()
		radio("Verstanden, Box diese Runde. Wir bereiten alles vor." if not pit_late else "Das kommt zu spät – wir sind nicht vorbereitet! Die Crew muss erst alles holen.")
	elif pit_plan["requested"]:
		pit_plan["requested"] = false
		pit_late = false
		if player_pit != null and player_pit.standby:
			_pit_leave(player_pit)
			player_pit = null
			pit_ready = false
		radio("Okay, Boxenstopp abgesagt. Bleib draußen.")
	else:
		pit_plan["requested"] = true
		pit_late = _pit_call_late()
		if pit_late:
			radio("Zu spät angefragt – wir wussten nichts! Die Crew muss erst alles holen, das dauert.")
		else:
			var tyres: String = "keine Reifen" if pit_plan["tyres"] == "" else String(CarPhysics.COMPOUNDS[pit_plan["tyres"]]["name"]) + "-Reifen"
			radio("Box, Box! Wir machen %d L Sprit, %s%s." % [int(pit_plan["fuel_add"]), tyres, ", Reparatur" if pit_plan["repair"] and player.total_damage() > 0.01 else ""])


# called in while the car is already coming down the pit lane: the crew cannot get ready in time
func _pit_call_late() -> bool:
	return player != null and player.in_pit and player.near_lane and T.box_ps - player.ps < 160.0


func _radio_lap() -> void:
	if fuel_line >= 0.0 and player.fuel < fuel_line:
		var used: float = fuel_line - player.fuel
		fuel_per_lap = used if fuel_per_lap < 0.0 else lerpf(fuel_per_lap, used, 0.5)
	fuel_line = player.fuel


func _radio_tick(dt: float) -> void:
	radio_t -= dt
	if radio_t <= 0.0:
		radio_suggest = {}
	radio_check_t -= dt
	if radio_check_t > 0.0 or player == null or player.retired or not started or radio_t > 1.5:
		return
	radio_check_t = 1.0
	var c = player
	var topt: float = c.cmp()["topt"]
	var tavg: float = (c.temp_f + c.temp_r) * 0.5
	var race := session == "race"
	# cold tyres after the start or a stop
	if tavg < topt - 22.0 and absf(c.u) > 15.0 and not c.in_pit and not radio_flags.has("cold"):
		radio_flags["cold"] = true
		radio("Reifen sind kalt, nur %d °C. Vorsichtig bremsen!" % int(tavg))
		return
	if radio_flags.has("cold") and not radio_flags.has("warm") and tavg > topt - 10.0:
		radio_flags["warm"] = true
		radio("Reifen sind jetzt im Fenster (%d °C). Volle Attacke!" % int(tavg))
		return
	if not race:
		return
	# fuel
	if fuel_per_lap > 0.5 and not pit_plan["requested"]:
		var laps_left: float = c.fuel / fuel_per_lap
		if laps_left < 1.15 and not radio_flags.has("fuel1"):
			radio_flags["fuel1"] = true
			radio("BOX, BOX! Sprit reicht nur noch für diese Runde! (F = Box)", {"fuel_add": c.spec["fuelCap"]})
			return
		if laps_left < 2.3 and not radio_flags.has("fuel2"):
			radio_flags["fuel2"] = true
			radio("Sprit für noch %.1f Runden. Nächste Runde an die Box? (F = Ja)" % laps_left, {"fuel_add": c.spec["fuelCap"]})
			return
	# tyre wear
	var wear: float = maxf(c.wear_f, c.wear_r)
	if wear > 0.62 and not radio_flags.has("wear") and not pit_plan["requested"]:
		radio_flags["wear"] = true
		var cmp: String = c.compound if c.compound != "wet" or wet > 0.3 else "medium"
		radio("Reifen %s sind zu %d %% runter. Neue Reifen holen? (F = Ja)" % ["vorne" if c.wear_f > c.wear_r else "hinten", int(wear * 100.0)], {"tyres": cmp, "set": "all"})
		return
	# damage
	var dmg: float = c.total_damage()
	if dmg > last_dmg + 0.08:
		last_dmg = dmg
		radio("Wir sehen Schaden am Auto, Reparatur ca. %d s. Reinkommen? (F = Ja)" % int(c.repair_time()), {"repair": true})
		return
	# weather
	if wet > 0.3 and c.compound != "wet" and not radio_flags.has("rain"):
		radio_flags["rain"] = true
		radio_flags.erase("dry")
		radio("Es regnet stärker! Regenreifen vorbereiten? (F = Ja)", {"tyres": "wet", "set": "all"})
		return
	if wet < 0.12 and c.compound == "wet" and not radio_flags.has("dry"):
		radio_flags["dry"] = true
		radio_flags.erase("rain")
		radio("Strecke trocknet ab, Regenreifen überhitzen. Slicks holen? (F = Ja)", {"tyres": "medium", "set": "all"})


# garage slot of every grid entry: the human drivers first (in grid order), then the AI teams;
# spectators park out of sight and get none (-1)
func _garage_slots(grid: Array) -> Array:
	var slots: Array = []
	slots.resize(grid.size())
	var n := 0
	for pass_no in 2:
		for k in grid.size():
			var g: Dictionary = grid[k]
			if bool(g.get("spec", false)):
				slots[k] = -1
				continue
			var human: bool = int(g.get("peer", 0)) != 0 or bool(g.get("player", false))
			if human == (pass_no == 0):
				slots[k] = n
				n += 1
	return slots


func _box_for_slot(slot: int) -> float:
	if T.garage_ps.is_empty():
		return T.box_ps
	var gi: int = T.garage_for_slot(maxi(0, slot))
	if gi == T.player_garage and slot != garage_slot:
		gi = posmod(gi + 1, T.garage_ps.size())     # more cars than garages: never in the own one
	return T.garage_ps[gi]


# floating name above a friend's car: readable from far away, gone when far off
func _name_tag(v: Node3D, nm: String, num: int) -> void:
	var lb := Label3D.new()
	lb.name = "FriendTag"
	lb.text = "%s  #%d" % [nm, num]
	lb.font_size = 44
	lb.outline_size = 12
	lb.outline_modulate = Color(0.02, 0.06, 0.03, 0.85)
	lb.modulate = Color(0.45, 1.0, 0.55)
	lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lb.fixed_size = true
	lb.pixel_size = 0.0011
	lb.position = Vector3(0, 2.0, 0)
	lb.visibility_range_end = 450.0
	lb.render_priority = 2
	if ResourceLoader.exists("res://fonts/BarlowCondensed-Bold.ttf"):
		lb.font = load("res://fonts/BarlowCondensed-Bold.ttf")
	v.add_child(lb)


func _spawn_pit(c, v, plan: Dictionary, col: Color):
	var ps = PitStop.new()
	add_child(ps)
	ps.start(c, v, plan, col)
	return ps


func _process_damage() -> void:
	for k in cars.size():
		var c = cars[k]
		if c.has_meta("replay_repair"):
			c.remove_meta("replay_repair")
			replay.add_event(k, -1.0, Vector3.ZERO)
		if c.hits.is_empty():
			continue
		var v = visuals[k]
		for h in c.hits:
			v.apply_hit(h[0], h[1], h[2])
			replay.add_event(k, h[1], h[2])
			if c.is_player and h[1] > 0.05:
				audio.thud(h[1] * 3.0)
		c.hits.clear()
		for node in v.update_lost(c.lost):
			debris.append(_spawn_debris(node, c))
			if c.is_player:
				var wheel_gone: bool = c.lost["wheel_fl"] or c.lost["wheel_fr"] or c.lost["wheel_rl"] or c.lost["wheel_rr"]
				show_msg("RAD VERLOREN! Langsam zurück an die Box" if wheel_gone else "Fahrzeugteil verloren!", 3.0, Color(1.0, 0.3, 0.25))


# a car out of the race (heavy damage, black flag): message once; for the player the race is over
func _check_retired() -> void:
	for c in cars:
		if c.retired and not c.get_meta("retired_shown", false):
			c.set_meta("retired_shown", true)
			if not c.has_meta("dsq"):     # the black flag has its own message
				show_msg(("Du bist ausgefallen" if c.is_player else c.name + " ist ausgefallen"), 3.0, Color(1.0, 0.3, 0.25))
			if c.is_player and state == "race" and not _timed():
				# out of the race (DNF / black flag): after a moment the TV pictures of the others, then the podium
				get_tree().create_timer(5.0).timeout.connect(_finish_retired)


func _spawn_debris(node: Node3D, c) -> Dictionary:
	# a copy of the lost part (wing, splitter, mirror, whole wheel) flies off and stays on the track
	var piece: Node3D = node.duplicate()
	piece.visible = true
	for ch in piece.find_children("*", "Node3D", true, false):
		var n3: Node3D = ch
		n3.visible = true
	add_child(piece)
	piece.global_transform = node.global_transform
	var wv: Vector2 = c.world_vel()
	return {"node": piece, "vel": Vector3(wv.x * 0.6 + randf_range(-3, 3), randf_range(2, 5), wv.y * 0.6 + randf_range(-3, 3)),
		"ang": Vector3(randf_range(-6, 6), randf_range(-6, 6), randf_range(-6, 6)), "life": 90.0}


func _update_debris(dt: float) -> void:
	debris = _move_debris(debris, dt)


func _move_debris(list: Array, dt: float) -> Array:
	var keep: Array = []
	for d in list:
		var n: Node3D = d["node"]
		var vel: Vector3 = d["vel"]
		vel.y -= 9.81 * dt
		n.global_position += vel * dt
		var ang: Vector3 = d["ang"]
		n.rotate_x(ang.x * dt)
		n.rotate_y(ang.y * dt)
		n.rotate_z(ang.z * dt)
		var nd: Vector2 = world.nearest(n.global_position.x, n.global_position.z)
		var ground: float = T.py[int(nd.x)] + 0.04 if nd.y < T.half_w + 2.0 else world.terrain_height(n.global_position.x, n.global_position.z)
		if n.global_position.y < ground:
			n.global_position.y = ground
			vel = Vector3(vel.x * 0.6, absf(vel.y) * 0.3, vel.z * 0.6)
			d["ang"] = ang * 0.6
		d["vel"] = vel
		d["life"] -= dt
		if d["life"] > 0.0:
			keep.append(d)
		else:
			n.queue_free()
	return keep


# ---------------------------------------------------------------- HUD data
func lap_info() -> Dictionary:
	var c = player
	var delta := 999.0
	if c.best_trace.size() == T.N and c.lap_start >= 0.0 and c.best_trace[c.idx] >= 0.0:
		delta = (race_time - c.lap_start) - c.best_trace[c.idx]
	var per_lap: float = c.spec["fuelRate"] * 0.62 * (T.length / 52.0) * c.fuel_mul + 0.0015 * (T.length / 52.0)
	return {
		"lap": maxi(1, c.lap + 1) if laps_target == 0 else "%d/%d" % [maxi(1, c.lap + 1), laps_target],
		"last": Hud.fmt(c.last), "best": Hud.fmt(c.best), "cur": Hud.fmt(race_time - c.lap_start) if c.lap_start >= 0.0 else "-:--.---",
		"delta": delta, "fuel_laps": c.fuel / maxf(0.1, per_lap), "pos": order.find(c) + 1, "count": cars.size(),
	}


func sector_state() -> Array:
	var out: Array = []
	for k in 3:
		var cur: float = sectors_cur[k]
		var col := Color(0.15, 0.16, 0.19, 0.9)
		var t := "--.---"
		if cur > 0.0:
			t = "%.3f" % cur
			if overall_best_sec[k] > 0.0 and cur <= overall_best_sec[k] + 0.0005:
				col = Color(0.55, 0.25, 0.85, 0.95)
			elif sectors_best[k] > 0.0 and cur <= sectors_best[k] + 0.0005:
				col = Color(0.1, 0.6, 0.25, 0.95)
			else:
				col = Color(0.75, 0.6, 0.05, 0.95)
		out.append([t, col])
	return out


func gap_text(o, c) -> String:
	if _timed():
		if o.best < 0.0 or c.best < 0.0:
			return Hud.fmt(o.best) if o.best > 0.0 else "--"
		return "%+.3f" % (o.best - c.best)
	var dp := progress(o) - progress(c)
	if absf(dp) > T.length:
		return "%s%d Rd" % ["+" if dp < 0.0 else "-", int(absf(dp) / T.length)]
	var v := maxf(30.0, absf(c.u))
	return "%+.1f" % (-dp / v)


func relative_list(n: int) -> Array:
	var items: Array = []
	for o in cars:
		var gap: float = wrapf(o.s - player.s, -T.length * 0.5, T.length * 0.5)
		var v := maxf(30.0, absf(player.u))
		var lapdiff := 0
		var pd := progress(o) - progress(player) - gap
		if absf(pd) > T.length * 0.5:
			lapdiff = int(roundf(pd / T.length))
		items.append([o, -gap / v, lapdiff, gap])
	items.sort_custom(func(a, b): return a[3] > b[3])
	var idx := 0
	for k in items.size():
		if items[k][0] == player:
			idx = k
	var out: Array = []
	for k in range(maxi(0, idx - n), mini(items.size(), idx + n + 1)):
		out.append(items[k])
	return out


func remaining_text() -> String:
	if _timed():
		var qr := maxf(0.0, quali_len - race_time)
		var nm := "Training" if session == "practice" else "Quali"
		return "%s %d:%02d" % [nm, int(qr / 60.0), int(qr) % 60] if not chequered else nm + " – Zielflagge"
	if laps_target > 0:
		return "Runden"
	if chequered:
		return "Letzte Runde"
	var rem := maxf(0.0, duration_sec - race_time)
	return "Rest %d:%02d:%02d" % [int(rem / 3600.0), int(rem / 60.0) % 60, int(rem) % 60]


# ---------------------------------------------------------------- per frame
func _process(dt: float) -> void:
	_perf_guard(dt)
	dt = minf(dt, 0.1)
	_update_music(dt)
	if state == "replay":
		_replay_process(dt)
		return
	if state == "viewer":
		_viewer_process(dt)
		return
	if state == "menu" or player == null:
		_menu_camera(dt)
		return
	if paused and not is_online():
		return
	if finale.mode == "podium":
		finale.process(dt)
		var pinfo := _update_sky()
		for k in cars.size():
			visuals[k].sync(cars[k], 0.0, pinfo, wet, camera.global_position, 0.0)
		return
	if finale.mode == "watch":
		finale.process(dt)
	if paused:
		player.throttle = 0.0
		player.brake = 1.0
	elif finale.mode != "" or state == "results":
		pass                              # the race is over for the player: no more driving
	elif passenger_ai != null:
		_passenger_look(dt)
	else:
		_read_input(dt)
	if state == "grid":
		# online: the host waits until every driver has loaded the track; clients wait for the host's "go"
		if is_online() and net.is_host() and not net.all_ready():
			lights_t = 0.0
		# offline the start waits for the player's engine (X ignition, hold ENTER)
		if not is_online() and not player.engine_on and passenger_ai == null and not player.spectator:
			lights_t = 0.0
		else:
			_grid_engines()
		lights_t += dt
		var n := clampi(int(lights_t - 0.5), 0, 5)
		if n != lights_n and n > 0:
			audio.beep(440.0, 0.18)
		lights_n = n
		for k in world.start_lights.size():
			var m: StandardMaterial3D = world.start_lights[k]
			m.emission_energy_multiplier = 10.0 if k < n else 0.0
		if lights_t >= lights_out_at:
			for m in world.start_lights:
				var sm: StandardMaterial3D = m
				sm.emission_energy_multiplier = 0.0
			started = true
			state = "race"
			for c in cars:
				c.hold = false
			if is_online() and net.is_host():
				net.send_go()
			for m in world.green_lights:
				var gm: StandardMaterial3D = m
				gm.emission_energy_multiplier = 9.0
			get_tree().create_timer(4.0).timeout.connect(_greens_off)
			show_msg("GO!  GO!  GO!", 1.5, Color(0.3, 1.0, 0.4))
			audio.beep(880.0, 0.5)
	acc += dt
	var steps := 0
	while acc >= DT and steps < 40:
		_physics_tick()
		acc -= DT
		steps += 1
	if steps >= 40:
		acc = 0.0
	if is_online():
		net.tick(dt)
	if state == "race" or state == "results":
		_update_pits(dt)
	if state == "race":
		_radio_tick(dt)
	if state == "race":
		_quali_tick()
	_process_damage()
	_check_retired()
	_update_debris(dt)
	_update_weather(dt)
	order_t -= dt
	if order_t <= 0.0:
		order_t = 0.2
		order = racing_cars()
		order.sort_custom(func(a, b): return progress(a) > progress(b))
		blue_flag = false
		if player.spec["key"] == "gt3" and started and session == "race":
			for o in cars:
				if o.spec["key"] == "hyper":
					var g: float = wrapf(player.s - o.s, 0.0, T.length)
					if g > 5.0 and g < 70.0 and o.u > player.u:
						blue_flag = true
	msg_t -= dt
	hint_t -= dt
	var info := _update_sky()
	for k in cars.size():
		visuals[k].sync(cars[k], dt, info, wet, camera.global_position, acc)
	world.set_wet(wet)
	var lamps_on := info > 0.02
	for l in world.pit_lights:
		var ol: OmniLight3D = l
		ol.visible = lamps_on                 # switched-off lights cost nothing on the GPU
		ol.light_energy = info * 2.5
	world.lamp_mat.emission_energy_multiplier = info * 6.0
	_update_camera(dt)
	_update_audio(dt)


func _update_weather(dt: float) -> void:
	if settings["weather"] == "mixed" and started:
		var f := race_time / maxf(600.0, duration_sec if laps_target == 0 else 900.0)
		rain_on = f > 0.3 and f < 0.75
	if rain_on:
		wet = minf(1.0, wet + dt / 240.0)
	else:
		wet = maxf(0.0, wet - dt / 600.0)
	for c in cars:
		c.wet = wet
	rain.emitting = rain_on
	rain.global_position = camera.global_position + Vector3(0, 10, 0)


# sun position for a mid-June day at ~50°N (local summer time, solar noon ~14:00)
func _update_sky() -> float:
	var lat := deg_to_rad(50.0)
	var dec := deg_to_rad(23.2)
	var ha := deg_to_rad((hour - 14.0) * 15.0)
	var sin_el := sin(lat) * sin(dec) + cos(lat) * cos(dec) * cos(ha)
	var el := asin(sin_el)
	var cos_az := (sin(dec) - sin(el) * sin(lat)) / maxf(1e-4, cos(el) * cos(lat))
	var az := acos(clampf(cos_az, -1.0, 1.0))
	if ha > 0.0:
		az = TAU - az
	var dir := Vector3(cos(el) * sin(az), sin(el), -cos(el) * cos(az)).normalized()
	var el_deg := rad_to_deg(el)
	var day := smoothstep(-4.0, 8.0, el_deg)
	var twilight := smoothstep(-12.0, 2.0, el_deg)
	var night := 1.0 - smoothstep(-7.0, 3.0, el_deg)
	var overcast := wet * 0.7 if rain_on else wet * 0.3
	# sun light points from the sun towards the scene
	sun.look_at_from_position(Vector3.ZERO, -dir if dir.y > -0.2 else Vector3(0.3, -1, 0.2), Vector3.UP if absf(dir.y) < 0.99 else Vector3.FORWARD)
	var warm := smoothstep(0.0, 22.0, el_deg)
	sun.light_color = Color(1.0, 0.62 + 0.38 * warm, 0.4 + 0.58 * warm)
	sun.light_energy = 1.7 * smoothstep(-2.0, 10.0, el_deg) * (1.0 - overcast * 0.75)
	sun.visible = sun.light_energy > 0.01
	var md := Vector3(-dir.x, maxf(0.35, -dir.y + 0.35), -dir.z).normalized()
	moon.look_at_from_position(Vector3.ZERO, -md, Vector3.UP)
	moon.light_energy = 0.14 * night * (1.0 - overcast)
	moon.visible = moon.light_energy > 0.005
	var top_day := Color(0.2, 0.4, 0.75).lerp(Color(0.45, 0.48, 0.52), overcast)
	var hor_day := Color(0.66, 0.76, 0.86).lerp(Color(0.6, 0.62, 0.64), overcast)
	var hor_dusk := Color(0.95, 0.55, 0.3)
	var top_night := Color(0.004, 0.007, 0.018)
	var hor_night := Color(0.02, 0.03, 0.05)
	sky_hor = hor_night.lerp(hor_dusk, twilight).lerp(hor_day, day)
	sky_mat.set_shader_parameter("top_col", top_night.lerp(Color(0.15, 0.2, 0.4), twilight).lerp(top_day, day))
	sky_mat.set_shader_parameter("hor_col", sky_hor)
	sky_mat.set_shader_parameter("gnd_col", Color(0.1, 0.12, 0.1) * (0.2 + day))
	sky_mat.set_shader_parameter("star_a", night * (1.0 - overcast))
	sky_mat.set_shader_parameter("energy", 0.3 + 0.7 * twilight)
	sky_mat.set_shader_parameter("cover", 0.32 + overcast * 0.65)
	sky_mat.set_shader_parameter("cloud_dark", clampf(overcast * 1.2, 0.0, 1.0) * (0.3 + 0.7 * day))
	sky_mat.set_shader_parameter("wind", Vector2(Time.get_ticks_msec() * 0.0000035, Time.get_ticks_msec() * 0.0000012))
	if sun.visible:
		sky_mat.set_shader_parameter("sun_col", sun.light_color)
		sky_mat.set_shader_parameter("sun_vis", (1.0 - overcast * 0.85) * clampf(sun.light_energy, 0.0, 1.0))
	else:
		sky_mat.set_shader_parameter("sun_col", Color(0.75, 0.8, 0.95))
		sky_mat.set_shader_parameter("sun_vis", 0.12 * (1.0 - overcast))
	env.fog_sun_scatter = 0.12 * day * (1.0 - overcast)
	env.ambient_light_sky_contribution = 1.0
	env.ambient_light_energy = 0.25 + 0.9 * day
	env.fog_light_color = sky_hor
	env.fog_density = 0.00025 + overcast * 0.0025 + (1.0 - day) * 0.0001
	env.tonemap_exposure = 1.0 + night * 0.6
	env.ssr_enabled = wet > 0.2 and settings["quality"] in ["high", "ultra"]
	if focus_ok():
		sun.directional_shadow_max_distance = _shadow_dist()
	return night


func focus_ok() -> bool:
	return player != null


func focus_car():
	if (state == "replay" or (finale != null and finale.mode == "watch")) and focus >= 0 and focus < cars.size():
		return cars[focus]
	return player


func focus_vis():
	if (state == "replay" or (finale != null and finale.mode == "watch")) and focus >= 0 and focus < visuals.size():
		return visuals[focus]
	return player_vis


# the chase camera stays on the car's side of barriers, catch fences and the pit wall: when the car is
# close to a wall or spins, the camera would otherwise swing behind the fence and the picture is grey
func _cam_keep_inside(p: Vector3, c) -> Vector3:
	var car_lat: float = c.lat
	T.locate(p.x, p.z, c.idx, 12)
	var i: int = T.loc_i
	var lat: float = T.loc_lat
	var right := Vector3(T.rx[i], 0, T.rz[i])
	var pit_r: bool = T.pit_open[i] == 1
	var wall_r: float = T.pit_wall_off if pit_r else T.bar_r[i]
	var wall_l: float = T.bar_l[i]
	if car_lat < wall_r and lat > wall_r - 0.6:
		p -= right * (lat - (wall_r - 0.6))
	elif car_lat > -wall_l and lat < -wall_l + 0.6:
		p += right * ((-wall_l + 0.6) - lat)
	elif pit_r and car_lat > wall_r and lat < wall_r + 0.6:
		p += right * ((wall_r + 0.6) - lat)              # car in the pit lane: stay on the lane side
	return p


# the garage block (12 m deep, ~6.5 m high behind the garage fronts) is solid: at Spa the pit exit runs
# right behind it, so a trailing camera could end up inside the buildings - pull it in towards the car
func _in_garage_block(p: Vector3) -> bool:
	var q0 := maxi(0, int(T.garage_ps[0]) - 8)
	var q1 := mini(T.lN - 1, int(T.garage_ps[T.garage_ps.size() - 1]) + 8)
	var best := -1
	var bd := 1e18
	for q in range(q0, q1 + 1, 2):
		var d := Vector2(p.x - T.lx[q], p.z - T.lz[q]).length_squared()
		if d < bd:
			bd = d
			best = q
	if best < 0 or bd > 40.0 * 40.0:
		return false
	var la: float = (p.x - T.lx[best]) * T.lrx[best] + (p.z - T.lz[best]) * T.lrz[best]
	return la > T.GARAGE_LAT - 0.4 and la < T.GARAGE_LAT + 12.6 and p.y < T.ly[best] + 7.0


# ground (or the paddock on it) between the camera and the car - e.g. where the Spa pit exit runs down in
# a cutting below the paddock: swing the camera straight behind the car, then closer, until the car is seen
func _ground_blocks(a: Vector3, b: Vector3) -> bool:
	for k in range(1, 8):
		var q := a.lerp(b, float(k) / 8.0)
		if world.terrain_height(q.x, q.z) > q.y - 0.7:
			return true
	return false


func _cam_clear_ground(p: Vector3, base: Vector3, dir: Vector3, back: float, up: float) -> Vector3:
	var aim := base + Vector3(0, 0.9, 0)
	if not _ground_blocks(p, aim):
		return p
	var k := 1.0
	while k > 0.3:
		var q := base - dir * back * k + Vector3(0, up, 0)
		q.y = maxf(q.y, world.terrain_height(q.x, q.z) + 0.8)
		if not _ground_blocks(q, aim):
			cam_pos = cam_pos.lerp(q, 0.5)
			return q
		k -= 0.15
	return base - dir * back * 0.35 + Vector3(0, up, 0)


func _cam_clear_garages(p: Vector3, base: Vector3, c) -> Vector3:
	if T.garage_ps.size() == 0 or (c.near_lane and c.plat > T.GARAGE_LAT - 1.5) or not _in_garage_block(p):
		return p
	var k := 0.9
	while k > 0.15:
		var q := base.lerp(p, k)
		q.y = maxf(q.y, base.y + 1.2)
		if not _in_garage_block(q):
			return q
		k -= 0.1
	return base.lerp(p, 0.2) + Vector3(0, 1.6, 0)


# keeps the chase camera inside the own garage (in front of the back wall, between the side walls)
func _garage_clamp(p: Vector3) -> Vector3:
	if T == null or T.lN == 0 or T.garage_ps.size() == 0:
		return p
	var q := clampi(int(T.box_ps), 0, T.lN - 1)
	var o: Vector4 = T.lane_point(T.box_ps, 0.0)
	var rgt := Vector3(T.lrx[q], 0, T.lrz[q]).normalized()
	var tng := Vector3(T.ltx[q], 0, T.ltz[q]).normalized()
	var d := p - Vector3(o.x, p.y, o.z)
	var la := d.dot(rgt)
	var al := d.dot(tng)
	if la < T.GARAGE_LAT - 0.5 or absf(al) > 9.0:
		return p
	la = minf(la, T.GARAGE_LAT + 11.0)
	al = clampf(al, -5.8, 5.8)
	var out := Vector3(o.x, p.y, o.z) + rgt * la + tng * al
	out.y = minf(p.y, o.y + 4.2)
	return out


func _update_camera(dt: float) -> void:
	var c = focus_car()
	if cam_mode == 2 and c != player:
		cam_mode = 0
	var base := Vector3(c.x, c.y, c.z)
	var fwd := Vector3(cos(c.psi), 0, sin(c.psi))
	var wv: Vector2 = c.world_vel()
	var vel := Vector3(wv.x, 0, wv.y)
	var spd := vel.length()
	var dir := fwd.lerp(vel.normalized(), 0.35).normalized() if spd > 3.0 else fwd
	shake = maxf(shake * exp(-dt * 6.0), (0.025 if c.surface == "curb" else 0.0) + (0.05 * minf(1.0, spd / 20.0) if c.surface in ["grass", "gravel"] else 0.0) + c.impact * 0.3)
	var in_cockpit := cam_mode == 2
	cockpit.set_active(in_cockpit)
	var fov: float = settings["fov"]
	if cam_mode == 0 or cam_mode == 1:
		var back := 8.2 if cam_mode == 0 else 5.6
		var up := 2.7 if cam_mode == 0 else 1.75
		var target := base - dir * back + Vector3(0, up, 0)
		target.y = maxf(target.y, world.terrain_height(target.x, target.z) + 0.8)
		target.y = maxf(target.y, c.y + 0.8)
		var fresh := not cam_init
		if not cam_init:
			cam_pos = target
			cam_init = true
		cam_pos = cam_pos.lerp(target, 1.0 - exp(-dt * (7.0 if cam_mode == 0 else 10.0)))
		var off := cam_pos - base
		off.y = 0.0
		if off.length() > 0.1:
			off = off.normalized() * back
			cam_pos.x = base.x + off.x
			cam_pos.z = base.z + off.z
		var fp := _cam_clear_garages(_garage_clamp(_cam_keep_inside(cam_pos, c)), base, c)
		fp = _cam_clear_ground(fp, base, dir, back, up)
		# the corrections (walls, garages, the cutting at the pit exit) switch on and off from one frame to
		# the next: blend them in and out so the picture never jumps (pit exits, garages)
		var corr := fp - cam_pos
		if fresh:
			cam_corr = corr
		cam_corr = cam_corr.lerp(corr, 1.0 - exp(-dt * 4.0))
		fp = cam_pos + cam_corr
		# never inside the ground: on steep descents (pit exit at Spa) the trailing camera would sink into the hillside
		var gy: float = world.terrain_height(fp.x, fp.z) + 0.8
		if fp.y < gy:
			fp.y = gy
			cam_pos.y = gy
		camera.global_position = fp
		camera.look_at(base + fwd * 4.0 + Vector3(0, 1.0 if cam_mode == 0 else 0.9, 0), Vector3.UP)
		camera.fov = fov - 8.0 + minf(14.0, spd * 0.12)
	elif cam_mode == 2:
		cockpit.update(dt, camera)
		camera.fov = fov
	elif cam_mode == 5:
		# passenger seat of the watched car (after the finish): look around with the mouse
		var vis = focus_vis()
		var eye: Vector3 = vis.passenger_eye()
		var t5: Transform3D = vis.chassis.global_transform
		camera.global_transform = Transform3D(t5.basis * Basis(Vector3.UP, -PI / 2) * Basis(Vector3.UP, cockpit.look_yaw) * Basis(Vector3.RIGHT, cockpit.look_pitch), t5 * eye)
		camera.fov = fov + 6.0
	elif drift_show != null and not show_seats.is_empty():
		_show_camera(dt, c)
	elif cam_mode == 6 and finale.seat_i >= 0 and finale.seat_i < world.seats.size():
		# grandstand seat: the eyes follow the watched car while it is in view, otherwise the nearest car
		# the stand can see; with nothing in view they rest on the track in front of the stand
		var seat: Dictionary = world.seats[finale.seat_i]
		var eye: Vector3 = seat["pos"]
		var look: Vector3 = seat["look"]
		var bestd := 420.0
		var cands6: Array = [c] if c != null and not c.spectator else []
		for o in cars:
			if o != c and not o.spectator and not o.in_pit:
				cands6.append(o)
		if drift_show != null and c != null and not c.spectator:
			cands6 = []
			look = Vector3(c.x, c.y + 0.8, c.z)       # drift show: always on the watched car
		for o in cands6:
			var op := Vector3(o.x, o.y + 0.8, o.z)
			var d6: float = op.distance_to(eye)
			if d6 < bestd and world.line_clear(eye, op):
				bestd = d6
				look = op
				if o == c:
					break
		if not cam_init:
			seat_look = look
			cam_init = true
		seat_look = seat_look.lerp(look, 1.0 - exp(-dt * 4.0))
		camera.global_position = eye
		camera.look_at(seat_look, Vector3.UP)
		var fd: float = eye.distance_to(seat_look)
		camera.fov = clampf(2200.0 / maxf(20.0, fd), 16.0, 62.0) if drift_show == null else clampf(1250.0 / maxf(15.0, fd), 11.0, 48.0)
	elif cam_mode == 3:
		var t: Transform3D = focus_vis().chassis.global_transform
		camera.global_transform = Transform3D(t.basis * Basis(Vector3.UP, -PI / 2), t * Vector3(1.6, 1.0, 0.0))
		camera.fov = fov
	else:
		_tv_camera(dt, c, base, fwd, vel)
	# the own driver is hidden in the driver's view (the camera sits in his helmet), visible as passenger
	if player_vis.driver_fig != null:
		player_vis.set_driver_view(in_cockpit and passenger_ai == null, bool(settings.get("driver_hands", true)))
	if shake > 0.001 and cam_mode != 2:
		camera.global_position += Vector3(randf() - 0.5, randf() - 0.5, 0) * shake


# TV view like a real broadcast: a trackside camera holds the car while it comes and goes (no cutting
# every two seconds), it follows smoothly with a little lead so the corner ahead is in the picture, and
# now and then the helicopter shows a long stretch of the track from above
func _tv_camera(dt: float, c, base: Vector3, fwd: Vector3, vel: Vector3) -> void:
	var tgt := base + Vector3(0, 0.8, 0)
	var spd := vel.length()
	var fresh: bool = not cam_init or tv_car != c
	if fresh:
		cam_init = true
		tv_car = c
		tv_kind = "cam"
		tv_cur = Vector3.ZERO
		tv_t = 99.0
		tv_aim = tgt
	tv_t += dt
	if tv_kind == "heli":
		var side := Vector3(-fwd.z, 0, fwd.x) * tv_side
		var want := base - fwd * 30.0 + side * 26.0
		want.y = maxf(world.terrain_height(want.x, want.z), base.y) + 28.0
		if tv_heli == Vector3.ZERO or fresh:
			tv_heli = want
		tv_heli = tv_heli.lerp(want, 1.0 - exp(-dt * 1.2))
		tv_aim = tv_aim.lerp(tgt + fwd * minf(40.0, spd * 0.6), 1.0 - exp(-dt * 3.0))
		camera.global_position = tv_heli
		camera.look_at(tv_aim, Vector3.UP)
		tv_fov = lerpf(tv_fov, 42.0, 1.0 - exp(-dt * 2.0))
		camera.fov = tv_fov
		if tv_t > 9.0:
			tv_kind = "cam"
			tv_cur = Vector3.ZERO
			tv_t = 99.0
			tv_cams = 0
		return
	# trackside camera: keep it while it sees the car and the car is still near or coming closer
	var keep := false
	if tv_cur != Vector3.ZERO:
		var d := tv_cur.distance_to(base)
		var away: bool = vel.dot(base - tv_cur) > 0.0
		if world.line_clear(tv_cur, tgt):
			tv_blind = 0.0
		else:
			tv_blind += dt
		keep = tv_blind < 0.5 and d < 300.0 and (tv_t < 5.0 or not away or d < 140.0)
	if not keep:
		if tv_cams >= 3 and spd > 15.0:
			# after a few trackside shots: the helicopter
			tv_kind = "heli"
			tv_t = 0.0
			tv_side = -tv_side
			tv_heli = Vector3.ZERO
			_tv_camera(dt, c, base, fwd, vel)
			return
		# the next camera: one the car is driving towards (it comes into the picture), seeing it now
		var best := Vector3.ZERO
		var best_score := -1e9
		for sp in tv_spots:
			var spv: Vector3 = sp
			var dd: float = spv.distance_to(base)
			if dd > 260.0 or dd < 12.0:
				continue
			var ahead: float = vel.normalized().dot((spv - base).normalized()) if spd > 1.0 else 0.0
			var score: float = ahead * 120.0 - dd * 0.3
			if score > best_score and world.line_clear(spv, tgt):
				best_score = score
				best = spv
		if best == Vector3.ZERO:
			# no trackside camera sees it: the helicopter
			tv_kind = "heli"
			tv_t = 0.0
			tv_heli = Vector3.ZERO
			_tv_camera(dt, c, base, fwd, vel)
			return
		var cut := best != tv_cur
		tv_cur = best
		tv_t = 0.0
		tv_blind = 0.0
		tv_cams += 1
		if cut:
			tv_aim = tgt + fwd * minf(25.0, spd * 0.35)
			tv_fov = clampf(2400.0 / maxf(10.0, best.distance_to(base)), 14.0, 58.0)
	# smooth panning with a little lead; the zoom keeps the car a similar size, but never jumps
	var dist := tv_cur.distance_to(base)
	tv_aim = tv_aim.lerp(tgt + fwd * minf(25.0, spd * 0.35), 1.0 - exp(-dt * 5.0))
	tv_fov = lerpf(tv_fov, clampf(2400.0 / maxf(10.0, dist), 14.0, 58.0), 1.0 - exp(-dt * 1.8))
	camera.global_position = tv_cur
	camera.look_at(tv_aim, Vector3.UP)
	camera.fov = tv_fov


func _menu_camera(dt: float) -> void:
	if T == null:
		return
	menu_t += dt
	var p: Vector4 = T.point_at(80.0 + menu_t * 6.0, 0.0)
	camera.global_position = Vector3(p.x + cos(menu_t * 0.1) * 30.0, p.y + 9.0, p.z + sin(menu_t * 0.1) * 30.0)
	camera.look_at(Vector3(p.x, p.y + 1.0, p.z), Vector3.UP)
	camera.fov = 50.0
	hour = settings["start_hour"]
	_update_sky()


func _update_audio(dt: float) -> void:
	if drift_show != null:
		# the drift show: the watched car as the main sound (fading with the distance), the others around
		var fc = focus_car()
		audio.update(fc, cars, camera, 4 if cam_mode != 5 else 5, dt)
		return
	audio.update(player, cars, camera, cam_mode, dt)


func _grid_key(g: Dictionary) -> String:
	return "player" if g.get("player", false) else String(g["cls"]) + ":" + String(g["team"][0])


# ---------------------------------------------------------------- qualifying
func _quali_tick() -> void:
	if not _timed() or chequered:
		return
	if race_time >= quali_len:
		chequered = true
		show_msg("🏁 Zeit abgelaufen – letzte Runde zu Ende fahren", 4.0)
		if player.in_pit or player.lap_start < 0.0:
			_finish()


func _end_session() -> void:
	paused = false
	audio.muted = sound_off
	overlay.visible = false
	_finish()


func _show_quali_results() -> void:
	var sorted := cars.duplicate()
	sorted.sort_custom(func(a, b): return _qkey(a) < _qkey(b))
	if session == "quali":
		quali_order.clear()
		for c in sorted:
			quali_order.append(c.get_meta("grid_key"))
	var nm := "TRAINING" if session == "practice" else "QUALIFYING"
	var btns: Array = []
	if not session_queue.is_empty():
		var nxt: String = session_queue[0]
		btns.append(["WEITER: " + {"quali": "QUALIFYING", "race": "RENNEN", "practice": "TRAINING"}.get(nxt, "RENNEN"), _next_session])
	btns.append([nm + " NOCHMAL", _restart])
	btns.append(["HAUPTMENÜ", _to_menu])
	var sub := "%s   ·   Platz %d   ·   Beste Runde %s" % [String(T.def["name"]), sorted.find(player) + 1, Hud.fmt(player.best)]
	hud.visible = false
	_show_overlay("ERGEBNIS · " + nm, btns, _results_table(sorted, true), sub)


func _qkey(c) -> float:
	return c.best if c.best > 0.0 else 1e9 - c.lap


func _next_session() -> void:
	if session_queue.is_empty():
		_to_menu()
		return
	session = session_queue.pop_front()
	paused = false
	audio.muted = sound_off
	_start_race()


# the player's grid entry from the logged-in profile
# which GT3 an AI team races (a mixed field: every third team in a BMW)
func ai_model(k: int) -> String:
	return "bmw" if k % 3 == 1 else "amg"


func my_entry() -> Dictionary:
	var liv: Array = Menu.LIVERIES[int(settings["livery"]) % Menu.LIVERIES.size()]
	var p: Dictionary = Profile.current
	var team := String(p.get("team", "Team Traindorf"))
	var c1: Color = p.get("c1", liv[1])
	var c2: Color = p.get("c2", liv[2])
	return {"cls": settings["cls"], "team": [team, c1, c2, liv[3], int(p.get("number", 24))], "player": true, "driver": String(p.get("name", "Du")),
		"model": String(settings.get("gt3_model", "amg"))}


var last_record := {}


# statistics for the profile, once per session
func _record_session() -> void:
	if recorded or player == null or player.spectator:
		return
	recorded = true
	var sorted := cars.duplicate()
	if _timed():
		sorted.sort_custom(func(a, b): return _qkey(a) < _qkey(b))
	else:
		sorted.sort_custom(func(a, b): return progress(a) > progress(b))
	var cls_list: Array = []
	for c in sorted:
		if c.spec["key"] == player.spec["key"]:
			cls_list.append(c)
	var fastest := 1e9
	for c in cars:
		if c.best > 0.0:
			fastest = minf(fastest, c.best)
	var inc: int = tl_strikes + int(penalty / 5.0) + (1 if player.total_damage() > 0.3 else 0)
	last_record = Profile.record({
		"session": session, "track": settings["track"], "track_name": String(T.def["name"]), "cls": player.spec["key"],
		"pos": sorted.find(player) + 1, "cls_pos": cls_list.find(player) + 1, "field": sorted.size(), "cls_field": cls_list.size(),
		"best": player.best, "laps": maxi(0, player.lap), "km": maxi(0, player.lap) * T.length / 1000.0,
		"fastest": player.best > 0.0 and absf(player.best - fastest) < 0.0005, "pole": cls_list.find(player) == 0 and player.best > 0.0,
		"incidents": inc, "finished": not player.retired, "time": race_time, "ai": settings["ai_diff"], "online": is_online(),
	})
	if event_id != "" and session == "race":
		var cp: int = cls_list.find(player) + 1
		var pts: int = Events.points_for(cp, not player.retired)
		Profile.record_event(event_id, cp, not player.retired, pts)
		last_record["event_pts"] = pts
		show_msg("EVENT: +%d Punkte · Gesamt %d" % [pts, int(Profile.current["stats"].get("ev_points", 0))], 5.0, Color(1.0, 0.8, 0.1))
		event_id = ""


func _track_limits(c) -> void:
	if not settings["quali_limits"]:
		return
	# lenient: only clearly beyond the white line counts (a wheel or two over the kerb is fine)
	var limit: float = T.half_w + c.spec["wid"] * 0.5 + 1.3
	var off: bool = absf(c.lat) > limit and not c.in_pit
	if _timed() and off and not c.lap_invalid and c.lap_start >= 0.0:
		c.lap_invalid = true
		if c.is_player:
			show_msg("TRACK LIMITS – Rundenzeit gestrichen", 2.8, Color(1.0, 0.3, 0.25))
	if not c.is_player or _timed() or not started:
		return
	if tl_off and c.in_pit:
		tl_via_pit = true
	if off and not tl_off:
		tl_off = true
		tl_t0 = race_time
		tl_i0 = c.idx
		tl_via_pit = false
	elif tl_off and absf(c.lat) < T.half_w + 0.6:
		tl_off = false
		if tl_via_pit or c.retired:
			return
		var used: float = race_time - tl_t0
		var ref: float = _ref_time_between(c, tl_i0, c.idx)
		if ref < 0.0 or ref > 60.0:
			return
		var gain: float = ref - used
		if gain > 2.0:
			penalty += 5.0
			tl_strikes = 0
			show_msg("STRAFE +5 s  ·  Abkürzung (%.1f s Vorteil)" % gain, 3.5, Color(1.0, 0.25, 0.2))
			audio.beep(330.0, 0.5)
		elif gain > 0.5:
			tl_strikes += 1
			if tl_strikes >= 5:
				tl_strikes = 0
				penalty += 5.0
				show_msg("STRAFE +5 s  ·  5x Track Limits", 3.5, Color(1.0, 0.25, 0.2))
				audio.beep(330.0, 0.5)
			else:
				show_msg("TRACK LIMITS  ·  Verwarnung %d/5  (+%.2f s Vorteil)" % [tl_strikes, gain], 2.8, Color(1.0, 0.65, 0.1))
				audio.beep(520.0, 0.2)
		else:
			show_msg("Abseits der Strecke  ·  kein Zeitvorteil", 1.6, Color(0.85, 0.85, 0.85))


# reference time between two track samples: own best lap if recorded, else a clean model lap
func _ref_time_between(c, i0: int, i1: int) -> float:
	var bt: PackedFloat32Array = c.best_trace
	if bt.size() == T.N and c.best > 0.0 and bt[i0] >= 0.0 and bt[i1] >= 0.0:
		var d: float = bt[i1] - bt[i0]
		if d < -1.0:
			d += c.best
		return d
	if tl_ref.size() != T.N:
		var vp: PackedFloat32Array = T.speed_profile(c.spec)
		tl_ref.resize(T.N)
		var acc := 0.0
		for i in T.N:
			tl_ref[i] = acc
			acc += T.ds / maxf(8.0, vp[i] * 0.94)
	var d2: float = tl_ref[i1] - tl_ref[i0]
	if d2 < -1.0:
		d2 += tl_ref[T.N - 1] + T.ds / 30.0
	return d2


# ================================================================ replays
func start_replay(from: String) -> void:
	if not replay.has_data():
		show_msg("Noch kein Replay aufgenommen", 2.0)
		return
	replay_from = from
	if from == "pause":
		replay_snap.clear()
		for c in cars:
			replay_snap.append([c.x, c.y, c.z, c.psi, c.u, c.v, c.steer, c.pitch, c.roll, c.heave, c.brake, c.rpm, c.gear, c.r, c.lost.duplicate(),
				c.grade_pitch, c.slip_r, c.wheel_spin, c.load_var, c.road_now, c.surface, c.flash, c.spin_r, c.lock_f, c.lock_r, c.hold])
		paused = false
	overlay.visible = false
	menu.visible = false
	hud.visible = true
	pit_menu_open = false
	# the replay starts with clean cars: dents and flying parts come at the moment they happened
	for d in debris:
		var dn: Node3D = d["node"]
		dn.visible = false
	replay_bodies.clear()
	for v in visuals:
		replay_bodies.append(v.body_state())
		v.set_body_state(v.base_verts)
	replay_ev = 0
	replay_last_t = -100.0
	state = "replay"
	replay_t = maxf(0.0, replay.length() - 90.0) if from == "pause" else 0.0
	replay_end = -1.0
	replay_play = true
	replay_speed = 1.0
	focus = maxi(0, cars.find(player))
	cam_mode = 0
	cam_init = false
	audio.muted = sound_off
	if cockpit:
		cockpit.set_active(false)


func stop_replay() -> void:
	for d in replay_debris:
		var rn: Node3D = d["node"]
		rn.queue_free()
	replay_debris.clear()
	for d in debris:
		var dn: Node3D = d["node"]
		dn.visible = true
	for k in mini(visuals.size(), replay_bodies.size()):
		visuals[k].set_body_state(replay_bodies[k])
	replay_bodies.clear()
	match replay_from:
		"results":
			state = "results"
			for k in visuals.size():
				visuals[k].show_lost(cars[k].lost)
			_show_results()
		"pause":
			for k in mini(cars.size(), replay_snap.size()):
				var c = cars[k]
				var sn: Array = replay_snap[k]
				c.x = sn[0]
				c.y = sn[1]
				c.z = sn[2]
				c.psi = sn[3]
				c.u = sn[4]
				c.v = sn[5]
				c.steer = sn[6]
				c.pitch = sn[7]
				c.roll = sn[8]
				c.heave = sn[9]
				c.brake = sn[10]
				c.rpm = sn[11]
				c.gear = sn[12]
				c.r = sn[13]
				c.lost = sn[14]
				c.grade_pitch = sn[15]
				c.slip_r = sn[16]
				c.wheel_spin = sn[17]
				c.load_var = sn[18]
				c.road_now = sn[19]
				c.surface = sn[20]
				c.flash = sn[21]
				c.spin_r = sn[22]
				c.lock_f = sn[23]
				c.lock_r = sn[24]
				c.hold = sn[25]
				visuals[k].show_lost(c.lost)
			state = "race"
			cam_init = false
			_toggle_pause()
		"movie":
			get_tree().quit()
		_:
			_to_menu()


# cars for a replay loaded from a file (no physics, no AI)
func _spawn_replay_cars() -> void:
	_sync_liveries()
	_clear_race()
	for k in replay.grid.size():
		var g: Dictionary = replay.grid[k]
		var key: String = g["cls"]
		var model := String(g.get("model", "amg")) if key == "gt3" else ""
		var c = CarPhysics.new(CarPhysics.spec_for(key, model), T, CarPhysics.default_setup(key))
		c.place(-14.0 - k * 9.0, 3.2 if k % 2 else -3.2)
		c.name = String(g["name"])
		c.num = int(g.get("num", k + 1))
		c.is_player = bool(g["player"])
		var team: Array = g["team"]
		if team.size() < 5:
			team = ["", Color(0.8, 0.1, 0.1), Color.WHITE, Color.BLACK, c.num]
		c.set_meta("team", team)
		var v = CarVisual.new()
		add_child(v)
		v.setup(key, [team[1], team[2], team[3]], team[4], settings["quality"], c.is_player, model)
		_seat_driver(c, v, team)
		cars.append(c)
		visuals.append(v)
		drivers.append(null)
		if c.is_player:
			player = c
			player_vis = v
	if player == null and cars.size() > 0:
		player = cars[0]
		player_vis = visuals[0]
	cockpit = Cockpit.new()
	cockpit.build(player, player_vis, self)
	hud.prepare_minimap()
	order = cars.duplicate()
	started = true


func play_replay_file(path: String) -> void:
	if not replay.load_file(path):
		OS.alert("Die Replay-Datei konnte nicht gelesen werden.", "Trois Forêts 24")
		return
	replay_file = path
	if built_track != replay.track:
		settings["track"] = replay.track
		await _build_world()
	_spawn_replay_cars()
	start_replay("menu")


func _replay_process(dt: float) -> void:
	_video_watch()
	if replay_play:
		replay_t = clampf(replay_t + dt * replay_speed, 0.0, replay.length())
	if replay_end > 0.0 and replay_t >= replay_end - 0.01:
		get_tree().quit()
		return
	var hw: Vector2 = replay.apply(cars, replay_t)
	hour = hw.x
	wet = hw.y
	if replay.nf < replay.NF:
		# old replay files: the slope comes from the track
		for c in cars:
			var nd: Vector2 = world.nearest(c.x, c.z)
			var ix := int(nd.x)
			c.grade_pitch = atan(T.grade[ix] * cos(c.psi - T.head[ix]))
	# a jump (skip, rewind, start) catches up silently; normal playback shows dents, sparks and flying parts
	var jump := replay_t < replay_last_t - 0.001 or replay_t - replay_last_t > 1.0
	replay_last_t = replay_t
	if jump:
		for d in replay_debris:
			var rn: Node3D = d["node"]
			rn.queue_free()
		replay_debris.clear()
	_replay_damage(replay_t, jump)
	if replay_from == "movie":
		# automatic director: mostly the player's car, TV cameras and chase cam alternate
		replay_dir_t -= dt
		if replay_dir_t <= 0.0:
			replay_dir_t = randf_range(11.0, 16.0)
			cam_mode = [4, 0, 4, 4, 1][randi() % 5]
			focus = maxi(0, cars.find(player)) if randf() < 0.75 else randi() % cars.size()
			cam_init = false
	order_t -= dt
	if order_t <= 0.0:
		order_t = 0.5
		order = cars.duplicate()
	msg_t -= dt
	var info := _update_sky()
	var rdt := dt * replay_speed if replay_play else 0.0
	for k in cars.size():
		if not jump:
			for node in visuals[k].update_lost(cars[k].lost):
				replay_debris.append(_spawn_debris(node, cars[k]))
		visuals[k].show_lost(cars[k].lost)
		visuals[k].sync(cars[k], rdt, info, wet, camera.global_position, 0.0)
	replay_debris = _move_debris(replay_debris, rdt)
	world.set_wet(wet)
	world.lamp_mat.emission_energy_multiplier = info * 6.0
	_update_camera(dt)
	_update_audio(dt)


# body dents of the replay up to time t (rewinding starts again from clean cars)
func _replay_damage(t: float, silent: bool) -> void:
	var fr: float = t / replay.DT
	if replay_ev > 0 and replay_ev <= replay.event_count() and replay.event(replay_ev - 1)[0] > fr + 0.001:
		for v in visuals:
			v.set_body_state(v.base_verts)
		replay_ev = 0
		silent = true
	var dirty := {}
	while replay_ev < replay.event_count():
		var e: Array = replay.event(replay_ev)
		if e[0] > fr:
			break
		replay_ev += 1
		var k: int = e[1]
		if k < 0 or k >= visuals.size():
			continue
		if e[2] < 0.0:
			visuals[k].set_body_state(visuals[k].base_verts)
			dirty.erase(k)
		else:
			visuals[k].apply_hit("", e[2], e[3], not silent)
			if silent:
				dirty[k] = true
	for k in dirty:
		visuals[k].rebuild_body()


func _replay_input(ev: InputEvent) -> void:
	if not (ev is InputEventKey) or not ev.pressed or ev.echo:
		return
	var kc: int = ev.physical_keycode
	match kc:
		KEY_ESCAPE, KEY_BACKSPACE:
			stop_replay()
		KEY_SPACE, KEY_P:
			replay_play = not replay_play
		KEY_LEFT, KEY_A:
			replay_t = maxf(0.0, replay_t - 10.0)
			cam_init = false
		KEY_RIGHT, KEY_D:
			replay_t = minf(replay.length(), replay_t + 10.0)
			cam_init = false
		KEY_UP, KEY_W:
			replay_speed = minf(4.0, replay_speed * 2.0)
		KEY_DOWN, KEY_S:
			replay_speed = maxf(0.125, replay_speed * 0.5)
		KEY_HOME:
			replay_t = 0.0
		KEY_C:
			cam_mode = (cam_mode + 1) % 5
			if cam_mode == 2 and focus_car() != player:
				cam_mode = 3
			cam_init = false
		KEY_N, KEY_PAGEDOWN:
			focus = (focus + 1) % cars.size()
			cam_init = false
		KEY_B, KEY_PAGEUP:
			focus = posmod(focus - 1, cars.size())
			cam_init = false
		KEY_F5, KEY_K:
			_replay_save()
		KEY_V:
			_replay_video()
		KEY_E:
			_replay_mail_dialog()
		KEY_M:
			sound_off = not sound_off
			audio.muted = sound_off


func _replay_save() -> String:
	var path: String = replay.save_file()
	if path == "":
		show_msg("Speichern fehlgeschlagen", 2.5, Color(1.0, 0.3, 0.25))
		return ""
	replay_file = path
	show_msg("Replay gespeichert: Downloads/TF24 Replays/" + path.get_file(), 3.5, Color(0.3, 1.0, 0.4))
	return path


# the game starts itself a second time in Godot's movie mode and records the replay from the current
# position (up to 5 minutes) as a video file next to the replay file
func _replay_video() -> void:
	var src := replay_file if replay_file != "" and FileAccess.file_exists(replay_file) else _replay_save()
	if src == "":
		return
	var out := src.get_basename() + "_%d.avi" % int(replay_t)
	var args := PackedStringArray()
	if OS.has_feature("editor"):
		args.append_array(["--path", ProjectSettings.globalize_path("res://")])
	args.append_array(["--write-movie", out, "--fixed-fps", "30", "--resolution", "1280x720", "--",
		"--tf24-replay=" + src, "--tf24-from=%.2f" % replay_t, "--tf24-len=120"])
	var pid := OS.create_process(OS.get_executable_path(), args)
	if pid <= 0:
		show_msg("Video konnte nicht gestartet werden", 3.0, Color(1.0, 0.3, 0.25))
		return
	replay_play = false
	video_pid = pid
	video_avi = out
	show_msg("Video wird aufgenommen (zweites Fenster, max. 2 Min.) → " + out.get_file(), 5.0, Color(0.3, 0.6, 1.0))
	replay.info["video"] = out


func _ffmpeg_path() -> String:
	for p in ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/usr/bin/ffmpeg", OS.get_user_data_dir().path_join("tools/ffmpeg")]:
		if FileAccess.file_exists(p):
			return p
	return ""


# after the movie export: convert the big AVI into a small MP4 (plays on iPhone, QuickTime, in mails)
func _video_watch() -> void:
	if video_pid > 0 and not OS.is_process_running(video_pid):
		video_pid = -1
		var ff := _ffmpeg_path()
		if ff != "" and FileAccess.file_exists(video_avi):
			var mp4 := video_avi.get_basename() + ".mp4"
			video_conv_pid = OS.create_process(ff, PackedStringArray(["-y", "-loglevel", "error", "-i", video_avi, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
				"-pix_fmt", "yuv420p", "-vf", "scale=1280:-2", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", mp4]))
			replay.info["video"] = mp4
			show_msg("Video fertig – wird in MP4 umgewandelt …", 3.0, Color(0.3, 0.6, 1.0))
		else:
			show_msg("Video fertig: " + video_avi.get_file() + " (Downloads/TF24 Replays)", 4.0, Color(0.3, 1.0, 0.4))
	if video_conv_pid > 0 and not OS.is_process_running(video_conv_pid):
		video_conv_pid = -1
		show_msg("MP4-Video fertig: " + String(replay.info.get("video", "")).get_file(), 4.0, Color(0.3, 1.0, 0.4))


func _replay_mail_dialog() -> void:
	replay_play = false
	var src := replay_file if replay_file != "" and FileAccess.file_exists(replay_file) else _replay_save()
	if src == "":
		return
	var video: String = replay.info.get("video", "")
	var file := video if video != "" and FileAccess.file_exists(video) else src
	for ch in overlay.get_children():
		ch.queue_free()
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.6)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(bg)
	var pc := Ui.panel(Color(0.04, 0.05, 0.09, 0.97), 12, Color(1, 1, 1, 0.2), 1)
	pc.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	pc.offset_left = -380
	pc.offset_right = 380
	pc.offset_top = -190
	pc.offset_bottom = 190
	overlay.add_child(pc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	pc.add_child(v)
	v.add_child(Ui.label("REPLAY PER E-MAIL", "head", 40))
	var info := Ui.label("Datei: " + file.get_file() + "\nDie Mail öffnet sich fertig ausgefüllt. Zieh die Datei aus dem Ordner (öffnet sich daneben) in die Mail – große Videos verschickt Apple Mail automatisch per Mail Drop.", "body", 16, Ui.MUTED)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(700, 0)
	v.add_child(info)
	var le := LineEdit.new()
	le.placeholder_text = "deine@email.de"
	le.text = String(settings.get("email", ""))
	le.custom_minimum_size = Vector2(700, 46)
	le.add_theme_font_size_override("font_size", 20)
	v.add_child(le)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	v.add_child(hb)
	var send := Ui.primary("E-MAIL ÖFFNEN", 20)
	var _lfm := func():
		settings["email"] = le.text.strip_edges()
		menu.save_settings()
		var subj := "Trois Forêts 24 – Replay " + String(replay.info.get("date", ""))
		var body := "Mein Replay aus Trois Forêts 24 (%s).\n%s\n\nDatei: %s" % [String(T.def["name"]), String(replay.info.get("result", "")), file.get_file()]
		OS.shell_open("mailto:%s?subject=%s&body=%s" % [settings["email"].uri_encode(), subj.uri_encode(), body.uri_encode()])
		OS.shell_show_in_file_manager(file)
		overlay.visible = false
	send.pressed.connect(_lfm)
	hb.add_child(send)
	var folder := Ui.outline("ORDNER ÖFFNEN", 18)
	folder.pressed.connect(func(): OS.shell_show_in_file_manager(file))
	hb.add_child(folder)
	var close := Ui.outline("SCHLIESSEN", 18)
	close.pressed.connect(func(): overlay.visible = false)
	hb.add_child(close)
	overlay.visible = true
	le.grab_focus()


# ================================================================ track viewer (fly over the whole track)
func start_viewer() -> void:
	if T == null:
		return
	state = "viewer"
	menu.visible = false
	hud.visible = true
	var p: Vector4 = T.point_at(0.0, 0.0)
	view_pos = Vector3(p.x, p.y + 60.0, p.z)
	view_yaw = PI / 2.0 - p.w
	view_pitch = -0.6
	view_tour = false
	view_speed = 40.0
	hud.prepare_minimap()


func _viewer_process(dt: float) -> void:
	if view_tour:
		# guided flight along the track at 45 m height, looking ahead
		view_tour_s = fposmod(view_tour_s + dt * 38.0, T.length)
		var p: Vector4 = T.point_at(view_tour_s, 0.0)
		var q: Vector4 = T.point_at(view_tour_s + 120.0, 0.0)
		var target := Vector3(p.x, p.y + 45.0, p.z) - Vector3(q.x - p.x, 0, q.z - p.z).normalized() * 40.0
		view_pos = view_pos.lerp(target, 1.0 - exp(-dt * 2.0))
		camera.global_position = view_pos
		camera.look_at(Vector3(q.x, q.y, q.z), Vector3.UP)
	else:
		var fwd := Vector3(cos(view_pitch) * sin(view_yaw), sin(view_pitch), cos(view_pitch) * cos(view_yaw))
		var right := Vector3(cos(view_yaw), 0, -sin(view_yaw))
		var mv := Vector3.ZERO
		if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
			mv += fwd
		if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
			mv -= fwd
		if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
			mv -= right
		if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
			mv += right
		if Input.is_physical_key_pressed(KEY_E) or Input.is_physical_key_pressed(KEY_SPACE):
			mv += Vector3.UP
		if Input.is_physical_key_pressed(KEY_Q) or Input.is_physical_key_pressed(KEY_CTRL):
			mv -= Vector3.UP
		var sp := view_speed * (4.0 if Input.is_physical_key_pressed(KEY_SHIFT) else 1.0)
		view_pos += mv.normalized() * sp * dt if mv.length() > 0.01 else Vector3.ZERO
		view_pos.y = maxf(view_pos.y, world.terrain_height(view_pos.x, view_pos.z) + 1.5)
		view_pos.y = minf(view_pos.y, 1500.0)
		camera.global_position = view_pos
		camera.look_at(view_pos + fwd, Vector3.UP)
	camera.fov = 60.0
	hour = settings["start_hour"]
	_update_sky()
	msg_t -= dt


func _viewer_input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton:
		if ev.button_index == MOUSE_BUTTON_LEFT or ev.button_index == MOUSE_BUTTON_RIGHT:
			view_drag = ev.pressed
		elif ev.pressed and ev.button_index == MOUSE_BUTTON_WHEEL_UP:
			view_speed = minf(400.0, view_speed * 1.25)
		elif ev.pressed and ev.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			view_speed = maxf(5.0, view_speed / 1.25)
	elif ev is InputEventMouseMotion and view_drag:
		view_yaw -= ev.relative.x * 0.004
		view_pitch = clampf(view_pitch - ev.relative.y * 0.004, -1.5, 1.4)
		view_tour = false
	elif ev is InputEventKey and ev.pressed and not ev.echo:
		match ev.physical_keycode:
			KEY_ESCAPE, KEY_BACKSPACE:
				state = "menu"
				hud.visible = false
				menu.visible = true
				menu.go("home", false)
			KEY_F, KEY_T:
				view_tour = not view_tour
				if view_tour:
					T.locate_global(view_pos.x, view_pos.z)
					view_tour_s = T.loc_s
			KEY_H:
				# jump high above the track centre for the full overview
				view_tour = false
				var c := Vector3.ZERO
				for k in 16:
					var p: Vector4 = T.point_at(T.length * k / 16.0, 0.0)
					c += Vector3(p.x, p.y, p.z) / 16.0
				view_pos = c + Vector3(0, 1100.0, 900.0)
				view_yaw = PI
				view_pitch = -0.9

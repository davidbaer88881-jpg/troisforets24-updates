# Crash report: while the game runs, a small marker file exists (with what the game was doing). A clean
# exit removes it. If it is still there at the next start, the last session ended with a crash: the end
# of that session's log (Godot keeps the logs of the last sessions) is written as a text file into the
# Downloads folder, so it can be sent to whoever fixes the game.
extends Node

const FLAG := "user://running.flag"
const TRACE := "user://trace.log"
const TRACE_PREV := "user://trace_prev.log"
const Updater = preload("res://scripts/updater.gd")

var game
var report_path := ""          # set when the last session crashed and a report was written
var _t := 0.0


var _trace: FileAccess


func _ready() -> void:
	# the last session's step-by-step trace (written line by line, so it survives a crash)
	if FileAccess.file_exists(TRACE):
		DirAccess.rename_absolute(ProjectSettings.globalize_path(TRACE), ProjectSettings.globalize_path(TRACE_PREV))
	_trace = FileAccess.open(TRACE, FileAccess.WRITE)
	if FileAccess.file_exists(FLAG):
		report_path = _write_report(FileAccess.get_file_as_string(FLAG))
	_mark("start")
	trace("Start, Version %d" % Updater.installed_number())


# one line of what the game is doing (menu pages, online steps, race start); flushed at once
func trace(msg: String) -> void:
	if _trace == null:
		return
	_trace.store_line("%s  %s" % [Time.get_time_string_from_system(), msg])
	_trace.flush()


func _process(dt: float) -> void:
	_t -= dt
	if _t <= 0.0:
		_t = 10.0
		_mark("")


# what the game is doing right now (part of a report should it crash)
func _mark(_why: String) -> void:
	var f := FileAccess.open(FLAG, FileAccess.WRITE)
	if f == null:
		return
	var st := "-"
	var onl := false
	if game != null:
		st = String(game.state)
		onl = game.net != null and game.net.online
	f.store_string("version=%d state=%s online=%s players=%d time=%s" % [Updater.installed_number(), st, onl,
			game.net.players.size() if game != null and game.net != null else 0, Time.get_datetime_string_from_system()])


func clean_exit() -> void:
	if FileAccess.file_exists(FLAG):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(FLAG))


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_EXIT_TREE:
		clean_exit()


func _write_report(info: String) -> String:
	# newest log of an earlier session (the running session writes godot.log)
	var dir := "user://logs"
	var best := ""
	var best_t := 0
	var da := DirAccess.open(dir)
	if da == null:
		return ""
	for fn in da.get_files():
		if not fn.ends_with(".log") or fn == "godot.log":
			continue
		var t := FileAccess.get_modified_time(dir + "/" + fn)
		if t > best_t:
			best_t = t
			best = fn
	var lines: PackedStringArray = FileAccess.get_file_as_string(dir + "/" + best).split("\n") if best != "" else PackedStringArray()
	var tail := lines.slice(maxi(0, lines.size() - 400))
	var out := "Trois Forêts 24 - Absturzbericht\n%s\nSystem: %s %s, %s\nLog: %s\n\n" % [info, OS.get_name(), OS.get_version(),
			RenderingServer.get_video_adapter_name(), best]
	out += "--- Ablauf (letzte Schritte vor dem Absturz) ---\n"
	var tr := FileAccess.get_file_as_string(TRACE_PREV).split("\n")
	out += "\n".join(tr.slice(maxi(0, tr.size() - 120)))
	out += "\n--- Godot-Log ---\n"
	out += "\n".join(tail)
	var dl := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if dl == "":
		dl = OS.get_user_data_dir()
	var path := dl.path_join("TF24_Absturzbericht_%s.txt" % Time.get_datetime_string_from_system().replace(":", "-"))
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return ""
	f.store_string(out)
	return path

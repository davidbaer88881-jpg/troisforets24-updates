# Cinematic for the loading screen: the Mercedes and the BMW flat out side by side through the night,
# floodlights sweeping over them, sparks from the plank, and a TV director cutting between low tracking
# shots, wheel cams, a chase cam and the helicopter. Runs in its own 3D world inside a SubViewport, so
# the track that is being built at the same time is not touched.
extends SubViewportContainer

const CarVisual = preload("res://scripts/car_visual.gd")
const Human = preload("res://scripts/human.gd")

const SPEED := 74.0            # m/s, about 265 km/h
const SHOT_LEN := 3.6          # seconds per camera shot
const LAMP_GAP := 48.0         # floodlight masts along the track
const ROAD_SHADER := """
shader_type spatial;
render_mode cull_disabled;
varying vec3 wp;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	float z = abs(wp.z);
	float n = noise(wp.xz * 3.1) * 0.5 + noise(wp.xz * 0.37) * 0.5;
	vec3 asphalt = vec3(0.045, 0.047, 0.052) * (0.75 + 0.5 * n);
	// rubbered-in racing line
	asphalt *= 1.0 - 0.35 * smoothstep(3.5, 0.0, abs(wp.z + 1.0)) * (0.6 + 0.4 * noise(wp.xz * vec2(0.05, 2.0)));
	vec3 col = asphalt;
	float rough = 0.62 - 0.12 * n;
	float line = smoothstep(6.85, 6.9, z) * (1.0 - smoothstep(7.08, 7.13, z));
	col = mix(col, vec3(0.85), line);
	// kerbs: red / white blocks
	float kerb = step(7.13, z) * (1.0 - step(8.4, z));
	float blk = step(0.5, fract(wp.x / 6.0));
	col = mix(col, mix(vec3(0.62, 0.02, 0.02), vec3(0.85), blk), kerb);
	rough = mix(rough, 0.3, kerb);
	// grass beyond
	float grass = step(8.4, z);
	col = mix(col, vec3(0.012, 0.03, 0.014) * (0.6 + 0.8 * noise(wp.xz * 0.8)), grass);
	rough = mix(rough, 0.9, grass);
	ALBEDO = col;
	ROUGHNESS = rough;
	SPECULAR = 0.4;
}
"""
const BARRIER_SHADER := """
shader_type spatial;
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	float post = step(0.88, fract(wp.x / 2.0));
	float band = step(0.35, fract(wp.y * 2.2 + 0.1));
	vec3 steel = vec3(0.55, 0.57, 0.6) * (0.6 + 0.4 * band);
	ALBEDO = mix(steel, vec3(0.08), post);
	METALLIC = 0.7;
	ROUGHNESS = 0.35;
}
"""


# just the fields the car's visual reads every frame
class Puppet:
	extends RefCounted
	var x := 0.0
	var y := 0.0
	var z := 0.0
	var psi := 0.0
	var r := 0.0
	var u := 74.0
	var v := 0.0
	var steer := 0.0
	var grade_pitch := 0.0
	var road_now := 0.0
	var heave := 0.0
	var roll := 0.0
	var pitch := 0.0
	var wheel_spin := 0.0
	var lock_f := false
	var lock_r := false
	var spin_r := false
	var brake := 0.0
	var flash := 0.0
	var hold := false
	var surface := "asphalt"
	var slip_r := 0.0
	var load_var := 1.0
	var spec := {"steerMax": 0.28}

	func steer_pull() -> float:
		return 0.0

	func world_vel() -> Vector2:
		return Vector2(u * cos(psi) - v * sin(psi), u * sin(psi) + v * cos(psi))


var vp: SubViewport
var root3d: Node3D
var cam: Camera3D
var road: MeshInstance3D
var barriers: Array = []
var lamps: Array = []          # [node, side]
var cars: Array = []           # {"vis", "p", "lane", "ph"}
var ready_3d := false
var running := false
var t := 0.0
var dist := 0.0
var _shot := -1
var _shot_t := 0.0
var _bump_t := 0.0
var _flash: ColorRect


func _init() -> void:
	stretch = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


# built over a few frames (the car models are the expensive part); the loading screen fades it in
func build(quality: String) -> void:
	vp = SubViewport.new()
	vp.own_world_3d = true
	vp.msaa_3d = Viewport.MSAA_2X if quality != "low" else Viewport.MSAA_DISABLED
	vp.scaling_3d_scale = 0.8 if quality == "low" else 1.0
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	root3d = Node3D.new()
	vp.add_child(root3d)
	_environment()
	_track()
	await get_tree().process_frame
	# the two cars: the Mercedes in its real livery, the BMW in team colours
	var specs := [
		["amg", [Color(0.05, 0.08, 0.3), Color(0.95, 0.1, 0.12), Color(1.0, 0.8, 0.1)], 24, true, -2.3, 0.0],
		["bmw", [Color(0.92, 0.93, 0.95), Color(0.05, 0.25, 0.75), Color(0.9, 0.08, 0.1)], 31, false, 2.4, 1.7],
	]
	for sp in specs:
		var vis = CarVisual.new()
		root3d.add_child(vis)
		vis.setup("gt3", sp[1], sp[2], quality, sp[3], sp[0])
		var look := {"suit": sp[1][0], "accent": sp[1][1], "stripe": sp[1][2], "helmet": sp[1][1], "helmet2": sp[1][0],
			"skin": Color(0.9, 0.74, 0.6), "visor": "gold" if sp[3] else "dark", "pattern": "stripes", "helmet_model": "gp"}
		vis.add_driver(look)
		var p := Puppet.new()
		p.z = sp[4]
		cars.append({"vis": vis, "p": p, "lane": sp[4], "ph": sp[5]})
		await get_tree().process_frame
	cam = Camera3D.new()
	cam.current = true
	cam.near = 0.05
	cam.far = 900.0
	root3d.add_child(cam)
	_flash = ColorRect.new()
	_flash.color = Color(1, 1, 1, 0)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_flash)
	ready_3d = true
	_step(0.0)


func set_running(on: bool) -> void:
	running = on
	if vp != null:
		vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS if on else SubViewport.UPDATE_DISABLED


func _environment() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.008, 0.012, 0.03)
	sm.sky_horizon_color = Color(0.16, 0.05, 0.05)
	sm.ground_horizon_color = Color(0.05, 0.02, 0.02)
	sm.ground_bottom_color = Color(0.0, 0.0, 0.0)
	sm.sky_energy_multiplier = 0.6
	sm.sun_angle_max = 0.0
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.3
	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.glow_bloom = 0.08
	env.glow_hdr_threshold = 1.2
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	env.fog_enabled = true
	env.fog_light_color = Color(0.06, 0.03, 0.04)
	env.fog_density = 0.006
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.12
	env.adjustment_saturation = 1.15
	var we := WorldEnvironment.new()
	we.environment = env
	root3d.add_child(we)
	# cool moonlight from behind for the outlines of the cars
	var moon := DirectionalLight3D.new()
	moon.light_color = Color(0.55, 0.65, 1.0)
	moon.light_energy = 0.35
	moon.rotation = Vector3(-0.5, 2.4, 0.0)
	root3d.add_child(moon)


func _track() -> void:
	var pm := PlaneMesh.new()
	pm.size = Vector2(700, 160)
	var rm := ShaderMaterial.new()
	var rs := Shader.new()
	rs.code = ROAD_SHADER
	rm.shader = rs
	road = MeshInstance3D.new()
	road.mesh = pm
	road.material_override = rm
	root3d.add_child(road)
	var bs := Shader.new()
	bs.code = BARRIER_SHADER
	var bmat := ShaderMaterial.new()
	bmat.shader = bs
	for side in [-1.0, 1.0]:
		var bm := BoxMesh.new()
		bm.size = Vector3(700, 0.75, 0.12)
		var b := MeshInstance3D.new()
		b.mesh = bm
		b.material_override = bmat
		b.position = Vector3(0, 0.55, side * 11.0)
		root3d.add_child(b)
		barriers.append(b)
		# dark tree line behind the barriers
		var fm := BoxMesh.new()
		fm.size = Vector3(700, 16, 2)
		var fmat := StandardMaterial3D.new()
		fmat.albedo_color = Color(0.008, 0.02, 0.01)
		fmat.roughness = 1.0
		var f := MeshInstance3D.new()
		f.mesh = fm
		f.material_override = fmat
		f.position = Vector3(0, 8, side * 34.0)
		root3d.add_child(f)
		barriers.append(f)
	# floodlight masts: their light sweeps over the cars as they pass
	var pole_m := StandardMaterial3D.new()
	pole_m.albedo_color = Color(0.25, 0.26, 0.28)
	pole_m.metallic = 0.6
	pole_m.roughness = 0.4
	var lamp_m := StandardMaterial3D.new()
	lamp_m.albedo_color = Color(1, 1, 1)
	lamp_m.emission_enabled = true
	lamp_m.emission = Color(1.0, 0.93, 0.8)
	lamp_m.emission_energy_multiplier = 9.0
	for k in 12:
		var side := -1.0 if k % 2 == 0 else 1.0
		var n := Node3D.new()
		var pole := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.09
		cm.bottom_radius = 0.14
		cm.height = 12.0
		pole.mesh = cm
		pole.material_override = pole_m
		pole.position = Vector3(0, 6, 0)
		n.add_child(pole)
		var arm := MeshInstance3D.new()
		var am := BoxMesh.new()
		am.size = Vector3(0.12, 0.12, 3.0)
		arm.mesh = am
		arm.material_override = pole_m
		arm.position = Vector3(0, 11.9, -side * 1.4)
		n.add_child(arm)
		var head := MeshInstance3D.new()
		var hm := BoxMesh.new()
		hm.size = Vector3(0.9, 0.2, 0.5)
		head.mesh = hm
		head.material_override = lamp_m
		head.position = Vector3(0, 11.75, -side * 2.8)
		n.add_child(head)
		var ol := OmniLight3D.new()
		ol.light_color = Color(1.0, 0.9, 0.75)
		ol.light_energy = 9.0
		ol.omni_range = 32.0
		ol.omni_attenuation = 1.4
		ol.position = Vector3(0, 11.0, -side * 3.5)
		n.add_child(ol)
		root3d.add_child(n)
		lamps.append([n, side, float(k / 2)])


func _process(dt: float) -> void:
	if not ready_3d or not running or not is_visible_in_tree():
		return
	# a long loading step freezes the picture; afterwards the cars carry on instead of jumping ahead
	_step(minf(dt, 1.0 / 20.0))


func _step(dt: float) -> void:
	t += dt
	dist += SPEED * dt
	# floodlights and the long objects stay around the cars
	for l in lamps:
		var node: Node3D = l[0]
		var side: float = l[1]
		var slot: float = l[2]
		var span := LAMP_GAP * 6.0
		var lx := dist - 60.0 + fposmod(slot * LAMP_GAP + (side * 0.5 + 0.5) * LAMP_GAP * 0.5 - dist, span)
		node.position = Vector3(lx, 0, side * 13.0)
	road.position = Vector3(dist + 150.0, 0, 0)
	for b in barriers:
		var bn: Node3D = b
		bn.position.x = dist + 150.0
	# the duel: slipstream, pulling alongside, dropping back - never touching
	_bump_t -= dt
	var bump := false
	if _bump_t <= 0.0:
		_bump_t = randf_range(0.5, 1.4)
		bump = true
	for i in cars.size():
		var c: Dictionary = cars[i]
		var p: Puppet = c["p"]
		var ph: float = c["ph"]
		var gap := 0.0 if i == 0 else 4.5 * sin(t * 0.33 + 0.6) - 1.0
		var lane: float = c["lane"] + 0.7 * sin(t * 0.5 + ph)
		var dlane: float = 0.35 * cos(t * 0.5 + ph)
		var nx := dist + gap
		var vx := SPEED + (0.0 if i == 0 else 4.5 * 0.33 * cos(t * 0.33 + 0.6))
		p.u = vx
		p.psi = atan2(dlane, vx)
		p.r = 0.0
		p.x = nx
		p.z = lane
		p.y = 0.0
		p.steer = p.psi * 5.0
		p.roll = -dlane * 0.006 + 0.004 * sin(t * 13.0 + ph)
		p.pitch = 0.003 * sin(t * 9.0 + ph * 2.0)
		p.heave = 0.012 * sin(t * 17.0 + ph * 3.0)
		p.load_var = 1.25 if bump and randf() < 0.7 else 1.0
		p.road_now = 0.0
		var vis = c["vis"]
		vis.sync(p, dt, 0.55, 0.0, cam.global_position if cam != null else Vector3.ZERO, 0.0)
		if p.load_var > 1.2:
			vis.spark_burst(randf_range(0.12, 0.3))
	if cam != null:
		_camera(dt)


# the TV director: a new angle every few seconds, each one moving
func _camera(dt: float) -> void:
	var shot := int(t / SHOT_LEN) % 6
	var k := fmod(t, SHOT_LEN) / SHOT_LEN
	if shot != _shot:
		_shot = shot
		if _flash != null:
			_flash.color.a = 0.18          # a short flash on every cut
	if _flash != null:
		_flash.color.a = maxf(0.0, _flash.color.a - dt * 1.4)
	var a: Puppet = cars[0]["p"]
	var b: Puppet = cars[1]["p"]
	var pa := Vector3(a.x, 0, a.z)
	var mid := Vector3((a.x + b.x) * 0.5, 0, (a.z + b.z) * 0.5)
	var pos := Vector3.ZERO
	var look := Vector3.ZERO
	var fov := 50.0
	match shot:
		0:
			# low in front, the Mercedes coming at the lens
			pos = pa + Vector3(lerpf(6.5, 4.6, k), 0.5, -2.4 + k * 0.9)
			look = pa + Vector3(0, 0.6, 0)
			fov = 46.0
		1:
			# wheel cam: alongside at hub height, the tyres and the road streaming past
			pos = pa + Vector3(lerpf(2.6, -1.6, k), 0.38, -4.4)
			look = pa + Vector3(lerpf(1.2, -0.8, k), 0.45, 0)
			fov = 42.0
		2:
			# chase cam, low behind: tail lights, sparks from the plank
			pos = pa + Vector3(-9.0 + k * 1.5, 1.15, -1.4 + 0.6 * sin(k * 3.0))
			look = pa + Vector3(6.0, 0.6, 0)
			fov = 54.0
		3:
			# helicopter, banking around the duel
			var ang := lerpf(-0.9, 0.4, k)
			pos = mid + Vector3(cos(ang) * -22.0, 15.0 - k * 4.0, sin(ang) * 22.0)
			look = mid + Vector3(4.0, 0, 0)
			fov = 40.0
		4:
			# long lens from far ahead: both cars squeezed together, side by side
			pos = mid + Vector3(lerpf(46.0, 34.0, k), 2.6, 0.6)
			look = mid + Vector3(0, 0.7, 0)
			fov = 15.0
		_:
			# the BMW from the inside, the Mercedes just behind it
			var pb := Vector3(b.x, 0, b.z)
			pos = pb + Vector3(lerpf(-1.0, 3.5, k), 0.9, 4.3)
			look = pb + Vector3(-3.0, 0.5, -1.5)
			fov = 48.0
	# a little shake: the camera car is doing 265 km/h too
	var sh := Vector3(sin(t * 31.0) * 0.012, sin(t * 27.0 + 1.0) * 0.015, sin(t * 23.0 + 2.0) * 0.01)
	cam.fov = fov
	cam.look_at_from_position(pos + sh, look, Vector3.UP)

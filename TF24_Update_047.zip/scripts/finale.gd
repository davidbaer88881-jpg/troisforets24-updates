# End of a race: the player's car is back in its garage. While the others are still racing a TV director
# follows them (left/right switches the driver, C the camera). Offline the podium comes when the AI is home
# (at the latest after WATCH_MAX, Enter skips); online it comes as soon as the last friend has finished.
# The podium ceremony: the winning car in front of a three-step podium, the top three drivers with
# champagne, confetti and an orbiting camera. Afterwards main shows the results table.
extends Node

const Human = preload("res://scripts/human.gd")
const DriverModel = preload("res://scripts/driver.gd")
const Gfx = preload("res://scripts/gfx.gd")
const WATCH_MAX := 90.0        # offline: podium at the latest this long after the own finish
const WATCH_MAX_ONLINE := 900.0

var game
var mode := ""                 # "", "watch", "podium"
var t := 0.0
var dir_t := 0.0
var stage: Node3D
var figs: Array = []
var on_done: Callable
var spectator := false         # watching the whole race as a Zuschauer (no own car)
var seat_i := -1               # grandstand seat in use (camera mode 6)


func start_watch(g, done: Callable, as_spectator := false) -> void:
	game = g
	on_done = done
	mode = "watch"
	spectator = as_spectator
	t = 0.0
	dir_t = 0.0
	game.cam_mode = 4
	_pick(1)
	if spectator:
		seat_i = -1
		next_seat(1)
		dir_t = 20.0
		game.show_msg("ZUSCHAUER · T Tribüne wechseln · C Kamera · ←/→ Fahrer · V mitfahren", 8.0, Color(0.3, 0.8, 1.0))
	elif game.is_online() and not friends_running().is_empty():
		game.show_msg("ZIEL! Siegerehrung, sobald alle Freunde im Ziel sind · ←/→ Fahrer · V mitfahren · C Kamera", 6.0, Color(0.3, 0.8, 1.0))
	else:
		game.show_msg("ZIEL! ZUSCHAUEN · ←/→ Fahrer · V mitfahren · C Kamera · ENTER Siegerehrung", 6.0, Color(0.3, 0.8, 1.0))


func running_cars() -> Array:
	var out: Array = []
	for c in game.cars:
		if not c.finished and not c.retired and not c.spectator:
			out.append(c)
	return out


# other human drivers (online) still on track
func friends_running() -> Array:
	var out: Array = []
	for c in game.cars:
		if c.remote and not c.finished and not c.retired:
			out.append(c)
	return out


func _podium_due() -> bool:
	if spectator:
		# the whole race: podium when the flag is out and everybody is home (online: every human)
		if not game.chequered:
			return false
		return running_cars().is_empty() or (game.is_online() and friends_running().is_empty() and t > 60.0)
	if game.is_online():
		return friends_running().is_empty() or t > WATCH_MAX_ONLINE
	return running_cars().is_empty() or t > WATCH_MAX


func _pick(step: int) -> void:
	var list := running_cars()
	if list.is_empty():
		list = game.cars
	var cur = game.focus_car()
	var i := list.find(cur)
	var nc = list[posmod(i + step, list.size())] if i >= 0 else list[0]
	game.focus = game.cars.find(nc)
	game.cam_init = false
	game.show_msg("TV · " + String(nc.name), 1.6, Color(0.3, 0.8, 1.0))


func process(dt: float) -> void:
	t += dt
	if mode == "watch":
		# automatic director: a new shot every few seconds, preferring close fights
		dir_t -= dt
		if dir_t <= 0.0 and game.cam_mode != 5 and game.cam_mode != 6:
			dir_t = randf_range(7.0, 11.0)
			game.cam_mode = [4, 4, 0, 1, 3][randi() % 5]
			var list := running_cars()
			if not list.is_empty():
				list.sort_custom(func(a, b): return _gap_ahead(a) < _gap_ahead(b))
				game.focus = game.cars.find(list[0] if randf() < 0.7 else list[randi() % list.size()])
			game.cam_init = false
		var fc = game.focus_car()
		if fc == null or fc.finished or fc.retired:
			_pick(1)
		if _podium_due():
			start_podium()
	elif mode == "podium":
		_podium_process(dt)


# grandstand view (camera mode 6): the next seat; the camera follows the cars passing in front of it
func next_seat(step: int) -> void:
	var seats: Array = game.world.seats
	if seats.is_empty():
		return
	seat_i = posmod(seat_i + step, seats.size())
	game.cam_mode = 6
	game.cam_init = false
	dir_t = 1e9
	game.show_msg("TRIBÜNE  ·  " + String(seats[seat_i]["name"]) + "  ·  T = nächste Tribüne", 3.0, Color(0.3, 0.8, 1.0))


func _gap_ahead(c) -> float:
	var best := 1e9
	for o in game.cars:
		if o == c or o.finished or o.retired:
			continue
		var g: float = wrapf(o.s - c.s, 0.0, game.T.length)
		best = minf(best, g)
	return best


func handle_key(kc: int) -> bool:
	if mode == "watch":
		match kc:
			KEY_RIGHT, KEY_D:
				_pick(1)
				dir_t = maxf(dir_t, 25.0)
				return true
			KEY_LEFT, KEY_A:
				_pick(-1)
				dir_t = maxf(dir_t, 25.0)
				return true
			KEY_V:
				# ride along in the watched car
				game.cam_mode = 4 if game.cam_mode == 5 else 5
				game.cockpit.look_yaw = 0.0
				game.cockpit.look_pitch = 0.0
				dir_t = 1e9 if game.cam_mode == 5 else 6.0
				game.show_msg("BEIFAHRER bei " + String(game.focus_car().name) + " · Maus ziehen = umsehen · V = TV" if game.cam_mode == 5 else "TV-Kamera", 2.5, Color(0.3, 0.8, 1.0))
				return true
			KEY_T:
				next_seat(1)
				return true
			KEY_C:
				game.cam_mode = {0: 1, 1: 3, 3: 4, 4: 0, 5: 0, 6: 4}.get(game.cam_mode, 0)
				game.cam_init = false
				dir_t = 25.0
				return true
			KEY_ENTER, KEY_KP_ENTER, KEY_SPACE:
				var fr := friends_running()
				if spectator and not game.chequered:
					game.show_msg("Die Siegerehrung kommt nach dem Rennen", 2.0, Color(1.0, 0.8, 0.2))
				elif game.is_online() and not fr.is_empty():
					game.show_msg("Siegerehrung, sobald alle im Ziel sind · noch %d Freund%s auf der Strecke" % [fr.size(), "" if fr.size() == 1 else "e"], 2.5, Color(1.0, 0.8, 0.2))
				else:
					start_podium()
				return true
	elif mode == "podium":
		if kc in [KEY_ENTER, KEY_KP_ENTER, KEY_SPACE, KEY_ESCAPE]:
			_end()
			return true
	return false


# ---------------------------------------------------------------- podium
func start_podium() -> void:
	mode = "podium"
	t = 0.0
	var T = game.T
	var sorted: Array = game.racing_cars()
	sorted.sort_custom(func(a, b): return game.progress(a) > game.progress(b))
	var top: Array = sorted.slice(0, mini(3, sorted.size()))
	# the stage stands on the start-finish straight, facing the grandstands
	var s0: float = fposmod(40.0, T.length)
	var p: Vector4 = T.point_at(s0, 0.0)
	var i: int = T.idx(s0)
	var fwd := Vector3(T.tx[i], 0, T.tz[i]).normalized()
	var rgt := Vector3(T.rx[i], 0, T.rz[i]).normalized()
	stage = Node3D.new()
	game.add_child(stage)
	stage.global_transform = Transform3D(Basis(fwd, Vector3.UP, rgt), Vector3(p.x, p.y, p.z))
	# stage frame: x = along the track, z = across (right)
	var white := Gfx.mat(Color(0.95, 0.95, 0.96), 0.4)
	var dark := Gfx.mat(Color(0.06, 0.07, 0.1), 0.5)
	var gold := Gfx.mat(Color(0.95, 0.75, 0.15), 0.3, 0.7)
	var red := Gfx.mat(Color(0.85, 0.08, 0.1), 0.6)
	_box(Vector3(14.0, 0.25, 8.0), Vector3(0, 0.12, 2.0), dark)                    # platform
	_box(Vector3(14.0, 6.0, 0.3), Vector3(0, 3.0, 6.0), dark)                       # back wall
	_box(Vector3(14.0, 0.5, 0.32), Vector3(0, 5.6, 5.98), red)
	var lbl := Label3D.new()
	lbl.text = "TROIS FORÊTS 24  ·  SIEGEREHRUNG"
	lbl.font_size = 96
	lbl.pixel_size = 0.008
	lbl.position = Vector3(0, 4.2, 5.82)
	lbl.rotation.y = PI
	lbl.modulate = Color.WHITE
	stage.add_child(lbl)
	# steps: 2nd left, 1st middle, 3rd right as seen from the front (the stage x axis points to the right of the track)
	var steps := [[0.0, 1.05, "1"], [1.7, 0.75, "2"], [-1.7, 0.5, "3"]]
	for k in top.size():
		var sx: float = steps[k][0]
		var h: float = steps[k][1]
		_box(Vector3(1.6, h, 1.4), Vector3(sx, 0.25 + h * 0.5, 4.4), white)
		var n := Label3D.new()
		n.text = steps[k][2]
		n.font_size = 220
		n.pixel_size = 0.004
		n.modulate = Color(0.95, 0.75, 0.15) if k == 0 else Color(0.2, 0.22, 0.28)
		n.position = Vector3(sx, 0.25 + h * 0.5, 3.69)
		n.rotation.y = PI
		stage.add_child(n)
		var c = top[k]
		var fig: Node3D = DriverModel.build(game.driver_look(c)) if DriverModel.available() else null
		if fig != null:
			DriverModel.stand(fig)
		else:
			fig = Human.build("driver", game.driver_look(c))
		fig.position = Vector3(sx, 0.25 + h, 4.4)
		fig.rotation.y = PI                     # faces the camera (-z)
		stage.add_child(fig)
		figs.append([fig, k])
		var name_l := Label3D.new()
		name_l.text = String(c.name)
		name_l.font_size = 44
		name_l.pixel_size = 0.005
		name_l.outline_size = 10
		name_l.position = Vector3(sx, 0.25 + h + 2.15, 4.4)
		name_l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		stage.add_child(name_l)
		_champagne(fig, k == 0)
	# trophy for the winner
	_box(Vector3(0.18, 0.35, 0.18), Vector3(0.45, 0.25 + 1.05 + 0.3, 4.1), gold)
	_confetti()
	# the winning car parked in front of the podium, all other cars out of sight
	for k in game.cars.size():
		var c = game.cars[k]
		var v = game.visuals[k]
		v.visible = c == top[0]
	var wc = top[0]
	var cp: Vector4 = T.point_at(s0 + 0.0, -0.5)
	wc.x = cp.x
	wc.z = cp.z
	wc.y = cp.y
	wc.u = 0.0
	wc.v = 0.0
	wc.r = 0.0
	wc.psi = atan2(T.tz[i], T.tx[i]) + 0.35
	wc.hold = true
	game.hud.visible = false
	game.show_msg("", 0.0)


func _podium_process(dt: float) -> void:
	# camera: slow arc in front of the podium, rising a bit
	var a := -0.55 + t * 0.07
	var dist := 8.5 - minf(2.5, t * 0.2)
	var local := Vector3(sin(a) * dist, 2.2 + t * 0.06, -cos(a) * dist + 3.0)
	game.camera.global_position = stage.global_transform * local
	game.camera.look_at(stage.global_transform * Vector3(0, 1.7, 4.0), Vector3.UP)
	game.camera.fov = 50.0
	for f in figs:
		var fig: Node3D = f[0]
		var wave := sin(t * 3.0 + float(f[1]))
		var up := 1.0 if f[1] == 0 else 0.6
		if fig.has_meta("drv"):
			# the bottle arm high up and waving, the other one cheering
			DriverModel.arms(fig, Vector3(0.35 - wave * 0.1, 1.0 * up, 0.25), Vector3(-0.45, -0.2 + 0.8 * up, 0.5 + wave * 0.15), 0.05, 0.15)
			fig.position.y = 0.25 + float([1.05, 0.75, 0.5][f[1]]) + absf(sin(t * 4.0 + float(f[1]))) * (0.05 if f[1] == 0 else 0.02)
			continue
		var j: Dictionary = fig.get_meta("j")
		(j["sh_r"] as Node3D).rotation = Vector3(-2.6 * up + wave * 0.15, 0, 0.2)
		(j["sh_l"] as Node3D).rotation = Vector3(-1.2 - wave * 0.2, 0, -0.25)
		(j["el_r"] as Node3D).rotation.x = -0.2
		(j["el_l"] as Node3D).rotation.x = -0.6
		(j["hips"] as Node3D).position.y = 0.95 + absf(sin(t * 4.0 + float(f[1]))) * (0.05 if f[1] == 0 else 0.02)
	if t > 16.0:
		_end()


func _end() -> void:
	if mode == "":
		return
	mode = ""
	if stage != null:
		stage.queue_free()
		stage = null
	figs.clear()
	for k in game.visuals.size():
		game.visuals[k].visible = not game.cars[k].spectator
	if on_done.is_valid():
		on_done.call()


func _box(size: Vector3, pos: Vector3, m: Material) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = m
	mi.position = pos
	stage.add_child(mi)
	return mi


func _champagne(fig: Node3D, winner: bool) -> void:
	var hand: Node3D
	var newfig := fig.has_meta("drv")
	if newfig:
		hand = DriverModel.hand_node(fig, "R")
	else:
		var j: Dictionary = fig.get_meta("j")
		hand = j["el_r"]
	var bottle := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.025
	cm.bottom_radius = 0.045
	cm.height = 0.32
	bottle.mesh = cm
	bottle.material_override = Gfx.mat(Color(0.1, 0.25, 0.12), 0.15, 0.3)
	bottle.position = Vector3(0, -0.05, 0.0) if newfig else Vector3(0, -0.33, 0.04)
	hand.add_child(bottle)
	var p := CPUParticles3D.new()
	p.amount = 160 if winner else 90
	p.lifetime = 1.4
	p.direction = Vector3(0, -1, 0.25)
	p.spread = 14.0
	p.initial_velocity_min = 4.0
	p.initial_velocity_max = 7.5
	p.gravity = Vector3(0, -6.0, 0)
	p.scale_amount_min = 0.03
	p.scale_amount_max = 0.07
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 6
	sm.rings = 3
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(1.0, 0.95, 0.75, 0.75)
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = fm
	p.mesh = sm
	p.position = Vector3(0, -0.22, 0.0) if newfig else Vector3(0, -0.5, 0.04)
	hand.add_child(p)


func _confetti() -> void:
	var p := CPUParticles3D.new()
	p.amount = 500
	p.lifetime = 5.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(7.0, 0.2, 3.0)
	p.position = Vector3(0, 8.0, 3.0)
	p.direction = Vector3(0, -1, 0)
	p.initial_velocity_min = 0.5
	p.initial_velocity_max = 1.5
	p.gravity = Vector3(0, -1.2, 0)
	p.angular_velocity_min = -360.0
	p.angular_velocity_max = 360.0
	p.scale_amount_min = 0.05
	p.scale_amount_max = 0.09
	var qm := QuadMesh.new()
	qm.size = Vector2(1.0, 0.6)
	var cm := StandardMaterial3D.new()
	cm.vertex_color_use_as_albedo = true
	cm.cull_mode = BaseMaterial3D.CULL_DISABLED
	cm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	qm.material = cm
	p.mesh = qm
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0.95, 0.75, 0.15), Color(0.85, 0.1, 0.1), Color(0.95, 0.95, 0.95), Color(0.2, 0.4, 0.95)])
	g.offsets = PackedFloat32Array([0.0, 0.33, 0.66, 1.0])
	p.color_initial_ramp = g
	stage.add_child(p)

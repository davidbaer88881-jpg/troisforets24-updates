# A visible pit stop with a full crew: jointed people (hips, knees, elbows) in team overalls and helmets,
# wheel-gun men and tyre carriers at every corner, air-jack man, refueller with hose, fire marshal,
# lollipop man and engineers at the garage. Emits sound events (wheel guns, air jack) for the player's stop.
extends Node3D

const Gfx = preload("res://scripts/gfx.gd")
const CarPhysics = preload("res://scripts/car_physics.gd")
const Human = preload("res://scripts/human.gd")
const DriverModel = preload("res://scripts/driver.gd")
var _crew_near := true

var car
var vis
var plan := {}
var t := 0.0
var duration := 10.0
var work := 8.0
var tyre_t := 0.0
var fuel_t := 0.0
var repair_t := 0.0
var fuel_target := 0.0
var done := false
var crew: Array = []        # {node, from, to, role, wheel, face}
var hose: MeshInstance3D
var lance_hose: MeshInstance3D
var lolli: MeshInstance3D
var lolli_mat: StandardMaterial3D
var tyres_done := false
var repaired := false
var team_col := Color(0.1, 0.3, 0.9)
# sound events for the player's stop, read and cleared by main: [name, world position] for the crew's
# work (pit_audio.gd) or "go" for the release beep
var events: Array = []
var fueling := false         # fuel is flowing (loop sound at the filler)
var fuel_pos := Vector3.ZERO
var _was_fueling := false
var _tool_t := 0.0
var _gun_fired := {}
var _mats := {}
var _jacked := false
var _released := false
var tyre_off := 0.0          # WEC rule: no tyre change while refuelling -> tyres start after the fuel
var extra_t := 0.0           # brake pads / wing adjustment
var standby := false         # crew already waiting in the box (the driver called in)
var walk := 1.4              # time to reach the car
var delay := 0.0             # crew not prepared: tyres still have to be fetched
var old_tyres: Array = []    # [mesh, wheel] lying next to the car after the swap

const WALK := 1.4
const JACK := 0.5
const GARAGE_Z := 4.2        # garage front is ~3 m to the car's right (working lane -> garage)


func start(c, v, p: Dictionary, col: Color) -> void:
	_setup(c, v, p, col)
	global_transform = Transform3D(Basis(Vector3.UP, -car.psi), Vector3(car.x, car.y, car.z))


# crew walks out before the car arrives and waits at the box line with the new tyres
func prepare(c, v, p: Dictionary, col: Color, xf: Transform3D) -> void:
	standby = true
	_setup(c, v, p, col)
	global_transform = xf
	for cm in crew:
		var n: Node3D = cm["node"]
		n.position = cm["from"]


# the car has stopped: re-anchor on the car, the waiting crew walks the last metre
func begin(c, p: Dictionary) -> void:
	var pb := get_node_or_null("PitBoard")
	if pb != null:
		pb.queue_free()
	var gpos: Array = []
	for cm in crew:
		var n: Node3D = cm["node"]
		gpos.append(n.global_position)
	global_transform = Transform3D(Basis(Vector3.UP, -c.psi), Vector3(c.x, c.y, c.z))
	for q in crew.size():
		var n: Node3D = crew[q]["node"]
		var lp: Vector3 = to_local(gpos[q])
		lp.y = 0.0
		crew[q]["from"] = lp
		n.position = lp
	plan["repair"] = p.get("repair", false)
	# the driver may have changed the plan after calling in: the stop uses what is set when the car stands
	for k in ["fuel_add", "tyres", "set", "press_f", "press_r", "wing", "pads"]:
		if p.has(k):
			plan[k] = p[k]
	tyre_t = 0.0
	if String(plan.get("tyres", "")) != "":
		tyre_t = 7.5 if String(plan.get("set", "all")) == "all" else 4.5
	fuel_target = clampf(car.fuel + float(plan.get("fuel_add", 0.0)), 0.0, car.spec["fuelCap"])
	fuel_t = maxf(0.0, (fuel_target - car.fuel) / 4.5)
	repair_t = car.repair_time() if plan["repair"] else 0.0
	if repair_t > 0.0 and not _has_role("repair"):
		_repair_crew(true)
	_timing()
	standby = false
	t = 0.0


func _has_role(r: String) -> bool:
	for cm in crew:
		if cm["role"] == r:
			return true
	return false


func _timing() -> void:
	tyre_off = fuel_t if tyre_t > 0.0 else 0.0
	extra_t = 0.0
	if plan.get("pads", false):
		extra_t = 32.0
	elif plan.has("wing") and int(plan["wing"]) != int(car.setup["wing"]):
		extra_t = 3.0
	work = maxf(maxf(fuel_t + tyre_t, extra_t), maxf(repair_t, 2.0))
	duration = delay + walk + JACK + work + JACK + 0.4


func _change_wheel(w: Dictionary) -> bool:
	var st := String(plan.get("set", "all"))
	return st == "all" or (st == "front") == bool(w["front"])


func _setup(c, v, p: Dictionary, col: Color) -> void:
	car = c
	vis = v
	plan = p
	team_col = col
	var ready: bool = p.get("ready", true)
	walk = 0.9 if ready else WALK
	delay = 0.0 if ready else 2.6
	fuel_target = clampf(car.fuel + float(plan.get("fuel_add", 0.0)), 0.0, car.spec["fuelCap"])
	fuel_t = maxf(0.0, (fuel_target - car.fuel) / 4.5)
	tyre_t = 0.0
	if String(plan.get("tyres", "")) != "":
		tyre_t = 7.5 if String(plan.get("set", "all")) == "all" else 4.5
	repair_t = car.repair_time() if plan.get("repair", false) else 0.0
	_timing()
	_mats = {
		"stripe": Gfx.mat(Color(0.95, 0.95, 0.95), 0.6),
		"tool": Gfx.mat(Color(0.12, 0.12, 0.13), 0.35, 0.7),
		"tyre": Gfx.mat(Color(0.05, 0.05, 0.05), 0.85),
		"red": Gfx.mat(Color(0.85, 0.08, 0.06), 0.4),
		"screen": Gfx.emissive(Color(0.35, 0.7, 1.0), 1.2),
		"reflect": Gfx.mat(Color(0.85, 0.87, 0.9), 0.25, 0.6),
		"hose": Gfx.mat(Color(0.75, 0.12, 0.08), 0.6),
	}
	var L: float = car.spec["len"]
	# start spots: prepared crews wait on the box line next to the car, otherwise they come from the garage
	var line_z := 2.75
	if tyre_t > 0.0:
		var k := 0
		for w in vis.wheels:
			if not _change_wheel(w):
				continue
			var hp: Vector3 = w["home"]
			var sd: float = w["side"]
			var start_x := hp.x + (1.2 if hp.x > 0.0 else -1.2)
			# wheel gun man kneels at the hub, the carrier brings the new tyre and takes the old one away
			var gf := Vector3(hp.x + (0.4 if hp.x > 0.0 else -0.4), 0, line_z) if ready else Vector3(start_x, 0, GARAGE_Z + 0.4 * k)
			var cf := Vector3(hp.x + (1.0 if hp.x > 0.0 else -1.0), 0, line_z + 0.3) if ready else Vector3(start_x + 0.6, 0, GARAGE_Z + 1.0 + 0.3 * k)
			_add_crew("gun", gf, Vector3(hp.x, 0, sd * 1.5), w, Vector3(hp.x, 0, sd * 0.8))
			_add_crew("carrier", cf, Vector3(hp.x + (0.9 if hp.x > 0.0 else -0.9), 0, sd * 1.75), w, Vector3(hp.x, 0, sd * 0.8))
			k += 1
		# tyre engineer: checks the pressures / temperatures of the old tyres on his tablet
		_add_crew("tyre_eng", Vector3(0.3, 0, GARAGE_Z + 0.8), Vector3(0.3, 0, 2.45), null, Vector3(0.3, 0, 0))
	if fuel_t > 0.0:
		_add_crew("fuel", Vector3(-0.6, 0, line_z if ready else GARAGE_Z), Vector3(-0.45, 0, 1.45), null, Vector3(-0.45, 0, 0.5))
		_add_crew("fire", Vector3(-1.8, 0, line_z + 0.4 if ready else GARAGE_Z + 0.5), Vector3(-1.7, 0, 2.3), null, Vector3(-0.45, 0, 1.0))
	_add_crew("jack", Vector3(-L / 2 - 0.4, 0, line_z if ready else GARAGE_Z), Vector3(-L / 2 - 0.65, 0, 0.35), null, Vector3(0, 0, 0))
	_add_crew("lollipop", Vector3(L / 2 + 1.4, 0, line_z if ready else GARAGE_Z), Vector3(L / 2 + 1.1, 0, 0.7), null, Vector3(L / 2 + 1.1 + 2.0, 0, 0.7))
	# windscreen tear-off / cleaning and radiator intakes
	_add_crew("screen", Vector3(0.6, 0, line_z if ready else GARAGE_Z + 0.4), Vector3(0.55, 0, 1.3), null, Vector3(0.55, 0, 0.0))
	_add_crew("intake", Vector3(L / 2 + 0.6, 0, line_z if ready else GARAGE_Z + 0.2), Vector3(L / 2 + 0.55, 0, -0.35), null, Vector3(L / 2 - 0.6, 0, -0.35))
	if repair_t > 0.0:
		_repair_crew(ready)
	# engineers watching at the garage entrance (headsets, timing screens)
	for k in 3:
		var pos := Vector3(-1.4 + k * 1.5, 0, GARAGE_Z + 1.6 + (0.3 if k == 1 else 0.0))
		_add_crew("engineer", pos, pos, null, Vector3(pos.x, 0, 0))
	for cm in crew:
		if cm["role"] == "gun":
			cm["hose"] = _cyl(0.022, _mats["hose"])
	hose = _cyl(0.035, _mats["tool"])
	lance_hose = _cyl(0.025, _mats["tool"])
	var bm := CylinderMesh.new()
	bm.top_radius = 0.28
	bm.bottom_radius = 0.28
	bm.height = 0.03
	lolli_mat = Gfx.emissive(Color(1.0, 0.1, 0.1), 1.5)
	lolli = MeshInstance3D.new()
	lolli.mesh = bm
	lolli.material_override = lolli_mat
	lolli.rotation.x = PI / 2
	add_child(lolli)
	# old tyres lying next to the car after they come off
	var otm := CylinderMesh.new()
	otm.top_radius = 0.33
	otm.bottom_radius = 0.33
	otm.height = 0.3
	otm.radial_segments = 16
	for w in vis.wheels:
		if tyre_t <= 0.0 or not _change_wheel(w):
			continue
		var om := MeshInstance3D.new()
		om.mesh = otm
		om.material_override = _mats["tyre"]
		om.visible = false
		add_child(om)
		old_tyres.append([om, w])
	if tyre_t > 0.0:
		_tyre_rack(L)
	if standby:
		_pit_board(L)


# coloured compound band on both sidewalls of a new tyre plus the silver rim
func _tyre_band(parent: Node3D) -> void:
	var cdef: Dictionary = CarPhysics.COMPOUNDS.get(String(plan.get("tyres", "medium")), CarPhysics.COMPOUNDS["medium"])
	var bm := TorusMesh.new()
	bm.inner_radius = 0.26
	bm.outer_radius = 0.29
	bm.rings = 18
	bm.ring_segments = 4
	var rm := CylinderMesh.new()
	rm.top_radius = 0.2
	rm.bottom_radius = 0.2
	rm.height = 0.31
	rm.radial_segments = 14
	var rim := MeshInstance3D.new()
	rim.mesh = rm
	rim.material_override = _mats["reflect"]
	rim.rotation.x = PI / 2
	parent.add_child(rim)
	var band_m := Gfx.mat(cdef["col"], 0.5)
	for z in [-0.15, 0.15]:
		var b := MeshInstance3D.new()
		b.mesh = bm
		b.material_override = band_m
		b.rotation.x = PI / 2
		b.position = Vector3(0, 0, z)
		parent.add_child(b)


# chrome tyre trolley on castors with the next sets (two levels, wheels lying across), parked at the garage
func _tyre_rack(L: float) -> void:
	var rack := Node3D.new()
	rack.position = Vector3(-L / 2 - 2.6, 0, GARAGE_Z + 0.7)
	add_child(rack)
	var chrome: Material = _mats["reflect"]
	for x in [-0.85, 0.85]:
		for z in [-0.3, 0.3]:
			_boxm(rack, Vector3(0.035, 1.35, 0.035), Vector3(x, 0.78, z), chrome)
			var cs := SphereMesh.new()
			cs.radius = 0.06
			cs.height = 0.12
			var c := MeshInstance3D.new()
			c.mesh = cs
			c.material_override = _mats["tool"]
			c.position = Vector3(x, 0.06, z)
			rack.add_child(c)
	for y in [0.2, 0.85]:
		for z in [-0.3, 0.3]:
			_boxm(rack, Vector3(1.75, 0.03, 0.03), Vector3(0, y, z), chrome)
	_boxm(rack, Vector3(0.03, 0.03, 0.66), Vector3(0.95, 1.2, 0), chrome)          # push handle
	for lv in 2:
		for k in 4:
			var t := Node3D.new()
			t.position = Vector3(-0.63 + k * 0.42, 0.53 + lv * 0.65, 0)
			t.rotation.y = PI / 2
			rack.add_child(t)
			var tm := CylinderMesh.new()
			tm.top_radius = 0.32
			tm.bottom_radius = 0.32
			tm.height = 0.3
			tm.radial_segments = 16
			var tmi := MeshInstance3D.new()
			tmi.mesh = tm
			tmi.material_override = _mats["tyre"]
			tmi.rotation.z = PI / 2
			tmi.rotation.x = 0.0
			t.add_child(tmi)
			var holder := Node3D.new()
			holder.rotation.y = PI / 2
			t.add_child(holder)
			_tyre_band(holder)


# pit board held over the working lane while the crew waits for the car: position and gap
func _pit_board(L: float) -> void:
	var b := Node3D.new()
	b.position = Vector3(L / 2 + 3.4, 0, 2.6)
	add_child(b)
	_boxm(b, Vector3(0.03, 2.0, 0.03), Vector3(0, 1.0, 0), _mats["reflect"])
	_boxm(b, Vector3(0.9, 0.6, 0.03), Vector3(0, 2.1, 0), _mats["tool"])
	var l := Label3D.new()
	l.text = "BOX\n24"
	l.font_size = 60
	l.pixel_size = 0.006
	l.modulate = Color(1.0, 0.85, 0.1)
	l.position = Vector3(0, 2.1, -0.03)
	l.rotation.y = PI
	l.outline_size = 0
	b.add_child(l)
	b.set_meta("board", true)
	b.name = "PitBoard"


func _repair_crew(ready: bool) -> void:
	var L: float = car.spec["len"]
	_add_crew("repair", Vector3(L / 2, 0, 2.75 if ready else GARAGE_Z), Vector3(L / 2 + 0.7, 0, -0.5), null, Vector3(0, 0, -0.5))
	_add_crew("repair", Vector3(-L / 2, 0, 2.75 if ready else GARAGE_Z), Vector3(-L / 2 - 0.75, 0, -0.45), null, Vector3(0, 0, -0.45))


func _cyl(r: float, m: Material) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = 1.0
	cm.radial_segments = 8
	var mi := MeshInstance3D.new()
	mi.mesh = cm
	mi.material_override = m
	mi.visible = false
	add_child(mi)
	return mi


func _capsule(parent: Node3D, r: float, h: float, pos: Vector3, m: Material) -> MeshInstance3D:
	var cm := CapsuleMesh.new()
	cm.radius = r
	cm.height = h
	cm.radial_segments = 12
	cm.rings = 6
	var mi := MeshInstance3D.new()
	mi.mesh = cm
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi


func _boxm(parent: Node3D, size: Vector3, pos: Vector3, m: Material) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi


func _joint(parent: Node3D, pos: Vector3) -> Node3D:
	var j := Node3D.new()
	j.position = pos
	parent.add_child(j)
	return j


# a jointed crew member facing +Z, origin between the feet
func _person(role: String) -> Node3D:
	# crew in team overalls with cap and headset (see human.gd); skin and hair vary per person
	var skins := [Color(0.88, 0.68, 0.54), Color(0.76, 0.55, 0.4), Color(0.55, 0.37, 0.25), Color(0.93, 0.76, 0.64)]
	var hairs := [Color(0.16, 0.11, 0.07), Color(0.08, 0.07, 0.06), Color(0.45, 0.3, 0.15), Color(0.55, 0.52, 0.48)]
	var look := {"suit": team_col, "accent": team_col.darkened(0.5), "skin": skins[randi() % skins.size()], "hair": hairs[randi() % hairs.size()]}
	var p: Node3D = DriverModel.build_crew(look) if DriverModel.available() else null
	if p == null:
		p = Human.build("crew", look)
	var j: Dictionary = p.get_meta("j")
	var torso: Node3D = j["torso"]
	# role props, held in the right hand (end of the right forearm)
	var hand: Node3D = j["el_r"]
	match role:
		"gun":
			var g := _joint(hand, Vector3(0, -0.34, 0.05))
			_boxm(g, Vector3(0.11, 0.17, 0.24), Vector3.ZERO, _mats["tool"])
			_boxm(g, Vector3(0.07, 0.07, 0.2), Vector3(0, -0.02, 0.2), _mats["tool"])
			_boxm(g, Vector3(0.09, 0.05, 0.05), Vector3(0, -0.02, 0.32), _mats["reflect"])      # socket
			_boxm(g, Vector3(0.3, 0.03, 0.03), Vector3(0, 0.08, 0.02), _mats["tool"])           # side handle
			_boxm(g, Vector3(0.06, 0.06, 0.06), Vector3(0, 0.0, -0.13), _mats["hose"])         # air hose coupling
			j["prop"] = g
		"carrier":
			var tyre := _joint(torso, Vector3(0, 0.15, 0.36))
			var tm := CylinderMesh.new()
			tm.top_radius = 0.33
			tm.bottom_radius = 0.33
			tm.height = 0.3
			var tmi := MeshInstance3D.new()
			tmi.mesh = tm
			tmi.material_override = _mats["tyre"]
			tmi.rotation.x = PI / 2
			tyre.add_child(tmi)
			_tyre_band(tyre)
			j["prop"] = tyre
		"fuel":
			var nz := _joint(hand, Vector3(0, -0.34, 0.06))
			_boxm(nz, Vector3(0.1, 0.12, 0.35), Vector3(0, 0, 0.1), _mats["tool"])
			j["prop"] = nz
		"fire":
			var ext := _joint(hand, Vector3(0, -0.45, 0.0))
			_capsule(ext, 0.08, 0.5, Vector3.ZERO, _mats["red"])
			j["prop"] = ext
		"jack":
			var lance := _joint(hand, Vector3(0, -0.34, 0.05))
			_boxm(lance, Vector3(0.05, 0.05, 0.5), Vector3(0, 0, 0.22), _mats["tool"])
			j["prop"] = lance
		"tyre_eng", "engineer":
			var tab := _joint(hand, Vector3(0, -0.33, 0.08))
			_boxm(tab, Vector3(0.2, 0.015, 0.28), Vector3.ZERO, _mats["tool"])
			_boxm(tab, Vector3(0.17, 0.004, 0.24), Vector3(0, 0.01, 0), _mats["screen"])
			j["prop"] = tab
		"screen", "intake":
			var cloth := _joint(hand, Vector3(0, -0.34, 0.03))
			_boxm(cloth, Vector3(0.12, 0.03, 0.2), Vector3.ZERO, _mats["stripe"])
			j["prop"] = cloth
	p.set_meta("j", j)
	return p


func _add_crew(role: String, from: Vector3, to: Vector3, wheel, face: Vector3) -> void:
	var n := _person(role)
	n.position = from
	var sc := randf_range(0.94, 1.07)
	n.scale = Vector3(sc, sc, sc)
	add_child(n)
	crew.append({"node": n, "from": from, "to": to, "role": role, "wheel": wheel, "face": face, "seed": randf() * 10.0})


# pose: walk phase, crouch 0..1 (deep kneel at 1), arm pose ("swing", "front", "hold", "up", "side")
func _pose(n: Node3D, wph: float, moving: bool, crouch: float, arms: String, jitter: float) -> void:
	var j: Dictionary = n.get_meta("j")
	var sw := sin(wph * 8.0) * 0.55 if moving else 0.0
	var hips: Node3D = j["hips"]
	var torso: Node3D = j["torso"]
	hips.position.y = 0.95 - crouch * 0.48 + (absf(sin(wph * 8.0)) * 0.03 if moving else 0.0)
	torso.rotation.x = crouch * 0.45 + (0.08 if moving else 0.0)
	torso.rotation.z = 0.0
	for side in ["l", "r"]:
		var sg := 1.0 if side == "l" else -1.0
		var th: Node3D = j["th_" + side]
		var kn: Node3D = j["kn_" + side]
		if crouch > 0.01:
			# kneel: one knee down, the other leg forward
			var front: bool = side == "l"
			th.rotation.x = lerpf(0.0, -1.5 if front else -0.25, crouch)
			kn.rotation.x = lerpf(0.0, 1.5 if front else 1.9, crouch)
		else:
			th.rotation.x = sw * sg
			kn.rotation.x = maxf(0.0, -sw * sg) * 0.9 + 0.05
		var sh: Node3D = j["sh_" + side]
		var el: Node3D = j["el_" + side]
		match arms:
			"front":
				sh.rotation.x = -1.25 + (sin(t * 55.0) * jitter if side == "r" else 0.0)
				el.rotation.x = -0.35
			"hold":
				sh.rotation.x = -0.75
				el.rotation.x = -1.1
			"up":
				sh.rotation.x = -2.4 if side == "r" else -sw * sg * 0.7
				el.rotation.x = -0.15 if side == "r" else -0.3
			"wipe":
				sh.rotation.x = -1.35 if side == "r" else -0.9
				el.rotation.x = -0.45 + (sin(t * 9.0 + jitter) * 0.35 if side == "r" else 0.0)
			_:
				sh.rotation.x = -sw * sg * 0.8
				el.rotation.x = -0.25 - (0.3 if moving else 0.0)
		sh.rotation.z = sg * 0.08
		if arms == "wipe" and side == "r":
			sh.rotation.z = -0.1 + sin(t * 4.5 + jitter) * 0.55
	# weight shift from one leg to the other while standing, breathing, looking around
	if not moving and crouch < 0.05:
		hips.rotation.z = sin(t * 0.9 + jitter * 2.0) * 0.04
		hips.position.x = sin(t * 0.9 + jitter * 2.0) * 0.025
	else:
		hips.rotation.z = 0.0
		hips.position.x = 0.0
	var hd: Node3D = j["head"]
	torso.rotation.x += sin(t * 2.1 + jitter * 3.0) * 0.015
	hd.rotation.y = sin(t * 0.7 + jitter * 5.0) * (0.35 if not moving and crouch < 0.1 else 0.0)
	# the skinned crew body follows the pose (only when the pit stop is near the camera)
	if _crew_near and n.has_meta("drv"):
		DriverModel.follow(n)


func _face(n: Node3D, target: Vector3) -> void:
	var tgt := Vector3(target.x, n.position.y, target.z)
	if tgt.distance_to(n.position) > 0.05:
		n.look_at(to_global(tgt), Vector3.UP, true)


func step(dt: float) -> void:
	if done:
		return
	if standby:
		# crew waits for the car: nothing happens (and nothing is shown) until the car stands in the box
		_idle_wait()
		return
	t += dt
	var tm := t - delay                 # unprepared crew: tyres are still being fetched
	var j_end := walk + JACK
	var work_end := j_end + work
	var out_start := work_end + JACK
	# air jack: the lance man plugs in, the car rises, drops when the work is finished
	if tm < walk:
		vis.jack = 0.0
	elif tm < j_end:
		vis.jack = 0.09 * (tm - walk) / JACK
		if not _jacked:
			_jacked = true
			events.append(["jack_up", vis.chassis.to_global(Vector3(-float(car.spec["len"]) * 0.5, 0.3, 0.0))])
	elif tm < work_end:
		vis.jack = 0.09
	else:
		vis.jack = 0.09 * clampf(1.0 - (tm - work_end) / JACK, 0.0, 1.0)
		if not _released:
			_released = true
			events.append(["jack_down", vis.chassis.to_global(Vector3(-float(car.spec["len"]) * 0.5, 0.3, 0.0))])
	var tt := (tm - j_end - tyre_off) / maxf(0.1, tyre_t)
	var vcam := get_viewport().get_camera_3d() if is_inside_tree() else null
	_crew_near = vcam == null or vcam.global_position.distance_to(global_position) < 70.0
	for c in crew:
		var n: Node3D = c["node"]
		var from: Vector3 = c["from"]
		var to: Vector3 = c["to"]
		var role: String = c["role"]
		var phase: float = c["seed"]
		if role == "engineer":
			n.position = from
			# watching the stop, one of them talks to the driver on the radio
			_pose(n, 0.0, false, 0.0, "hold" if int(phase) % 3 != 0 else "swing", phase)
			_face(n, c["face"])
			continue
		if tm < 0.0:
			# not prepared: the crew hurries around in front of the garage
			var f0 := 0.5 + 0.5 * sin(t * 2.5 + phase)
			n.position = from + Vector3(sin(phase) * 0.8 * f0, 0, -0.3 * f0)
			_face(n, Vector3(0, 0, 0))
			_pose(n, t + phase, true, 0.0, "swing", phase)
		elif tm < walk:
			var f := smoothstep(0.0, 1.0, tm / walk)
			n.position = from.lerp(to, f)
			_face(n, n.position + (to - from))
			_pose(n, tm * 1.6 + phase, true, 0.0, "hold" if role == "carrier" or role == "tyre_eng" else ("front" if role == "fuel" or role == "jack" else "swing"), 0.0)
		elif tm < out_start:
			n.position = to
			_face(n, c["face"])
			match role:
				"gun":
					var firing := (tt > 0.08 and tt < 0.3) or (tt > 0.62 and tt < 0.85)
					_pose(n, 0.0, false, 1.0, "front", 0.06 if firing else 0.0)
					if firing:
						var gjd: Dictionary = n.get_meta("j")
						var gtor: Node3D = gjd["torso"]
						gtor.rotation.z = sin(t * 61.0) * 0.03          # body shaken by the impact wrench
				"carrier":
					# hands the new tyre over, then crouches to roll the old one away; leans in when fitting
					_pose(n, 0.0, false, 0.6 if tt > 0.3 and tt < 0.62 else 0.25, "hold", 0.0)
					if tt > 0.48 and tt < 0.62:
						var tj: Dictionary = n.get_meta("j")
						var tor: Node3D = tj["torso"]
						tor.rotation.x += 0.35
				"lollipop":
					_pose(n, 0.0, false, 0.0, "up", 0.0)
				"fuel", "jack":
					_pose(n, 0.0, false, 0.15, "front", 0.0)
				"fire":
					_pose(n, 0.0, false, 0.0, "hold", 0.0)
				"screen":
					_pose(n, 0.0, false, 0.0, "wipe", phase)
				"intake":
					_pose(n, 0.0, false, 0.55, "wipe", phase)
				"tyre_eng":
					# walks over to the old tyres once they are off
					if tt > 0.5:
						var ot: Vector3 = to + Vector3(sin(t * 0.8 + phase) * 1.2, 0, 0)
						n.position = to.lerp(ot, clampf((tt - 0.5) * 3.0, 0.0, 1.0))
					_pose(n, 0.0, false, 0.35 if tt > 0.6 else 0.0, "hold", phase)
				_:
					_pose(n, 0.0, false, 0.6, "front", 0.0)
		else:
			var f := smoothstep(0.0, 1.0, (tm - out_start) / WALK)
			# everybody walks back to the garage
			var back := Vector3(from.x, 0, maxf(from.z, GARAGE_Z))
			n.position = to.lerp(back, f)
			_face(n, n.position + (back - to))
			_pose(n, tm + phase, true, 0.0, "hold" if role == "carrier" else "swing", 0.0)
		# wheel swap: gun off -> old wheel out -> new wheel on -> gun on
		if role == "gun" and c["wheel"] != null and tm >= 0.0:
			var w: Dictionary = c["wheel"]
			var pv: Node3D = w["pivot"]
			var home: Vector3 = w["home"]
			var off := 0.0
			if tt > 0.3 and tt < 0.62:
				off = smoothstep(0.3, 0.4, tt) * (1.0 - smoothstep(0.52, 0.62, tt)) * 0.6
			pv.position.z = home.z + float(w["side"]) * off
			pv.visible = not (tt > 0.42 and tt < 0.5)
			# loosen, old wheel dropped, new wheel on the hub, tighten
			for mk in [[0.1, "gun_off"], [0.45, "tyre_drop"], [0.56, "hub"], [0.64, "gun_on"]]:
				var mark: float = mk[0]
				var key: String = "%d_%.2f" % [n.get_instance_id(), mark]
				if tt > mark and not _gun_fired.has(key) and tm < out_start:
					_gun_fired[key] = true
					var wp: Vector3 = pv.global_position
					if mk[1] == "tyre_drop":
						wp = to_global(Vector3(home.x + (0.55 if home.x > 0.0 else -0.55), 0.15, float(w["side"]) * 1.95))
					events.append([mk[1], wp])
	# wheel gun air hoses from the gantry above the garage to every gun
	for cm in crew:
		if cm.has("hose"):
			var hm: MeshInstance3D = cm["hose"]
			var gn: Node3D = cm["node"]
			if tm >= 0.0 and tm < out_start + WALK * 0.8:
				var gj: Dictionary = gn.get_meta("j")
				var gp: Node3D = gj["prop"]
				_stretch(hm, Vector3(gn.position.x, 2.8, GARAGE_Z - 0.6), to_local(gp.global_position))
			else:
				hm.visible = false
	# old tyres on the ground next to each corner until the carriers take them away
	for ot in old_tyres:
		var om: MeshInstance3D = ot[0]
		var w2: Dictionary = ot[1]
		var hp: Vector3 = w2["home"]
		om.visible = tm >= 0.0 and tt > 0.45 and tm < out_start
		om.position = Vector3(hp.x + (0.55 if hp.x > 0.0 else -0.55), 0.15, float(w2["side"]) * 1.95)
		om.rotation = Vector3.ZERO
	# fuel hose from the garage rig to the filler on the car's right side
	fueling = tm > j_end + 0.25 and tm < j_end + fuel_t + 0.15 and fuel_t > 0.0
	fuel_pos = to_global(Vector3(-0.45, 1.0, 1.05))
	if fueling != _was_fueling:
		_was_fueling = fueling
		events.append(["coupling", fuel_pos])          # dry-break coupling on / off
	if tm > j_end and tm < j_end + fuel_t + 0.4 and fuel_t > 0.0:
		car.fuel = minf(fuel_target, car.fuel + 4.5 * dt)
		_stretch(hose, Vector3(-0.6, 2.6, GARAGE_Z - 0.3), Vector3(-0.45, 1.0, 1.05))
	else:
		hose.visible = false
	# repairs and brake work: the mechanics' tools around the car
	var tool_end := maxf(repair_t if not repaired or tm < j_end + repair_t else 0.0, extra_t if plan.get("pads", false) else 0.0)
	if tm > j_end + 0.3 and tm < j_end + tool_end - 0.3:
		_tool_t -= dt
		if _tool_t <= 0.0:
			_tool_t = randf_range(0.35, 0.9)
			var names := ["ratchet", "hammer", "driver", "panel"] if repair_t > 0.0 else ["ratchet", "driver"]
			var L2: float = car.spec["len"]
			var at := Vector3(randf_range(-L2 * 0.45, L2 * 0.45), randf_range(0.2, 0.8), randf_range(-0.9, 0.9))
			if repair_t <= 0.0:
				at = Vector3(L2 * 0.33 * (1.0 if randf() < 0.5 else -1.0), 0.35, 0.85 * (1.0 if randf() < 0.5 else -1.0))
			events.append([names[randi() % names.size()], vis.chassis.to_global(at)])
	var L: float = car.spec["len"]
	if tm > walk and tm < out_start:
		_stretch(lance_hose, Vector3(-L / 2 - 0.4, 0.05, GARAGE_Z - 0.5), Vector3(-L / 2 - 0.3, 0.45, 0.3))
	else:
		lance_hose.visible = false
	if not tyres_done and tyre_t > 0.0 and tm > j_end + tyre_off + tyre_t * 0.5:
		tyres_done = true
		var st := String(plan.get("set", "all"))
		# new tyres come with the pressures chosen in the pit menu
		if plan.has("press_f") and st != "rear":
			car.setup["press_f"] = float(plan["press_f"])
		if plan.has("press_r") and st != "front":
			car.setup["press_r"] = float(plan["press_r"])
		# no tyre warmers: new tyres come out cold
		if st != "rear":
			car.wear_f = 0.0
			car.temp_f = 45.0
		if st != "front":
			car.wear_r = 0.0
			car.temp_r = 45.0
		if st == "all":
			car.compound = String(plan["tyres"])
	if extra_t > 0.0 and tm > j_end + extra_t and not plan.get("_extra_done", false):
		plan["_extra_done"] = true
		if plan.get("pads", false):
			car.pad_wear = 0.0
		if plan.has("wing"):
			car.setup["wing"] = int(plan["wing"])
	if not repaired and repair_t > 0.0 and tm > j_end + repair_t:
		repaired = true
		car.repair()
		vis.repair_visual()
		car.set_meta("replay_repair", true)
	# lollipop: red while working, green to release
	lolli.position = Vector3(L / 2 + 1.1, 2.2, 0.7) if tm > walk * 0.7 else Vector3(0, -50, 0)
	var go := tm >= work_end
	if go and not events.has("go") and lolli_mat.emission != Color(0.1, 1.0, 0.2):
		events.append("go")
	lolli_mat.emission = Color(0.1, 1.0, 0.2) if go else Color(1.0, 0.1, 0.1)
	lolli_mat.albedo_color = lolli_mat.emission.darkened(0.5)
	if t >= duration:
		done = true
		fueling = false
		vis.jack = 0.0
		for w in vis.wheels:
			var pv: Node3D = w["pivot"]
			var home: Vector3 = w["home"]
			pv.position.z = home.z
			pv.visible = true


# waiting for the car: crew at the box line, looking up the lane, carriers holding the new tyres
func _idle_wait() -> void:
	for c in crew:
		var n: Node3D = c["node"]
		var role: String = c["role"]
		var phase: float = c["seed"]
		n.position = c["from"]
		if role == "engineer":
			_face(n, c["face"])
		else:
			_face(n, n.position + Vector3(-5.0, 0, 0))
		var arms := "hold" if role in ["carrier", "tyre_eng", "fire"] else ("front" if role in ["fuel", "jack", "gun"] else "swing")
		if role == "lollipop":
			arms = "up"
		_pose(n, 0.0, false, 0.0, arms, phase if arms == "swing" else 0.0)
	lolli.position = Vector3(car.spec["len"] / 2 + 1.1, 2.2, 0.7)
	lolli_mat.emission = Color(1.0, 0.1, 0.1)


func _stretch(mi: MeshInstance3D, a: Vector3, b: Vector3) -> void:
	mi.visible = true
	var mid := (a + b) * 0.5
	var dir := b - a
	var dl := dir.length()
	var bas := Basis.looking_at(dir.normalized(), Vector3.UP if absf(dir.normalized().y) < 0.95 else Vector3.RIGHT)
	# the cylinder runs along local Y: tilt it onto the looking_at -Z axis
	mi.transform = Transform3D(bas * Basis(Vector3.RIGHT, -PI / 2), mid)
	mi.scale = Vector3(1, dl, 1)


func progress() -> Dictionary:
	var j_end := delay + walk + JACK
	return {
		"fuel": clampf((t - j_end) / maxf(0.01, fuel_t), 0.0, 1.0) if fuel_t > 0.0 else -1.0,
		"tyres": clampf((t - j_end - tyre_off) / maxf(0.01, tyre_t), 0.0, 1.0) if tyre_t > 0.0 else -1.0,
		"extra": clampf((t - j_end) / maxf(0.01, extra_t), 0.0, 1.0) if extra_t > 0.0 else -1.0,
		"repair": clampf((t - j_end) / maxf(0.01, repair_t), 0.0, 1.0) if repair_t > 0.0 else -1.0,
		"total": clampf(t / duration, 0.0, 1.0), "left": maxf(0.0, duration - t),
	}

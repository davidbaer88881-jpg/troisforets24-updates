# Online multiplayer.
#  - "code" (recommended): the host gets a fresh 5-letter code, friends type it in. Everything runs through a
#    server (relay.gd), so no IP addresses or router settings are needed.
#  - "ip": direct connection over ENet (UDP) in the same WLAN / Tailscale.
# Every computer simulates its own car and sends its state several times a second; the host also simulates
# the AI cars. Cars from other computers are drawn with dead reckoning + smooth correction.
extends Node

signal lobby_changed

const PORT := 24724
const MAX_PEERS := 16
const Profile = preload("res://scripts/profile.gd")
const Updater = preload("res://scripts/updater.gd")
const Relay = preload("res://scripts/relay.gd")
const STRIDE := 40               # bytes per car state (see _pack)
const TIMEOUT := 9.0          # seconds without a message: player gone
# race settings the host chooses in the lobby (same as for a normal race)
const CFG_KEYS := ["track", "duration", "start_hour", "time_scale", "weather", "wear", "damage", "ai_diff",
	"quali_limits", "rules", "n_gt3", "n_hy", "max_humans"]

var game
var mode := ""                 # "", "code", "ip"
var peer: ENetMultiplayerPeer
var relay: Node
var code := ""
var id := 0
var players := {}              # peer id -> {name, team, number, cls, c1, c2, c3, ver, ready}
var lobby_cfg := {}            # host's race settings (sent to everybody)
var online := false
var status := ""
var ready_peers := {}
var send_acc := 0.0
var corr := {}                     # car index -> Vector3 position error still to blend in
var corr_psi := {}                 # car index -> heading error still to blend in
var last_seen := {}            # relay: peer id -> seconds since the last message
var _ping_t := 0.0
var _wait_t := 0.0            # client: time waiting for the host to answer
var ext_ip := ""
var upnp_state := ""
var _upnp: UPNP
var _upnp_thread: Thread


func _ready() -> void:
	multiplayer.peer_connected.connect(func(_p): pass)
	multiplayer.peer_disconnected.connect(_peer_gone)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)
	relay = Relay.new()
	relay.name = "Relay"
	add_child(relay)
	relay.opened.connect(_relay_opened)
	relay.failed.connect(_relay_failed)
	relay.message.connect(_on_msg)


func my_id() -> int:
	return id if online else 1


func is_host() -> bool:
	return online and id == 1


func status_text() -> String:
	return status


func _me() -> Dictionary:
	var p: Dictionary = Profile.current
	var s: Dictionary = game.settings
	var liv: Array = game.menu.LIVERIES[int(s["livery"]) % game.menu.LIVERIES.size()]
	var rd: bool = players.get(id, {}).get("ready", false) if online else false
	return {"name": String(p.get("name", "Fahrer")), "team": String(p.get("team", "Team")), "number": int(p.get("number", 24)),
		"cls": String(s["cls"]), "c1": p.get("c1", liv[1]).to_html(), "c2": p.get("c2", liv[2]).to_html(), "c3": Color(liv[3]).to_html(),
		"ver": Updater.installed_number(), "ready": rd or id == 1, "spec": bool(game.menu.spectate), "model": String(s.get("gt3_model", "amg"))}


func host_cfg_from_settings() -> void:
	for k in CFG_KEYS:
		lobby_cfg[k] = game.settings.get(k)


# ---------------------------------------------------------------- send / receive (both modes)
func _send(ev: String, data, to: int = 0) -> void:
	if mode == "code":
		relay.send(ev, data, to)
	elif mode == "ip" and peer != null:
		if to == 0:
			_m.rpc(ev, data)
		else:
			_m.rpc_id(to, ev, data)


func _send_fast(ev: String, data) -> void:
	if mode == "code":
		relay.send(ev, data, 0)
	elif mode == "ip" and peer != null:
		_mu.rpc(ev, data)


@rpc("any_peer", "reliable")
func _m(ev: String, data) -> void:
	_on_msg(multiplayer.get_remote_sender_id(), ev, data)


@rpc("any_peer", "unreliable_ordered")
func _mu(ev: String, data) -> void:
	_on_msg(multiplayer.get_remote_sender_id(), ev, data)


func _on_msg(from: int, ev: String, data) -> void:
	last_seen[from] = 0.0
	match ev:
		"hello":          # a player (re)announces himself; the host answers with the lobby
			if is_host() and data is Dictionary:
				_register(from, data)
		"lobby":          # host -> all: players + race settings
			if not is_host() and from == 1 and data is Dictionary:
				var pl: Dictionary = {}
				for k in data["players"].keys():
					pl[int(k)] = data["players"][k]
				players = pl
				lobby_cfg = data["cfg"]
				if not players.has(id) and mode == "code":
					status = "Verbinde …"
				else:
					status = "In der Lobby. Der Host stellt das Rennen ein und startet es."
				lobby_changed.emit()
		"rejected":
			if int(data.get("to", id)) == id:
				status = String(data["why"])
				lobby_changed.emit()
				leave_keep_status()
		"bye":
			_peer_gone(from)
		"begin":
			if from == 1 and not is_host():
				_begin_race(data)
		"ready":
			if is_host():
				ready_peers[from] = true
		"go":
			if from == 1 and game != null:
				game.lights_out_at = game.lights_t
		"st":
			_states(_unpack_buf(data))
		"ping":
			pass


func _unpack_buf(data) -> PackedByteArray:
	if data is PackedByteArray:
		return data
	if data is String:
		return Marshalls.base64_to_raw(data)
	return PackedByteArray()


# ---------------------------------------------------------------- lobby: code (server)
func host_code() -> String:
	leave()
	mode = "code"
	id = 1
	code = Relay.new_code()
	online = true
	players = {1: {}}
	players[1] = _me()
	host_cfg_from_settings()
	status = "Verbinde mit dem Server …"
	relay.open(code, id)
	lobby_changed.emit()
	return status


func join_code(c: String) -> String:
	leave()
	c = Relay.clean_code(c)
	if c.length() != 5:
		status = "Der Code hat 5 Zeichen (Buchstaben und Zahlen)."
		lobby_changed.emit()
		return status
	mode = "code"
	code = c
	id = 2 + randi() % 1000000000
	online = true
	status = "Verbinde mit Lobby %s …" % code
	relay.open(code, id)
	lobby_changed.emit()
	return status


func _relay_opened() -> void:
	last_seen = {}
	if is_host():
		status = "Lobby offen! Gib deinen Freunden den Code: %s" % code
		_broadcast_lobby()
	else:
		status = "Suche Lobby %s …" % code
		_send("hello", _me())
		_ping_t = 2.0
		_wait_t = 0.0
	lobby_changed.emit()


func _relay_failed(reason: String) -> void:
	status = reason
	var was := online
	leave_keep_status()
	if was and game != null and game.is_online():
		game.show_msg("Verbindung verloren: " + reason, 4.0, Color(1.0, 0.3, 0.25))


# ---------------------------------------------------------------- lobby: IP (ENet, same WLAN / Tailscale)
func host() -> String:
	leave()
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PEERS)
	if err != OK:
		status = "Lobby konnte nicht gestartet werden (Port %d belegt? Fehler %d)." % [PORT, err]
		return status
	multiplayer.multiplayer_peer = peer
	mode = "ip"
	id = 1
	online = true
	players = {1: _me()}
	host_cfg_from_settings()
	status = "Lobby läuft. Freunde im gleichen WLAN verbinden sich mit deiner IP-Adresse."
	lobby_changed.emit()
	_open_router_port()
	return status


func join(ip: String) -> String:
	leave()
	ip = ip.strip_edges().get_slice(" ", 0)
	if ip == "":
		status = "Bitte die IP-Adresse des Hosts eingeben."
		return status
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK:
		status = "Verbindung fehlgeschlagen (Fehler %d)." % err
		return status
	multiplayer.multiplayer_peer = peer
	mode = "ip"
	online = true
	status = "Verbinde mit %s …" % ip
	return status


func _on_connected() -> void:
	id = multiplayer.get_unique_id()
	status = "Verbunden! Warte auf den Start durch den Host."
	_send("hello", _me(), 1)
	lobby_changed.emit()


func _on_failed() -> void:
	status = "Host nicht erreichbar. Tipp: Mit Lobby-Code verbinden – das klappt überall."
	leave_keep_status()


func _on_server_gone() -> void:
	status = "Der Host hat die Lobby geschlossen."
	leave_keep_status()
	if game != null and game.is_online():
		game.show_msg("Verbindung zum Host verloren", 4.0, Color(1.0, 0.3, 0.25))


func _open_router_port() -> void:
	if upnp_state == "busy":
		return
	upnp_state = "busy"
	ext_ip = ""
	_upnp_thread = Thread.new()
	_upnp_thread.start(_upnp_work)


func _upnp_work() -> void:
	var u := UPNP.new()
	var ok := false
	var ip := ""
	if u.discover(2500, 2, "InternetGatewayDevice") == UPNP.UPNP_RESULT_SUCCESS and u.get_gateway() != null and u.get_gateway().is_valid_gateway():
		ok = u.add_port_mapping(PORT, PORT, "Trois Forets 24", "UDP", 0) == UPNP.UPNP_RESULT_SUCCESS
		ip = u.query_external_address()
	call_deferred("_upnp_done", u, ok, ip)


func _upnp_done(u: UPNP, ok: bool, ip: String) -> void:
	if _upnp_thread != null:
		_upnp_thread.wait_to_finish()
		_upnp_thread = null
	_upnp = u if ok else null
	ext_ip = ip
	upnp_state = "ok" if ok else "fail"
	lobby_changed.emit()


# ---------------------------------------------------------------- lobby (both modes)
func leave() -> void:
	status = ""
	leave_keep_status()


func leave_keep_status() -> void:
	if mode == "code" and relay != null:
		if relay.is_open():
			relay.send("bye", {})
		relay.close()
	if _upnp != null:
		_upnp.delete_port_mapping(PORT, "UDP")
		_upnp = null
		upnp_state = ""
	if peer != null:
		peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	peer = null
	mode = ""
	online = false
	players = {}
	ready_peers = {}
	corr = {}
	corr_psi = {}
	last_seen = {}
	code = ""
	lobby_changed.emit()


func _register(from: int, info: Dictionary) -> void:
	var mine := Updater.installed_number()
	if int(info.get("ver", 0)) != mine:
		_send("rejected", {"to": from, "why": "Andere Spielversion: Host hat Version %d, du hast %d. Im Hauptmenü auf UPDATE drücken, dann neu verbinden." % [mine, int(info.get("ver", 0))]}, from)
		return
	if game != null and game.is_online():
		_send("rejected", {"to": from, "why": "Das Rennen läuft schon – warte bis zur nächsten Lobby."}, from)
		return
	var cap := int(lobby_cfg.get("max_humans", MAX_PEERS))
	if not players.has(from) and players.size() >= cap:
		_send("rejected", {"to": from, "why": "Die Lobby ist voll (%d Fahrer)." % cap}, from)
		return
	players[from] = info
	_broadcast_lobby()


func _broadcast_lobby() -> void:
	if not is_host():
		return
	players[1] = _me()
	var ps := {}
	for k in players.keys():
		ps[str(k)] = players[k]
	_send("lobby", {"players": ps, "cfg": lobby_cfg})
	lobby_changed.emit()


# my class / ready flag changed in the lobby
func update_me() -> void:
	if not online:
		return
	if is_host():
		_broadcast_lobby()
	else:
		players[id] = _me()
		_send("hello", players[id], 1)
		lobby_changed.emit()


func set_ready(r: bool) -> void:
	if not online:
		return
	var me := _me()
	me["ready"] = r
	players[id] = me
	if is_host():
		_broadcast_lobby()
	else:
		_send("hello", me, 1)
		lobby_changed.emit()


func set_cfg(k: String, v) -> void:
	if not is_host():
		return
	lobby_cfg[k] = v
	game.settings[k] = v
	_broadcast_lobby()


func everyone_ready() -> bool:
	for k in players.keys():
		if int(k) != 1 and not bool(players[k].get("ready", false)):
			return false
	return players.size() >= 1


func _peer_gone(pid: int) -> void:
	if pid == 1 and not is_host() and online:
		status = "Der Host hat die Lobby geschlossen."
		leave_keep_status()
		if game != null and game.is_online():
			game.show_msg("Verbindung zum Host verloren", 4.0, Color(1.0, 0.3, 0.25))
		return
	if not players.has(pid):
		return
	players.erase(pid)
	ready_peers.erase(pid)
	last_seen.erase(pid)
	if is_host():
		_broadcast_lobby()
	if game != null and game.is_online():
		for c in game.cars:
			if c.has_meta("peer") and int(c.get_meta("peer")) == pid:
				c.retired = true
				c.u = 0.0
	lobby_changed.emit()


func _process(dt: float) -> void:
	if mode != "code" or not relay.is_open():
		return
	# keep-alive and timeouts (the server channel has no "disconnected" event)
	_ping_t -= dt
	if _ping_t <= 0.0:
		_ping_t = 2.0
		if is_host():
			if game == null or not game.is_online():
				_broadcast_lobby()
			else:
				_send("ping", 0)
		else:
			if players.has(id):
				_send("ping", 0)
			else:
				_send("hello", _me())       # still waiting for the host's answer
	for k in last_seen.keys():
		last_seen[k] += dt
		if last_seen[k] > TIMEOUT:
			last_seen.erase(k)
			_peer_gone(int(k))
	if not is_host() and not players.has(id):
		_wait_t += dt
		if _wait_t > 10.0:
			status = "Keine Lobby mit dem Code %s gefunden. Code richtig? Ist die Lobby des Hosts offen?" % code
			leave_keep_status()


# ---------------------------------------------------------------- race start
func start_online_race() -> void:
	if not is_host():
		return
	players[1] = _me()
	for k in lobby_cfg.keys():
		game.settings[k] = lobby_cfg[k]
	var s: Dictionary = game.settings
	var grid: Array = []
	# humans first (in join order), then AI cars of the chosen classes
	var ids: Array = players.keys()
	ids.sort()
	var watchers: Array = []
	for pid in ids:
		var pl: Dictionary = players[pid]
		var e := {"cls": pl["cls"], "model": String(pl.get("model", "amg")), "team": [pl["team"], pl["c1"], pl["c2"], pl.get("c3", "ffffff"), int(pl["number"])], "peer": int(pid), "driver": pl["name"],
			"spec": bool(pl.get("spec", false))}
		if e["spec"]:
			watchers.append(e)          # spectators: a parked car at the end of the list, never on the grid
		else:
			grid.append(e)
	for k in int(s.get("n_hy", 0)):
		var t: Array = game._team("hyper", k)
		grid.append({"cls": "hyper", "team": [t[0], Color(t[1]).to_html(), Color(t[2]).to_html(), Color(t[3]).to_html(), t[4]], "peer": 0})
	for k in int(s.get("n_gt3", 0)):
		var t: Array = game._team("gt3", k)
		grid.append({"cls": "gt3", "model": game.ai_model(k), "team": [t[0], Color(t[1]).to_html(), Color(t[2]).to_html(), Color(t[3]).to_html(), t[4]], "peer": 0})
	grid.append_array(watchers)
	var cfg := {"grid": grid, "lights": 6.0 + randf() * 1.6}
	for k in CFG_KEYS:
		cfg[k] = s.get(k)
	ready_peers = {}
	_send("begin", cfg)
	_begin_race(cfg)


func _begin_race(cfg: Dictionary) -> void:
	# colours travel as html strings
	cfg = cfg.duplicate(true)
	var grid: Array = cfg["grid"]
	for g in grid:
		var gd: Dictionary = g
		var t: Array = gd["team"]
		gd["team"] = [t[0], Color.html(String(t[1])), Color.html(String(t[2])), Color.html(String(t[3])), int(t[4])]
		gd["player"] = false
		gd["peer"] = int(gd["peer"])
	game.start_online(cfg)


func send_ready() -> void:
	if not online:
		return
	for k in game.cars.size():
		var c = game.cars[k]
		var g: Dictionary = game.online_grid[k]
		c.set_meta("peer", int(g.get("peer", 0)))
	if is_host():
		ready_peers[1] = true
	else:
		_send("ready", 0, 1)


func all_ready() -> bool:
	for pid in players.keys():
		if not ready_peers.has(pid):
			return false
	return true


func send_go() -> void:
	_send("go", 0)


# ---------------------------------------------------------------- car states
# send rate: through the server the free plan allows 100 messages per second for everybody together,
# so fewer updates per player the more players there are (dead reckoning fills the gaps)
func send_hz() -> float:
	if mode == "ip":
		return 30.0
	var n := maxi(1, players.size())
	return clampf(80.0 / float(n * n), 3.0, 12.0)


func tick(dt: float) -> void:
	if not online or game.cars.is_empty():
		return
	send_acc += dt
	if send_acc < 1.0 / send_hz():
		return
	send_acc = 0.0
	var me := my_id()
	var host := is_host()
	var buf := PackedByteArray()
	for k in game.cars.size():
		var c = game.cars[k]
		var p: int = int(c.get_meta("peer", 0))
		if p == me or (p == 0 and host):
			buf.append_array(_pack(k, c))
	if buf.size() > 0:
		_send_fast("st", Marshalls.raw_to_base64(buf) if mode == "code" else buf)


# one car state in 40 bytes (was 72): positions/heading/track position as 32-bit floats, the rest as
# 16-bit values - plenty of precision for drawing the car and its gauges
func _pack(k: int, c) -> PackedByteArray:
	var b := PackedByteArray()
	b.resize(STRIDE)
	b.encode_u8(0, k)
	b.encode_u8(1, (1 if c.in_pit else 0) | (2 if c.retired else 0) | (clampi(int(c.gear) + 1, 0, 15) << 2))
	b.encode_float(2, c.x)
	b.encode_float(6, c.y)
	b.encode_float(10, c.z)
	b.encode_float(14, c.psi)
	b.encode_float(18, c.s)
	b.encode_half(22, c.u)
	b.encode_half(24, c.v)
	b.encode_half(26, c.r)
	b.encode_half(28, c.steer)
	b.encode_half(30, c.throttle)
	b.encode_half(32, c.brake)
	b.encode_half(34, c.lat)
	b.encode_u16(36, clampi(int(c.rpm), 0, 65535))
	b.encode_s16(38, clampi(int(c.lap), -32768, 32767))
	return b


func _states(buf: PackedByteArray) -> void:
	if game == null or game.cars.is_empty():
		return
	var n := buf.size() / STRIDE
	for q in n:
		var o := q * STRIDE
		var k := buf.decode_u8(o)
		if k < 0 or k >= game.cars.size():
			continue
		var c = game.cars[k]
		if not c.remote:
			continue
		var fl := buf.decode_u8(o + 1)
		var psi := buf.decode_float(o + 14)
		c.u = buf.decode_half(o + 22)
		c.v = buf.decode_half(o + 24)
		c.r = buf.decode_half(o + 26)
		# the packet is already a little old when it arrives: move it forward by the typical latency, then
		# blend position and heading over the next frames instead of jumping (dead_reckon)
		var lag := 0.06
		var cp := cos(psi)
		var sp := sin(psi)
		var target := Vector3(buf.decode_float(o + 2) + (c.u * cp - c.v * sp) * lag, buf.decode_float(o + 6), buf.decode_float(o + 10) + (c.u * sp + c.v * cp) * lag)
		var err := target - Vector3(c.x, c.y, c.z)
		var perr := angle_difference(c.psi, psi + c.r * lag)
		if err.length() > 25.0:
			c.x = target.x
			c.y = target.y
			c.z = target.z
			c.psi = psi
			corr[k] = Vector3.ZERO
			corr_psi[k] = 0.0
		else:
			corr[k] = err
			corr_psi[k] = perr
		c.steer = buf.decode_half(o + 28)
		c.throttle = buf.decode_half(o + 30)
		c.brake = buf.decode_half(o + 32)
		c.lat = buf.decode_half(o + 34)
		c.rpm = buf.decode_u16(o + 36)
		c.lap = buf.decode_s16(o + 38)
		c.gear = ((fl >> 2) & 15) - 1
		c.s = buf.decode_float(o + 18)
		c.in_pit = (fl & 1) != 0
		c.retired = (fl & 2) != 0


# remote cars between packets: keep moving with their last speed, blend in the correction
func dead_reckon(c, dt: float) -> void:
	var k: int = c.get_meta("car_k", -1)
	if k < 0:
		k = game.cars.find(c)
		c.set_meta("car_k", k)
	var wv: Vector2 = c.world_vel()
	c.x += wv.x * dt
	c.z += wv.y * dt
	c.psi += c.r * dt
	if corr.has(k):
		var e: Vector3 = corr[k]
		var f := minf(1.0, dt * 6.0)
		c.x += e.x * f
		c.y += e.y * f
		c.z += e.z * f
		corr[k] = e * (1.0 - f)
	if corr_psi.has(k):
		var pe: float = corr_psi[k]
		var fp := minf(1.0, dt * 8.0)
		c.psi += pe * fp
		corr_psi[k] = pe * (1.0 - fp)
	c.idx = game.T.idx(c.s)

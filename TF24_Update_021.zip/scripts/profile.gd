# Local driver profiles: name, team, country, number, colours, optional password, career statistics,
# driver rating (DR) and safety rating (SR) and the latest results. Stored in user://profiles.cfg.
extends RefCounted

const FILE := "user://profiles.cfg"

static var profiles: Array = []      # Dictionaries
static var current: Dictionary = {}
static var last_id := ""


static func _new_stats() -> Dictionary:
	return {"races": 0, "wins": 0, "class_wins": 0, "podiums": 0, "poles": 0, "fastest_laps": 0, "laps": 0,
		"km": 0.0, "dnf": 0, "clean": 0, "quali": 0, "practice": 0, "time": 0.0, "best": {}}


static func make(pname: String, team: String, country: String, number: int, c1: Color, c2: Color, password: String) -> Dictionary:
	return {
		"id": str(Time.get_unix_time_from_system()) + "_" + str(randi() % 100000),
		"name": pname.strip_edges(), "team": team.strip_edges(), "country": country, "number": clampi(number, 1, 999),
		"c1": c1, "c2": c2, "pw": _hash(password) if password != "" else "",
		"created": Time.get_date_string_from_system(), "dr": 1200.0, "sr": 45.0,
		"stats": _new_stats(), "history": [],
	}


static func _hash(pw: String) -> String:
	return ("tf24:" + pw).sha256_text()


static func check_password(p: Dictionary, pw: String) -> bool:
	return String(p.get("pw", "")) == "" or String(p["pw"]) == _hash(pw)


static func set_password(p: Dictionary, pw: String) -> void:
	p["pw"] = _hash(pw) if pw != "" else ""


static func load_all() -> void:
	profiles.clear()
	var cf := ConfigFile.new()
	if cf.load(FILE) != OK:
		return
	last_id = cf.get_value("meta", "last", "")
	for sec in cf.get_sections():
		if sec == "meta":
			continue
		var d = cf.get_value(sec, "data", null)
		if d is Dictionary:
			var pd: Dictionary = d
			# fill keys added in later versions
			var st: Dictionary = pd.get("stats", {})
			var base := _new_stats()
			for k in base.keys():
				if not st.has(k):
					st[k] = base[k]
			pd["stats"] = st
			if not pd.has("history"):
				pd["history"] = []
			profiles.append(pd)


static func save_all() -> void:
	var cf := ConfigFile.new()
	cf.set_value("meta", "last", last_id)
	for p in profiles:
		var pd: Dictionary = p
		cf.set_value("p_" + String(pd["id"]), "data", pd)
	cf.save(FILE)
	# a profile linked to an online account is uploaded too
	if Engine.has_meta("account"):
		var acc = Engine.get_meta("account")
		if is_instance_valid(acc):
			acc.push_soon()


static func add(p: Dictionary) -> void:
	profiles.append(p)
	login(p)


static func remove(p: Dictionary) -> void:
	profiles.erase(p)
	if current == p:
		current = {}
	save_all()


static func login(p: Dictionary) -> void:
	current = p
	last_id = String(p["id"])
	save_all()


static func logout() -> void:
	current = {}


static func logged_in() -> bool:
	return not current.is_empty()


static func last_profile() -> Dictionary:
	for p in profiles:
		var pd: Dictionary = p
		if String(pd["id"]) == last_id:
			return pd
	return {} if profiles.is_empty() else profiles[0]


# ---------------------------------------------------------------- ranks
# DR: Bronze < 1600 <= Silber < 2200 <= Gold < 2800 <= Platin, three levels per tier
static func dr_tier(dr: float) -> Array:
	var tiers := [["BRONZE", 0.0, 1600.0], ["SILBER", 1600.0, 2200.0], ["GOLD", 2200.0, 2800.0], ["PLATIN", 2800.0, 3400.0]]
	return _tier(dr, tiers)


static func sr_tier(sr: float) -> Array:
	var tiers := [["BRONZE", 0.0, 40.0], ["SILBER", 40.0, 60.0], ["GOLD", 60.0, 80.0], ["PLATIN", 80.0, 100.01]]
	return _tier(sr, tiers)


# -> [tier name, level 1..3, progress inside the level 0..1]
static func _tier(v: float, tiers: Array) -> Array:
	for t in tiers:
		var ta: Array = t
		var lo: float = ta[1]
		var hi: float = ta[2]
		if v < hi or ta == tiers[tiers.size() - 1]:
			var f := clampf((v - lo) / (hi - lo), 0.0, 0.9999)
			var lv := 3 - int(f * 3.0)          # level 3 = entry, level 1 = top of the tier
			return [ta[0], lv, fmod(f * 3.0, 1.0)]
	return ["BRONZE", 3, 0.0]


static func short_rank(tier: Array) -> String:
	return String(tier[0]).substr(0, 1) + str(tier[1])


# ---------------------------------------------------------------- results
# r: {session, track, track_name, cls, pos, cls_pos, field, cls_field, best, laps, km, fastest, pole,
#     incidents, finished, time, ai}
static func record(r: Dictionary) -> Dictionary:
	if current.is_empty():
		return {}
	var st: Dictionary = current["stats"]
	var ses: String = r.get("session", "race")
	st["laps"] = int(st["laps"]) + int(r.get("laps", 0))
	st["km"] = float(st["km"]) + float(r.get("km", 0.0))
	st["time"] = float(st["time"]) + float(r.get("time", 0.0))
	var best: float = r.get("best", -1.0)
	var key := String(r.get("track", "")) + "_" + String(r.get("cls", ""))
	var bests: Dictionary = st["best"]
	if best > 0.0 and (not bests.has(key) or best < float(bests[key])):
		bests[key] = best
	var d_dr := 0.0
	var d_sr := 0.0
	var inc: int = r.get("incidents", 0)
	if ses == "race":
		st["races"] = int(st["races"]) + 1
		var pos: int = r.get("cls_pos", r.get("pos", 1))
		var n: int = maxi(2, int(r.get("cls_field", r.get("field", 2))))
		if not r.get("finished", true):
			st["dnf"] = int(st["dnf"]) + 1
		else:
			if int(r.get("pos", 99)) == 1:
				st["wins"] = int(st["wins"]) + 1
			if pos == 1:
				st["class_wins"] = int(st["class_wins"]) + 1
			if pos <= 3:
				st["podiums"] = int(st["podiums"]) + 1
		if r.get("fastest", false):
			st["fastest_laps"] = int(st["fastest_laps"]) + 1
		# DR: result against the field, weighted by the AI strength
		var perf := 1.0 - float(pos - 1) / float(n - 1)
		var ai: float = r.get("ai", 90.0) / 100.0
		d_dr = (perf - 0.45) * 60.0 * ai * (0.4 if not r.get("finished", true) else 1.0)
		# SR: clean races go up, incidents (track limits, penalties, contact) go down
		if inc == 0 and r.get("finished", true):
			st["clean"] = int(st["clean"]) + 1
		d_sr = 2.5 - inc * 2.0
	else:
		st[ses] = int(st.get(ses, 0)) + 1
		if ses == "quali" and r.get("pole", false):
			st["poles"] = int(st["poles"]) + 1
		d_sr = 0.8 - inc * 1.0
	current["dr"] = clampf(float(current["dr"]) + d_dr, 800.0, 3400.0)
	current["sr"] = clampf(float(current["sr"]) + d_sr, 0.0, 100.0)
	var h: Array = current["history"]
	var entry := r.duplicate()
	entry["date"] = Time.get_date_string_from_system()
	entry["d_dr"] = d_dr
	entry["d_sr"] = d_sr
	h.push_front(entry)
	while h.size() > 20:
		h.pop_back()
	save_all()
	return entry

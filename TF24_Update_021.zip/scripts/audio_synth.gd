# Car audio, sample based: engine loops are synthesised once at start-up (physically inspired: firing
# pulses through exhaust resonances) for three rpm bands and two loads, then played on Godot's audio
# thread and only pitched / cross-faded per frame -> no crackles or pitch jumps when the frame rate dips,
# the window loses focus or the camera changes. Plus turbo, gearbox whine, tyres, road, wind, curbs,
# gravel, backfire pops on lift-off and downshifts, shift clunks and 3D sound for nearby rivals.
extends Node

const SR := 32000
# recording rpms of the engine loops: many bands -> small pitch shifts -> exhaust resonances stay put
const BANDS := {"hyper": [2400.0, 4200.0, 6000.0, 7800.0, 9300.0], "gt3": [1300.0, 2600.0, 3900.0, 5200.0, 6500.0, 7900.0]}

var muted := false:
	set(v):
		muted = v
		AudioServer.set_bus_mute(_bus, v)
var _bus := 0
var _lp: AudioEffectLowPassFilter
var bank := {}            # "hyper"/"gt3" -> {"on": [wav x3], "off": [wav x3]}
var loops := {}           # name -> AudioStreamWAV
var oneshots := {}
var eng: Array = []       # [band][load] AudioStreamPlayer for the player's car
var eng_key := ""
var lay := {}             # extra loop players
var gain := {}            # smoothed gains
var pool: Array = []
var pool_i := 0
var rivals: Array = []    # AudioStreamPlayer3D pairs for the nearest cars
var pop_t := 0.0
var lift_t := 0.0
var prev_thr := 0.0
var prev_gear := 1
var rng := RandomNumberGenerator.new()
var engine_gain := 1.0
var blip_t := 0.0


func _ready() -> void:
	rng.seed = 42
	# reuse the "Car" bus if it already exists (never stack buses), and always start unmuted
	_bus = AudioServer.get_bus_index("Car")
	if _bus < 0:
		AudioServer.add_bus()
		_bus = AudioServer.bus_count - 1
		AudioServer.set_bus_name(_bus, "Car")
	else:
		while AudioServer.get_bus_effect_count(_bus) > 0:
			AudioServer.remove_bus_effect(_bus, 0)
	AudioServer.set_bus_mute(_bus, false)
	AudioServer.set_bus_send(_bus, "Master")
	_lp = AudioEffectLowPassFilter.new()
	_lp.cutoff_hz = 16000.0
	AudioServer.add_bus_effect(_bus, _lp)
	var comp := AudioEffectCompressor.new()
	comp.threshold = -10.0
	comp.ratio = 3.0
	AudioServer.add_bus_effect(_bus, comp)
	var lim := AudioEffectHardLimiter.new()
	lim.ceiling_db = -0.5
	AudioServer.add_bus_effect(_bus, lim)
	AudioServer.set_bus_volume_db(_bus, -4.0)
	_build_bank("hyper", 6, false, 1.25)
	_build_bank("gt3", 8, true, 0.85)
	loops["turbo"] = _tone_loop(1000.0, 0.15, 0.35)
	loops["whine"] = _tone_loop(800.0, 0.35, 0.05)
	loops["squeal"] = _resonant_noise_loop([[850.0, 18.0, 1.0], [1750.0, 14.0, 0.45], [2600.0, 10.0, 0.2]], 1.2, 0.5)
	loops["road"] = _filtered_noise_loop(0.012, 0.0, 1.6)
	loops["wind"] = _filtered_noise_loop(0.07, 0.01, 2.0)
	loops["gravel"] = _gravel_loop()
	loops["curb"] = _curb_loop()
	oneshots["pop"] = _pop()
	oneshots["pop2"] = _pop(0.6)
	oneshots["clunk"] = _clunk()
	oneshots["bov"] = _blowoff()
	oneshots["gun"] = _wheel_gun()
	oneshots["hiss"] = _air_hiss()
	oneshots["radio"] = _radio_click()
	oneshots["dog"] = _dog_clack()
	oneshots["air"] = _shift_air()
	oneshots["cut"] = _ignition_cut()
	for nm in ["turbo", "whine", "squeal", "road", "wind", "gravel", "curb"]:
		lay[nm] = _player(loops[nm])
		gain[nm] = 0.0
	for k in 8:
		var p := AudioStreamPlayer.new()
		p.bus = "Car"
		add_child(p)
		pool.append(p)
	for k in 3:
		var pair: Array = []
		for b in 2:
			var p3 := AudioStreamPlayer3D.new()
			p3.bus = "Car"
			p3.unit_size = 9.0
			p3.max_distance = 320.0
			p3.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
			p3.doppler_tracking = AudioStreamPlayer3D.DOPPLER_TRACKING_IDLE_STEP
			p3.volume_db = -80.0
			add_child(p3)
			pair.append(p3)
		rivals.append({"players": pair, "key": ""})


# ---------------------------------------------------------------- synthesis helpers
func _wav(buf: PackedFloat32Array, loop: bool) -> AudioStreamWAV:
	var peak := 0.0001
	for v in buf:
		peak = maxf(peak, absf(v))
	var data := PackedByteArray()
	data.resize(buf.size() * 2)
	var k := 0.9 / peak
	for i in buf.size():
		data.encode_s16(i * 2, int(clampf(buf[i] * k, -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = SR
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = buf.size()
	return w


# RBJ band-pass biquad coefficients [b0, b2, a1, a2] (b1 = 0)
func _bp(f: float, q: float) -> PackedFloat32Array:
	var w0 := TAU * f / SR
	var al := sin(w0) / (2.0 * q)
	var a0 := 1.0 + al
	return PackedFloat32Array([al / a0, -al / a0, -2.0 * cos(w0) / a0, (1.0 - al) / a0])


# runs the input twice through a bank of resonators so the filter state at the loop end equals the start
func _resonate(x: PackedFloat32Array, res: Array) -> PackedFloat32Array:
	var n := x.size()
	var y := PackedFloat32Array()
	y.resize(n)
	y.fill(0.0)
	for r in res:
		var f: float = r[0]
		var q: float = r[1]
		var g: float = r[2]
		var c := _bp(f, q)
		var x1 := 0.0
		var x2 := 0.0
		var y1 := 0.0
		var y2 := 0.0
		for _rep in 2:
			for i in n:
				var xi := x[i]
				var yi := c[0] * xi + c[1] * x2 - c[2] * y1 - c[3] * y2
				x2 = x1
				x1 = xi
				y2 = y1
				y1 = yi
				if _rep == 1:
					y[i] += yi * g
	return y


func _build_bank(key: String, cyl: int, crossplane: bool, bright: float) -> void:
	var b := {"on": [], "off": []}
	for rpm_base in BANDS[key]:
		var rb: float = rpm_base
		for ld in ["on", "off"]:
			b[ld].append(_engine_loop(cyl, rb, ld == "on", crossplane, bright))
	bank[key] = b


# One engine loop recorded at a fixed rpm. Each cylinder bank has its own exhaust pipe:
# the AMG M159 6.2 V8 is a cross-plane engine (firing order 1-5-4-8-6-3-7-2), so each bank fires at
# 180-270-180-90 degree intervals -> the deep, uneven V8 burble. The GT3 race exhaust (side exits,
# one per bank, no silencers) adds a hard rasp; on the overrun the pulses are weak and irregular (crackle).
func _engine_loop(cyl: int, rpm: float, on: bool, crossplane: bool, bright: float) -> AudioStreamWAV:
	var cyc := int(roundf(120.0 / rpm * SR))          # samples per 4-stroke cycle (2 revolutions)
	var ncyc := maxi(8, int(0.6 * SR / cyc))
	var n := cyc * ncyc
	var fire: Array = []
	if crossplane and cyl == 8:
		fire = [[0.0, 180.0, 450.0, 630.0], [90.0, 270.0, 360.0, 540.0]]
	else:
		fire = [[], []]
		for k in cyl:
			var fa: Array = fire[k % 2]
			fa.append(720.0 * k / cyl)
	var tau := (0.0011 if on else 0.0008) * SR
	var att := maxi(2, int(0.00015 * SR))
	var plen := int(tau * 6.0)
	var low := clampf(1.0 - (rpm - 1500.0) / 4000.0, 0.0, 1.0)      # low rpm: lumpier
	var out := PackedFloat32Array()
	out.resize(n)
	out.fill(0.0)
	var env_all := PackedFloat32Array()
	env_all.resize(n)
	env_all.fill(0.0)
	for bk in 2:
		var x := PackedFloat32Array()
		x.resize(n)
		x.fill(0.0)
		var angles: Array = fire[bk]
		for c in ncyc:
			for ang in angles:
				var start := c * cyc + int(float(ang) / 720.0 * cyc)
				var amp: float
				if on:
					amp = 1.0 + rng.randf_range(-0.07, 0.07) * (1.0 + low * 2.0)
				else:
					amp = 0.32 * (1.0 + rng.randf_range(-0.35, 0.35))
					if rng.randf() < 0.1:
						amp *= 0.15          # near-misfire on the overrun
					elif rng.randf() < 0.05:
						amp *= 2.2           # unburnt fuel lights in the pipe
				for j in plen:
					var e := float(j) / att if j < att else exp(-float(j - att) / tau)
					var ix := (start + j) % n
					x[ix] += amp * e
					env_all[ix] = maxf(env_all[ix], amp * e)
		# pipe resonances (bank 2 pipe slightly shorter); fixed in Hz like a real exhaust
		var pf := 1.0 if bk == 0 else 1.07
		var res: Array
		if on:
			res = [[72.0 * bright * pf, 2.0, 1.0], [165.0 * bright * pf, 2.8, 0.85], [390.0 * bright * pf, 3.5, 0.6], [880.0 * bright * pf, 4.5, 0.32], [2100.0 * bright * pf, 5.0, 0.13]]
		else:
			res = [[68.0 * bright * pf, 2.5, 1.0], [150.0 * bright * pf, 3.5, 0.6], [360.0 * bright * pf, 4.0, 0.3], [1100.0 * bright * pf, 5.0, 0.12]]
		var y := _resonate(x, res)
		# the far bank arrives a little later and quieter
		var dl := 0 if bk == 0 else int(0.0009 * SR)
		var g := 1.0 if bk == 0 else 0.78
		for i in n:
			out[(i + dl) % n] += y[i] * g
	# combustion / exhaust rasp: noise gated by the pulses, brighter with load and rpm
	var rasp := (0.22 if on else 0.1) * bright * (0.5 + rpm / 8000.0)
	var prev := 0.0
	var lp := 0.0
	for i in n:
		var r := rng.randf_range(-1.0, 1.0)
		var hp := r - prev                  # crude high-pass -> raspy
		prev = r
		lp += (hp - lp) * 0.6
		var v := out[i] * 2.0 + lp * rasp * (0.25 + env_all[i])
		out[i] = tanh(v * (1.9 if on else 1.2))
	return _wav(out, true)


func _tone_loop(freq: float, h2: float, noise: float) -> AudioStreamWAV:
	var per := int(SR / freq)
	var fq := float(SR) / per
	var n := per * int(fq * 0.5)
	var b := PackedFloat32Array()
	b.resize(n)
	for i in n:
		var t := TAU * fq * i / SR
		b[i] = sin(t) + h2 * sin(2.0 * t) + rng.randf_range(-noise, noise)
	return _wav(b, true)


func _filtered_noise_loop(lp_k: float, hp_k: float, secs: float) -> AudioStreamWAV:
	var n := int(SR * secs)
	var b := PackedFloat32Array()
	b.resize(n)
	var lp := 0.0
	var hp := 0.0
	for _rep in 2:
		for i in n:
			lp += (rng.randf_range(-1.0, 1.0) - lp) * lp_k
			hp += (lp - hp) * hp_k
			if _rep == 1:
				b[i] = lp - hp
	return _wav(b, true)


func _resonant_noise_loop(res: Array, secs: float, flutter: float) -> AudioStreamWAV:
	var n := int(SR * secs)
	var x := PackedFloat32Array()
	x.resize(n)
	for i in n:
		var am := 1.0 - flutter * 0.5 * (1.0 + sin(TAU * 8.0 * i / n) * sin(TAU * 3.0 * i / n))
		x[i] = rng.randf_range(-1.0, 1.0) * am
	return _wav(_resonate(x, res), true)


func _gravel_loop() -> AudioStreamWAV:
	var n := int(SR * 1.5)
	var b := PackedFloat32Array()
	b.resize(n)
	b.fill(0.0)
	for k in 900:
		var p := rng.randi_range(0, n - 1)
		var a := rng.randf_range(0.2, 1.0)
		for j in 60:
			b[(p + j) % n] += a * rng.randf_range(-1.0, 1.0) * exp(-j / 12.0)
	var lp := 0.0
	for i in n:
		lp += (rng.randf_range(-1.0, 1.0) - lp) * 0.02
		b[i] += lp * 2.0
	return _wav(b, true)


func _curb_loop() -> AudioStreamWAV:
	# 10 thumps per loop -> pitch_scale maps speed to the kerb-stripe rate
	var n := SR
	var b := PackedFloat32Array()
	b.resize(n)
	b.fill(0.0)
	for k in 10:
		var p := k * n / 10
		for j in 1200:
			var t := float(j) / SR
			b[(p + j) % n] += sin(TAU * 70.0 * t) * exp(-t * 60.0) + rng.randf_range(-0.3, 0.3) * exp(-t * 120.0)
	return _wav(b, true)


func _pop(dark: float = 1.0) -> AudioStreamWAV:
	var n := int(SR * 0.12)
	var x := PackedFloat32Array()
	x.resize(n)
	for i in n:
		var t := float(i) / SR
		x[i] = rng.randf_range(-1.0, 1.0) * exp(-t * 45.0) + (1.0 if i < 40 else 0.0)
	var y := _resonate(x, [[180.0 * dark, 2.0, 1.0], [520.0 * dark, 3.0, 0.6], [1400.0, 2.0, 0.3]])
	for i in n:
		y[i] = tanh(y[i] * 3.0)
	return _wav(y, false)


func _clunk() -> AudioStreamWAV:
	var n := int(SR * 0.08)
	var b := PackedFloat32Array()
	b.resize(n)
	for i in n:
		var t := float(i) / SR
		b[i] = sin(TAU * 110.0 * t) * exp(-t * 70.0) + rng.randf_range(-0.6, 0.6) * exp(-t * 300.0)
	return _wav(b, false)


# dog-ring engagement of a sequential racing gearbox: hard metallic "clack" (steel on steel, ringing
# 1.8-4.5 kHz) plus the thump of the shift barrel through the chassis
func _dog_clack() -> AudioStreamWAV:
	var n := int(SR * 0.16)
	var b := PackedFloat32Array()
	b.resize(n)
	var modes := [[1870.0, 38.0, 0.6], [2730.0, 55.0, 0.45], [3910.0, 70.0, 0.3], [4560.0, 90.0, 0.2]]
	var lp := 0.0
	for i in n:
		var t := float(i) / SR
		var v := 0.0
		for m in modes:
			var md: Array = m
			v += sin(TAU * float(md[0]) * t + float(md[0]) * 0.001) * exp(-t * float(md[1])) * float(md[2])
		var nz := rng.randf_range(-1.0, 1.0)
		lp += (nz - lp) * 0.2
		v += nz * exp(-t * 900.0) * 0.9                      # contact transient
		v += sin(TAU * 72.0 * t) * exp(-t * 45.0) * 0.8      # body thump
		v += lp * exp(-t * 120.0) * 0.3
		b[i] = v
	return _wav(b, false)


# pneumatic shift actuator: short, sharp air puff
func _shift_air() -> AudioStreamWAV:
	var n := int(SR * 0.12)
	var b := PackedFloat32Array()
	b.resize(n)
	var prev := 0.0
	for i in n:
		var t := float(i) / SR
		var nz := rng.randf_range(-1.0, 1.0)
		var hp := nz - prev
		prev = nz
		var env := minf(1.0, t * 400.0) * exp(-t * 32.0)
		b[i] = hp * env
	return _wav(b, false)


# upshift ignition cut: the exhaust note drops out for ~50 ms and comes back with a bark
func _ignition_cut() -> AudioStreamWAV:
	var n := int(SR * 0.12)
	var b := PackedFloat32Array()
	b.resize(n)
	var lp := 0.0
	for i in n:
		var t := float(i) / SR
		var nz := rng.randf_range(-1.0, 1.0)
		lp += (nz - lp) * 0.18
		var env := exp(-pow((t - 0.012) * 90.0, 2.0)) + 0.6 * exp(-pow((t - 0.055) * 120.0, 2.0))
		b[i] = (lp * 1.6 + sin(TAU * 95.0 * t) * 0.6) * env
	return _wav(b, false)


func _blowoff() -> AudioStreamWAV:
	var n := int(SR * 0.45)
	var x := PackedFloat32Array()
	x.resize(n)
	for i in n:
		var t := float(i) / SR
		x[i] = rng.randf_range(-1.0, 1.0) * exp(-t * 7.0) * minf(1.0, t * 80.0)
	return _wav(_resonate(x, [[2800.0, 2.0, 1.0], [5200.0, 3.0, 0.5]]), false)


# impact wrench: a fast train of metallic hammer blows (~28 per second) for half a second
func _wheel_gun() -> AudioStreamWAV:
	var n := int(SR * 0.55)
	var x := PackedFloat32Array()
	x.resize(n)
	x.fill(0.0)
	var period := int(SR / 28.0)
	var p := 0
	while p < n:
		var a := rng.randf_range(0.7, 1.0) * (1.0 - float(p) / n * 0.3)
		for j in 260:
			if p + j < n:
				x[p + j] += a * rng.randf_range(-1.0, 1.0) * exp(-j / 40.0)
		p += period
	var y := _resonate(x, [[1900.0, 6.0, 1.0], [3300.0, 8.0, 0.7], [5200.0, 5.0, 0.4], [700.0, 3.0, 0.5]])
	for i in n:
		y[i] = tanh(y[i] * 2.5) * minf(1.0, float(n - i) / (SR * 0.03))
	return _wav(y, false)


# air jack: compressed-air blast that fades out
# radio: squelch burst + click (band-limited like a team radio)
func _radio_click() -> AudioStreamWAV:
	var n := int(0.16 * SR)
	var b := PackedFloat32Array()
	b.resize(n)
	var lp := 0.0
	var lp2 := 0.0
	for i in n:
		var tt := float(i) / SR
		var nz := rng.randf_range(-1.0, 1.0)
		lp += (nz - lp) * 0.35
		lp2 += (lp - lp2) * 0.05
		var bandn := lp - lp2
		var env := exp(-tt * 22.0)
		b[i] = bandn * env * 0.9 + (0.6 if i < 40 else 0.0) * sin(i * 0.9)
	return _wav(b, false)


func radio() -> void:
	_shot("radio", 0.5)


func _air_hiss() -> AudioStreamWAV:
	var n := int(SR * 0.7)
	var x := PackedFloat32Array()
	x.resize(n)
	for i in n:
		var tt := float(i) / SR
		x[i] = rng.randf_range(-1.0, 1.0) * minf(1.0, tt * 60.0) * exp(-tt * 4.0)
	return _wav(_resonate(x, [[3500.0, 1.5, 1.0], [7000.0, 2.0, 0.6], [1200.0, 1.2, 0.3]]), false)


func pit_event(e: String) -> void:
	match e:
		"gun":
			_shot("gun", 0.55, rng.randf_range(0.92, 1.08))
		"jack_up":
			_shot("hiss", 0.45, 1.0)
		"jack_down":
			_shot("hiss", 0.35, 0.85)
			_shot("clunk", 0.4, 0.7)
		"go":
			beep(660.0, 0.15)


func _player(stream: AudioStream) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.bus = "Car"
	p.volume_db = -80.0
	add_child(p)
	p.play()
	return p


func _shot(nm: String, vol: float, pitch: float = 1.0) -> void:
	if muted:
		return
	var p: AudioStreamPlayer = pool[pool_i]
	pool_i = (pool_i + 1) % pool.size()
	p.stream = oneshots[nm]
	p.volume_db = linear_to_db(maxf(0.0001, vol))
	p.pitch_scale = pitch
	p.play()


func _apply(p, g: float, pitch: float) -> void:
	p.volume_db = linear_to_db(maxf(0.00001, g))
	p.pitch_scale = clampf(pitch, 0.3, 3.5)


# ---------------------------------------------------------------- per frame
func _ensure_engine(key: String) -> void:
	if eng_key == key:
		return
	for row in eng:
		for p in row:
			p.queue_free()
	eng.clear()
	var b: Dictionary = bank[key]
	for k in b["on"].size():
		eng.append([_player(b["on"][k]), _player(b["off"][k])])
	eng_key = key


# triangular cross-fade weights over the rpm bands
static func band_weights(rpm: float, bands: Array) -> PackedFloat32Array:
	var nb := bands.size()
	var w := PackedFloat32Array()
	w.resize(nb)
	w.fill(0.0)
	if rpm <= float(bands[0]):
		w[0] = 1.0
	elif rpm >= float(bands[nb - 1]):
		w[nb - 1] = 1.0
	else:
		var k := 0
		while k < nb - 2 and rpm >= float(bands[k + 1]):
			k += 1
		var f: float = (rpm - float(bands[k])) / (float(bands[k + 1]) - float(bands[k]))
		w[k] = cos(f * PI * 0.5)
		w[k + 1] = sin(f * PI * 0.5)
	return w


# called at every race start: everything audible again, rival engines re-assigned
func reset() -> void:
	AudioServer.set_bus_mute(_bus, muted)
	AudioServer.set_bus_volume_db(_bus, -4.0)
	for r in rivals:
		var rd: Dictionary = r
		rd["key"] = ""
	prev_gear = 1
	pop_t = 0.0
	lift_t = 0.0


func update(car, cars: Array, cam: Camera3D, cam_mode: int, dt: float) -> void:
	# self-healing: a loop that stopped for whatever reason starts again, the bus follows `muted`
	if AudioServer.is_bus_mute(_bus) != muted:
		AudioServer.set_bus_mute(_bus, muted)
	for row in eng:
		for p in row:
			var ap: AudioStreamPlayer = p
			if not ap.playing:
				ap.play()
	for nm in lay.keys():
		var lp: AudioStreamPlayer = lay[nm]
		if not lp.playing:
			lp.play()
	var key: String = car.spec["key"]
	_ensure_engine(key)
	var bands: Array = BANDS[key]
	var rpm: float = car.rpm
	var thr: float = car.throttle
	var cut: bool = car.shift_timer > 0.0
	# rev limiter: fuel cut bouncing at ~16 Hz
	if rpm > float(car.spec["rpmMax"]) * 0.985 and thr > 0.5 and fmod(Time.get_ticks_msec() * 0.016, 1.0) < 0.4:
		cut = true
	var eload := 0.0 if cut else clampf(thr * 1.2, 0.0, 1.0)
	# downshift auto-blip: the ECU opens the throttle for ~0.12 s to match revs
	blip_t = maxf(0.0, blip_t - dt)
	if blip_t > 0.0:
		eload = maxf(eload, 0.85)
	var w := band_weights(rpm, bands)
	var inside := cam_mode == 2
	var tv := cam_mode == 4
	var dist := cam.global_position.distance_to(Vector3(car.x, car.y, car.z))
	var master := (1.0 / (1.0 + maxf(0.0, dist - 8.0) * 0.04)) if tv else 1.0
	var eng_vol := (0.55 + 0.45 * eload) * master * (0.8 if inside else 1.0) * engine_gain
	for k in bands.size():
		var pitch: float = rpm / bands[k]
		_apply(eng[k][0], w[k] * eload * eng_vol, pitch)
		_apply(eng[k][1], w[k] * (1.0 - eload) * eng_vol * 0.75, pitch)
	# filtering: muffled inside the cockpit, bright outside
	_lp.cutoff_hz = lerpf(_lp.cutoff_hz, 5200.0 if inside else 17000.0, minf(1.0, dt * 6.0))
	var v: float = absf(car.u)
	var slip := maxf(absf(car.slip_f), absf(car.slip_r))
	var surf: String = car.surface
	var on_road := surf == "asphalt" or surf == "curb" or surf == "pit" or surf == "runoff"
	var sq := 0.0
	if on_road and v > 3.0:
		sq = clampf((slip - 0.06) * 5.0, 0.0, 1.0) * clampf(v / 10.0, 0.0, 1.0)
		if car.lock_f or car.lock_r:
			sq = maxf(sq, 0.85)
		if car.spin_r:
			sq = maxf(sq, 0.7)
	sq *= 1.0 - 0.75 * car.wet
	var targets := {
		"squeal": [sq * 0.9 * master, 0.85 + slip * 1.2 - (0.15 if car.lock_f else 0.0)],
		"road": [clampf(v / 60.0, 0.0, 1.0) * 0.35 * master * (1.0 + car.wet), 0.7 + v / 120.0],
		"wind": [clampf(v * v / 6500.0, 0.0, 0.8) * (0.5 if inside else 1.0) * master, 0.8 + v / 150.0],
		"gravel": [(1.0 if surf == "gravel" or surf == "grass" else 0.0) * clampf(v / 12.0, 0.0, 1.0) * 0.8 * master, 0.8 + v / 60.0],
		"curb": [(1.0 if surf == "curb" else 0.0) * clampf(v / 8.0, 0.0, 1.0) * master, v / 14.0],
		"whine": [clampf(v / 50.0, 0.0, 1.0) * (0.55 if inside else 0.18) * master, 0.4 + v / 45.0],
		"turbo": [(clampf((rpm / car.spec["rpmMax"] - 0.35) * 2.0, 0.0, 1.0) * thr * (0.35 if key == "hyper" else 0.0)) * master, 0.6 + rpm / car.spec["rpmMax"]],
	}
	for nm in targets.keys():
		var tg: Array = targets[nm]
		gain[nm] = lerpf(gain[nm], tg[0], minf(1.0, dt * 14.0))
		_apply(lay[nm], gain[nm], tg[1])
	# events: shifts, lift-off pops, blow-off valve
	var gear: int = car.gear
	if gear != prev_gear:
		# sequential paddle shift: dog clack + air actuator, ignition cut up, auto-blip down
		_shot("dog", (0.7 if inside else 0.22) * master, rng.randf_range(0.94, 1.06) * (1.04 if gear > prev_gear else 0.97))
		_shot("air", (0.28 if inside else 0.06) * master, rng.randf_range(0.9, 1.1))
		if gear > prev_gear and gear > 1:
			if thr > 0.5 and rpm > car.spec["rpmMax"] * 0.6:
				_shot("cut", (0.6 if inside else 0.8) * master, rng.randf_range(0.9, 1.05))
		elif gear < prev_gear and gear > 0:
			blip_t = 0.12
			if rpm > car.spec["rpmMax"] * 0.45:
				pop_t = 0.6           # unburnt fuel after the blip -> burst of pops
	prev_gear = gear
	if thr < 0.1 and prev_thr > 0.6 and rpm > car.spec["rpmMax"] * 0.55:
		lift_t = 1.4
		if key == "hyper":
			_shot("bov", 0.35 * master, rng.randf_range(0.9, 1.1))
	prev_thr = thr
	lift_t = maxf(0.0, lift_t - dt)
	pop_t = maxf(0.0, pop_t - dt)
	if (pop_t > 0.0 or (lift_t > 0.0 and thr < 0.1)) and rpm > car.spec["rpmMax"] * 0.4:
		var rate := 9.0 if pop_t > 0.0 else 4.0
		if rng.randf() < rate * dt:
			_shot("pop" if rng.randf() < 0.6 else "pop2", rng.randf_range(0.25, 0.6) * master * (0.6 if inside else 1.0), rng.randf_range(0.85, 1.25))
	_update_rivals(car, cars)


func _update_rivals(player, cars: Array) -> void:
	var near: Array = []
	for o in cars:
		if o == player:
			continue
		var d := Vector2(o.x - player.x, o.z - player.z).length()
		if d < 300.0:
			near.append([d, o])
	near.sort_custom(func(a, b): return a[0] < b[0])
	for k in rivals.size():
		var r: Dictionary = rivals[k]
		var pair: Array = r["players"]
		if k >= near.size():
			for p in pair:
				p.volume_db = -80.0
			continue
		var o = near[k][1]
		var okey: String = o.spec["key"]
		var bands: Array = BANDS[okey]
		if r["key"] != okey:
			var on_l: Array = bank[okey]["on"]
			pair[0].stream = on_l[1]
			pair[1].stream = on_l[on_l.size() - 2]
			pair[0].play()
			pair[1].play()
			r["key"] = okey
		var pos := Vector3(o.x, o.y + 0.6, o.z)
		var lo_b: float = bands[1]
		var hi_b: float = bands[bands.size() - 2]
		var f := clampf((o.rpm - lo_b) / (hi_b - lo_b), 0.0, 1.0)
		var ld := 0.45 + 0.55 * clampf(o.throttle, 0.0, 1.0)
		for b in 2:
			var p3: AudioStreamPlayer3D = pair[b]
			p3.global_position = pos
			var wb: float = cos(f * PI * 0.5) if b == 0 else sin(f * PI * 0.5)
			p3.volume_db = linear_to_db(maxf(0.00001, wb * ld * 1.6))
			p3.pitch_scale = clampf(o.rpm / (lo_b if b == 0 else hi_b), 0.3, 3.0)


func thud(strength: float) -> void:
	_shot("pop2", clampf(strength, 0.2, 1.0), 0.45)


func beep(freq: float, dur: float = 0.25) -> void:
	if muted:
		return
	var n := int(SR * dur)
	var b := PackedFloat32Array()
	b.resize(n)
	for i in n:
		b[i] = (0.5 if fmod(i * freq / SR, 1.0) < 0.5 else -0.5) * (1.0 - float(i) / n)
	var p: AudioStreamPlayer = pool[pool_i]
	pool_i = (pool_i + 1) % pool.size()
	p.stream = _wav(b, false)
	p.volume_db = -8.0
	p.pitch_scale = 1.0
	p.play()

# Track geometry: centreline sampling, racing line, speed profile, pit lane, barriers.
# Pure data (no nodes) so it is cheap to query from physics and AI.
extends RefCounted

const DS := 2.0
const CURB_W := 1.3

var def: Dictionary
var id: String
var half_w := 7.0
var N := 0
var ds := 2.0
var length := 0.0
var px := PackedFloat32Array()
var pz := PackedFloat32Array()
var py := PackedFloat32Array()
var tx := PackedFloat32Array()
var tz := PackedFloat32Array()
var rx := PackedFloat32Array()
var rz := PackedFloat32Array()
var head := PackedFloat32Array()
var kap := PackedFloat32Array()
var grade := PackedFloat32Array()
var curb := PackedByteArray()        # 1 where either side carries a kerb (kept for compatibility)
var curb_l := PackedByteArray()      # kerbs per side, placed where the racing line touches the edge
var curb_r := PackedByteArray()
var band_l := PackedStringArray()    # painted run-off bands per side ("g" green, "r" red, "y" yellow), e.g. "gry"
var band_r := PackedStringArray()
var ext_l := PackedFloat32Array()    # max. lateral extent per side before geometry would fold (inside of tight corners)
var ext_r := PackedFloat32Array()
var pit_open := PackedByteArray()    # 1 where the right side opens towards the pit lane (no track barrier)
var pit_edge := PackedFloat32Array() # track-lateral of the pit lane's inner edge (only where pit_open)
var run_l := PackedByteArray()        # run-off beyond the kerb: 0 grass, 1 gravel, 2 tarmac
var run_r := PackedByteArray()
var bar_l := PackedFloat32Array()
var bar_r := PackedFloat32Array()
var line_d := PackedFloat32Array()
var line_x := PackedFloat32Array()
var line_z := PackedFloat32Array()
var line_k := PackedFloat32Array()

# pit lane: its own centreline (1 m samples), always on the right side of the track
const LANE_IN := 2.7        # lane half width towards the track (fast lane)
const LANE_OUT := 2.8       # lane half width away from the track
const BOX_LAT := 5.9        # centre of the working lane / box spots (lane lateral)
const GARAGE_LAT := 9.0     # garage fronts (lane lateral)
const GARAGE_W := 14.0
var lN := 0
var lL := 0.0
var lx := PackedFloat32Array()
var lz := PackedFloat32Array()
var ly := PackedFloat32Array()
var ltx := PackedFloat32Array()
var ltz := PackedFloat32Array()
var lrx := PackedFloat32Array()
var lrz := PackedFloat32Array()
var l_ts := PackedFloat32Array()      # track s of each lane sample
var l_tlat := PackedFloat32Array()    # track lateral of each lane sample
var l_out := PackedFloat32Array()     # lateral extent away from the track (lane edge or garage fronts)
var l_wall := PackedByteArray()       # 1 = concrete pit wall on the track side
var l_gar := PackedByteArray()        # 1 = garage section
var l_vmax := PackedFloat32Array()    # curvature speed limit along the lane
var garage_ps := PackedFloat32Array() # lane s of every garage centre
var t2l := PackedInt32Array()         # track sample -> nearest lane sample (search hint), -1 = none
var player_garage := 0
var box_ps := 0.0                     # lane s of the player's box
var lim_a := 0.0                      # lane s of the speed-limit lines
var lim_b := 0.0
var lloc_i := 0
var lloc_s := 0.0
var lloc_lat := 0.0
var lloc_d := 1e9

var pit_in := 0.0
var pit_out := 0.0
var pit_wall_from := 0.0
var pit_wall_to := 0.0
var pit_box := 0.0
var pit_lane_off := 15.5
var pit_wall_off := 10.2
var pit_limit := 60.0 / 3.6

# results of locate()
var loc_i := 0
var loc_s := 0.0
var loc_lat := 0.0

var _profiles := {}


func build(d: Dictionary) -> void:
	def = d
	id = d["id"]
	half_w = d["half_w"]
	var ctrl: Array = d["ctrl"]
	var pts: Array = []
	for p in ctrl:
		pts.append(p)
	var n := pts.size()
	# dense polyline through centripetal Catmull-Rom
	var dense: Array[Vector2] = []
	for i in n:
		var p0: Vector2 = pts[(i - 1 + n) % n]
		var p1: Vector2 = pts[i]
		var p2: Vector2 = pts[(i + 1) % n]
		var p3: Vector2 = pts[(i + 2) % n]
		var seg := maxi(4, int(ceilf(p1.distance_to(p2) / 0.5)))
		for k in seg:
			dense.append(_catmull(p0, p1, p2, p3, float(k) / seg))
	var dn := dense.size()
	var cum := PackedFloat32Array()
	cum.resize(dn + 1)
	cum[0] = 0.0
	for i in range(1, dn + 1):
		cum[i] = cum[i - 1] + dense[i - 1].distance_to(dense[i % dn])
	_resample_from(dense, cum)
	# GPS-derived layouts carry small kinks: a light smoothing removes them while every corner keeps
	# its real radius (displacement stays below ~3 m), then resample uniformly again
	var sm: int = d.get("smooth", 0)
	if sm > 0:
		_smooth_centreline(sm)
		var pts2: Array[Vector2] = []
		for i in N:
			pts2.append(Vector2(px[i], pz[i]))
		var cum2 := PackedFloat32Array()
		cum2.resize(N + 1)
		cum2[0] = 0.0
		for i in range(1, N + 1):
			cum2[i] = cum2[i - 1] + pts2[i - 1].distance_to(pts2[i % N])
		_resample_from(pts2, cum2)
	# scale to the official lap length (GPS traces run a few metres short)
	if d.has("scale_len"):
		var f: float = float(d["scale_len"]) / length
		for i in N:
			px[i] *= f
			pz[i] *= f
		length *= f
		ds *= f
	_compute_frame()
	_compute_elevation()
	_compute_runoff_barriers()
	_compute_racing_line()
	_compute_curbs()
	_build_pit_lane()


func _resample_from(pts: Array[Vector2], cum: PackedFloat32Array) -> void:
	var dn := pts.size()
	length = cum[dn]
	N = int(roundf(length / DS))
	ds = length / N
	px.resize(N)
	pz.resize(N)
	py.resize(N)
	tx.resize(N)
	tz.resize(N)
	rx.resize(N)
	rz.resize(N)
	head.resize(N)
	kap.resize(N)
	grade.resize(N)
	bar_l.resize(N)
	bar_r.resize(N)
	curb.resize(N)
	curb_l.resize(N)
	curb_r.resize(N)
	run_l.resize(N)
	run_r.resize(N)
	band_l.resize(N)
	band_r.resize(N)
	pit_open.resize(N)
	pit_edge.resize(N)
	ext_l.resize(N)
	ext_r.resize(N)
	var j := 0
	for i in N:
		var s := i * ds
		while j < dn - 1 and cum[j + 1] < s:
			j += 1
		var a: Vector2 = pts[j]
		var b: Vector2 = pts[(j + 1) % dn]
		var w := (s - cum[j]) / maxf(1e-6, cum[j + 1] - cum[j])
		px[i] = lerpf(a.x, b.x, w)
		pz[i] = lerpf(a.y, b.y, w)


func _catmull(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, t: float) -> Vector2:
	var t0 := 0.0
	var t1 := t0 + maxf(1e-4, sqrt(p0.distance_to(p1)))
	var t2 := t1 + maxf(1e-4, sqrt(p1.distance_to(p2)))
	var t3 := t2 + maxf(1e-4, sqrt(p2.distance_to(p3)))
	var tt := t1 + (t2 - t1) * t
	var a1 := p0.lerp(p1, (tt - t0) / (t1 - t0))
	var a2 := p1.lerp(p2, (tt - t1) / (t2 - t1))
	var a3 := p2.lerp(p3, (tt - t2) / (t3 - t2))
	var b1 := a1.lerp(a2, (tt - t0) / (t2 - t0))
	var b2 := a2.lerp(a3, (tt - t1) / (t3 - t1))
	return b1.lerp(b2, (tt - t1) / (t2 - t1))


func _smooth_centreline(iters: int) -> void:
	for it in iters:
		var ax := px.duplicate()
		var az := pz.duplicate()
		for i in N:
			var sx := 0.0
			var sz := 0.0
			for k in range(-4, 5):
				var q := (i + k + N) % N
				sx += ax[q]
				sz += az[q]
			px[i] = sx / 9.0
			pz[i] = sz / 9.0


func _compute_frame() -> void:
	for i in N:
		var a := (i - 1 + N) % N
		var b := (i + 1) % N
		var dx := px[b] - px[a]
		var dz := pz[b] - pz[a]
		var l := maxf(1e-6, sqrt(dx * dx + dz * dz))
		dx /= l
		dz /= l
		tx[i] = dx
		tz[i] = dz
		rx[i] = -dz
		rz[i] = dx
		head[i] = atan2(dz, dx)
	var K := 4
	for i in N:
		var dh := wrapf(head[(i + K) % N] - head[(i - K + N) % N], -PI, PI)
		kap[i] = dh / (2.0 * K * ds)


func _compute_elevation() -> void:
	var prof: Array = def["elev"]
	if def.has("fia"):
		_fia_elevation()
	elif prof.size() > 0:
		var E: Array[Vector2] = []
		for p in prof:
			E.append(p)
		E.append(Vector2(length, 0.0))
		for i in N:
			var s := i * ds
			var j := 0
			while j < E.size() - 2 and E[j + 1].x < s:
				j += 1
			var p0: Vector2 = E[maxi(0, j - 1)]
			var p1: Vector2 = E[j]
			var p2: Vector2 = E[j + 1]
			var p3: Vector2 = E[mini(E.size() - 1, j + 2)]
			var t := clampf((s - p1.x) / maxf(1e-3, p2.x - p1.x), 0.0, 1.0)
			var t2 := t * t
			var t3 := t2 * t
			py[i] = 0.5 * ((2.0 * p1.y) + (-p0.y + p2.y) * t + (2.0 * p0.y - 5.0 * p1.y + 4.0 * p2.y - p3.y) * t2 + (-p0.y + 3.0 * p1.y - 3.0 * p2.y + p3.y) * t3)
	else:
		for i in N:
			var u := float(i) / N * TAU
			py[i] = 6.0 * sin(u + 0.5) + 3.5 * sin(u * 3.0 + 1.3) + 1.5 * sin(u * 7.0 + 2.1)
		for i in N:
			var s := i * ds
			var d := minf(minf(absf(s), absf(s - length)), absf(s - 300.0))
			py[i] *= clampf((d - 380.0) / 250.0, 0.0, 1.0)
	for i in N:
		grade[i] = (py[(i + 1) % N] - py[(i - 1 + N) % N]) / (2.0 * ds)


# Monotone cubic (PCHIP) through the official elevation points: smooth, no overshoot between anchors.
func _fia_elevation() -> void:
	var pts: Array = def["fia"]
	var scale: float = length / float(def["fia_len"])
	var base: float = def["fia_base"]
	var ex := PackedFloat32Array()
	var ey := PackedFloat32Array()
	for p in pts:
		var v: Vector2 = p
		ex.append(v.x * scale)
		ey.append(v.y - base)
	var n := ex.size()
	var dx := PackedFloat32Array()
	var dl := PackedFloat32Array()
	for k in n - 1:
		dx.append(ex[k + 1] - ex[k])
		dl.append((ey[k + 1] - ey[k]) / dx[k])
	var m := PackedFloat32Array()
	m.resize(n)
	m.fill(0.0)
	for k in range(1, n - 1):
		if dl[k - 1] * dl[k] > 0.0:
			var w1 := 2.0 * dx[k] + dx[k - 1]
			var w2 := dx[k] + 2.0 * dx[k - 1]
			m[k] = (w1 + w2) / (w1 / dl[k - 1] + w2 / dl[k])
	var d0 := dl[n - 2]
	var d1 := dl[0]
	var me := 0.0 if d0 * d1 <= 0.0 else 2.0 / (1.0 / d0 + 1.0 / d1)
	m[0] = me
	m[n - 1] = me
	var sg := 0
	for i in N:
		var s := i * ds
		while sg < n - 2 and ex[sg + 1] < s:
			sg += 1
		var h := dx[sg]
		var t := clampf((s - ex[sg]) / h, 0.0, 1.0)
		var t2 := t * t
		var t3 := t2 * t
		py[i] = (2.0 * t3 - 3.0 * t2 + 1.0) * ey[sg] + (t3 - 2.0 * t2 + t) * h * m[sg] + (-2.0 * t3 + 3.0 * t2) * ey[sg + 1] + (t3 - t2) * h * m[sg + 1]


func _compute_runoff_barriers() -> void:
	# run-off: explicit zones (real circuits) or gravel on the outside of slow corners (fictional track)
	var pd: Dictionary = def["pit"]
	var zones: Array = def.get("runoff", [])
	var zone_bar := PackedFloat32Array()
	zone_bar.resize(N)
	zone_bar.fill(0.0)
	for i in N:
		run_l[i] = 0
		run_r[i] = 0
		band_l[i] = ""
		band_r[i] = ""
		pit_open[i] = 0
		pit_edge[i] = 0.0
		var mk := 0.0
		for k in range(-30, 31, 2):
			var kk := kap[(i + k + N) % N]
			if absf(kk) > absf(mk):
				mk = kk
		var s := i * ds
		if zones.is_empty():
			if absf(mk) > 1.0 / 140.0 and not in_range(s, float(pd["in"]) - 80.0, float(pd["out"]) + 80.0):
				if mk > 0.0:
					run_l[i] = 1
					band_l[i] = "g"
				else:
					run_r[i] = 1
					band_r[i] = "g"
			continue
		for z in zones:
			var zz: Array = z
			if in_range(s, zz[0], zz[1]):
				var typ: int = zz[3]
				var b_out: String = zz[5] if zz.size() > 5 else "g"
				var b_in: String = zz[6] if zz.size() > 6 else b_out
				if zz[2] == "both" or mk == 0.0:
					run_l[i] = typ
					run_r[i] = typ
					# for "both" zones the outside of the local corner gets b_out, the inside b_in
					band_l[i] = b_out if mk >= 0.0 else b_in
					band_r[i] = b_in if mk >= 0.0 else b_out
				elif mk > 0.0:
					run_l[i] = typ        # right-hand corner: outside is the left
					band_l[i] = b_out
				else:
					run_r[i] = typ
					band_r[i] = b_out
				zone_bar[i] = maxf(zone_bar[i], zz[4])
	for i in N:
		var mk := 0.0
		for k in range(-40, 41, 4):
			mk = maxf(mk, absf(kap[(i + k + N) % N]))
		var run := 11.0 + minf(16.0, mk * 1400.0)
		bar_l[i] = half_w + run
		bar_r[i] = half_w + run
		if zone_bar[i] > 0.0:
			if run_l[i] != 0:
				bar_l[i] = maxf(bar_l[i], half_w + zone_bar[i])
			if run_r[i] != 0:
				bar_r[i] = maxf(bar_r[i], half_w + zone_bar[i])
		var s := i * ds
		if in_range(s, length - 450.0, 600.0):
			bar_l[i] = maxf(bar_l[i], half_w + 10.0)
	for _rep in 3:
		bar_l = _max_filter(bar_l, 10)
		bar_r = _max_filter(bar_r, 10)
	# inside of tight corners: nothing may reach past the local centre of curvature
	for i in N:
		var kmax := 0.0
		var kmin := 0.0
		for k in range(-12, 13):
			var kk := kap[(i + k + N) % N]
			kmax = maxf(kmax, kk)
			kmin = minf(kmin, kk)
		ext_r[i] = 400.0 if kmax <= 1e-4 else clampf(0.8 / kmax, half_w + 3.0, 400.0)
		ext_l[i] = 400.0 if kmin >= -1e-4 else clampf(0.8 / -kmin, half_w + 3.0, 400.0)
		bar_l[i] = minf(bar_l[i], ext_l[i])
		bar_r[i] = minf(bar_r[i], ext_r[i])


# Kerbs where cars really use them: the racing line touches the edge at turn-in, apex and exit.
func _compute_curbs() -> void:
	var lim := half_w - 1.4
	for i in N:
		curb_l[i] = 0
		curb_r[i] = 0
		var mk := 0.0
		for k in range(-30, 31, 3):
			mk = maxf(mk, absf(kap[(i + k + N) % N]))
		if mk < 1.0 / 420.0:
			continue
		if line_d[i] > lim - 0.9:
			curb_r[i] = 1
		elif line_d[i] < -lim + 0.9:
			curb_l[i] = 1
	curb_l = _clean_flags(_dilate(curb_l, 6), 8)
	curb_r = _clean_flags(_dilate(curb_r, 6), 8)
	for i in N:
		curb[i] = 1 if curb_l[i] == 1 or curb_r[i] == 1 else 0


func _dilate(src: PackedByteArray, w: int) -> PackedByteArray:
	var out := PackedByteArray()
	out.resize(N)
	for i in N:
		var on := 0
		for k in range(-w, w + 1):
			if src[(i + k + N) % N] == 1:
				on = 1
				break
		out[i] = on
	return out


# removes runs shorter than min_len samples
func _clean_flags(src: PackedByteArray, min_len: int) -> PackedByteArray:
	var out := src.duplicate()
	var start := 0
	while start < N and src[start] == 1:
		start += 1
	var k := 0
	while k < N:
		var i := (start + k) % N
		if src[i] == 1:
			var n := 0
			while n < N and src[(i + n) % N] == 1:
				n += 1
			if n < min_len:
				for m in n:
					out[(i + m) % N] = 0
			k += n
		else:
			k += 1
	return out


# ---------------------------------------------------------------- pit lane (own centreline)
func _key_lat(keys: Array, s: float) -> float:
	for k in keys.size() - 1:
		var a: Array = keys[k]
		var b: Array = keys[k + 1]
		var sa: float = a[0]
		var sb: float = b[0]
		if s >= sa and s <= sb:
			var t := smoothstep(0.0, 1.0, (s - sa) / maxf(1e-3, sb - sa))
			return lerpf(float(a[1]), float(b[1]), t)
	var last: Array = keys[keys.size() - 1]
	return float(last[1])


func _resample_poly(src: PackedVector2Array, step: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	if src.size() < 2:
		return src
	out.append(src[0])
	var carry := 0.0
	for i in src.size() - 1:
		var a := src[i]
		var b := src[i + 1]
		var seg := a.distance_to(b)
		var pos := step - carry
		while pos <= seg:
			out.append(a.lerp(b, pos / maxf(1e-6, seg)))
			pos += step
		carry = seg - (pos - step)
	return out


func _seg_hit(p1: Vector2, p2: Vector2, p3: Vector2, p4: Vector2) -> bool:
	var d := (p2.x - p1.x) * (p4.y - p3.y) - (p2.y - p1.y) * (p4.x - p3.x)
	if absf(d) < 1e-9:
		return false
	var t := ((p3.x - p1.x) * (p4.y - p3.y) - (p3.y - p1.y) * (p4.x - p3.x)) / d
	var u := ((p3.x - p1.x) * (p2.y - p1.y) - (p3.y - p1.y) * (p2.x - p1.x)) / d
	return t >= 0.0 and t <= 1.0 and u >= 0.0 and u <= 1.0


# an offset curve on the inside of a hairpin folds over itself: cut the loop out
func _remove_loops(src: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	var n := src.size()
	var i := 0
	while i < n - 1:
		var cut := -1
		for j in range(mini(n - 2, i + 160), i + 1, -1):
			if _seg_hit(src[i], src[i + 1], src[j], src[j + 1]):
				cut = j
				break
		out.append(src[i])
		i = cut + 1 if cut >= 0 else i + 1
	out.append(src[n - 1])
	return out


func _build_pit_lane() -> void:
	var pd: Dictionary = def["pit"]
	pit_in = wrap_s(pd["in"])
	pit_out = wrap_s(pd["out"])
	pit_wall_from = wrap_s(pd["wall_from"])      # speed-limit zone (track s)
	pit_wall_to = wrap_s(pd["wall_to"])
	pit_box = wrap_s(pd["box"])
	var L0 := half_w + 5.4
	pit_lane_off = L0
	pit_wall_off = L0 - LANE_IN - 0.25
	var keys: Array = pd.get("lane", [[float(pd["in"]), half_w * 0.4], [float(pd["in"]) + 80.0, L0], [float(pd["out"]) - 80.0, L0], [float(pd["out"]), half_w * 0.45]])
	var s0: float = keys[0][0]
	var s1: float = keys[keys.size() - 1][0]
	var raw := PackedVector2Array()
	var ss := s0
	while ss <= s1 + 0.01:
		var p := point_at(ss, _key_lat(keys, ss))
		raw.append(Vector2(p.x, p.z))
		ss += 1.0
	raw = _remove_loops(raw)
	var pts := _resample_poly(raw, 1.0)
	for _it in 40:
		var cp := pts.duplicate()
		for q in range(6, pts.size() - 6):
			var acc := Vector2.ZERO
			for k in range(-6, 7):
				acc += cp[q + k]
			pts[q] = acc / 13.0
	pts = _resample_poly(pts, 1.0)
	lN = pts.size()
	lL = float(lN - 1)
	for arr_name in ["lx", "lz", "ly", "ltx", "ltz", "lrx", "lrz", "l_ts", "l_tlat", "l_out", "l_vmax"]:
		var a: PackedFloat32Array = get(arr_name)
		a.resize(lN)
		set(arr_name, a)
	l_wall.resize(lN)
	l_gar.resize(lN)
	for q in lN:
		lx[q] = pts[q].x
		lz[q] = pts[q].y
	for q in lN:
		var a := mini(lN - 1, q + 1)
		var b := maxi(0, q - 1)
		var d := Vector2(lx[a] - lx[b], lz[a] - lz[b]).normalized()
		ltx[q] = d.x
		ltz[q] = d.y
		lrx[q] = -d.y
		lrz[q] = d.x
	# map onto the track: track s / lateral / height
	# forward-biased search: the lane runs the same way as the track; inside the La Source loop the
	# nearest piece of track jumps ahead from the straight to the hairpin and the descent
	var hint := idx(s0)
	for q in lN:
		var best := hint
		var bd := 1e18
		for k in range(-3, 61):
			var i := (hint + k + N) % N
			var dx := lx[q] - px[i]
			var dz := lz[q] - pz[i]
			var d := dx * dx + dz * dz
			if d < bd:
				bd = d
				best = i
		hint = best
		var ddx := lx[q] - px[best]
		var ddz := lz[q] - pz[best]
		l_ts[q] = wrap_s(best * ds + ddx * tx[best] + ddz * tz[best])
		l_tlat[q] = ddx * rx[best] + ddz * rz[best]
		ly[q] = height_at(l_ts[q])
	for _it in 6:
		var c := ly.duplicate()
		for q in range(3, lN - 3):
			ly[q] = (c[q - 3] + c[q - 2] + c[q - 1] + c[q] + c[q + 1] + c[q + 2] + c[q + 3]) / 7.0
	# garage section, lane width, pit wall
	var gar: Array = pd.get("garages", [float(pd["wall_from"]) + 10.0, float(pd["wall_to"]) - 10.0])
	var dist_g := PackedFloat32Array()
	dist_g.resize(lN)
	for q in lN:
		l_gar[q] = 1 if in_range(l_ts[q], gar[0], gar[1]) and l_tlat[q] > half_w + 3.0 else 0
		dist_g[q] = 0.0 if l_gar[q] == 1 else 1e9
	for q in range(1, lN):
		dist_g[q] = minf(dist_g[q], dist_g[q - 1] + 1.0)
	for q in range(lN - 2, -1, -1):
		dist_g[q] = minf(dist_g[q], dist_g[q + 1] + 1.0)
	for q in lN:
		l_out[q] = lerpf(GARAGE_LAT, LANE_OUT, smoothstep(0.0, 25.0, dist_g[q]))
		var gap: float = l_tlat[q] - LANE_IN - half_w
		l_wall[q] = 1 if gap > 1.4 and q > 8 and q < lN - 8 else 0
	# curvature speed limit (low-speed grip ~1.2 g), with braking ahead of tight bits
	for q in lN:
		var a := mini(lN - 1, q + 3)
		var b := maxi(0, q - 3)
		var h1 := atan2(ltz[a], ltx[a])
		var h0 := atan2(ltz[b], ltx[b])
		var kk := absf(wrapf(h1 - h0, -PI, PI)) / maxf(1.0, float(a - b))
		l_vmax[q] = minf(70.0, sqrt(11.5 / maxf(1e-4, kk)))
	for q in range(lN - 2, -1, -1):
		l_vmax[q] = minf(l_vmax[q], sqrt(l_vmax[q + 1] * l_vmax[q + 1] + 2.0 * 7.0))
	# garages: one every 14 m along the garage section; the player's one nearest to "box"
	garage_ps = PackedFloat32Array()
	var gs: float = float(gar[0]) + GARAGE_W * 0.5
	while gs <= float(gar[1]) - GARAGE_W * 0.5 + 0.01:
		garage_ps.append(lane_ps_at(gs, true))
		gs += GARAGE_W
	player_garage = 0
	var bd := 1e9
	for k in garage_ps.size():
		var d: float = absf(wrapf(l_ts[int(garage_ps[k])] - pit_box, -length * 0.5, length * 0.5))
		if d < bd:
			bd = d
			player_garage = k
	box_ps = garage_ps[player_garage] if garage_ps.size() > 0 else lL * 0.5
	lim_a = lane_ps_at(pd["wall_from"], false)
	lim_b = lane_ps_at(pd["wall_to"], false)
	t2l.resize(N)
	t2l.fill(-1)
	for q in lN:
		t2l[idx(l_ts[q])] = q
	var carry := 0
	var i0 := idx(pit_in - 40.0)
	var cnt := int((wrap_s(pit_out - pit_in) + 80.0) / ds)
	for k in cnt:
		var i := (i0 + k) % N
		if t2l[i] >= 0:
			carry = t2l[i]
		else:
			t2l[i] = carry
	# open the track's right side where the lane runs next to it (the lane walls take over)
	for i in N:
		pit_edge[i] = 1e9
	for q in lN:
		if l_tlat[q] > 45.0:
			continue
		var i := idx(l_ts[q])
		for k in range(-2, 3):
			var j := (i + k + N) % N
			pit_open[j] = 1
			pit_edge[j] = minf(pit_edge[j], l_tlat[q] - LANE_IN)
	for i in N:
		if pit_open[i] == 1:
			bar_r[i] = 90.0
			run_r[i] = 0
			band_r[i] = ""
			curb_r[i] = curb_r[i] if pit_edge[i] > half_w + 1.6 else 0
		else:
			pit_edge[i] = 0.0


# lane s nearest to a track position (garage_only: restrict to the garage section)
func lane_ps_at(track_s: float, garage_only: bool) -> float:
	var best := 0
	var bd := 1e9
	for q in lN:
		if garage_only and l_gar[q] == 0:
			continue
		var d: float = absf(wrapf(l_ts[q] - wrap_s(track_s), -length * 0.5, length * 0.5))
		if d < bd:
			bd = d
			best = q
	return float(best)


func lane_locate(x: float, z: float, hint: int, rng: int = 20) -> void:
	var best := clampi(hint, 0, lN - 1)
	var bd := 1e18
	for k in range(-rng, rng + 1):
		var q := hint + k
		if q < 0 or q >= lN:
			continue
		var dx := x - lx[q]
		var dz := z - lz[q]
		var d := dx * dx + dz * dz
		if d < bd:
			bd = d
			best = q
	var ddx := x - lx[best]
	var ddz := z - lz[best]
	lloc_i = best
	lloc_s = clampf(best + ddx * ltx[best] + ddz * ltz[best], 0.0, lL)
	lloc_lat = ddx * lrx[best] + ddz * lrz[best]
	lloc_d = sqrt(bd)


func lane_locate_global(x: float, z: float) -> void:
	var best := 0
	var bd := 1e18
	for q in lN:
		var dx := x - lx[q]
		var dz := z - lz[q]
		var d := dx * dx + dz * dz
		if d < bd:
			bd = d
			best = q
	lane_locate(x, z, best, 2)


# returns Vector4(x, y, z, heading) on the pit lane
func lane_point(ps: float, la: float = 0.0) -> Vector4:
	var f := clampf(ps, 0.0, lL - 0.001)
	var i := int(f)
	var j := mini(lN - 1, i + 1)
	var w := f - i
	var x := lerpf(lx[i], lx[j], w) + lerpf(lrx[i], lrx[j], w) * la
	var z := lerpf(lz[i], lz[j], w) + lerpf(lrz[i], lrz[j], w) * la
	return Vector4(x, lerpf(ly[i], ly[j], w), z, atan2(ltz[i], ltx[i]))


# is a car (lane locate already done) inside the pit lane surface?
func lane_inside(llat: float, li: int, track_lat: float) -> bool:
	if lloc_d > 25.0 or llat < -LANE_IN - 0.3 or llat > l_out[li] + 0.3:
		return false
	# where the lane still overlaps the track (its first/last metres) the car counts as on track
	return track_lat > half_w - 0.3 or l_tlat[li] - LANE_IN > half_w


func _max_filter(src: PackedFloat32Array, w: int) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(N)
	for i in N:
		var mx := 0.0
		for k in range(-w, w + 1):
			mx = maxf(mx, src[(i + k + N) % N])
		out[i] = mx
	return out


func _compute_racing_line() -> void:
	var lim := half_w - 1.15      # car half width + 15 cm: uses the full track like a real racing line
	line_d.resize(N)
	line_x.resize(N)
	line_z.resize(N)
	line_k.resize(N)
	line_d.fill(0.0)
	for stage in [[24, 80], [12, 100], [6, 120], [3, 150], [1, 150]]:
		var step: int = stage[0]
		var iters: int = stage[1]
		for it in iters:
			for i in N:
				line_x[i] = px[i] + rx[i] * line_d[i]
				line_z[i] = pz[i] + rz[i] * line_d[i]
			for i in N:
				var a := (i - step + N) % N
				var b := (i + step) % N
				var mx := (line_x[a] + line_x[b]) * 0.5
				var mz := (line_z[a] + line_z[b]) * 0.5
				var nd := (mx - px[i]) * rx[i] + (mz - pz[i]) * rz[i]
				line_d[i] = clampf(line_d[i] + (nd - line_d[i]) * 0.5, -lim, lim)
	for i in N:
		line_x[i] = px[i] + rx[i] * line_d[i]
		line_z[i] = pz[i] + rz[i] * line_d[i]
	var raw := PackedFloat32Array()
	raw.resize(N)
	var S := 3
	for i in N:
		var a := (i - S + N) % N
		var b := (i + S) % N
		var ax := line_x[i] - line_x[a]
		var az := line_z[i] - line_z[a]
		var bx := line_x[b] - line_x[i]
		var bz := line_z[b] - line_z[i]
		var cross := ax * bz - az * bx
		var la := sqrt(ax * ax + az * az)
		var lb := sqrt(bx * bx + bz * bz)
		var lc := sqrt(pow(line_x[b] - line_x[a], 2) + pow(line_z[b] - line_z[a], 2))
		raw[i] = 2.0 * cross / maxf(1e-6, la * lb * lc)
	for i in N:
		var s := 0.0
		for k in range(-3, 4):
			s += raw[(i + k + N) % N]
		line_k[i] = s / 7.0


# Max-speed profile along the racing line for a car spec (used by AI and the line display).
func speed_profile(spec: Dictionary, grip_scale: float = 1.0) -> PackedFloat32Array:
	var key := "%s_%.3f" % [spec["cls"], grip_scale]
	if _profiles.has(key):
		return _profiles[key]
	var g := 9.81
	var rho := 1.225
	var mu: float = spec["mu"] * grip_scale * 0.93
	var kdf: float = 0.5 * rho * spec["ClA"] / spec["mass"]
	var kdr: float = 0.5 * rho * spec["CdA"] / spec["mass"]
	var vtop: float = spec["vmax"]
	var v := PackedFloat32Array()
	v.resize(N)
	for i in N:
		var kk := absf(line_k[i])
		var den := kk - mu * kdf
		v[i] = vtop if den <= 1e-6 else minf(vtop, sqrt(mu * g / den))
	for rep in 2:
		for n in range(N - 1, -1, -1):
			var jn := (n + 1) % N
			var vj := v[jn]
			var tot := mu * 0.82 * (g + kdf * vj * vj)
			var alat := vj * vj * absf(line_k[jn])
			var decel := sqrt(maxf(0.0, tot * tot - alat * alat)) * 0.9 + kdr * vj * vj
			v[n] = minf(v[n], sqrt(vj * vj + 2.0 * decel * ds))
	for rep in 2:
		for i in N:
			var jn := (i + 1) % N
			var vi := maxf(5.0, v[i])
			var tot := mu * 0.5 * (g + kdf * vi * vi)
			var alat := vi * vi * absf(line_k[i])
			var grip := sqrt(maxf(0.0, tot * tot - alat * alat * 0.25))
			var acc := minf(grip, spec["power"] * 0.9 / (spec["mass"] * vi)) - kdr * vi * vi
			v[jn] = minf(v[jn], sqrt(maxf(0.0, vi * vi + 2.0 * maxf(0.0, acc) * ds)))
	_profiles[key] = v
	return v


# Reference speeds for the racing-line display: what the car can really do with warm tyres and ABS
# (full grip in braking, ~1.6-1.9 g with downforce). Brake markers start exactly where braking at the
# limit is needed, not earlier.
func brake_profile(spec: Dictionary) -> PackedFloat32Array:
	var key := "brk_" + String(spec["cls"])
	if _profiles.has(key):
		return _profiles[key]
	var g := 9.81
	var rho := 1.225
	var mu: float = spec["mu"] * 0.98
	var kdf: float = 0.5 * rho * spec["ClA"] / spec["mass"]
	var kdr: float = 0.5 * rho * spec["CdA"] / spec["mass"]
	var vtop: float = spec["vmax"]
	var v := PackedFloat32Array()
	v.resize(N)
	for i in N:
		var kk := absf(line_k[i])
		var den := kk - mu * kdf
		v[i] = vtop if den <= 1e-6 else minf(vtop, sqrt(mu * g / den))
	for rep in 3:
		for n in range(N - 1, -1, -1):
			var jn := (n + 1) % N
			var vj := v[jn]
			var tot := mu * 0.96 * (g + kdf * vj * vj)
			var alat := vj * vj * absf(line_k[jn])
			var decel := sqrt(maxf(0.0, tot * tot - alat * alat)) + kdr * vj * vj
			decel = minf(decel, float(spec["brakeMax"]) / float(spec["mass"]) + kdr * vj * vj)
			v[n] = minf(v[n], sqrt(vj * vj + 2.0 * decel * ds))
	for rep in 2:
		for i in N:
			var jn := (i + 1) % N
			var vi := maxf(5.0, v[i])
			var tot := mu * (g + kdf * vi * vi)
			var alat := vi * vi * absf(line_k[i])
			var grip := sqrt(maxf(0.0, tot * tot - alat * alat))
			var acc := minf(grip * 0.6, spec["power"] * 0.92 / (spec["mass"] * vi)) - kdr * vi * vi
			v[jn] = minf(v[jn], sqrt(maxf(0.0, vi * vi + 2.0 * maxf(0.0, acc) * ds)))
	_profiles[key] = v
	return v


# ---------------------------------------------------------------- queries
func wrap_s(s: float) -> float:
	return fposmod(s, length)


func idx(s: float) -> int:
	return int(floorf(wrap_s(s) / ds)) % N


func in_range(s: float, a: float, b: float) -> bool:
	s = wrap_s(s)
	a = wrap_s(a)
	b = wrap_s(b)
	if a > b:
		return s >= a or s <= b
	return s >= a and s <= b


func locate(x: float, z: float, hint: int, rng: int = 14) -> void:
	var best := hint
	var bd := 1e18
	for k in range(-rng, rng + 1):
		var i := (hint + k + N) % N
		var dx := x - px[i]
		var dz := z - pz[i]
		var d := dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	var ddx := x - px[best]
	var ddz := z - pz[best]
	loc_i = best
	loc_s = wrap_s(best * ds + ddx * tx[best] + ddz * tz[best])
	loc_lat = ddx * rx[best] + ddz * rz[best]


func locate_global(x: float, z: float) -> void:
	var best := 0
	var bd := 1e18
	for i in N:
		var dx := x - px[i]
		var dz := z - pz[i]
		var d := dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	locate(x, z, best, 2)


func height_at(s: float) -> float:
	var f := wrap_s(s) / ds
	var i := int(floorf(f)) % N
	var w := f - floorf(f)
	return lerpf(py[i], py[(i + 1) % N], w)


# returns Vector4(x, y, z, heading)
func point_at(s: float, lat: float = 0.0) -> Vector4:
	var f := wrap_s(s) / ds
	var i := int(floorf(f)) % N
	var jn := (i + 1) % N
	var w := f - floorf(f)
	var x := lerpf(px[i], px[jn], w)
	var z := lerpf(pz[i], pz[jn], w)
	var r_x := lerpf(rx[i], rx[jn], w)
	var r_z := lerpf(rz[i], rz[jn], w)
	return Vector4(x + r_x * lat, lerpf(py[i], py[jn], w), z + r_z * lat, atan2(tz[i], tx[i]))


func basis_at(i: int) -> Basis:
	# x = forward, y = up, z = right (matches the car model convention)
	var f := Vector3(tx[i], grade[i], tz[i]).normalized()
	var r := Vector3(rx[i], 0.0, rz[i])
	var u := r.cross(f).normalized()
	return Basis(f, u, f.cross(u).normalized())

# Race HUD drawn immediate-mode: standings, relative, timing with sectors, gear dial, tyres, fuel,
# damage map, radar, minimap, pit menu, pit progress, start lights and messages.
extends Control

const Gfx = preload("res://scripts/gfx.gd")
const Ui = preload("res://scripts/ui.gd")
const CarPhysics = preload("res://scripts/car_physics.gd")

var game
var font: Font
var hfont: Font
var tower_bottom := 0.0
var fps_t := 0.0
var fps := 0
var frames := 0
var mm_pts := PackedVector2Array()
var mm_tf := Transform2D()
var base_xf := Transform2D()

const PANEL := Color(0.03, 0.035, 0.05, 0.72)
const ROW_ME := Color(0.55, 0.57, 0.62, 0.55)
const HY := Color(0.86, 0.13, 0.17)
const GT := Color(0.13, 0.62, 0.3)
const ACC := Color(1.0, 0.83, 0.0)


func _ready() -> void:
	font = Ui.font("bold")
	hfont = Ui.font("head")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func prepare_minimap() -> void:
	var T = game.T
	var mn := Vector2(1e9, 1e9)
	var mx := Vector2(-1e9, -1e9)
	mm_pts = PackedVector2Array()
	for i: int in range(0, T.N, 3):
		var p := Vector2(T.px[i], T.pz[i])
		mm_pts.append(p)
		mn = Vector2(minf(mn.x, p.x), minf(mn.y, p.y))
		mx = Vector2(maxf(mx.x, p.x), maxf(mx.y, p.y))
	mm_pts.append(mm_pts[0])
	var box := Vector2(170, 210)
	var sc := minf(box.x / (mx.x - mn.x), box.y / (mx.y - mn.y))
	var off := (box - (mx - mn) * sc) * 0.5
	mm_tf = Transform2D(0.0, Vector2(sc, sc), 0.0, off - mn * sc)


func _process(dt: float) -> void:
	frames += 1
	fps_t += dt
	if fps_t >= 1.0:
		fps = frames
		frames = 0
		fps_t = 0.0
	queue_redraw()


# ---------------------------------------------------------------- draw helpers
func panel(r: Rect2, col := PANEL) -> void:
	draw_rect(r, col)


func txt(p: Vector2, s: String, sz: int, col := Color.WHITE, align := HORIZONTAL_ALIGNMENT_LEFT, w := -1.0) -> void:
	draw_string(font, p, s, align, w, sz, col)


func big(p: Vector2, s: String, sz: int, col := Color.WHITE, align := HORIZONTAL_ALIGNMENT_LEFT, w := -1.0) -> void:
	draw_string(hfont, p, s, align, w, sz, col)


func cls_chip(r: Rect2, o, label: String) -> void:
	draw_rect(r, cls_col(o))
	draw_string(hfont, r.position + Vector2(0, r.size.y - 4), label, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, int(r.size.y - 3), Color.WHITE)


static func fmt(t: float) -> String:
	if t < 0.0 or t > 36000.0:
		return "-:--.---"
	var m := int(t / 60.0)
	return "%d:%06.3f" % [m, t - m * 60.0]


func cls_col(c) -> Color:
	return GT if c.spec["key"] == "gt3" else HY


func _draw() -> void:
	if game == null or not game.hud_visible:
		return
	# global HUD scale (menu: Anzeigengröße) – everything below is laid out in scaled units
	var k: float = game.settings.get("ui_scale", 1.25)
	base_xf = Transform2D(0.0, Vector2(k, k), 0.0, Vector2.ZERO)
	draw_set_transform_matrix(base_xf)
	var vp := get_viewport_rect().size / k
	if game.state == "viewer":
		_draw_viewer(vp)
		return
	if game.player == null:
		return
	if game.state == "replay":
		_draw_replay(vp)
		return
	var c = game.player
	_draw_session(c)
	_draw_timing(vp, c)
	_draw_relative(vp, c)
	_draw_minimap(vp)
	_draw_dial(vp, c)
	_draw_damage(vp, c)
	if game.settings["radar"]:
		_draw_radar(vp, c)
	_draw_center(vp, c)
	if game.pit_menu_open:
		_draw_pit_menu(vp, c)
	_draw_radio(vp)
	txt(Vector2(vp.x - 70, vp.y - 6), "%d FPS" % fps, 12, Color(1, 1, 1, 0.35))


# replay: timeline, speed, followed car, keys (in movie export only a small corner badge)
func _draw_replay(vp: Vector2) -> void:
	var c = game.focus_car()
	if game.replay_from == "movie":
		rrect(Rect2(24, 24, 360, 64), Color(0.02, 0.03, 0.05, 0.75), 8.0)
		draw_rect(Rect2(24, 24, 6, 64), ACC)
		big(Vector2(44, 52), "TROIS FORÊTS 24  ·  REPLAY", 20, Color.WHITE)
		txt(Vector2(44, 76), "#%d  %s   %d km/h" % [int(c.num), String(c.name), int(absf(c.u) * 3.6)], 16, Color(0.8, 0.83, 0.88))
		return
	var R = game.replay
	var L: float = R.length()
	var w := minf(1100.0, vp.x - 80.0)
	var x := vp.x * 0.5 - w * 0.5
	var y := vp.y - 150.0
	rrect(Rect2(x, y, w, 126), Color(0.02, 0.03, 0.05, 0.85), 10.0)
	draw_rect(Rect2(x, y, 6, 126), ACC)
	big(Vector2(x + 20, y + 32), "REPLAY", 24, ACC)
	txt(Vector2(x + 130, y + 30), "#%d  %s   ·   %d km/h   ·   Gang %d" % [int(c.num), String(c.name), int(absf(c.u) * 3.6), int(c.gear)], 18, Color.WHITE)
	var spd: float = game.replay_speed
	txt(Vector2(x + 20, y + 30), ("PLAY  %sx" % (str(spd) if spd >= 1.0 else "1/%d" % int(round(1.0 / spd)))) if game.replay_play else "PAUSE", 18, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT, w - 40)
	# timeline
	var bx := x + 20
	var bw := w - 40
	rrect(Rect2(bx, y + 50, bw, 10), Color(0.18, 0.19, 0.23), 5.0)
	var f: float = game.replay_t / maxf(0.01, L)
	rrect(Rect2(bx, y + 50, bw * f, 10), ACC, 5.0)
	draw_circle(Vector2(bx + bw * f, y + 55), 9, Color.WHITE)
	txt(Vector2(bx, y + 84), "%s / %s" % [fmt_clock(R.t0 + game.replay_t), fmt_clock(R.t0 + L)], 15, Color(0.75, 0.78, 0.82))
	txt(Vector2(bx, y + 84), ["Kamera: Verfolger", "Kamera: Nah", "Kamera: Cockpit", "Kamera: Motorhaube", "Kamera: TV"][game.cam_mode], 15, Color(0.75, 0.78, 0.82), HORIZONTAL_ALIGNMENT_RIGHT, bw)
	txt(Vector2(bx, y + 112), "Leertaste Pause · ←/→ 10 s · ↑/↓ Tempo · C Kamera · N/B Auto · K Speichern · V Video · E E-Mail · Esc zurück", 14, Color(0.6, 0.63, 0.68), HORIZONTAL_ALIGNMENT_CENTER, bw)
	if game.msg_t > 0.0:
		var a := clampf(game.msg_t * 2.0, 0.0, 1.0)
		rrect(Rect2(vp.x * 0.5 - 380, 40, 760, 50), Color(0.04, 0.05, 0.07, 0.85 * a), 8.0)
		txt(Vector2(vp.x * 0.5 - 380, 74), game.msg, 22, Color(1, 1, 1, a), HORIZONTAL_ALIGNMENT_CENTER, 760)


static func fmt_clock(t: float) -> String:
	var ti := int(maxf(0.0, t))
	return "%d:%02d:%02d" % [ti / 3600, (ti / 60) % 60, ti % 60] if ti >= 3600 else "%d:%02d" % [ti / 60, ti % 60]


func _draw_viewer(vp: Vector2) -> void:
	rrect(Rect2(24, 24, 520, 150), Color(0.02, 0.03, 0.05, 0.8), 10.0)
	draw_rect(Rect2(24, 24, 6, 150), ACC)
	big(Vector2(44, 58), "STRECKE ANSEHEN", 26, ACC)
	txt(Vector2(44, 86), "%s  ·  %.2f km" % [String(game.T.def["name"]), game.T.length / 1000.0], 18, Color.WHITE)
	txt(Vector2(44, 112), "Rundflug (F): " + ("AN" if game.view_tour else "AUS") + "   ·   Tempo %d km/h" % int(game.view_speed * 3.6), 15, Color(0.75, 0.78, 0.82))
	txt(Vector2(44, 136), "WASD fliegen · Q/E runter/hoch · Maus ziehen = umsehen", 14, Color(0.6, 0.63, 0.68))
	txt(Vector2(44, 158), "Shift schnell · Mausrad Tempo · H Übersicht · Esc zurück", 14, Color(0.6, 0.63, 0.68))
	# map with the camera position and view direction
	if mm_pts.size() > 1:
		var origin := Vector2(vp.x - 210, vp.y - 250)
		rrect(Rect2(origin, Vector2(186, 226)), Color(0.03, 0.035, 0.05, 0.7), 10.0)
		var tfm := Transform2D(0.0, origin + Vector2(8, 8)) * mm_tf
		var pts := tfm * mm_pts
		draw_polyline(pts, Color(0, 0, 0, 0.6), 7.0, true)
		draw_polyline(pts, Color(0.92, 0.94, 0.96), 3.5, true)
		var cp: Vector3 = game.camera.global_position
		var fw: Vector3 = -game.camera.global_transform.basis.z
		var a2 := tfm * Vector2(cp.x, cp.z)
		var d2 := Vector2(fw.x, fw.z).normalized()
		draw_line(a2, a2 + d2 * 16.0, ACC, 3.0)
		draw_circle(a2, 6.0, Color(0, 0, 0))
		draw_circle(a2, 4.5, ACC)


func _draw_session(c) -> void:
	var order: Array = game.order
	var x := 18.0
	var y := 14.0
	var w := 480.0
	# header: session and remaining time
	panel(Rect2(x, y, w, 46))
	var sname: String = {"practice": "Practice", "quali": "Qualifying"}.get(game.session, "Race")
	txt(Vector2(x + 12, y + 32), sname, 24, Color.WHITE)
	big(Vector2(x, y + 40), game.remaining_text().replace("Rest ", "").replace("Quali ", "").replace("Training ", ""), 38, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT, w - 12)
	var idx := order.find(c)
	var show: Array = []
	for k in [0, 1, 2, idx - 2, idx - 1, idx, idx + 1, idx + 2]:
		if k >= 0 and k < order.size() and not show.has(k):
			show.append(k)
	show.sort()
	var yy := y + 50.0
	var rh := 30.0
	panel(Rect2(x, yy, w, show.size() * rh + 6))
	yy += 3
	var prev := -1
	for k in show:
		if prev >= 0 and k - prev > 1:
			draw_line(Vector2(x + 8, yy), Vector2(x + w - 8, yy), Color(1, 1, 1, 0.25), 1.0)
		var o = order[k]
		if o == c:
			draw_rect(Rect2(x, yy, w, rh), ROW_ME)
		txt(Vector2(x + 6, yy + 22), str(k + 1), 21, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT, 26)
		cls_chip(Rect2(x + 40, yy + 6, 34, 19), o, "GT3" if o.spec["key"] == "gt3" else "HY")
		txt(Vector2(x + 82, yy + 22), str(o.num), 20, Color(0.82, 0.84, 0.88))
		txt(Vector2(x + 128, yy + 22), o.name, 21, Color(0.45, 0.45, 0.45) if o.retired else Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, 190)
		var gap := ""
		if o.retired:
			gap = "OUT"
		elif o != c:
			gap = game.gap_text(o, c)
		else:
			gap = "-"
		txt(Vector2(x + 318, yy + 22), gap, 20, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT, 92)
		if o.in_pit:
			txt(Vector2(x + 420, yy + 22), "PIT", 19, Color.WHITE)
		else:
			# fuel level bar like the energy column
			var fr: float = clampf(o.fuel / float(o.spec["fuelCap"]), 0.0, 1.0)
			draw_rect(Rect2(x + 424, yy + 8, 4, 15), Color(0.25, 0.85, 0.35) if fr > 0.2 else Color(1.0, 0.6, 0.1))
			txt(Vector2(x + 432, yy + 22), "%d%%" % int(fr * 100.0), 17, Color.WHITE)
		yy += rh
		prev = k
	tower_bottom = yy + 3.0


func _draw_timing(vp: Vector2, c) -> void:
	var w := 230.0
	var x := vp.x - w - 18.0
	var y := 14.0
	var info: Dictionary = game.lap_info()
	var rows := [["Runde", str(info["lap"]), Color.WHITE], ["Letzte", info["last"], Color.WHITE], ["Beste", info["best"], Color(0.8, 0.55, 1.0)], ["Aktuelle", info["cur"], Color.WHITE]]
	panel(Rect2(x, y, w, rows.size() * 34 + 74))
	var yy := y
	for r in rows:
		txt(Vector2(x + 10, yy + 25), r[0], 21, Color.WHITE)
		var val: String = r[1]
		txt(Vector2(x, yy + 25), "-" if val == "-:--.---" else val, 21, r[2], HORIZONTAL_ALIGNMENT_RIGHT, w - 10)
		draw_line(Vector2(x, yy + 34), Vector2(x + w, yy + 34), Color(1, 1, 1, 0.08), 1.0)
		yy += 34
	var secs: Array = game.sector_state()
	for k in 3:
		var sc: Array = secs[k]
		var sx := x + 8 + k * 72
		txt(Vector2(sx, yy + 16), "S%d" % (k + 1), 13, Color(1, 1, 1, 0.8), HORIZONTAL_ALIGNMENT_CENTER, 68)
		draw_rect(Rect2(sx + 4, yy + 20, 60, 4), sc[1])
	var dv: float = info["delta"]
	var dtext := "-.---" if absf(dv) >= 90.0 else "%+.3f" % dv
	big(Vector2(x, yy + 62), dtext, 30, Color.WHITE if absf(dv) >= 90.0 else (Color(0.3, 1.0, 0.45) if dv < 0.0 else Color(1.0, 0.4, 0.35)), HORIZONTAL_ALIGNMENT_CENTER, w)
	yy += 74
	if game.session == "race" and (game.penalty > 0.0 or game.tl_strikes > 0):
		draw_rect(Rect2(x, yy + 6, w, 30), Color(0.6, 0.06, 0.05, 0.9) if game.penalty > 0.0 else Color(0.55, 0.38, 0.02, 0.9))
		var t := "TRACK LIMITS %d/3" % game.tl_strikes
		if game.penalty > 0.0:
			t += "  ·  +%d s" % int(game.penalty)
		txt(Vector2(x, yy + 28), t, 18, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, w)


func _draw_relative(vp: Vector2, c) -> void:
	var rel: Array = game.relative_list(3)
	var w := 400.0
	var x := 18.0
	var rh := 32.0
	var h := rel.size() * rh + 34
	var y := vp.y - h - 18.0
	panel(Rect2(x, y, w, h))
	txt(Vector2(x + 10, y + 22), "Relativ", 17, Color.WHITE)
	var yy := y + 30
	for item in rel:
		var o = item[0]
		var gap: float = item[1]
		var lapdiff: int = item[2]
		var col := Color.WHITE
		if lapdiff > 0:
			col = Color(1.0, 0.55, 0.55)
		elif lapdiff < 0:
			col = Color(0.55, 0.75, 1.0)
		if o == c:
			draw_rect(Rect2(x, yy, w, rh), ROW_ME)
		var pos: int = game.order.find(o) + 1
		# class chip: position in white box + class colour
		draw_rect(Rect2(x + 8, yy + 6, 24, 21), Color(0.95, 0.95, 0.96) if o != c else ACC)
		draw_string(hfont, Vector2(x + 8, yy + 24), str(pos), HORIZONTAL_ALIGNMENT_CENTER, 24, 18, cls_col(o))
		cls_chip(Rect2(x + 34, yy + 6, 34, 21), o, "GT3" if o.spec["key"] == "gt3" else "HY")
		txt(Vector2(x + 78, yy + 24), o.name, 21, col, HORIZONTAL_ALIGNMENT_LEFT, 200)
		if o.in_pit:
			txt(Vector2(x + 284, yy + 24), "PIT", 19, Color.WHITE)
		if o != c:
			txt(Vector2(x + 300, yy + 24), "%+.1f" % gap, 21, col, HORIZONTAL_ALIGNMENT_RIGHT, 90)
		yy += rh


func _draw_minimap(vp: Vector2) -> void:
	if mm_pts.size() < 2:
		return
	var origin := Vector2(18, vp.y - 226 - 18 - (game.relative_list(3).size() * 32 + 34) - 10)
	if origin.y < tower_bottom + 8.0:
		return          # small screen / big HUD: no room between the timing tower and the relative box
	rrect(Rect2(origin, Vector2(186, 226)), Color(0.03, 0.035, 0.05, 0.6), 10.0)
	var tfm := Transform2D(0.0, origin + Vector2(8, 8)) * mm_tf
	var pts := tfm * mm_pts
	draw_polyline(pts, Color(0, 0, 0, 0.6), 7.0, true)
	draw_polyline(pts, Color(0.92, 0.94, 0.96), 3.5, true)
	for o in game.cars:
		if o == game.player:
			continue
		draw_circle(tfm * Vector2(o.x, o.z), 3.5, cls_col(o) if not o.retired else Color(0.4, 0.4, 0.4))
	var p = game.player
	draw_circle(tfm * Vector2(p.x, p.z), 6.0, Color(0, 0, 0))
	draw_circle(tfm * Vector2(p.x, p.z), 4.5, ACC)


func _draw_dial(vp: Vector2, c) -> void:
	var R := 118.0
	var cen := Vector2(vp.x - R - 34, vp.y - R - 40)
	draw_circle(cen, R + 12, Color(0.02, 0.025, 0.035, 0.8))
	var spec: Dictionary = c.spec
	var frac := clampf((c.rpm - spec["rpmIdle"]) / (spec["rpmMax"] - spec["rpmIdle"]), 0.0, 1.0)
	var a0 := deg_to_rad(120.0)
	var a1 := deg_to_rad(420.0)
	# coloured rpm ring: green -> yellow -> red, white needle segment
	draw_arc(cen, R - 2, a0, a1, 64, Color(1, 1, 1, 0.1), 12.0, true)
	var segs := 40
	for k in segs:
		var f0 := float(k) / segs
		if f0 > frac:
			break
		var col := Color(0.2, 0.85, 0.35).lerp(Color(1.0, 0.85, 0.1), clampf(f0 * 1.6, 0.0, 1.0))
		if f0 > 0.85:
			col = Color(1.0, 0.2, 0.15)
		draw_arc(cen, R - 2, lerpf(a0, a1, f0), lerpf(a0, a1, minf(frac, f0 + 1.0 / segs)), 3, col, 12.0, true)
	var gear_txt := "N" if c.gear == 0 else ("R" if c.gear < 0 else str(c.gear))
	big(cen + Vector2(-110, 38), gear_txt, 132, Color(0.3, 0.6, 1.0) if c.limiter else Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 120)
	big(cen + Vector2(0, -22), "%d" % int(c.rpm), 34, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, 120)
	big(cen + Vector2(10, 38), "%d" % int(absf(c.u) * 3.6), 52, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 90)
	txt(cen + Vector2(10, 62), "KPH", 18, Color(0.85, 0.87, 0.9), HORIZONTAL_ALIGNMENT_CENTER, 90)
	# fuel / energy bars under the dial (like the real display)
	var info0: Dictionary = game.lap_info()
	var bx := cen.x - 100
	var by := cen.y + R - 6
	var fr: float = clampf(c.fuel / spec["fuelCap"], 0.0, 1.0)
	draw_rect(Rect2(bx, by, 200, 20), Color(0.08, 0.08, 0.1, 0.9))
	draw_rect(Rect2(bx, by, 200 * fr, 20), Color(0.86, 0.2, 0.35))
	txt(Vector2(bx + 6, by + 16), "%.1fL (%.1f Runden)" % [c.fuel, info0["fuel_laps"]], 15, Color.WHITE)


func rrect(r: Rect2, col: Color, radius: float, border: Color = Color(0, 0, 0, 0), bw: float = 0.0) -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(int(radius))
	sb.anti_aliasing = true
	if bw > 0.0:
		sb.border_color = border
		sb.set_border_width_all(int(bw))
	draw_style_box(sb, r)


# car status (bottom right, left of the rev dial): assists, car from above with damage zones and
# rounded tyres coloured by temperature, tread left, fuel per lap and compound
func _draw_damage(vp: Vector2, c) -> void:
	var w := 178.0
	var h := 262.0
	var x := vp.x - 34.0 - 2.0 * 118.0 - 24.0 - 16.0 - w
	var y := vp.y - 22.0 - h
	rrect(Rect2(x, y, w, h), Color(0.02, 0.025, 0.035, 0.8), 10.0)
	# assist pills
	var flags := [["TC", c.tc_active, c.tc_on], ["ABS", c.abs_active, c.abs_on], ["PIT", c.limiter, true], ["SLIP", c.draft > 0.15, true]]
	for k in flags.size():
		var f: Array = flags[k]
		var r := Rect2(x + 8 + k * 41, y + 8, 37, 20)
		var on: bool = f[1]
		var col := (Color(0.25, 0.55, 1.0) if f[0] == "PIT" else Color(1.0, 0.72, 0.12)) if on else Color(0.13, 0.14, 0.17)
		rrect(r, col, 10.0)
		draw_string(hfont, r.position + Vector2(0, 16), f[0], HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 14,
			Color(0.05, 0.05, 0.05) if on else (Color(0.8, 0.82, 0.86) if f[2] else Color(0.4, 0.4, 0.42)))
	# car body from above (damage zones), rounded
	var d: Dictionary = c.dmg
	var cx := x + w * 0.5
	var top := y + 46.0
	var zc := func(v: float) -> Color:
		if v < 0.05:
			return Color(0.32, 0.36, 0.42)
		if v < 0.35:
			return Color(1.0, 0.75, 0.1)
		return Color(1.0, 0.22, 0.16)
	rrect(Rect2(cx - 30, top, 60, 34), zc.call(d["front"]), 16.0)                       # nose
	rrect(Rect2(cx - 34, top + 30, 12, 92), zc.call(maxf(d["left"], d["susp_l"])), 6.0)  # left side
	rrect(Rect2(cx + 22, top + 30, 12, 92), zc.call(maxf(d["right"], d["susp_r"])), 6.0) # right side
	rrect(Rect2(cx - 20, top + 34, 40, 84), Color(0.1, 0.11, 0.14), 8.0)                # cockpit
	rrect(Rect2(cx - 14, top + 52, 28, 44), zc.call(d["engine"]), 6.0)                  # engine / gearbox
	rrect(Rect2(cx - 32, top + 118, 64, 30), zc.call(d["rear"]), 12.0)                  # rear
	rrect(Rect2(cx - 38, top + 146, 76, 7), Color(0.05, 0.05, 0.06) if not c.lost["wing"] else Color(1.0, 0.22, 0.16), 3.0)
	# tyres: rounded, colour = temperature, number = tread left
	var cmp: Dictionary = c.cmp()
	var temps := [c.temp_f, c.temp_f + 1.5, c.temp_r, c.temp_r + 1.5]
	var wears := [c.wear_f, c.wear_f, c.wear_r, c.wear_r]
	for k in 4:
		var left := k % 2 == 0
		var ty: float = top + (12.0 if k < 2 else 104.0)
		var tr := Rect2(cx + (-62.0 if left else 42.0), ty, 20, 40)
		var tc: Color = Gfx.temp_col(temps[k], cmp["topt"])
		rrect(tr, tc, 9.0, Color(0, 0, 0, 0.6), 2.0)
		# tread bar inside the tyre
		var tread: float = clampf(1.0 - wears[k], 0.0, 1.0)
		rrect(Rect2(tr.position.x + 6, tr.position.y + 4 + 32 * (1.0 - tread), 8, 32 * tread), Color(1, 1, 1, 0.55), 3.0)
		var lx := tr.position.x - 40.0 if left else tr.end.x + 4.0
		draw_string(font, Vector2(lx, ty + 16), "%d°" % int(temps[k]), HORIZONTAL_ALIGNMENT_RIGHT if left else HORIZONTAL_ALIGNMENT_LEFT, 36, 15, Color.WHITE)
		draw_string(font, Vector2(lx, ty + 33), "%d%%" % int(tread * 100.0), HORIZONTAL_ALIGNMENT_RIGHT if left else HORIZONTAL_ALIGNMENT_LEFT, 36, 13, Color(0.75, 0.78, 0.82))
	# compound + fuel use
	var info: Dictionary = game.lap_info()
	rrect(Rect2(x + 8, y + h - 50, w - 16, 20), Color(0.1, 0.11, 0.14), 10.0)
	draw_circle(Vector2(x + 20, y + h - 40), 6.0, cmp["col"])
	draw_string(font, Vector2(x + 30, y + h - 34), String(cmp["name"]).to_upper(), HORIZONTAL_ALIGNMENT_LEFT, 80, 14, Color.WHITE)
	draw_string(font, Vector2(x + 8, y + h - 34), "%.1f Rd." % info["fuel_laps"], HORIZONTAL_ALIGNMENT_RIGHT, w - 24, 14, Color(0.75, 0.78, 0.82))
	if c.lost["wing"] or c.lost["splitter"]:
		draw_string(hfont, Vector2(x, y + h - 10), "FLÜGEL VERLOREN!" if c.lost["wing"] else "FRONTSPLITTER!", HORIZONTAL_ALIGNMENT_CENTER, w, 16, Color(1.0, 0.3, 0.2))
	else:
		draw_string(font, Vector2(x, y + h - 10), "SCHADEN · REIFEN", HORIZONTAL_ALIGNMENT_CENTER, w, 13, Color(0.6, 0.63, 0.68))


func _draw_radar(vp: Vector2, c) -> void:
	var near: Array = []
	for o in game.cars:
		if o == c:
			continue
		var dx: float = o.x - c.x
		var dz: float = o.z - c.z
		var cp := cos(c.psi)
		var sp := sin(c.psi)
		var fwd := dx * cp + dz * sp
		var side := -dx * sp + dz * cp
		if absf(fwd) < 22.0 and absf(side) < 9.0:
			near.append([o, fwd, side])
	if near.is_empty():
		return
	var cen := Vector2(vp.x * 0.5, 190)
	var sc := 6.5
	draw_rect(Rect2(cen - Vector2(70, 150), Vector2(140, 300)), Color(0, 0, 0, 0.28))
	var L: float = c.spec["len"]
	draw_rect(Rect2(cen - Vector2(6, L * sc * 0.5), Vector2(12, L * sc)), Color(1, 1, 1, 0.85))
	var left_warn := 0.0
	var right_warn := 0.0
	for item in near:
		var o = item[0]
		var f: float = item[1]
		var s: float = item[2]
		var ol: float = o.spec["len"]
		var dpsi: float = wrapf(o.psi - c.psi, -PI, PI)
		var pos := cen + Vector2(s * sc, -f * sc)
		draw_set_transform_matrix(base_xf * Transform2D(dpsi, pos))
		var close := absf(f) < (L + ol) * 0.5 + 0.5
		var col := Color(1.0, 0.25, 0.2, 0.9) if close and absf(s) < 3.2 else (Color(1.0, 0.8, 0.1, 0.85) if close else Color(0.8, 0.85, 0.9, 0.7))
		draw_rect(Rect2(Vector2(-6, -ol * sc * 0.5), Vector2(12, ol * sc)), col)
		draw_set_transform_matrix(base_xf)
		if close:
			if s < 0.0:
				left_warn = maxf(left_warn, 1.0 if absf(s) < 3.2 else 0.5)
			else:
				right_warn = maxf(right_warn, 1.0 if absf(s) < 3.2 else 0.5)
	for side in [[-1.0, left_warn], [1.0, right_warn]]:
		var wv: float = side[1]
		if wv > 0.0:
			draw_rect(Rect2(cen + Vector2(side[0] * 62 - 4, -60), Vector2(8, 120)), Color(1.0, 0.2, 0.15, 0.9) if wv >= 1.0 else Color(1.0, 0.8, 0.1, 0.9))


# marshal flags like in LMU: one row of flag cards at the top centre, plus the open penalty
func _draw_flags(vp: Vector2) -> void:
	var R = game.rules
	var cards: Array = []     # [text, colour, text colour, (optional second colour for split flags)]
	if R.dsq:
		cards.append(["SCHWARZE FLAGGE", Color(0.02, 0.02, 0.02, 0.95), Color.WHITE])
	if R.fcy == "warn":
		cards.append(["FCY IN %d s" % int(ceil(R.fcy_t)), Color(1.0, 0.82, 0.05, 0.95), Color.BLACK])
	elif R.fcy == "on":
		cards.append(["FULL COURSE YELLOW  ·  80", Color(1.0, 0.82, 0.05, 0.95), Color.BLACK])
	elif R.fcy == "end":
		cards.append(["FCY · GRÜN IN %d s" % int(ceil(R.fcy_t)), Color(1.0, 0.82, 0.05, 0.95), Color.BLACK])
	elif R.yellow == 2:
		cards.append(["DOPPELT GELB  ·  NICHT ÜBERHOLEN", Color(1.0, 0.82, 0.05, 0.95), Color.BLACK])
	elif R.yellow == 1:
		cards.append(["GELB  ·  NICHT ÜBERHOLEN", Color(1.0, 0.82, 0.05, 0.95), Color.BLACK])
	elif R.green_t > 0.0:
		cards.append(["GRÜN", Color(0.1, 0.7, 0.25, 0.95), Color.WHITE])
	if game.blue_flag:
		cards.append(["BLAUE FLAGGE", Color(0.12, 0.42, 1.0, 0.95), Color.WHITE])
	if R.bw_t > 0.0:
		cards.append(["VERWARNUNG", Color(0.02, 0.02, 0.02, 0.95), Color.WHITE, Color(0.95, 0.95, 0.95, 0.95)])
	if R.meatball:
		cards.append(["REPARATUR NÖTIG", Color(0.02, 0.02, 0.02, 0.95), Color.WHITE, Color(1.0, 0.45, 0.0, 1.0)])
	var pt: String = R.pending_text()
	if R.stopgo_t >= 0.0:
		pt = "STOP & GO  ·  %d" % int(ceil(R.stopgo_t))
	if pt != "":
		cards.append([pt, Color(0.75, 0.08, 0.06, 0.95), Color.WHITE])
	if cards.is_empty():
		return
	var w := 300.0
	var gap := 10.0
	var x0 := vp.x * 0.5 - (cards.size() * w + (cards.size() - 1) * gap) * 0.5
	for k in cards.size():
		var cd: Array = cards[k]
		var r := Rect2(x0 + k * (w + gap), 64, w, 38)
		rrect(r, cd[1], 6.0)
		if cd.size() > 3:
			# split flag: diagonal half (black/white) or orange disc (black/orange)
			if String(cd[0]) == "VERWARNUNG":
				draw_colored_polygon(PackedVector2Array([r.position + Vector2(r.size.x - 44, 0), r.position + Vector2(r.size.x, 0), r.position + Vector2(r.size.x, r.size.y)]), cd[3])
			else:
				draw_circle(r.position + Vector2(r.size.x - 22, r.size.y * 0.5), 12, cd[3])
		txt(r.position + Vector2(0, 27), cd[0], 19, cd[2], HORIZONTAL_ALIGNMENT_CENTER, w)


func _draw_center(vp: Vector2, c) -> void:
	# start lights
	if game.state == "grid":
		var n: int = game.lights_n
		rrect(Rect2(vp.x * 0.5 - 150, 100, 300, 64), Color(0.02, 0.02, 0.03, 0.9), 12.0)
		for k in 5:
			draw_circle(Vector2(vp.x * 0.5 - 112 + k * 56, 132), 20, Color(1.0, 0.1, 0.1) if k < n else Color(0.15, 0.05, 0.05))
	_draw_flags(vp)
	if game.msg_t > 0.0:
		var a := clampf(game.msg_t * 2.0, 0.0, 1.0)
		var w := 640.0
		var my: float = 112.0 if game.pit_menu_open else vp.y * 0.26      # above the open pit menu
		rrect(Rect2(vp.x * 0.5 - w * 0.5, my, w, 54), Color(0.04, 0.05, 0.07, 0.8 * a), 8.0)
		draw_rect(Rect2(vp.x * 0.5 - w * 0.5, my, 6, 54), Color(game.msg_col.r, game.msg_col.g, game.msg_col.b, a))
		txt(Vector2(vp.x * 0.5 - w * 0.5, my + 38), game.msg, 30, Color(1, 1, 1, a), HORIZONTAL_ALIGNMENT_CENTER, w)
	if c.retired:
		draw_rect(Rect2(vp.x * 0.5 - 220, vp.y * 0.4, 440, 80), Color(0.5, 0.05, 0.05, 0.85))
		txt(Vector2(vp.x * 0.5 - 220, vp.y * 0.4 + 52), "DISQUALIFIZIERT" if c.has_meta("dsq") else "AUSGEFALLEN", 44, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 440)
	var ps = game.player_pit
	if ps != null and not ps.standby:
		var pr: Dictionary = ps.progress()
		var w := 380.0
		var x := vp.x * 0.5 - w * 0.5
		var y := vp.y - 200.0
		rrect(Rect2(x, y, w, 156), Color(0.03, 0.035, 0.05, 0.85), 10.0)
		big(Vector2(x, y + 26), "BOXENSTOPP  ·  %.1f s" % pr["left"], 24, ACC, HORIZONTAL_ALIGNMENT_CENTER, w)
		var yy := y + 40
		for item in [["Tanken", pr["fuel"]], ["Reifen", pr["tyres"]], ["Reparatur", pr["repair"]], ["Bremse/Flügel", pr.get("extra", -1.0)]]:
			var v: float = item[1]
			txt(Vector2(x + 14, yy + 15), item[0], 15, Color(0.75, 0.78, 0.82) if v >= 0.0 else Color(0.4, 0.4, 0.4))
			rrect(Rect2(x + 110, yy + 4, w - 130, 12), Color(0.15, 0.16, 0.19), 6.0)
			if v > 0.02:
				rrect(Rect2(x + 110, yy + 4, (w - 130) * v, 12), Color(0.2, 0.85, 0.4) if v >= 1.0 else ACC, 6.0)
			yy += 26
	if game.hint_t > 0.0:
		txt(Vector2(0, vp.y - 10), "W/S Gas/Bremse · A/D Lenken · Maus L/R oder Q/E Schalten · L Pit-Limiter · Tab Boxenmenü · F Box anfordern · C Kamera · Esc Pause", 14, Color(1, 1, 1, clampf(game.hint_t, 0.0, 0.6)), HORIZONTAL_ALIGNMENT_CENTER, vp.x)


func _draw_pit_menu(vp: Vector2, c) -> void:
	var w := 470.0
	var x := 520.0
	var y := vp.y * 0.22
	rrect(Rect2(x, y, w, 470), Color(0.03, 0.035, 0.05, 0.92), 10.0)
	txt(Vector2(x + 14, y + 26), "BOXENSTRATEGIE", 20, ACC)
	var plan: Dictionary = game.pit_plan
	var set_names := {"all": "Alle 4", "front": "Nur vorne", "rear": "Nur hinten"}
	var tyre_name: String = "Kein Wechsel" if plan["tyres"] == "" else String(CarPhysics.COMPOUNDS[plan["tyres"]]["name"])
	if plan["tyres"] != "" and plan["set"] != "all":
		tyre_name = "gleiche Mischung"
	var rows := [
		["1 / 2", "Nachtanken", "+%d L  (im Tank %d L)" % [int(plan["fuel_add"]), int(c.fuel)]],
		["3", "Reifen", tyre_name],
		["4", "Welche Reifen", "-" if plan["tyres"] == "" else String(set_names[plan["set"]])],
		["5", "Reparatur", ("Ja (%.0f s)" % c.repair_time()) if plan["repair"] else "Nein"],
		["7", "Reifendruck (neue Reifen)", "%+.1f bar" % float(plan["press_f"])],
		["8", "Heckflügel", "%d%s" % [int(plan["wing"]), "  (jetzt %d)" % int(c.setup["wing"]) if int(plan["wing"]) != int(c.setup["wing"]) else ""]],
		["9", "Bremsbeläge wechseln", ("Ja (+32 s)  ·  Belag %d %%" if plan["pads"] else "Nein  ·  Belag %d %%") % int((1.0 - c.pad_wear) * 100.0)],
		["0", "Sprit bis ins Ziel", "+%d L berechnen" % int(game.fuel_to_finish())],
		["F", "Box anfordern", "JA – Crew bereitet vor" if plan["requested"] else "nein"],
	]
	var yy := y + 56
	for r in rows:
		txt(Vector2(x + 14, yy), r[0], 14, Color(0.6, 0.63, 0.68))
		txt(Vector2(x + 70, yy), r[1], 17, Color.WHITE)
		var col: Color = Color(0.3, 1.0, 0.45) if r[0] == "F" and plan["requested"] else ACC
		txt(Vector2(x + 70, yy), r[2], 17, col, HORIZONTAL_ALIGNMENT_RIGHT, w - 90)
		yy += 32
	var tf: float = c.temp_f
	var tr: float = c.temp_r
	txt(Vector2(x + 14, yy + 2), "Reifen: vorne %d °C · %d %%   hinten %d °C · %d %%" % [int(tf), int((1.0 - c.wear_f) * 100.0), int(tr), int((1.0 - c.wear_r) * 100.0)], 14, Color(0.75, 0.78, 0.82))
	var kg: float = c.fuel * CarPhysics.FUEL_KG
	var add_kg: float = minf(float(plan["fuel_add"]), c.spec["fuelCap"] - c.fuel) * CarPhysics.FUEL_KG
	txt(Vector2(x + 14, yy + 24), "Sprit-Gewicht jetzt %d kg · nach dem Stopp %d kg (≈ +%.1f s/Runde)" % [int(kg), int(kg + add_kg), (kg + add_kg) * 0.03 * game.T.length / 7000.0], 14, Color(0.75, 0.78, 0.82))
	if game.session == "race":
		var no_tyres: bool = not game._tyres_allowed(plan)
		txt(Vector2(x + 14, yy + 46), "Reifensätze übrig: %s%s" % [str(snappedf(game.tyre_sets_left, 0.5)), "  –  KEINE NEUEN REIFEN MEHR" if no_tyres else ""], 14, Color(1.0, 0.4, 0.3) if no_tyres else Color(0.75, 0.78, 0.82))
	txt(Vector2(x + 14, yy + 70), "Geschätzte Standzeit: %.1f s%s" % [game.estimate_stop(), "" if plan["requested"] else "  (+3 s, nicht angefordert)"], 15, Color(0.75, 0.78, 0.82))
	txt(Vector2(x + 14, yy + 92), "Erst tanken, dann Reifen (WEC-Regel) · In deiner Box anhalten · Tab schließt", 13, Color(0.6, 0.63, 0.68))


# crew radio message (top left, below the timing tower area)
func _draw_radio(vp: Vector2) -> void:
	if game.pit_plan.get("requested", false):
		panel(Rect2(vp.x * 0.5 - 70, 112, 140, 30), Color(0.05, 0.45, 0.15, 0.9))
		txt(Vector2(vp.x * 0.5 - 70, 134), "BOX  BOX", 18, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 140)
	if game.radio_t <= 0.0 or game.radio_txt == "":
		return
	var a := clampf(game.radio_t * 2.0, 0.0, 1.0)
	var w := 430.0
	var x := vp.x - 18.0 - w
	var y := 282.0
	var ask: bool = not game.radio_suggest.is_empty()
	var h := 112.0 if ask else 90.0
	rrect(Rect2(x, y, w, h), Color(0.03, 0.04, 0.06, 0.88 * a), 8.0)
	draw_rect(Rect2(x, y + 6, 4, h - 12), Color(0.2, 0.75, 1.0, a))
	# little blinking "on air" dot
	if int(Time.get_ticks_msec() / 400) % 2 == 0:
		draw_circle(Vector2(x + 22, y + 18), 5, Color(1.0, 0.25, 0.2, a))
	txt(Vector2(x + 34, y + 24), "BOXENFUNK · RENNINGENIEUR", 14, Color(0.45, 0.8, 1.0, a))
	draw_multiline_string(font, Vector2(x + 18, y + 50), game.radio_txt, HORIZONTAL_ALIGNMENT_LEFT, w - 30, 17, 2, Color(1, 1, 1, a))
	if ask:
		txt(Vector2(x + 18, y + h - 12), "F = Ja, Box diese Runde   ·   ignorieren = Nein", 14, Color(0.3, 1.0, 0.45, a))

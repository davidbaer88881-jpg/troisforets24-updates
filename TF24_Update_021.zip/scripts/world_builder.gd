# Builds the circuit: road, curbs, gravel, pit lane with markings, barriers, terrain, forests, buildings.
extends RefCounted

const Gfx = preload("res://scripts/gfx.gd")
const Flora = preload("res://scripts/flora.gd")
const NB_FWD := [Vector2i(-1, 0), Vector2i(0, -1), Vector2i(-1, -1), Vector2i(1, -1)]
const NB_BWD := [Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(-1, 1)]

var T
var root: Node3D
var quality := "high"
var start_lights: Array = []
var road_mat: ShaderMaterial
var curb_mat: ShaderMaterial
var lane_mat: ShaderMaterial
var terrain_mat: ShaderMaterial
var road_tex := {}
var grass_tex := {}
var macro: NoiseTexture2D
var pit_lights: Array = []
var lamp_mat: StandardMaterial3D
var line_mesh: MeshInstance3D
var grass_mat: ShaderMaterial
var flat_zones: Array = []            # Vector4(x, z, radius, height): terrain kept below the pit lane / paddock
var paddock_w := PackedFloat32Array() # paddock depth behind the garages per lane sample
var stand_zones: Array = []           # [s0, s1, back lateral] kept free of trees

# distance field (nearest track sample per grid cell) used for terrain and tree placement
var g_min := Vector2.ZERO
var g_step := 12.0
var g_nx := 0
var g_nz := 0
var g_idx := PackedInt32Array()
var g_dist := PackedFloat32Array()
var g_h := PackedFloat32Array()


func build(track, parent: Node3D, q: String) -> Node3D:
	T = track
	quality = q
	root = Node3D.new()
	root.name = "World"
	parent.add_child(root)
	_road()
	_curbs()
	_runoff()
	_barriers()
	_distance_field()
	_pit_lane()
	_grandstands()
	_terrain()
	_trees()
	_meadow()
	_garages()
	_gantry()
	_bridges()
	_boards()
	_signs()
	return root


# ---------------------------------------------------------------- helpers
func up_at(i: int) -> Vector3:
	return Vector3(T.rx[i], 0.0, T.rz[i]).cross(Vector3(T.tx[i], T.grade[i], T.tz[i])).normalized()


func range_idx(from_s: float, to_s: float) -> PackedInt32Array:
	var out := PackedInt32Array()
	var a: int = T.idx(from_s)
	var b: int = T.idx(to_s)
	if b == a:
		b = (a + 1) % T.N        # a strip needs at least two samples
	var i := a
	while true:
		out.append(i)
		if i == b or out.size() > T.N + 1:
			break
		i = (i + 1) % T.N
	return out


func all_idx() -> PackedInt32Array:
	var out := PackedInt32Array()
	for i: int in T.N + 1:
		out.append(i % T.N)
	return out


func runs(flag: Callable) -> Array:
	var res: Array = []
	var start := 0
	while start < T.N and flag.call(start):
		start += 1
	var cur := PackedInt32Array()
	for k: int in T.N + 1:
		var i: int = (start + k) % T.N
		if flag.call(i):
			cur.append(i)
		elif cur.size() > 0:
			res.append(cur)
			cur = PackedInt32Array()
	if cur.size() > 0:
		res.append(cur)
	return res


func strip(ids: PackedInt32Array, lat_a: Callable, lat_b: Callable, yoff: float, cols: int, v_scale: float,
		color_fn: Callable = Callable(), bulge: float = 0.0, tangents: bool = false) -> ArrayMesh:
	var verts := PackedVector3Array()
	var nrm := PackedVector3Array()
	var uvs := PackedVector2Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	var s_acc := 0.0
	var n := ids.size()
	for k in n:
		var i := ids[k]
		if k > 0:
			s_acc += T.ds
		var a: float = lat_a.call(i)
		var b: float = lat_b.call(i)
		var up := up_at(i)
		for c in cols + 1:
			var f := float(c) / cols
			var la := lerpf(a, b, f)
			verts.append(Vector3(T.px[i] + T.rx[i] * la, T.py[i] + yoff + bulge * sin(f * PI), T.pz[i] + T.rz[i] * la))
			nrm.append(up)
			uvs.append(Vector2(f, s_acc / v_scale))
			if color_fn.is_valid():
				var cc: float = color_fn.call(i, la)
				colors.append(Color(cc, cc, cc))
		if k < n - 1:
			for c in cols:
				var a0 := k * (cols + 1) + c
				var b0 := a0 + cols + 1
				indices.append_array([a0, b0, a0 + 1, a0 + 1, b0, b0 + 1])
	return Gfx.make_mesh(verts, nrm, uvs, colors, indices, tangents)


# vertical wall/ribbon along a lateral offset; both faces are rendered via the material
func wall(ids: PackedInt32Array, lat_fn: Callable, y0: float, h: float, v_scale: float) -> ArrayMesh:
	var verts := PackedVector3Array()
	var nrm := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	var s_acc := 0.0
	for k in ids.size():
		var i := ids[k]
		if k > 0:
			s_acc += T.ds
		var la: float = lat_fn.call(i)
		var base := Vector3(T.px[i] + T.rx[i] * la, T.py[i] + y0, T.pz[i] + T.rz[i] * la)
		var nn := Vector3(-T.rx[i], 0.0, -T.rz[i]) * signf(la if la != 0.0 else 1.0)
		verts.append(base)
		verts.append(base + Vector3(0, h, 0))
		nrm.append(nn)
		nrm.append(nn)
		uvs.append(Vector2(s_acc / v_scale, 1.0))
		uvs.append(Vector2(s_acc / v_scale, 0.0))
		if k < ids.size() - 1:
			var a0 := k * 2
			indices.append_array([a0, a0 + 2, a0 + 1, a0 + 1, a0 + 2, a0 + 3])
	return Gfx.make_mesh(verts, nrm, uvs, PackedColorArray(), indices)


func add_mesh(mesh: Mesh, m: Material, shadows: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mi)
	return mi


func node_at(s: float, lat: float, yoff: float = 0.0) -> Node3D:
	var n := Node3D.new()
	var i: int = T.idx(s)
	var p: Vector4 = T.point_at(s, lat)
	n.transform = Transform3D(Basis(Vector3(T.tx[i], 0, T.tz[i]), Vector3.UP, Vector3(T.rx[i], 0, T.rz[i])), Vector3(p.x, p.y + yoff, p.z))
	root.add_child(n)
	return n


func box(parent: Node3D, size: Vector3, pos: Vector3, m: Material, shadows: bool = true) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = m
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func label(parent: Node3D, text: String, pos: Vector3, size: int, col: Color, rot := Vector3.ZERO, px_size := 0.02) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = size
	l.pixel_size = px_size
	l.modulate = col
	l.outline_size = 0
	l.position = pos
	l.rotation = rot
	l.double_sided = true
	l.shaded = true
	parent.add_child(l)
	return l


# ---------------------------------------------------------------- road & curbs
func _rubber(i: int, la: float) -> float:
	var d: float = la - T.line_d[i]
	return 1.0 - 0.3 * exp(-d * d / 4.5)


func _road_material(width: float, vscale: float, tint: float, rubber_k: float) -> ShaderMaterial:
	var m := Gfx.shader_mat(Gfx.ROAD_SHADER)
	m.set_shader_parameter("alb", road_tex["albedo"])
	m.set_shader_parameter("rough_t", road_tex["rough"])
	m.set_shader_parameter("nrm", road_tex["normal"])
	m.set_shader_parameter("macro", macro)
	m.set_shader_parameter("width", width)
	m.set_shader_parameter("vscale", vscale)
	m.set_shader_parameter("tint", tint)
	m.set_shader_parameter("rubber_k", rubber_k)
	return m


func _road() -> void:
	road_tex = Gfx.asphalt(false)
	macro = Gfx.macro_noise()
	var hw: float = T.half_w
	road_mat = _road_material(2.0 * hw, 14.0, 1.0, 1.0)
	var mesh := strip(all_idx(), func(_i): return -hw, func(_i): return hw, 0.02, 10, 14.0, _rubber, 0.0, true)
	add_mesh(mesh, road_mat)
	# start/finish chequered line + grid boxes
	var chk := StandardMaterial3D.new()
	chk.albedo_texture = Gfx.checker()
	chk.roughness = 0.6
	var sl := strip(range_idx(-1.0, 1.0), func(_i): return -hw + 0.3, func(_i): return hw - 0.3, 0.035, 1, 2.0)
	add_mesh(sl, chk)
	var white := Gfx.mat(Color(0.92, 0.92, 0.9), 0.6)
	# white track-limit lines along both edges (the kerbs lie outside them)
	add_mesh(strip(all_idx(), func(_i): return -hw + 0.04, func(_i): return -hw + 0.22, 0.03, 1, 6.0), white)
	add_mesh(strip(all_idx(), func(_i): return hw - 0.22, func(_i): return hw - 0.04, 0.03, 1, 6.0), white)
	for k in 24:
		var s := -14.0 - k * 9.0
		var la := 3.2 if k % 2 else -3.2
		add_mesh(strip(range_idx(s - 0.2, s + 0.4), func(_i): return la - 1.2, func(_i): return la + 1.2, 0.035, 1, 1.0), white)


func _curbs() -> void:
	curb_mat = Gfx.shader_mat(Gfx.CURB_SHADER)
	curb_mat.set_shader_parameter("macro", macro)
	var hw: float = T.half_w
	for r in runs(func(i): return T.curb_l[i] == 1):
		var ids: PackedInt32Array = r
		add_mesh(strip(ids, func(_i): return -hw - 1.3, func(_i): return -hw + 0.02, 0.03, 6, 8.0, Callable(), 0.07, true), curb_mat)
	for r in runs(func(i): return T.curb_r[i] == 1):
		var ids: PackedInt32Array = r
		add_mesh(strip(ids, func(_i): return hw - 0.02, func(_i): return hw + 1.3, 0.03, 6, 8.0, Callable(), 0.07, true), curb_mat)


func _side_ext(i: int, sd: int) -> float:
	return T.ext_r[i] if sd > 0 else T.ext_l[i]


# outer edge of the run-off / verge on one side (never past the barrier or the pit lane)
func _side_outer(i: int, sd: int) -> float:
	var o: float = (T.bar_r[i] if sd > 0 else T.bar_l[i]) + 0.6
	if sd > 0 and T.pit_open[i] == 1:
		o = maxf(T.half_w + 0.3, T.pit_edge[i] - 0.1)
	return minf(o, _side_ext(i, sd))


func _band_col(c: String) -> Color:
	match c:
		"r":
			return Color(0.78, 0.07, 0.08)
		"y":
			return Color(0.95, 0.78, 0.05)
		_:
			return Color(0.12, 0.55, 0.3)


func _runoff() -> void:
	var gm := StandardMaterial3D.new()
	gm.albedo_texture = Gfx.gravel()
	gm.albedo_color = Color(0.85, 0.8, 0.7)
	gm.roughness = 1.0
	gm.uv1_scale = Vector3(3, 1, 1)
	var tm := StandardMaterial3D.new()
	tm.albedo_texture = road_tex["albedo"]
	tm.albedo_color = Color(0.86, 0.85, 0.82)
	tm.roughness = 0.95
	tm.uv1_scale = Vector3(2, 1, 1)
	grass_tex = Gfx.grass()
	grass_mat = Gfx.shader_mat(Gfx.GRASS_SHADER)
	grass_mat.set_shader_parameter("alb", grass_tex["albedo"])
	grass_mat.set_shader_parameter("nrm", grass_tex["normal"])
	grass_mat.set_shader_parameter("macro", macro)
	var band_mats := {}
	for c in ["g", "r", "y"]:
		var bm := Gfx.mat(_band_col(c), 0.7)
		band_mats[c] = bm
	var hw: float = T.half_w
	for side in [-1, 1]:
		var sd: int = side
		var start_of := func(i: int) -> float:
			var cb: int = T.curb_r[i] if sd > 0 else T.curb_l[i]
			return hw + (1.3 if cb == 1 else 0.0)
		# verge (grass) wherever there is no run-off: covers the ground right up to the asphalt
		var vflag := func(i): return (T.run_r[i] if sd > 0 else T.run_l[i]) == 0
		for r in runs(vflag):
			var ids: PackedInt32Array = r
			add_mesh(strip(ids, func(i): return sd * minf(start_of.call(i), _side_outer(i, sd)), func(i): return sd * _side_outer(i, sd), -0.015, 2, 6.0, Callable(), 0.0, true), grass_mat)
		# painted bands (2 m each) right behind the kerb
		for bi in 4:
			var bk: int = bi
			for c in ["g", "r", "y"]:
				var col: String = c
				var bflag := func(i):
					var bs: String = T.band_r[i] if sd > 0 else T.band_l[i]
					return bs.length() > bk and bs[bk] == col
				for r in runs(bflag):
					var ids: PackedInt32Array = r
					add_mesh(strip(ids, func(i): return sd * minf(start_of.call(i) + bk * 2.0, _side_outer(i, sd)),
						func(i): return sd * minf(start_of.call(i) + bk * 2.0 + 2.0, _side_outer(i, sd)), 0.012, 1, 6.0), band_mats[col])
		# gravel / tarmac beyond the bands up to the barrier
		for typ in [1, 2]:
			var ty: int = typ
			var flag := func(i): return (T.run_r[i] if sd > 0 else T.run_l[i]) == ty
			for r in runs(flag):
				var ids: PackedInt32Array = r
				var inner := func(i: int) -> float:
					var bs: String = T.band_r[i] if sd > 0 else T.band_l[i]
					return minf(start_of.call(i) + 2.0 * bs.length(), _side_outer(i, sd))
				add_mesh(strip(ids, func(i): return sd * inner.call(i), func(i): return sd * _side_outer(i, sd),
					-0.04 if ty == 1 else 0.0, 3, 6.0), gm if ty == 1 else tm)


# ---------------------------------------------------------------- pit lane (own centreline)
func lane_runs(flag: Callable) -> Array:
	var res: Array = []
	var cur := PackedInt32Array()
	for q: int in T.lN:
		if flag.call(q):
			cur.append(q)
		elif cur.size() > 0:
			res.append(cur)
			cur = PackedInt32Array()
	if cur.size() > 0:
		res.append(cur)
	return res


func lane_range(a: float, b: float) -> PackedInt32Array:
	var out := PackedInt32Array()
	for q in range(clampi(int(a), 0, T.lN - 1), clampi(int(ceilf(b)), 0, T.lN - 1) + 1):
		out.append(q)
	return out


func lane_strip(ids: PackedInt32Array, lat_a: Callable, lat_b: Callable, yoff: float, cols: int, v_scale: float) -> ArrayMesh:
	var verts := PackedVector3Array()
	var nrm := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	var n := ids.size()
	for k in n:
		var q := ids[k]
		var a: float = lat_a.call(q)
		var b: float = lat_b.call(q)
		for c in cols + 1:
			var f := float(c) / cols
			var la := lerpf(a, b, f)
			verts.append(Vector3(T.lx[q] + T.lrx[q] * la, T.ly[q] + yoff, T.lz[q] + T.lrz[q] * la))
			nrm.append(Vector3.UP)
			uvs.append(Vector2(f, float(q) / v_scale))
		if k < n - 1:
			for c in cols:
				var a0 := k * (cols + 1) + c
				var b0 := a0 + cols + 1
				indices.append_array([a0, b0, a0 + 1, a0 + 1, b0, b0 + 1])
	return Gfx.make_mesh(verts, nrm, uvs, PackedColorArray(), indices)


func lane_wall(ids: PackedInt32Array, la: float, y0: float, h: float, v_scale: float) -> ArrayMesh:
	var verts := PackedVector3Array()
	var nrm := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	for k in ids.size():
		var q := ids[k]
		var base := Vector3(T.lx[q] + T.lrx[q] * la, T.ly[q] + y0, T.lz[q] + T.lrz[q] * la)
		var nn := Vector3(-T.lrx[q], 0.0, -T.lrz[q])
		verts.append(base)
		verts.append(base + Vector3(0, h, 0))
		nrm.append(nn)
		nrm.append(nn)
		uvs.append(Vector2(float(q) / v_scale, 1.0))
		uvs.append(Vector2(float(q) / v_scale, 0.0))
		if k < ids.size() - 1:
			var a0 := k * 2
			indices.append_array([a0, a0 + 2, a0 + 1, a0 + 1, a0 + 2, a0 + 3])
	return Gfx.make_mesh(verts, nrm, uvs, PackedColorArray(), indices)


func lane_node(ps: float, la: float, yoff: float = 0.0) -> Node3D:
	var n := Node3D.new()
	var q := clampi(int(ps), 0, T.lN - 1)
	var p: Vector4 = T.lane_point(ps, la)
	n.transform = Transform3D(Basis(Vector3(T.ltx[q], 0, T.ltz[q]), Vector3.UP, Vector3(T.lrx[q], 0, T.lrz[q])), Vector3(p.x, p.y + yoff, p.z))
	root.add_child(n)
	return n


# where the lane asphalt starts on the track side: never on top of the track itself
func _lane_inner(q: int) -> float:
	return minf(T.l_out[q], maxf(-T.LANE_IN, T.half_w - T.l_tlat[q] + 0.05))


func _pit_lane() -> void:
	lane_mat = _road_material(9.0, 12.0, 0.9, 0.0)
	var all := lane_range(0.0, T.lL)
	add_mesh(lane_strip(all, _lane_inner, func(q): return T.l_out[q], 0.025, 6, 12.0), lane_mat)
	var white := Gfx.mat(Color(0.95, 0.95, 0.93), 0.6)
	var red := Gfx.mat(Color(0.82, 0.08, 0.08), 0.6)
	var yellow := Gfx.mat(Color(0.95, 0.76, 0.0), 0.6)
	var LI: float = T.LANE_IN
	# solid white line where track and lane are not separated by the wall (pit entry / exit)
	for r in lane_runs(func(q): return T.l_wall[q] == 0 and q > 2 and q < T.lN - 3):
		var ids: PackedInt32Array = r
		add_mesh(lane_strip(ids, func(_q): return -LI + 0.05, func(_q): return -LI + 0.35, 0.045, 1, 5.0), white)
	# fast lane / working lane divider (red with white edges, as at Spa) in front of the garages
	for r in lane_runs(func(q): return T.l_out[q] > 6.0):
		var ids: PackedInt32Array = r
		add_mesh(lane_strip(ids, func(_q): return 2.75, func(_q): return 2.9, 0.04, 1, 5.0), white)
		add_mesh(lane_strip(ids, func(_q): return 2.9, func(_q): return 3.3, 0.04, 1, 5.0), red)
		add_mesh(lane_strip(ids, func(_q): return 3.3, func(_q): return 3.45, 0.04, 1, 5.0), white)
	# speed-limit lines across the lane
	for li in [T.lim_a, T.lim_b]:
		var lp: float = li
		var qq := clampi(int(lp), 0, T.lN - 1)
		var wdt: float = T.l_out[qq] + LI - 0.2
		var ln := lane_node(lp, -LI + 0.1 + wdt * 0.5, 0.045)
		box(ln, Vector3(0.6, 0.02, wdt), Vector3.ZERO, yellow, false)
		var n := lane_node(lp + (7.0 if lp == T.lim_a else -7.0), 0.0, 0.05)
		label(n, "PIT LIMIT 60" if lp == T.lim_a else "END PIT LIMIT", Vector3.ZERO, 150, Color(1, 0.85, 0.1), Vector3(-PI / 2, -PI / 2, 0), 0.012)
	# box spots: marked rectangles in the working lane, the player's one highlighted
	var box_m := Gfx.mat(Color(0.92, 0.92, 0.9), 0.6)
	var me_m := Gfx.emissive(Color(1.0, 0.85, 0.1), 0.6)
	for k in T.garage_ps.size():
		var bs: float = T.garage_ps[k]
		var m: Material = me_m if k == T.player_garage else box_m
		var spot_w: float = T.GARAGE_LAT - 0.2 - 3.45
		for e in [-6.5, 6.5]:
			var bn := lane_node(bs + e, 3.45 + spot_w * 0.5, 0.04)
			box(bn, Vector3(0.18, 0.02, spot_w), Vector3.ZERO, m, false)
		var tn := lane_node(bs, T.GARAGE_LAT - 1.05, 0.04)
		box(tn, Vector3(2.4, 0.02, 0.3), Vector3.ZERO, m, false)
		if k == T.player_garage:
			var n := lane_node(bs, T.BOX_LAT + 1.2, 0.05)
			label(n, "BOX 24", Vector3.ZERO, 200, Color(1, 0.85, 0.1), Vector3(-PI / 2, -PI / 2, 0), 0.01)
	# concrete pit wall on the track side
	var concrete := Gfx.mat(Color(0.8, 0.8, 0.81), 0.9)
	concrete.cull_mode = BaseMaterial3D.CULL_DISABLED
	var wl: float = -LI - 0.25
	for r in lane_runs(func(q): return T.l_wall[q] == 1):
		var ids: PackedInt32Array = r
		add_mesh(lane_wall(ids, wl - 0.22, -0.4, 1.5, 4.0), concrete, true)
		add_mesh(lane_wall(ids, wl + 0.22, -0.4, 1.5, 4.0), concrete, true)
		add_mesh(lane_strip(ids, func(_q): return wl - 0.22, func(_q): return wl + 0.22, 1.1, 1, 4.0), concrete)
		add_mesh(lane_strip(ids, func(_q): return wl - 0.23, func(_q): return wl + 0.23, 1.1 + 0.005, 1, 4.0), red)
	# armco along the far side of the narrow lane sections
	var armco := StandardMaterial3D.new()
	armco.albedo_texture = Gfx.armco()
	armco.metallic = 0.7
	armco.roughness = 0.4
	armco.cull_mode = BaseMaterial3D.CULL_DISABLED
	for r in lane_runs(func(q): return T.l_out[q] < 3.5):
		var ids: PackedInt32Array = r
		add_mesh(lane_wall(ids, T.LANE_OUT + 0.4, -0.5, 1.35, 4.0), armco, true)
	# lamp posts on the pit wall (switched on at night)
	lamp_mat = Gfx.emissive(Color(1.0, 0.93, 0.8), 0.0)
	var pole := Gfx.mat(Color(0.45, 0.47, 0.5), 0.4, 0.6)
	var gps: PackedFloat32Array = T.garage_ps
	if gps.size() > 0:
		var lp := gps[0]
		while lp <= gps[gps.size() - 1] + 1.0:
			var n := lane_node(lp, wl)
			var cm := CylinderMesh.new()
			cm.top_radius = 0.1
			cm.bottom_radius = 0.15
			cm.height = 11.0
			var mi := MeshInstance3D.new()
			mi.mesh = cm
			mi.material_override = pole
			mi.position = Vector3(0, 6.0, 0)
			n.add_child(mi)
			box(n, Vector3(1.4, 0.3, 0.6), Vector3(0, 11.5, 0.6), lamp_mat, false)
			var ol := OmniLight3D.new()
			ol.position = Vector3(0, 11.0, 3.0)
			ol.omni_range = 26.0
			ol.light_energy = 0.0
			ol.light_color = Color(1.0, 0.92, 0.78)
			n.add_child(ol)
			pit_lights.append(ol)
			lp += 42.0
	# paddock behind the garages: as deep as the space to the next piece of track allows
	paddock_w.resize(T.lN)
	for q in T.lN:
		paddock_w[q] = 0.0
		if T.l_out[q] < 6.0:
			continue
		var w := 45.0
		var d: float = T.GARAGE_LAT + 12.0
		while d < T.GARAGE_LAT + 12.0 + 45.0:
			var p: Vector4 = T.lane_point(q, d)
			var nd := nearest(p.x, p.z)
			var ti := int(nd.x)
			var far_s: float = absf(wrapf(ti * T.ds - T.l_ts[q], -T.length * 0.5, T.length * 0.5))
			if far_s > 120.0 and nd.y < T.half_w + 22.0:
				w = d - (T.GARAGE_LAT + 12.0) - 6.0
				break
			d += 3.0
		paddock_w[q] = maxf(0.0, w)
	for _rep in 3:
		var c := paddock_w.duplicate()
		for q in range(2, T.lN - 2):
			paddock_w[q] = minf(c[q], minf(minf(c[q - 2], c[q - 1]), minf(c[q + 1], c[q + 2])))
	var pad := Gfx.mat(Color(0.5, 0.51, 0.53), 0.9)
	var g_back: float = T.GARAGE_LAT + 12.0
	for r in lane_runs(func(q): return paddock_w[q] > 4.0):
		var ids: PackedInt32Array = r
		add_mesh(lane_strip(ids, func(_q): return g_back - 0.5, func(q): return g_back + paddock_w[q], 0.0, 4, 10.0), pad)
		# retaining wall at the far edge of the paddock (the ground drops away towards the next road)
		var edge_q: PackedInt32Array = ids
		var verts := PackedVector3Array()
		var nrm := PackedVector3Array()
		var idx := PackedInt32Array()
		for k in edge_q.size():
			var q := edge_q[k]
			var la: float = g_back + paddock_w[q]
			var top := Vector3(T.lx[q] + T.lrx[q] * la, T.ly[q], T.lz[q] + T.lrz[q] * la)
			verts.append(top)
			verts.append(top + Vector3(0, -6.0, 0))
			nrm.append(Vector3(T.lrx[q], 0, T.lrz[q]))
			nrm.append(Vector3(T.lrx[q], 0, T.lrz[q]))
			if k < edge_q.size() - 1:
				var a0 := k * 2
				idx.append_array([a0, a0 + 2, a0 + 1, a0 + 1, a0 + 2, a0 + 3])
		var cw := Gfx.mat(Color(0.62, 0.62, 0.6), 0.95)
		cw.cull_mode = BaseMaterial3D.CULL_DISABLED
		add_mesh(Gfx.make_mesh(verts, nrm, PackedVector2Array(), PackedColorArray(), idx), cw)
	# keep the terrain below the lane, the garages and the paddock
	for q in range(0, T.lN, 3):
		var reach: float = T.l_out[q] + (12.0 + paddock_w[q] if T.l_out[q] > 6.0 else 1.5)
		var la: float = -T.LANE_IN
		while la <= reach:
			var p: Vector4 = T.lane_point(q, la)
			flat_zones.append(Vector4(p.x, p.z, 7.0, p.y - 0.45))
			la += 7.0


func _barriers() -> void:
	var armco := StandardMaterial3D.new()
	armco.albedo_texture = Gfx.armco()
	armco.metallic = 0.7
	armco.roughness = 0.4
	armco.cull_mode = BaseMaterial3D.CULL_DISABLED
	var fence := StandardMaterial3D.new()
	fence.albedo_texture = Gfx.fence()
	fence.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	fence.alpha_scissor_threshold = 0.5
	fence.cull_mode = BaseMaterial3D.CULL_DISABLED
	fence.metallic = 0.5
	fence.roughness = 0.5
	fence.uv1_scale = Vector3(1, 3, 1)
	for side in [-1.0, 1.0]:
		var sd: float = side
		var lat_fn := func(i): return sd * (T.bar_r[i] if sd > 0.0 else T.bar_l[i])
		var fen_fn := func(i): return sd * ((T.bar_r[i] if sd > 0.0 else T.bar_l[i]) + 0.7)
		# no track barrier where the pit lane runs alongside (its own walls take over)
		var flag := func(i): return sd < 0.0 or T.pit_open[i] == 0
		for r in runs(flag):
			var ids: PackedInt32Array = r
			add_mesh(wall(ids, lat_fn, -0.6, 1.35, 4.0), armco, true)
			add_mesh(wall(ids, fen_fn, -0.5, 4.3, 1.2), fence)


# ---------------------------------------------------------------- terrain
func _distance_field() -> void:
	var mn := Vector2(1e9, 1e9)
	var mx := Vector2(-1e9, -1e9)
	for i: int in T.N:
		mn = Vector2(minf(mn.x, T.px[i]), minf(mn.y, T.pz[i]))
		mx = Vector2(maxf(mx.x, T.px[i]), maxf(mx.y, T.pz[i]))
	var margin := 1100.0
	g_step = 16.0 if quality == "low" else 12.0
	g_min = mn - Vector2(margin, margin)
	g_nx = int((mx.x - mn.x + 2.0 * margin) / g_step) + 2
	g_nz = int((mx.y - mn.y + 2.0 * margin) / g_step) + 2
	var cells := g_nx * g_nz
	g_idx.resize(cells)
	g_idx.fill(-1)
	g_dist.resize(cells)
	g_dist.fill(1e9)
	for i: int in T.N:
		var cx := int(roundf((T.px[i] - g_min.x) / g_step))
		var cz := int(roundf((T.pz[i] - g_min.y) / g_step))
		var c := cz * g_nx + cx
		var d := Vector2(g_min.x + cx * g_step - T.px[i], g_min.y + cz * g_step - T.pz[i]).length()
		if d < g_dist[c]:
			g_dist[c] = d
			g_idx[c] = i
	# two-pass chamfer propagation of the nearest sample index
	for rep in 2:
		for cz in g_nz:
			for cx in g_nx:
				_relax(cx, cz, NB_FWD)
		for cz in range(g_nz - 1, -1, -1):
			for cx in range(g_nx - 1, -1, -1):
				_relax(cx, cz, NB_BWD)


func _relax(cx: int, cz: int, nbs: Array) -> void:
	var c := cz * g_nx + cx
	var wx := g_min.x + cx * g_step
	var wz := g_min.y + cz * g_step
	for nb in nbs:
		var o: Vector2i = nb
		var ox := cx + o.x
		var oz := cz + o.y
		if ox < 0 or oz < 0 or ox >= g_nx or oz >= g_nz:
			continue
		var cand := g_idx[oz * g_nx + ox]
		if cand < 0:
			continue
		var dx: float = wx - T.px[cand]
		var dz: float = wz - T.pz[cand]
		var d := sqrt(dx * dx + dz * dz)
		if d < g_dist[c]:
			g_dist[c] = d
			g_idx[c] = cand


func nearest(x: float, z: float) -> Vector2:  # (sample index, distance)
	var cx := clampi(int(roundf((x - g_min.x) / g_step)), 0, g_nx - 1)
	var cz := clampi(int(roundf((z - g_min.y) / g_step)), 0, g_nz - 1)
	var i := g_idx[cz * g_nx + cx]
	var dx: float = x - T.px[i]
	var dz: float = z - T.pz[i]
	return Vector2(i, sqrt(dx * dx + dz * dz))


func terrain_height(x: float, z: float) -> float:
	var fx := clampf((x - g_min.x) / g_step, 0.0, g_nx - 1.001)
	var fz := clampf((z - g_min.y) / g_step, 0.0, g_nz - 1.001)
	var ix := int(fx)
	var iz := int(fz)
	var u := fx - ix
	var v := fz - iz
	var h00 := g_h[iz * g_nx + ix]
	var h10 := g_h[iz * g_nx + ix + 1]
	var h01 := g_h[(iz + 1) * g_nx + ix]
	var h11 := g_h[(iz + 1) * g_nx + ix + 1]
	return lerpf(lerpf(h00, h10, u), lerpf(h01, h11, u), v)


func _terrain() -> void:
	var nz := Gfx.noise(17, 0.0025, 4)
	var spa: bool = T.id == "spa"
	g_h.resize(g_nx * g_nz)
	# ground next to the road sits a little below the lowest nearby road point, so it can never poke through
	var low := PackedFloat32Array()
	low.resize(T.N)
	for i in T.N:
		var mn: float = T.py[i]
		for k in range(-6, 7):
			mn = minf(mn, T.py[(i + k + T.N) % T.N])
		low[i] = mn
	for cz in g_nz:
		for cx in g_nx:
			var c := cz * g_nx + cx
			var i := g_idx[c]
			var x := g_min.x + cx * g_step
			var z := g_min.y + cz * g_step
			var far := nz.get_noise_2d(x, z) * (22.0 if spa else 11.0)
			var near: float = maxf(T.bar_l[i], T.bar_r[i]) + 5.0
			var t := smoothstep(near, near + (70.0 if spa else 90.0), g_dist[c])
			var base: float = low[i] - 0.35
			g_h[c] = lerpf(base, base * 0.7 + far + (6.0 if spa else 2.0) * t, t)
	# pit lane, garages and paddock: pull the ground below them
	for fz in flat_zones:
		var f: Vector4 = fz
		var reach := f.z + 14.0
		var cx0 := clampi(int((f.x - reach - g_min.x) / g_step), 0, g_nx - 1)
		var cx1 := clampi(int((f.x + reach - g_min.x) / g_step) + 1, 0, g_nx - 1)
		var cz0 := clampi(int((f.y - reach - g_min.y) / g_step), 0, g_nz - 1)
		var cz1 := clampi(int((f.y + reach - g_min.y) / g_step) + 1, 0, g_nz - 1)
		for cz in range(cz0, cz1 + 1):
			for cx in range(cx0, cx1 + 1):
				var d := Vector2(g_min.x + cx * g_step - f.x, g_min.y + cz * g_step - f.y).length()
				var wgt := 1.0 - smoothstep(f.z, reach, d)
				if wgt <= 0.0:
					continue
				var c := cz * g_nx + cx
				g_h[c] = lerpf(g_h[c], minf(g_h[c], f.w), wgt)
	var verts := PackedVector3Array()
	var nrm := PackedVector3Array()
	var uvs := PackedVector2Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	verts.resize(g_nx * g_nz)
	nrm.resize(g_nx * g_nz)
	uvs.resize(g_nx * g_nz)
	colors.resize(g_nx * g_nz)
	var tint := Gfx.noise(23, 0.006, 2)
	for cz in g_nz:
		for cx in g_nx:
			var c := cz * g_nx + cx
			var x := g_min.x + cx * g_step
			var z := g_min.y + cz * g_step
			verts[c] = Vector3(x, g_h[c], z)
			var hl := g_h[cz * g_nx + maxi(0, cx - 1)]
			var hr := g_h[cz * g_nx + mini(g_nx - 1, cx + 1)]
			var hd := g_h[maxi(0, cz - 1) * g_nx + cx]
			var hu := g_h[mini(g_nz - 1, cz + 1) * g_nx + cx]
			nrm[c] = Vector3(hl - hr, 2.0 * g_step, hd - hu).normalized()
			uvs[c] = Vector2(x / 18.0, z / 18.0)
			var tv := 0.82 + 0.18 * tint.get_noise_2d(x, z)
			var gc := Color(tv, tv, tv * 0.95)
			# forest floor: needles, leaves and moss instead of meadow
			var i2 := g_idx[c]
			if g_dist[c] > maxf(T.bar_l[i2], T.bar_r[i2]) + 14.0:
				var ff := smoothstep(0.1, 0.32, forest_value(x, z, g_dist[c]))
				gc = gc.lerp(Color(0.52, 0.42, 0.3) * tv, ff * 0.85)
			colors[c] = gc
	for cz in g_nz - 1:
		for cx in g_nx - 1:
			var a := cz * g_nx + cx
			indices.append_array([a, a + g_nx, a + 1, a + 1, a + g_nx, a + g_nx + 1])
	var mesh := Gfx.make_mesh(verts, nrm, uvs, colors, indices, true)
	terrain_mat = Gfx.shader_mat(Gfx.GRASS_SHADER)
	terrain_mat.set_shader_parameter("alb", grass_tex["albedo"])
	terrain_mat.set_shader_parameter("nrm", grass_tex["normal"])
	terrain_mat.set_shader_parameter("macro", macro)
	var mi := add_mesh(mesh, terrain_mat)
	mi.name = "Terrain"


# ---------------------------------------------------------------- vegetation
func _primitive_surface(mesh: ArrayMesh, prim: PrimitiveMesh, offset: Vector3, m: Material) -> void:
	var arr := prim.get_mesh_arrays()
	var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
	for k in v.size():
		v[k] += offset
	arr[Mesh.ARRAY_VERTEX] = v
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	mesh.surface_set_material(mesh.get_surface_count() - 1, m)


# forest density (same field for the trees and the darker forest floor)
var forest_noise: FastNoiseLite


func forest_value(x: float, z: float, dist: float) -> float:
	if forest_noise == null:
		forest_noise = Gfx.noise(41, 0.004, 3)
	return forest_noise.get_noise_2d(x, z) + (0.45 if dist < 280.0 else 0.0) + (0.25 if T.id == "spa" else 0.0)


# MultiMeshes split into map chunks, so the visibility range (level of detail) works per area
func _chunked(mesh: Mesh, xfs: Array, cols: Array, chunk: float, vis_begin: float, vis_end: float, shadows: bool, layer: int, fade: bool = false) -> void:
	var groups := {}
	for k in xfs.size():
		var t: Transform3D = xfs[k]
		var key := Vector2i(int(floorf(t.origin.x / chunk)), int(floorf(t.origin.z / chunk)))
		if not groups.has(key):
			groups[key] = []
		var g: Array = groups[key]
		g.append(k)
	for key in groups:
		var ids: Array = groups[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.use_colors = not cols.is_empty()
		mm.mesh = mesh
		mm.instance_count = ids.size()
		for q in ids.size():
			var k2: int = ids[q]
			mm.set_instance_transform(q, xfs[k2])
			if not cols.is_empty():
				mm.set_instance_color(q, cols[k2])
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mmi.layers = layer
		if vis_begin > 0.0:
			mmi.visibility_range_begin = vis_begin
			mmi.visibility_range_begin_margin = 15.0
		if vis_end > 0.0:
			mmi.visibility_range_end = vis_end
			mmi.visibility_range_end_margin = 15.0
		if fade:
			mmi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
		root.add_child(mmi)


# Ardennes forest: tall Norway spruces with beeches mixed in, young trees and saplings along the edges.
# Near the camera the detailed trees (many branch cards, shadows), further away a lighter version.
func _trees() -> void:
	var count := {"low": 9000, "medium": 18000, "high": 30000, "ultra": 42000}.get(quality, 30000) as int
	if T.id != "spa":
		count = int(count * 0.7)
	var spruce_tex := Flora.spruce_branch()
	var leaf_tex := Flora.leaf_cluster()
	var sp_fol := Flora.foliage_mat(spruce_tex, 256.0, 0.0)
	var be_fol := Flora.foliage_mat(leaf_tex, 256.0, 1.0)
	var sp_bark := Flora.bark_mat(Flora.bark(true))
	var be_bark := Flora.bark_mat(Flora.bark(false))
	var meshes := {
		"spruce": [Flora.spruce_mesh(true, sp_bark, sp_fol), Flora.spruce_mesh(false, sp_bark, sp_fol)],
		"beech": [Flora.beech_mesh(true, be_bark, be_fol), Flora.beech_mesh(false, be_bark, be_fol)],
	}
	var share := 0.68 if T.id == "spa" else 0.5
	var lists := {"spruce": [], "beech": []}
	var cols := {"spruce": [], "beech": []}
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 1234
	var tries := 0
	var placed := 0
	var w := (g_nx - 1) * g_step
	var hgt := (g_nz - 1) * g_step
	while placed < count and tries < count * 25:
		tries += 1
		var x := g_min.x + rnd.randf() * w
		var z := g_min.y + rnd.randf() * hgt
		var nd := nearest(x, z)
		var i := int(nd.x)
		var clear: float = maxf(T.bar_l[i], T.bar_r[i]) + 10.0
		if nd.y < clear:
			continue
		if T.in_range(i * T.ds, T.length - 500.0, 650.0) and nd.y < 95.0:
			continue
		var in_stand := false
		for zv in stand_zones:
			var zz: Array = zv
			if T.in_range(i * T.ds, float(zz[0]) - 12.0, float(zz[1]) + 12.0) and nd.y < float(zz[2]) + 12.0:
				in_stand = true
		if in_stand:
			continue
		var f := forest_value(x, z, nd.y)
		if f < 0.1 and rnd.randf() > 0.05:
			continue
		var edge := f < 0.24 or nd.y < clear + 14.0
		var sc := 0.8 + rnd.randf() * 0.65
		if edge and rnd.randf() < 0.35:
			sc = rnd.randf_range(0.18, 0.5)         # young trees and saplings along the forest edge
		var kind := "spruce" if rnd.randf() < share else "beech"
		var t3 := Transform3D(Basis(Vector3.UP, rnd.randf() * TAU).scaled(Vector3(sc, sc * rnd.randf_range(0.9, 1.15), sc)), Vector3(x, terrain_height(x, z) - 0.25, z))
		var l: Array = lists[kind]
		l.append(t3)
		var cl: Array = cols[kind]
		if kind == "spruce":
			cl.append(Color(rnd.randf_range(0.8, 1.05), rnd.randf_range(0.85, 1.08), rnd.randf_range(0.8, 1.0)))
		else:
			cl.append(Color(rnd.randf_range(0.85, 1.12), rnd.randf_range(0.88, 1.1), rnd.randf_range(0.75, 0.95)))
		placed += 1
	var near_end := 0.0 if quality == "low" else (150.0 if quality == "medium" else (210.0 if quality == "high" else 280.0))
	var shadows := quality != "low"
	for kind in ["spruce", "beech"]:
		var m: Array = meshes[kind]
		if near_end > 0.0:
			_chunked(m[0], lists[kind], cols[kind], 90.0, 0.0, near_end, shadows, 1)
		_chunked(m[1], lists[kind], cols[kind], 90.0, near_end, 0.0, shadows and quality == "ultra", 1)


# ---------------------------------------------------------------- buildings
func _grandstands() -> void:
	var stands: Array = []
	for sv in T.def["stands_left"]:
		var s: float = sv
		stands.append([s - 37.0, s + 37.0, -1.0, 12, true])
	for bs in T.def.get("big_stands", []):
		var b: Array = bs
		stands.append([float(b[0]), float(b[1]), float(b[2]), 22, true])
	var k := 0
	for st in stands:
		_stand(float(st[0]), float(st[1]), float(st[2]), int(st[3]), bool(st[4]), k)
		k += 1


# stepped grandstand along the track (follows curves and the hillside) with seated 3D spectators
func _stand(s0: float, s1: float, side: float, rows: int, roofed: bool, k: int) -> void:
	var concrete := Gfx.mat(Color(0.72, 0.73, 0.74), 0.9)
	concrete.cull_mode = BaseMaterial3D.CULL_DISABLED
	var seat_cols := [Color(0.85, 0.1, 0.12), Color(0.95, 0.8, 0.1), Color(0.1, 0.25, 0.6)]
	var seat_m := Gfx.mat(seat_cols[k % 3], 0.6)
	var roof_m := Gfx.mat(Color(0.92, 0.92, 0.94), 0.45, 0.3)
	roof_m.cull_mode = BaseMaterial3D.CULL_DISABLED
	var steel := Gfx.mat(Color(0.25, 0.27, 0.3), 0.5, 0.6)
	var ids := range_idx(s0, s1)
	var lat0 := 0.0
	for i in ids:
		lat0 = maxf(lat0, (T.bar_r[i] if side > 0.0 else T.bar_l[i]) + 4.0)
	lat0 = minf(lat0, 60.0)
	var step_d := 0.85
	var step_h := 0.48
	var base_y := 1.2
	for r in rows:
		var la := lat0 + r * step_d
		var y := base_y + r * step_h
		add_mesh(strip(ids, func(_i): return side * la, func(_i): return side * (la + step_d), y, 1, 6.0), seat_m if r % 2 == 0 else concrete)
		add_mesh(wall(ids, func(_i): return side * la, y - step_h - 0.05, step_h + 0.06, 6.0), concrete)
	var back := lat0 + rows * step_d
	var top := base_y + rows * step_h
	stand_zones.append([s0, s1, back])
	add_mesh(wall(ids, func(_i): return side * lat0, -2.5, base_y + 2.5, 6.0), concrete, true)
	add_mesh(wall(ids, func(_i): return side * back, -3.0, top + 5.5, 6.0), concrete, true)
	if roofed:
		add_mesh(strip(ids, func(_i): return side * (lat0 - 2.5), func(_i): return side * (back + 0.5), top + 5.5, 2, 8.0), roof_m, true)
		var d := 0.0
		for i in ids:
			d += T.ds
			if fmod(d, 18.0) < T.ds:
				var n := node_at(i * T.ds, side * (back - 0.3))
				box(n, Vector3(0.35, top + 8.5, 0.35), Vector3(0, (top + 5.5) / 2.0 - 1.5, 0), steel)
	# keep the ground below the stand
	for i in ids:
		var la2 := lat0
		while la2 <= back:
			var p: Vector4 = T.point_at(i * T.ds, side * la2)
			flat_zones.append(Vector4(p.x, p.z, 5.0, p.y - 0.5))
			la2 += 5.0
	if quality == "low":
		var crowd := StandardMaterial3D.new()
		crowd.albedo_texture = Gfx.crowd()
		crowd.uv1_scale = Vector3(1, 6, 1)
		for r in range(0, rows, 2):
			var la3 := lat0 + r * step_d + 0.3
			add_mesh(wall(ids, func(_i): return side * la3, base_y + r * step_h, 0.9, 12.0), crowd)
		return
	# spectators: one multimesh per stand; clothes, skin, hair/caps and cheering come from the shader
	var body := _person_mesh()
	var xf_list: Array = []
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 900 + k
	for r in rows:
		var la4 := lat0 + r * step_d + 0.45
		var y4 := base_y + r * step_h + 0.02
		for i in ids:
			for sub in 3:
				if rnd.randf() < 0.14:
					continue
				var sp: float = i * T.ds + sub * T.ds / 3.0
				var p4: Vector4 = T.point_at(sp, side * la4)
				var facing := Vector3(T.rx[i], 0, T.rz[i]) * (-side)
				var bas := Basis.looking_at(-facing, Vector3.UP).rotated(Vector3.UP, rnd.randf_range(-0.3, 0.3))
				var sc := rnd.randf_range(0.9, 1.08)
				xf_list.append(Transform3D(bas.scaled(Vector3(sc, sc, sc)), Vector3(p4.x, p4.y + y4, p4.z)))
	if xf_list.is_empty():
		return
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_custom_data = true
	mm.mesh = body
	mm.instance_count = xf_list.size()
	var rnd2 := RandomNumberGenerator.new()
	rnd2.seed = 4242 + k
	for q in xf_list.size():
		mm.set_instance_transform(q, xf_list[q])
		# shirts: many in the stand's team colour block, the rest mixed
		var shirt := float(rnd2.randi() % 10) / 10.0 + 0.05
		var pants := float(rnd2.randi() % 4)
		var hair := rnd2.randf() * 0.99
		mm.set_instance_custom_data(q, Color(shirt, pants + hair, rnd2.randf() * rnd2.randf(), rnd2.randf()))
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = Gfx.shader_mat(Gfx.CROWD_SHADER)
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.layers = 2      # not drawn in the mirrors (performance)
	root.add_child(mmi)


var _person_cache: ArrayMesh


# seated spectator facing +Z, origin on the seat; vertex colour r codes the body part for the shader
func _person_mesh() -> ArrayMesh:
	if _person_cache != null:
		return _person_cache
	var verts := PackedVector3Array()
	var nrm := PackedVector3Array()
	var cols := PackedColorArray()
	var idx := PackedInt32Array()
	var parts: Array = []
	var torso := CapsuleMesh.new()
	torso.radius = 0.17
	torso.height = 0.58
	parts.append([torso, Vector3(0, 0.36, 0), 0.0, Basis.IDENTITY])
	var thigh := BoxMesh.new()
	thigh.size = Vector3(0.14, 0.13, 0.42)
	var shin := BoxMesh.new()
	shin.size = Vector3(0.12, 0.42, 0.12)
	var shoe := BoxMesh.new()
	shoe.size = Vector3(0.11, 0.08, 0.24)
	var arm := CapsuleMesh.new()
	arm.radius = 0.055
	arm.height = 0.48
	var hand := SphereMesh.new()
	hand.radius = 0.045
	hand.height = 0.09
	for sd in [-1.0, 1.0]:
		parts.append([thigh, Vector3(sd * 0.09, 0.08, 0.2), 0.3, Basis.IDENTITY])
		parts.append([shin, Vector3(sd * 0.09, -0.12, 0.4), 0.3, Basis.IDENTITY])
		parts.append([shoe, Vector3(sd * 0.09, -0.32, 0.46), 0.9, Basis.IDENTITY])
		parts.append([arm, Vector3(sd * 0.2, 0.4, 0.03), 0.15, Basis.IDENTITY])
		parts.append([hand, Vector3(sd * 0.2, 0.15, 0.05), 0.6, Basis.IDENTITY])
	var head := SphereMesh.new()
	head.radius = 0.105
	head.height = 0.23
	parts.append([head, Vector3(0, 0.79, 0.02), 0.45, Basis.IDENTITY])
	var neck := CylinderMesh.new()
	neck.top_radius = 0.05
	neck.bottom_radius = 0.06
	neck.height = 0.1
	parts.append([neck, Vector3(0, 0.67, 0.0), 0.45, Basis.IDENTITY])
	var hair := SphereMesh.new()
	hair.radius = 0.112
	hair.height = 0.13
	hair.is_hemisphere = true
	parts.append([hair, Vector3(0, 0.82, 0.0), 0.75, Basis.IDENTITY])
	for pt in parts:
		var prim: PrimitiveMesh = pt[0]
		var off: Vector3 = pt[1]
		var code: float = pt[2]
		var arr := prim.get_mesh_arrays()
		var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var nn: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
		var ii: PackedInt32Array = arr[Mesh.ARRAY_INDEX]
		var base := verts.size()
		for q in v.size():
			verts.append(v[q] + off)
			nrm.append(nn[q])
			cols.append(Color(code, 0, 0))
		for q in ii.size():
			idx.append(ii[q] + base)
	var a := []
	a.resize(Mesh.ARRAY_MAX)
	a[Mesh.ARRAY_VERTEX] = verts
	a[Mesh.ARRAY_NORMAL] = nrm
	a[Mesh.ARRAY_COLOR] = cols
	a[Mesh.ARRAY_INDEX] = idx
	_person_cache = ArrayMesh.new()
	_person_cache.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	return _person_cache


# meadow: a dense grass carpet along the whole lap (short and mown at the verge, longer further out,
# drawn only near the camera), wild tufts and flowers in the fields further away
func _meadow() -> void:
	var dens := {"low": 0.0, "medium": 0.5, "high": 1.0, "ultra": 1.4}.get(quality, 1.0) as float
	if dens <= 0.0:
		return
	var gm := Gfx.shader_mat(Gfx.TUFT_SHADER)
	gm.set_shader_parameter("tex", Flora.meadow_blades())
	var clump := Flora.grass_clump(gm)
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 555
	var hw: float = T.half_w
	var carpet: Array = []
	var ccols: Array = []
	var band := 26.0
	var per_side := int(band * T.ds / 1.6 * dens)
	for i in T.N:
		for sd: float in [-1.0, 1.0]:
			if sd > 0.0 and (T.pit_open[i] == 1 or T.t2l[i] >= 0):
				continue                               # pit lane, garages and paddock
			var run: int = T.run_r[i] if sd > 0.0 else T.run_l[i]
			var curb: int = T.curb_r[i] if sd > 0.0 else T.curb_l[i]
			var bar: float = T.bar_r[i] if sd > 0.0 else T.bar_l[i]
			var start := hw + (1.6 if curb == 1 else 0.45)
			if run != 0:
				start = bar + 1.5
			var in_stand := false
			for zv in stand_zones:
				var zz: Array = zv
				if T.in_range(i * T.ds, float(zz[0]) - 4.0, float(zz[1]) + 4.0):
					in_stand = true
			for k in per_side:
				var la := start + rnd.randf() * band
				if in_stand and la > bar - 1.0:
					continue
				var s: float = i * T.ds + rnd.randf() * T.ds
				var p: Vector4 = T.point_at(s, sd * la)
				var y: float = terrain_height(p.x, p.z) if la > bar + 2.0 else p.y - 0.02
				var mown := la < start + 7.0 and run == 0
				var sc := rnd.randf_range(0.28, 0.5) if mown else rnd.randf_range(0.6, 1.25)
				carpet.append(Transform3D(Basis(Vector3.UP, rnd.randf() * TAU).scaled(Vector3(sc * 1.3, sc, sc * 1.3)), Vector3(p.x, y - 0.03, p.z)))
				var g := rnd.randf_range(0.85, 1.12)
				ccols.append(Color(g * rnd.randf_range(0.92, 1.08), g, g * rnd.randf_range(0.85, 1.0)))
	_chunked(clump, carpet, ccols, 60.0, 0.0, 95.0, false, 2, true)
	# wild tufts and flowers further out in the fields
	var count := int(16000 * dens)
	var tufts: Array = []
	var tcols: Array = []
	var flowers: Array = []
	var fcl: Array = []
	var fcols := [Color(1.0, 0.9, 0.2), Color(0.97, 0.97, 0.95), Color(0.65, 0.4, 0.9), Color(0.95, 0.35, 0.3), Color(0.98, 0.98, 0.98)]
	var tries := 0
	var span := Vector2((g_nx - 1) * g_step, (g_nz - 1) * g_step)
	while tufts.size() < count and tries < count * 12:
		tries += 1
		var x: float
		var z: float
		if rnd.randf() < 0.6:
			var i := rnd.randi_range(0, T.N - 1)
			var sd := -1.0 if rnd.randf() < 0.5 else 1.0
			var lim: float = (T.bar_r[i] if sd > 0.0 else T.bar_l[i])
			var la := rnd.randf_range(T.half_w + 20.0, lim + 90.0)
			x = T.px[i] + T.rx[i] * la * sd
			z = T.pz[i] + T.rz[i] * la * sd
		else:
			x = g_min.x + rnd.randf() * span.x
			z = g_min.y + rnd.randf() * span.y
		var nd := nearest(x, z)
		var ti := int(nd.x)
		var run: int = T.run_r[ti] if (x - T.px[ti]) * T.rx[ti] + (z - T.pz[ti]) * T.rz[ti] > 0.0 else T.run_l[ti]
		var limit: float = T.half_w + 2.2
		if run != 0 or T.pit_open[ti] == 1:
			limit = maxf(T.bar_l[ti], T.bar_r[ti]) + 1.5
		if nd.y < limit or nd.y > 500.0:
			continue
		if T.t2l[ti] >= 0 and nd.y < 110.0 and (x - T.px[ti]) * T.rx[ti] + (z - T.pz[ti]) * T.rz[ti] > 0.0:
			continue
		if forest_value(x, z, nd.y) > 0.2:
			continue                                   # no meadow inside the forest
		var y: float = terrain_height(x, z) if nd.y > maxf(T.bar_l[ti], T.bar_r[ti]) + 2.0 else T.py[ti] - 0.02
		var sc := rnd.randf_range(0.9, 1.7)
		tufts.append(Transform3D(Basis(Vector3.UP, rnd.randf() * TAU).scaled(Vector3(sc * 1.4, sc * rnd.randf_range(0.8, 1.3), sc * 1.4)), Vector3(x, y - 0.04, z)))
		var g2 := rnd.randf_range(0.85, 1.15)
		tcols.append(Color(g2 * rnd.randf_range(0.95, 1.12), g2, g2 * 0.9))
		if rnd.randf() < 0.1:
			flowers.append(Transform3D(Basis.IDENTITY.scaled(Vector3.ONE * sc), Vector3(x + 0.2, y - 0.05, z)))
			fcl.append(fcols[rnd.randi() % fcols.size()])
	_chunked(clump, tufts, tcols, 120.0, 0.0, 320.0, false, 2)
	if flowers.is_empty():
		return
	var flower := ArrayMesh.new()
	var fm := StandardMaterial3D.new()
	fm.vertex_color_use_as_albedo = true
	fm.roughness = 0.8
	var fs := SphereMesh.new()
	fs.radius = 0.05
	fs.height = 0.07
	fs.radial_segments = 6
	fs.rings = 3
	_primitive_surface(flower, fs, Vector3(0, 0.42, 0), fm)
	_chunked(flower, flowers, fcl, 120.0, 0.0, 200.0, false, 2)


func _garages() -> void:
	# open garages: floor, side walls, back wall with team graphics, lit ceiling, tyre stacks and tool trolleys
	var wallm := Gfx.mat(Color(0.86, 0.87, 0.89), 0.75)
	var floor_m := Gfx.mat(Color(0.55, 0.57, 0.6), 0.25, 0.1)
	var inner := Gfx.mat(Color(0.93, 0.93, 0.95), 0.6)
	var ceil_light := Gfx.emissive(Color(1.0, 0.98, 0.94), 2.2)
	var glass := Gfx.mat(Color(0.12, 0.18, 0.25), 0.08, 0.8)
	var tyre_m := Gfx.mat(Color(0.05, 0.05, 0.05), 0.85)
	var trolley := Gfx.mat(Color(0.75, 0.08, 0.1), 0.4, 0.3)
	var hl := Gfx.emissive(Color(1.0, 0.82, 0.1), 0.8)
	var spa: bool = T.id == "spa"
	for gk in T.garage_ps.size():
		var k: int = gk - T.player_garage
		var bs: float = T.garage_ps[gk]
		var n := lane_node(bs, T.GARAGE_LAT)
		var team_col := Color.from_hsv(fposmod(k * 0.137, 1.0), 0.65, 0.75)
		if k == 0:
			team_col = Color(1.0, 0.8, 0.1)
		box(n, Vector3(14, 1.2, 12), Vector3(0, -0.55, 6), floor_m, false)                 # epoxy floor (solid slab)
		box(n, Vector3(14, 1.2, 0.4), Vector3(0, -0.55, -0.2), Gfx.mat(Color(0.45, 0.46, 0.48), 0.9), false)
		box(n, Vector3(0.3, 6, 12), Vector3(-6.85, 3, 6), wallm)                            # side walls
		box(n, Vector3(0.3, 6, 12), Vector3(6.85, 3, 6), wallm)
		box(n, Vector3(14, 6, 0.3), Vector3(0, 3, 12), inner)                               # back wall
		box(n, Vector3(12, 2.0, 0.06), Vector3(0, 3.2, 11.8), Gfx.mat(team_col, 0.5), false)  # team graphic
		box(n, Vector3(14, 0.3, 12), Vector3(0, 6.0, 6), wallm)                             # ceiling
		box(n, Vector3(10, 0.06, 1.0), Vector3(0, 5.82, 4), ceil_light, false)
		box(n, Vector3(10, 0.06, 1.0), Vector3(0, 5.82, 8), ceil_light, false)
		box(n, Vector3(14, 0.9, 0.3), Vector3(0, 5.6, -0.2), hl if k == 0 else Gfx.mat(Color(0.2, 0.22, 0.26), 0.5), false)
		label(n, "BOX %d%s" % [gk + 1, "  ·  DEIN TEAM" if k == 0 else ""], Vector3(0, 5.6, -0.4), 120, Color(0.1, 0.1, 0.1) if k == 0 else Color.WHITE, Vector3(0, PI, 0), 0.012)
		for t in 3:   # tyre stacks (wrapped sets)
			for h in 4:
				var cm := CylinderMesh.new()
				cm.top_radius = 0.34
				cm.bottom_radius = 0.34
				cm.height = 0.3
				var mi := MeshInstance3D.new()
				mi.mesh = cm
				mi.material_override = tyre_m
				mi.position = Vector3(-5.6 + t * 0.8, 0.2 + h * 0.31, 10.8)
				n.add_child(mi)
		box(n, Vector3(1.2, 1.0, 0.6), Vector3(5.2, 0.6, 10.5), trolley)                    # tool trolley
		box(n, Vector3(0.9, 1.6, 0.6), Vector3(3.8, 0.85, 11.2), trolley)
		box(n, Vector3(14, 3, 10), Vector3(0, 7.5, 7), glass)                               # hospitality floor
		if spa:
			box(n, Vector3(14, 3.4, 9), Vector3(0, 10.7, 7.5), wallm)
			box(n, Vector3(14, 2.6, 0.2), Vector3(0, 10.6, 2.95), glass, false)
			box(n, Vector3(14, 0.3, 14), Vector3(0, 14.6, 6), Gfx.mat(Color(0.92, 0.92, 0.94), 0.4, 0.2))
			box(n, Vector3(14, 1.0, 0.08), Vector3(0, 12.9, 1.0), glass, false)
		if k == 0:
			var ol := OmniLight3D.new()
			ol.position = Vector3(0, 5.2, 6)
			ol.omni_range = 14.0
			ol.light_energy = 1.2
			n.add_child(ol)
	# pit wall stands (team command posts) with timing screens
	var post_m := Gfx.mat(Color(0.15, 0.16, 0.18), 0.5, 0.3)
	var screen := Gfx.emissive(Color(0.2, 0.5, 1.0), 1.2)
	for gk in range(0, T.garage_ps.size(), 2):
		var n := lane_node(T.garage_ps[gk], -T.LANE_IN - 1.25)
		box(n, Vector3(5, 1.0, 1.2), Vector3(0, 1.6, 0), post_m, true)
		box(n, Vector3(0.3, 1.1, 0.3), Vector3(-2.2, 0.55, 0), post_m, true)
		box(n, Vector3(0.3, 1.1, 0.3), Vector3(2.2, 0.55, 0), post_m, true)
		box(n, Vector3(5.4, 0.1, 1.8), Vector3(0, 3.2, 0), post_m, true)
		box(n, Vector3(4.4, 0.6, 0.05), Vector3(0, 2.4, 0.62), screen, false)


func _gantry() -> void:
	var n := node_at(6.0, 0.0)
	var gm := Gfx.mat(Color(0.11, 0.15, 0.2), 0.5, 0.5)
	var hw: float = T.half_w
	var right_z: float = T.pit_wall_off if T.pit_open[T.idx(6.0)] == 1 else hw + 3.5
	for zz in [-(hw + 3.5), right_z]:
		box(n, Vector3(0.8, 9, 0.8), Vector3(0, 4.5, zz), gm)
	box(n, Vector3(1.2, 2.2, 2.0 * hw + 8.0), Vector3(0, 8.2, 0), gm)
	label(n, String(T.def["name"]).to_upper(), Vector3(-0.62, 8.2, 0), 150, Color.WHITE, Vector3(0, -PI / 2, 0), 0.012)
	box(n, Vector3(0.6, 0.9, 5.5), Vector3(-0.85, 6.6, 0), Gfx.mat(Color(0.02, 0.02, 0.02), 0.4), false)
	for k in 5:
		var m := Gfx.emissive(Color(1.0, 0.08, 0.08), 0.0)
		var sm := SphereMesh.new()
		sm.radius = 0.28
		sm.height = 0.56
		var mi := MeshInstance3D.new()
		mi.mesh = sm
		mi.material_override = m
		mi.position = Vector3(-1.15, 6.6, -2.0 + k)
		n.add_child(mi)
		start_lights.append(m)


func _bridges() -> void:
	var white := Gfx.mat(Color(0.94, 0.94, 0.94), 0.6)
	var concrete := Gfx.mat(Color(0.7, 0.71, 0.72), 0.9)
	for bv in T.def["bridges"]:
		var s: float = bv
		var i: int = T.idx(s)
		var n := node_at(s, 0.0)
		var w: float = T.bar_l[i] + T.bar_r[i] + 6.0
		var zc: float = (T.bar_r[i] - T.bar_l[i]) / 2.0
		box(n, Vector3(3.5, 1.2, w), Vector3(0, 7.2, zc), white)
		box(n, Vector3(0.1, 1.1, w - 2), Vector3(-1.8, 7.2, zc), Gfx.mat(Color(1.0, 0.82, 0.0), 0.6), false)
		label(n, "VELOCE PNEUS  ·  VELOCE PNEUS", Vector3(-1.86, 7.2, zc), 180, Color(0.07, 0.07, 0.07), Vector3(0, -PI / 2, 0), 0.02)
		for zz in [-T.bar_l[i] - 2.0, T.bar_r[i] + 2.0]:
			box(n, Vector3(3, 8, 3), Vector3(0, 3.6, zz), concrete)


func _boards() -> void:
	var vp: PackedFloat32Array = T.speed_profile({"cls": "boards", "mu": 1.75, "ClA": 3.4, "CdA": 0.93, "mass": 1030.0, "vmax": 94.0, "power": 500000.0})
	var white := Gfx.mat(Color(0.95, 0.95, 0.95), 0.6)
	var pole := Gfx.mat(Color(0.2, 0.2, 0.2), 0.6)
	var last := -1e9
	for i: int in T.N:
		var s: float = i * T.ds
		if s - last < 450.0:
			continue
		var ahead: int = (i + int(300.0 / T.ds)) % T.N
		if vp[i] > 70.0 and vp[ahead] < vp[i] - 28.0:
			# find where braking starts for the corner ahead
			var entry := ahead
			for k in 160:
				var jj: int = (ahead - k + T.N) % T.N
				if vp[jj] >= vp[i] - 3.0:
					entry = jj
					break
			var side := -1.0 if T.kap[ahead] > 0.0 else 1.0
			if side > 0.0 and T.pit_open[T.idx(entry * T.ds - 200.0)] == 1:
				side = -1.0
			for d in [300, 200, 100]:
				var se: float = entry * T.ds - d
				var ii: int = T.idx(se)
				var off: float = side * ((T.bar_r[ii] if side > 0.0 else T.bar_l[ii]) - 1.0)
				var n := node_at(se, off)
				box(n, Vector3(0.06, 1.3, 0.06), Vector3(0, 0.65, 0), pole, false)
				box(n, Vector3(0.05, 1.4, 1.4), Vector3(0, 2.0, 0), white, false)
				label(n, str(d), Vector3(-0.04, 2.0, 0), 140, Color(0.05, 0.05, 0.05), Vector3(0, -PI / 2, 0), 0.006)
			last = s


func _signs() -> void:
	var board := Gfx.mat(Color(0.05, 0.2, 0.55), 0.5)
	var p_in := node_at(T.pit_in - 60.0, T.half_w + 4.0)
	box(p_in, Vector3(0.2, 2.4, 3.6), Vector3(0, 3.0, 0), board)
	label(p_in, "PIT IN ⇒", Vector3(-0.12, 3.0, 0), 200, Color.WHITE, Vector3(0, -PI / 2, 0), 0.008)
	var p_out := lane_node(maxf(0.0, T.lL - 50.0), T.LANE_OUT + 1.6)
	box(p_out, Vector3(0.2, 2.0, 3.0), Vector3(0, 2.8, 0), board)
	label(p_out, "PIT OUT", Vector3(-0.12, 2.8, 0), 180, Color.WHITE, Vector3(0, -PI / 2, 0), 0.008)
	for item in T.def.get("corners", []):
		var s: float = item[0]
		var i: int = T.idx(s)
		var side := 1.0 if T.kap[i] > 0.0 else -1.0     # inside of the corner
		if side > 0.0 and T.pit_open[i] == 1:
			side = -1.0
		var n := node_at(s, side * ((T.bar_r[i] if side > 0.0 else T.bar_l[i]) + 3.0))
		box(n, Vector3(0.3, 2.2, 14.0), Vector3(0, 4.0, 0), Gfx.mat(Color(0.75, 0.05, 0.08), 0.5))
		box(n, Vector3(0.2, 3.0, 0.2), Vector3(0, 1.5, -6.0), Gfx.mat(Color(0.3, 0.3, 0.3), 0.6), false)
		box(n, Vector3(0.2, 3.0, 0.2), Vector3(0, 1.5, 6.0), Gfx.mat(Color(0.3, 0.3, 0.3), 0.6), false)
		label(n, item[1], Vector3(-0.17, 4.0, 0), 110, Color.WHITE, Vector3(0, -PI / 2, 0), 0.012)


# ---------------------------------------------------------------- racing line (assist)
func build_racing_line(spec: Dictionary) -> MeshInstance3D:
	if line_mesh:
		line_mesh.queue_free()
	var vp: PackedFloat32Array = T.brake_profile(spec)
	var verts := PackedVector3Array()
	var nrm := PackedVector3Array()
	var colors := PackedColorArray()
	var indices := PackedInt32Array()
	# red = brake now (speed has to drop at the grip limit), yellow = the last ~25 m before the brake
	# point and the slow apex phase, green = full throttle
	var brake := PackedByteArray()
	brake.resize(T.N)
	for i in T.N:
		brake[i] = 1 if vp[(i + 1) % T.N] < vp[i] - 0.08 else 0
	var warn := int(26.0 / T.ds)
	for k: int in T.N + 1:
		var i: int = k % T.N
		var d: float = T.line_d[i]
		var c := Color(0.15, 1.0, 0.35)
		if brake[i] == 1:
			c = Color(1.0, 0.12, 0.1)
		else:
			for w in range(1, warn + 1):
				if brake[(i + w) % T.N] == 1:
					c = Color(1.0, 0.78, 0.1)
					break
			if c.g > 0.9 and vp[(i + 2) % T.N] - vp[i] < 0.15 and vp[i] < float(spec["vmax"]) * 0.7:
				c = Color(1.0, 0.78, 0.1)     # at the cornering limit: hold the speed, no more brake
		for o in [-0.35, 0.35]:
			verts.append(Vector3(T.px[i] + T.rx[i] * (d + o), T.py[i] + 0.06, T.pz[i] + T.rz[i] * (d + o)))
			nrm.append(Vector3.UP)
			colors.append(c)
		if k < T.N:
			var a := k * 2
			indices.append_array([a, a + 2, a + 1, a + 1, a + 2, a + 3])
	# opaque + unshaded: always visible on the whole lap (no transparency sorting, works day and night)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	line_mesh = add_mesh(Gfx.make_mesh(verts, nrm, PackedVector2Array(), colors, indices), m)
	line_mesh.extra_cull_margin = 50.0
	line_mesh.name = "RacingLine"
	return line_mesh


var _wet_set := -1.0


func set_wet(w: float) -> void:
	if absf(w - _wet_set) < 0.005:
		return
	_wet_set = w
	for m in [road_mat, curb_mat, lane_mat, grass_mat, terrain_mat]:
		if m != null:
			var sm: ShaderMaterial = m
			sm.set_shader_parameter("wet", w)

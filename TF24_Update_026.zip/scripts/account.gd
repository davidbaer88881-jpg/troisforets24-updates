extends Node
# Online account (e-mail + password, Supabase): the driver profile is stored in the cloud and can be
# loaded on any computer. Local profiles keep working; an account is linked to one local profile
# ("cloud_uid") which is uploaded after every save and downloaded at sign-in.

const Profile = preload("res://scripts/profile.gd")

const URL := "https://jrbfbvlwngvjzddfuesu.supabase.co"
const KEY := "sb_publishable_Oh8bUHeWTKHi1qyqZF9YiQ_WHXwReEa"     # publishable key (safe in the client, data protected by RLS)
const FILE := "user://account.cfg"
const TABLE := "tf24_profiles"

var uid := ""
var email := ""
var access := ""
var refresh_tok := ""
var expires_at := 0.0
var status := ""                 # last message for the UI
var _push_t := -1.0
var _busy_push := false


func _ready() -> void:
	Engine.set_meta("account", self)
	var cf := ConfigFile.new()
	if cf.load(FILE) == OK:
		uid = cf.get_value("a", "uid", "")
		email = cf.get_value("a", "email", "")
		refresh_tok = cf.get_value("a", "refresh", "")


func signed_in() -> bool:
	return uid != "" and refresh_tok != ""


func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("a", "uid", uid)
	cf.set_value("a", "email", email)
	cf.set_value("a", "refresh", refresh_tok)
	cf.save(FILE)


# ------------------------------------------------------------------ http
func _request(method: int, path: String, body = null, auth := false, extra: PackedStringArray = PackedStringArray()) -> Dictionary:
	var http := HTTPRequest.new()
	http.timeout = 15.0
	add_child(http)
	var headers := PackedStringArray(["apikey: " + KEY, "Content-Type: application/json"])
	if auth and access != "":
		headers.append("Authorization: Bearer " + access)
	headers.append_array(extra)
	var data := "" if body == null else JSON.stringify(body)
	var err := http.request(URL + path, headers, method, data)
	if err != OK:
		http.queue_free()
		return {"ok": false, "code": 0, "data": null, "error": "Keine Internetverbindung"}
	var res: Array = await http.request_completed
	http.queue_free()
	var code: int = res[1]
	var txt: String = (res[3] as PackedByteArray).get_string_from_utf8()
	var parsed = JSON.parse_string(txt) if txt != "" else null
	if res[0] != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "code": 0, "data": null, "error": "Keine Internetverbindung"}
	return {"ok": code >= 200 and code < 300, "code": code, "data": parsed, "error": _err_text(code, parsed)}


func _err_text(code: int, d) -> String:
	if code >= 200 and code < 300:
		return ""
	var msg := ""
	if d is Dictionary:
		msg = String(d.get("msg", d.get("error_description", d.get("message", d.get("error", "")))))
	var low := msg.to_lower()
	if "invalid login" in low or "invalid_grant" in low or "invalid credentials" in low:
		return "E-Mail oder Passwort falsch."
	if "already registered" in low or "already exists" in low:
		return "Diese E-Mail hat schon ein Konto – bitte anmelden."
	if "password should be" in low or "weak" in low:
		return "Das Passwort muss mindestens 6 Zeichen haben."
	if "invalid" in low and "email" in low:
		return "Diese E-Mail-Adresse ist ungültig."
	if "not confirmed" in low:
		return "Bitte bestätige zuerst die E-Mail (Link im Postfach)."
	if "rate limit" in low or code == 429:
		return "Zu viele Versuche – bitte kurz warten."
	return "Fehler %d: %s" % [code, msg] if msg != "" else "Fehler %d" % code


func _take_session(d: Dictionary) -> void:
	access = String(d.get("access_token", ""))
	refresh_tok = String(d.get("refresh_token", refresh_tok))
	expires_at = Time.get_unix_time_from_system() + float(d.get("expires_in", 3600)) - 60.0
	var u: Dictionary = d.get("user", {})
	uid = String(u.get("id", uid))
	email = String(u.get("email", email))
	_save()


# ------------------------------------------------------------------ auth
func sign_up(mail: String, pw: String) -> Dictionary:
	var r := await _request(HTTPClient.METHOD_POST, "/auth/v1/signup", {"email": mail.strip_edges(), "password": pw})
	if not r["ok"]:
		return r
	var d: Dictionary = r["data"]
	if d.has("access_token"):
		_take_session(d)
		return r
	# e-mail confirmation switched on in the project
	return {"ok": false, "code": 200, "data": d, "error": "Konto erstellt – bitte bestätige die E-Mail und melde dich dann an."}


func sign_in(mail: String, pw: String) -> Dictionary:
	var r := await _request(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=password", {"email": mail.strip_edges(), "password": pw})
	if r["ok"]:
		_take_session(r["data"])
	return r


func reset_password(mail: String) -> Dictionary:
	return await _request(HTTPClient.METHOD_POST, "/auth/v1/recover", {"email": mail.strip_edges()})


func ensure_session() -> bool:
	if refresh_tok == "":
		return false
	if access != "" and Time.get_unix_time_from_system() < expires_at:
		return true
	var r := await _request(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=refresh_token", {"refresh_token": refresh_tok})
	if r["ok"]:
		_take_session(r["data"])
		return true
	if int(r["code"]) == 400 or int(r["code"]) == 401:
		sign_out()          # refresh token no longer valid
	return false


func sign_out() -> void:
	uid = ""
	email = ""
	access = ""
	refresh_tok = ""
	DirAccess.remove_absolute(ProjectSettings.globalize_path(FILE))


# ------------------------------------------------------------------ profile data
static func to_cloud(p: Dictionary) -> Dictionary:
	var d := p.duplicate(true)
	d.erase("pw")
	d["c1"] = (p["c1"] as Color).to_html(false)
	d["c2"] = (p["c2"] as Color).to_html(false)
	return d


const FLOAT_KEYS := ["dr", "sr", "km", "time", "saved_at", "gain", "best", "lap", "d_dr", "d_sr"]


# JSON turns every number into a float: counts, numbers and positions become whole numbers again
static func _ints(v, key: String = ""):
	if key in FLOAT_KEYS:
		return v            # real decimal values (ratings, distances, lap times) stay as they are
	if v is Dictionary:
		var o := {}
		for k in v.keys():
			o[k] = _ints(v[k], String(k))
		return o
	if v is Array:
		var a: Array = []
		for x in v:
			a.append(_ints(x, key))
		return a
	if v is float and not key in FLOAT_KEYS and key != "" and fmod(v, 1.0) == 0.0 and absf(v) < 1e9:
		return int(v)
	return v


static func from_cloud(d: Dictionary, into: Dictionary) -> Dictionary:
	d = _ints(d)
	for k in d.keys():
		if k == "c1" or k == "c2":
			into[k] = Color.html(String(d[k]))
		elif k != "pw":
			into[k] = d[k]
	if not into.has("pw"):
		into["pw"] = ""
	return into


func download() -> Dictionary:
	if not await ensure_session():
		return {"ok": false, "error": "Nicht angemeldet"}
	var r := await _request(HTTPClient.METHOD_GET, "/rest/v1/%s?user_id=eq.%s&select=data" % [TABLE, uid], null, true)
	if not r["ok"]:
		return r
	var rows: Array = r["data"] if r["data"] is Array else []
	return {"ok": true, "data": rows[0]["data"] if rows.size() > 0 else null}


func upload(p: Dictionary) -> bool:
	if not await ensure_session():
		return false
	p["saved_at"] = Time.get_unix_time_from_system()
	var row := {"user_id": uid, "data": to_cloud(p), "updated_at": Time.get_datetime_string_from_system(true) + "Z"}
	var r := await _request(HTTPClient.METHOD_POST, "/rest/v1/" + TABLE, [row], true,
		PackedStringArray(["Prefer: resolution=merge-duplicates,return=minimal"]))
	status = "Profil online gespeichert" if r["ok"] else String(r["error"])
	return r["ok"]


# called whenever profiles are saved: uploads the linked profile a moment later (one upload per burst)
func push_soon() -> void:
	_push_t = 2.0


func _process(dt: float) -> void:
	if _push_t < 0.0:
		return
	_push_t -= dt
	if _push_t <= 0.0 and not _busy_push:
		_push_t = -1.0
		var p: Dictionary = Profile.current
		if signed_in() and not p.is_empty() and String(p.get("cloud_uid", "")) == uid:
			_busy_push = true
			await upload(p)
			_busy_push = false

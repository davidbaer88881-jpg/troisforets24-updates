extends RefCounted
const CarPhysics = preload("res://scripts/car_physics.gd")
# Race director (WEC/LMU style) for the player: flags, penalties and how they are served.
#  - jump start, pit speeding, crossing the pit entry/exit line  -> drive-through
#  - overtaking under yellow (not given back)                     -> drive-through, double yellow -> stop & go
#  - ignoring blue flags                                          -> warning, then drive-through
#  - causing a collision                                          -> warning / +5 s / drive-through / stop & go
#  - full course yellow after a heavy crash: 80 km/h everywhere, no overtaking   -> drive-through when too fast
#  - drive-through and stop & go have to be served within 3 laps, otherwise black flag (DSQ);
#    penalties still open at the finish become time (+25 s / +35 s)

const SERVE_LAPS := 3
const STOPGO_TIME := 10.0

var game
var pending: Array = []          # [{"type": "dt"/"sg", "reason": String, "laps": int}]
var warnings := 0
var yellow := 0                  # flag the player sees now: 0 none, 1 yellow, 2 double yellow
var green_t := 0.0               # green flag after a yellow zone
var bw_t := 0.0                  # black/white (warning) flag
var meatball := false            # black/orange: car must be repaired
var dsq := false
var stopgo_t := -1.0             # running stop & go countdown
var grid_pos := Vector2.ZERO
var jump_checked := false

var _zones: Array = []           # [[s_from, s_to, double, incident car]]
var _scan_t := 0.0
var _ahead := {}                 # car -> was ahead of the player (inside a yellow zone)
var _giveback: Array = []        # [{"car", "t", "double"}]
var _blue_t := 0.0
var _blue_clear := 0.0
var _blue_warned := false
var _contact_cd := {}            # car -> cooldown
var _was_in_pit := false
var _visit := false
var _visit_stopped := false
var _meat_said := false
# full course yellow
const FCY_KMH := 80.0
var fcy := ""                    # "" green, "warn" announced, "on", "end" (green soon)
var fcy_t := 0.0
var _fcy_over := 0.0
var _fcy_cd := 0.0
var _fcy_car = null
var _stopped := {}               # car -> seconds standing on the racing surface


func setup(g) -> void:
	game = g
	reset()


func reset() -> void:
	pending.clear()
	warnings = 0
	yellow = 0
	green_t = 0.0
	bw_t = 0.0
	meatball = false
	dsq = false
	stopgo_t = -1.0
	jump_checked = false
	_zones.clear()
	_ahead.clear()
	_giveback.clear()
	_blue_t = 0.0
	_blue_warned = false
	_contact_cd.clear()
	_was_in_pit = false
	_visit = false
	_visit_stopped = false
	_meat_said = false
	fcy = ""
	fcy_t = 0.0
	_fcy_cd = 0.0
	_fcy_car = null
	_stopped.clear()
	CarPhysics.fcy_speed = 0.0
	CarPhysics.contacts.clear()


func active() -> bool:
	return game.session == "race" and bool(game.settings.get("rules", true)) and game.player != null


func penalize(kind: String, reason: String) -> void:
	if not active() or dsq:
		return
	var p = game.player
	if kind == "time":
		game.penalty += 5.0
		game.show_msg("STRAFE +5 s  ·  " + reason, 3.5, Color(1.0, 0.25, 0.2))
	else:
		pending.append({"type": kind, "reason": reason, "laps": SERVE_LAPS})
		var nm := "DURCHFAHRTSSTRAFE" if kind == "dt" else "STOP & GO 10 s"
		game.show_msg(nm + "  ·  " + reason, 4.0, Color(1.0, 0.25, 0.2))
		game.radio("%s wegen %s. Innerhalb von %d Runden in die Box!" % [nm.capitalize(), reason, SERVE_LAPS])
	game.audio.beep(330.0, 0.5)
	if p != null and p.is_player:
		bw_t = 0.0


func warn(reason: String) -> void:
	if not active() or dsq:
		return
	warnings += 1
	bw_t = 4.0
	game.show_msg("VERWARNUNG (schwarz-weiße Flagge)  ·  " + reason, 3.0, Color(1.0, 0.65, 0.1))
	game.audio.beep(520.0, 0.25)


func pending_text() -> String:
	if pending.is_empty():
		return ""
	var p: Dictionary = pending[0]
	var nm := "DURCHFAHRT" if p["type"] == "dt" else "STOP & GO 10 s"
	var laps: int = p["laps"]
	return "%s  ·  noch %d %s" % [nm, laps, "Runde" if laps == 1 else "Runden"]


# ------------------------------------------------------------------ grid / jump start
func grid_tick() -> void:
	var p = game.player
	if not active() or p == null:
		return
	if not jump_checked and absf(p.u) < 0.05:
		grid_pos = Vector2(p.x, p.z)
		jump_checked = true
	if jump_checked and Vector2(p.x, p.z).distance_to(grid_pos) > 0.8 and not p.has_meta("jump"):
		p.set_meta("jump", true)
		penalize("dt", "Frühstart")


# player may creep before the lights go out (that is what a jump start is)
func player_free_on_grid() -> bool:
	var p = game.player
	return active() and game.state == "grid" and p.throttle > 0.6 and p.brake < 0.2


# ------------------------------------------------------------------ per physics step
func tick(dt: float) -> void:
	var p = game.player
	if p == null:
		return
	if not active() or not game.started:
		CarPhysics.contacts.clear()
		return
	_contacts(p)
	_pit_lines(p)
	_serve(p, dt)
	_fcy_tick(p, dt)
	_scan_t -= dt
	if _scan_t <= 0.0:
		_scan_t = 0.2
		_scan_yellow(p)
		_blue(p, 0.2)
		_meatball(p)
	for k in _contact_cd.keys():
		_contact_cd[k] -= dt
		if _contact_cd[k] <= 0.0:
			_contact_cd.erase(k)
	green_t = maxf(0.0, green_t - dt)
	bw_t = maxf(0.0, bw_t - dt)


func on_lap() -> void:
	if not active():
		return
	for q in pending:
		q["laps"] -= 1
	if not pending.is_empty() and int(pending[0]["laps"]) <= 0:
		dsq = true
		game.player.retired = true
		game.player.set_meta("dsq", true)
		game.show_msg("SCHWARZE FLAGGE  ·  Strafe nicht angetreten – disqualifiziert", 5.0, Color(1.0, 0.2, 0.2))
		game.radio("Wir sind disqualifiziert – die Strafe wurde nicht angetreten.")
	elif not pending.is_empty() and int(pending[0]["laps"]) == 1:
		game.radio("Letzte Runde, um die Strafe anzutreten! Diese Runde in die Box.")


# open penalties at the finish become time
func on_finish() -> void:
	fcy = ""
	CarPhysics.fcy_speed = 0.0
	for q in pending:
		game.penalty += 25.0 if q["type"] == "dt" else 35.0
	pending.clear()


# ------------------------------------------------------------------ collisions
func _contacts(p) -> void:
	for ct in CarPhysics.contacts:
		var a = ct[0]
		var b = ct[1]
		var rel: float = ct[2]
		if not (a == p or b == p) or rel < 3.0:
			continue
		var o = b if a == p else a
		if _contact_cd.has(o):
			continue
		_contact_cd[o] = 4.0
		# the player is to blame when he drives into the car in front of him
		var hd := Vector2(cos(p.psi), sin(p.psi))
		var to_o := Vector2(o.x - p.x, o.z - p.z)
		var d := to_o.length()
		if d < 0.01:
			continue
		var ahead := hd.dot(to_o / d)
		var closing: float = p.u - (o.u * cos(o.psi - p.psi))
		if ahead < 0.55 or closing < 1.5 or o.in_pit:
			continue
		if rel > 11.0 or o.total_damage() > 0.45:
			penalize("sg", "Kollision verursacht")
		elif rel > 6.5:
			penalize("dt", "Kollision verursacht")
		else:
			warn("Kontakt mit " + String(o.name))
			if warnings % 2 == 0:
				penalize("time", "wiederholter Kontakt")
	CarPhysics.contacts.clear()


# ------------------------------------------------------------------ pit lane lines and speed
func _pit_lines(p) -> void:
	var T = game.T
	var sep: bool = p.near_lane and T.l_tlat[p.pidx] - T.LANE_IN > T.half_w + 0.5 and T.l_wall[p.pidx] == 0
	if sep and _was_in_pit != p.in_pit and absf(p.u) > 3.0 and not p.retired:
		if p.ps > T.box_ps:
			penalize("dt", "Ausfahrtslinie der Boxengasse überfahren")
		else:
			penalize("dt", "Einfahrtslinie der Boxengasse überfahren")
	_was_in_pit = p.in_pit


func pit_speeding() -> void:
	penalize("dt", "zu schnell in der Boxengasse")


# ------------------------------------------------------------------ serving penalties
func _serve(p, dt: float) -> void:
	var T = game.T
	if stopgo_t >= 0.0:
		p.hold = true
		stopgo_t -= dt
		if stopgo_t < 0.0:
			p.hold = false
			pending.pop_front()
			_visit_stopped = true
			game.show_msg("STOP & GO ABGESESSEN  ·  LOS!", 2.5, Color(0.3, 1.0, 0.4))
			game.audio.beep(880.0, 0.4)
		return
	if p.in_pit and p.near_lane and p.ps > T.lim_a and p.ps < T.box_ps - 10.0 and not _visit:
		_visit = true
		_visit_stopped = false
	if _visit and p.near_lane and absf(p.ps - T.box_ps) < 8.0 and absf(p.u) < 0.5:
		_visit_stopped = true
	if _visit and (not p.near_lane or p.ps > T.lim_b):
		_visit = false
		if not _visit_stopped and not pending.is_empty() and pending[0]["type"] == "dt":
			pending.pop_front()
			game.show_msg("DURCHFAHRTSSTRAFE ANGETRETEN", 2.5, Color(0.3, 1.0, 0.4))
			game.radio("Strafe erledigt. Weiter Gas!")


# called by main when the player stops at his box: a stop & go comes first, no service allowed
func wants_stopgo() -> bool:
	return active() and not pending.is_empty() and pending[0]["type"] == "sg" and stopgo_t < 0.0


func begin_stopgo() -> void:
	stopgo_t = STOPGO_TIME
	game.show_msg("STOP & GO  ·  10 Sekunden stehen bleiben", 3.0, Color(1.0, 0.65, 0.1))


# ------------------------------------------------------------------ yellow flags
func _scan_yellow(p) -> void:
	var T = game.T
	var L: float = T.length
	_zones.clear()
	if game.race_time > 12.0:
		for c in game.cars:
			if c == p or c.in_pit or c.near_lane and c.in_pit:
				continue
			var slow: bool = absf(c.u) < 9.0 or c.retired
			# a car standing on the racing surface (or a crashed car next to it) brings out the full course yellow
			if (absf(c.u) < 2.0 and absf(c.lat) < T.half_w) or (c.retired and absf(c.lat) < T.half_w + 6.0):
				_stopped[c] = float(_stopped.get(c, 0.0)) + 0.2
				if _stopped[c] > 6.0 and fcy == "" and _fcy_cd <= 0.0 and game.race_time > 40.0:
					_start_fcy(c)
			else:
				_stopped.erase(c)
			if slow and absf(c.lat) < T.half_w + 9.0:
				_zones.append([wrapf(c.s - 260.0, 0.0, L), wrapf(c.s + 25.0, 0.0, L), absf(c.lat) < T.half_w + 0.5, c])
	var was: int = yellow
	yellow = 0
	var incident: Array = []
	for z in _zones:
		var a: float = z[0]
		var b: float = z[1]
		var inside: bool = (p.s > a and p.s < b) if a < b else (p.s > a or p.s < b)
		if inside:
			yellow = maxi(yellow, 2 if z[2] else 1)
			incident.append(z[3])
	if fcy == "on":
		yellow = 2           # whole track under yellow: no overtaking
		if not (_fcy_car in incident) and _fcy_car != null:
			incident.append(_fcy_car)
	if was > 0 and yellow == 0:
		green_t = 3.0
		_ahead.clear()
	elif yellow > 0 and was == 0:
		game.audio.beep(600.0, 0.15)
	# overtaking under yellow (passing the car that caused it is allowed)
	var pp: float = game.progress(p)
	if yellow > 0:
		for o in game.cars:
			if o == p or o in incident or o.in_pit:
				continue
			var go: float = game.progress(o)
			if absf(go - pp) > 60.0:
				_ahead.erase(o)
				continue
			var now_ahead := go > pp
			if _ahead.has(o) and _ahead[o] and not now_ahead and not _has_giveback(o):
				_giveback.append({"car": o, "t": 10.0, "double": yellow == 2})
				game.show_msg("ÜBERHOLT UNTER GELB  ·  Platz an %s zurückgeben!" % String(o.name), 4.0, Color(1.0, 0.85, 0.1))
				game.radio("Du hast unter Gelb überholt – lass %s sofort wieder vorbei!" % String(o.name))
			_ahead[o] = now_ahead
	for k in range(_giveback.size() - 1, -1, -1):
		var gb: Dictionary = _giveback[k]
		gb["t"] -= 0.2
		var o2 = gb["car"]
		if game.progress(o2) > pp:
			_giveback.remove_at(k)
			game.show_msg("Platz zurückgegeben  ·  keine Strafe", 2.0, Color(0.3, 1.0, 0.4))
		elif gb["t"] <= 0.0:
			_giveback.remove_at(k)
			penalize("sg" if gb["double"] else "dt", "Überholen unter Gelb")


func _start_fcy(c) -> void:
	fcy = "warn"
	fcy_t = 6.0
	_fcy_car = c
	_fcy_over = 0.0
	game.show_msg("FULL COURSE YELLOW in 5 s  ·  auf 80 km/h verlangsamen", 4.0, Color(1.0, 0.85, 0.1))
	game.radio("Full Course Yellow kommt! %s steht auf der Strecke. Runter auf 80 – L schaltet den 80er-Limiter." % String(c.name))
	game.audio.beep(600.0, 0.4)


func _fcy_tick(p, dt: float) -> void:
	_fcy_cd = maxf(0.0, _fcy_cd - dt)
	if fcy == "":
		return
	fcy_t -= dt
	match fcy:
		"warn":
			if fcy_t <= 0.0:
				fcy = "on"
				fcy_t = 40.0
				CarPhysics.fcy_speed = FCY_KMH / 3.6
				game.show_msg("FULL COURSE YELLOW  ·  max. 80 km/h, nicht überholen", 3.0, Color(1.0, 0.85, 0.1))
		"on":
			if not p.in_pit and not p.near_lane and p.u * 3.6 > FCY_KMH + 6.0:
				_fcy_over += dt
				if _fcy_over > 2.5:
					_fcy_over = -1e9
					penalize("dt", "zu schnell unter Full Course Yellow")
			if fcy_t <= 0.0:
				fcy = "end"
				fcy_t = 5.0
				game.show_msg("FCY endet  ·  Grün in 5 Sekunden", 3.0, Color(0.3, 1.0, 0.4))
		"end":
			if fcy_t <= 0.0:
				fcy = ""
				CarPhysics.fcy_speed = 0.0
				green_t = 3.0
				_fcy_cd = 120.0
				if p.limiter and not p.near_lane:
					p.limiter = false
				game.show_msg("GRÜN! GRÜN! GRÜN!", 2.0, Color(0.3, 1.0, 0.4))
				game.audio.beep(880.0, 0.4)


func _has_giveback(o) -> bool:
	for gb in _giveback:
		if gb["car"] == o:
			return true
	return false


# ------------------------------------------------------------------ blue flags
func _blue(p, dt: float) -> void:
	var T = game.T
	var pp: float = game.progress(p)
	# being lapped by any car (the hypercar rule for GT3 already sets the flag in main)
	for o in game.cars:
		if o == p or o.in_pit:
			continue
		var g: float = wrapf(p.s - o.s, 0.0, T.length)
		if g > 5.0 and g < 70.0 and o.u > p.u - 1.0 and game.progress(o) - pp > T.length * 0.5:
			game.blue_flag = true
	if game.blue_flag and not p.in_pit:
		_blue_t += dt
		_blue_clear = 0.0
	else:
		_blue_clear += dt
		if _blue_clear > 3.0:
			_blue_t = 0.0
			_blue_warned = false
	if _blue_t > 12.0 and not _blue_warned:
		_blue_warned = true
		warn("Blaue Flagge beachten – Platz machen!")
	elif _blue_t > 24.0:
		_blue_t = 0.0
		_blue_warned = false
		penalize("dt", "blaue Flaggen ignoriert")


# ------------------------------------------------------------------ black/orange (meatball)
func _meatball(p) -> void:
	var wheel: bool = p.lost["wheel_fl"] or p.lost["wheel_fr"] or p.lost["wheel_rl"] or p.lost["wheel_rr"]
	meatball = (wheel or p.total_damage() > 0.55 or p.lost["wing"]) and not p.retired
	if meatball and not _meat_said:
		_meat_said = true
		game.radio("Schwarz-orange Flagge: das Auto ist zu stark beschädigt. Komm zur Reparatur rein!")
	elif not meatball:
		_meat_said = false

# Track definitions: control points (x, z in metres), elevation profile [s, h] and theme.
extends RefCounted

static func trois_forets() -> Dictionary:
	return {
		"id": "tf", "name": "Circuit des Trois Forêts", "short": "TROIS FORÊTS", "half_w": 7.0, "theme": "tf",
		"ctrl": [
			Vector2(-150, 0), Vector2(200, 0), Vector2(520, 0), Vector2(700, 0),
			Vector2(800, 18), Vector2(860, 80), Vector2(880, 160),
			Vector2(905, 215), Vector2(880, 250), Vector2(905, 290),
			Vector2(980, 340), Vector2(1060, 360), Vector2(1120, 395),
			Vector2(1185, 470), Vector2(1205, 560),
			Vector2(1205, 900), Vector2(1205, 1250),
			Vector2(1213, 1290), Vector2(1235, 1318), Vector2(1220, 1350), Vector2(1196, 1378), Vector2(1205, 1420),
			Vector2(1205, 1800), Vector2(1205, 2080),
			Vector2(1197, 2120), Vector2(1175, 2148), Vector2(1190, 2180), Vector2(1214, 2208), Vector2(1205, 2250),
			Vector2(1205, 2600), Vector2(1200, 2700),
			Vector2(1175, 2770), Vector2(1125, 2800), Vector2(1078, 2775), Vector2(1062, 2725),
			Vector2(1020, 2620), Vector2(930, 2520), Vector2(830, 2450),
			Vector2(720, 2420), Vector2(665, 2380), Vector2(650, 2320),
			Vector2(645, 2250), Vector2(605, 2215), Vector2(560, 2190),
			Vector2(520, 2100), Vector2(500, 1700), Vector2(490, 1350),
			Vector2(470, 1150), Vector2(410, 1060), Vector2(450, 960),
			Vector2(380, 860), Vector2(300, 790), Vector2(330, 690),
			Vector2(250, 600), Vector2(160, 520), Vector2(120, 420),
			Vector2(60, 340), Vector2(-20, 300), Vector2(-120, 290),
			Vector2(-210, 250), Vector2(-250, 200), Vector2(-265, 140),
			Vector2(-245, 70), Vector2(-210, 20),
		],
		# periodic gentle elevation (generated in track.gd)
		"elev": [],
		"pit": {"in": -330.0, "out": 520.0, "wall_from": -165.0, "wall_to": 420.0, "box": 140.0},
		"stands_left": [-330, -250, -170, -90, 250, 330],
		"bridges": [1640.0],
	}

# Spa-Francorchamps, layout from real GPS centreline (7.0 km). Driven clockwise from the start/finish line.
static func spa() -> Dictionary:
	return {
		"id": "spa", "name": "Spa-Francorchamps", "short": "SPA", "half_w": 6.6, "theme": "spa",
		# light smoothing only (removes GPS kinks, keeps every corner radius), scaled to the official 7004 m
		"smooth": 4, "scale_len": 7004.0,
		"ctrl": PackedVector2Array([Vector2(0.0, -0.0), Vector2(-113.4, -198.1), Vector2(-114.6, -207.0), Vector2(-109.5, -214.9), Vector2(-99.1, -218.6), Vector2(-87.4, -215.4), Vector2(-50.1, -196.6), Vector2(40.5, -153.1), Vector2(84.1, -126.3), Vector2(129.4, -92.7), Vector2(170.0, -58.7), Vector2(202.2, -23.6), Vector2(375.4, 182.9), Vector2(387.6, 194.5), Vector2(408.4, 207.5), Vector2(445.8, 231.6), Vector2(462.1, 247.9), Vector2(475.9, 269.9), Vector2(484.8, 289.9), Vector2(490.7, 312.3), Vector2(495.7, 353.8), Vector2(498.6, 368.5), Vector2(503.6, 382.1), Vector2(513.2, 399.9), Vector2(598.8, 536.7), Vector2(653.2, 623.7), Vector2(668.3, 656.2), Vector2(678.0, 680.3), Vector2(689.3, 719.1), Vector2(757.6, 957.6), Vector2(862.4, 1319.8), Vector2(886.7, 1406.8), Vector2(888.0, 1421.0), Vector2(885.4, 1436.6), Vector2(877.1, 1449.2), Vector2(864.9, 1459.8), Vector2(849.4, 1468.1), Vector2(840.2, 1477.0), Vector2(833.9, 1487.5), Vector2(828.9, 1503.2), Vector2(829.7, 1518.9), Vector2(850.7, 1612.8), Vector2(850.2, 1629.0), Vector2(846.9, 1643.7), Vector2(835.6, 1659.9), Vector2(822.1, 1670.9), Vector2(583.3, 1836.1), Vector2(568.2, 1842.4), Vector2(553.1, 1842.8), Vector2(537.2, 1838.2), Vector2(524.2, 1828.7), Vector2(514.9, 1815.1), Vector2(511.2, 1801.5), Vector2(510.3, 1786.8), Vector2(514.9, 1773.1), Vector2(523.3, 1759.0), Vector2(535.5, 1749.1), Vector2(639.9, 1684.6), Vector2(651.2, 1673.0), Vector2(657.4, 1661.5), Vector2(660.0, 1647.9), Vector2(658.7, 1631.1), Vector2(615.5, 1504.2), Vector2(602.1, 1452.4), Vector2(571.5, 1292.5), Vector2(556.4, 1200.8), Vector2(553.1, 1185.1), Vector2(545.5, 1168.3), Vector2(535.5, 1154.6), Vector2(520.4, 1140.0), Vector2(503.6, 1129.0), Vector2(485.2, 1121.6), Vector2(465.9, 1118.5), Vector2(403.4, 1114.3), Vector2(379.6, 1117.0), Vector2(357.7, 1123.2), Vector2(335.6, 1132.6), Vector2(317.5, 1144.8), Vector2(296.6, 1164.1), Vector2(283.2, 1183.4), Vector2(268.5, 1211.2), Vector2(209.4, 1359.1), Vector2(156.6, 1490.7), Vector2(145.2, 1511.1), Vector2(131.9, 1525.3), Vector2(113.4, 1535.7), Vector2(95.0, 1540.9), Vector2(77.8, 1541.5), Vector2(60.6, 1537.8), Vector2(46.0, 1531.0), Vector2(21.6, 1515.3), Vector2(5.7, 1508.5), Vector2(-13.6, 1505.4), Vector2(-32.9, 1507.5), Vector2(-50.5, 1513.1), Vector2(-65.6, 1523.7), Vector2(-75.2, 1535.7), Vector2(-87.0, 1551.9), Vector2(-183.8, 1704.0), Vector2(-193.4, 1712.8), Vector2(-205.1, 1719.2), Vector2(-219.4, 1722.3), Vector2(-235.3, 1721.3), Vector2(-249.1, 1715.0), Vector2(-314.5, 1667.3), Vector2(-353.1, 1639.0), Vector2(-362.7, 1626.4), Vector2(-372.8, 1611.2), Vector2(-378.6, 1596.5), Vector2(-382.8, 1579.2), Vector2(-383.7, 1561.4), Vector2(-380.8, 1539.9), Vector2(-374.0, 1521.6), Vector2(-365.2, 1498.0), Vector2(-352.2, 1462.3), Vector2(-329.6, 1422.0), Vector2(-304.8, 1386.8), Vector2(-267.2, 1344.5), Vector2(-204.3, 1283.1), Vector2(-167.4, 1254.3), Vector2(-136.0, 1235.9), Vector2(25.8, 1151.5), Vector2(49.3, 1136.9), Vector2(71.5, 1119.5), Vector2(92.1, 1100.2), Vector2(109.6, 1079.1), Vector2(126.0, 1057.1), Vector2(147.8, 1016.9), Vector2(165.4, 978.1), Vector2(205.6, 888.4), Vector2(212.7, 869.0), Vector2(217.0, 848.1), Vector2(217.7, 821.8), Vector2(213.6, 798.3), Vector2(189.7, 736.9), Vector2(163.7, 669.3), Vector2(132.3, 584.9), Vector2(124.3, 553.5), Vector2(116.8, 516.3), Vector2(112.2, 481.7), Vector2(109.2, 452.3), Vector2(100.0, 316.6), Vector2(101.7, 307.7), Vector2(107.1, 301.3), Vector2(115.5, 299.2), Vector2(129.7, 301.3), Vector2(144.5, 301.3), Vector2(154.5, 299.2), Vector2(161.2, 291.9), Vector2(162.9, 283.5), Vector2(158.7, 272.5), Vector2(107.1, 188.1)]),
		# Official FIA elevation points [distance m, altitude m a.s.l.] along the 7004 m lap.
		# One extra point (1010 m / 407 m) reconstructs the documented ~18 % maximum gradient of Raidillon,
		# which the sparse FIA points alone would smooth down to ~14 %.
		"fia_len": 7004.0,
		"fia_base": 416.0,
		"fia": [
			Vector2(0, 416), Vector2(220, 424), Vector2(690, 403), Vector2(890, 391), Vector2(1010, 407), Vector2(1130, 415),
			Vector2(1490, 430), Vector2(2200, 463), Vector2(2470, 470), Vector2(2870, 456), Vector2(3110, 438), Vector2(3600, 402),
			Vector2(4280, 377), Vector2(4740, 373), Vector2(5100, 370), Vector2(5700, 384), Vector2(6000, 394), Vector2(6540, 408), Vector2(7004, 416),
		],
		"elev": [],
		# Pit lane on the right: entry right after the Bus Stop chicane, runs along the start/finish straight
		# past the garages, loops tightly inside La Source and merges again on the run down to Eau Rouge.
		# "lane" = [track s, lateral offset] key points of the lane centre; "wall_from/wall_to" = 60 km/h zone.
		"pit": {"in": -305.0, "out": 700.0, "wall_from": -195.0, "wall_to": 175.0, "box": -20.0, "garages": [-180.0, 160.0],
			"lane": [[-305.0, 3.0], [-235.0, 12.0], [640.0, 12.0], [700.0, 3.0]]},
		# run-off: [from s, to s, side ("out" / "both"), type (1 = gravel, 2 = tarmac), barrier distance from edge,
		#           painted bands outside / inside ("g" green, "r" red, "y" yellow; each band 2 m wide)]
		"runoff": [
			[160.0, 340.0, "out", 2, 30.0, "g"],            # La Source: huge light tarmac run-off
			[740.0, 950.0, "both", 2, 24.0, "yryr", "g"],   # Eau Rouge: red/yellow stripes outside, green inside
			[950.0, 1190.0, "both", 2, 30.0, "yryr", "g"],  # Raidillon
			[2200.0, 2420.0, "out", 1, 26.0, "g"],          # Les Combes
			[2440.0, 2600.0, "out", 1, 24.0, "g"],          # Malmedy
			[2840.0, 3040.0, "out", 1, 26.0, "g"],          # Bruxelles
			[3090.0, 3210.0, "out", 2, 20.0, "g"],          # no-name left-hander
			[3600.0, 4000.0, "out", 1, 24.0, "g"],          # Pouhon
			[4300.0, 4600.0, "out", 2, 20.0, "g"],          # Fagnes / Campus
			[4760.0, 4900.0, "out", 1, 24.0, "g"],          # Stavelot
			[5650.0, 6150.0, "out", 1, 28.0, "g"],          # Blanchimont
			[6570.0, 6720.0, "both", 2, 22.0, "yr", "g"],   # Bus Stop
		],
		"corners": [[244.0, "T1  LA SOURCE"], [904.0, "T2  EAU ROUGE"], [1000.0, "T3/4  RAIDILLON"], [1600.0, "KEMMEL"], [2290.0, "T5  LES COMBES"],
			[2518.0, "T7  MALMEDY"], [2930.0, "T8  BRUXELLES"], [3760.0, "T10/11  POUHON"], [4370.0, "T12  FAGNES"], [4530.0, "T13  CAMPUS"],
			[4830.0, "T14  STAVELOT"], [5040.0, "T15  PAUL FRÈRE"], [6080.0, "T16/17  BLANCHIMONT"], [6640.0, "T18/19  BUS STOP"]],
		"stands_left": [-200, -120, 80],
		# the big grandstand facing Eau Rouge / Raidillon (left side, built into the hill)
		"big_stands": [[860.0, 1040.0, -1.0]],
		"bridges": [2150.0],
	}

static func all() -> Array:
	return [trois_forets(), spa()]

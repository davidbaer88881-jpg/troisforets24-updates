# Vehicle dynamics: bicycle model with load transfer, aero, Pacejka-style tyres, friction circle,
# drivetrain, TC/ABS, suspension heave (curbs), tyre temp/wear/pressure, fuel, setup and damage.
extends RefCounted

const G := 9.81
const RHO := 1.225

const SPECS := {
	"hyper": {
		"cls": "HYPERCAR", "key": "hyper", "mass": 1030.0, "L": 3.05, "a": 1.62, "h": 0.30, "Iz": 2300.0,
		"power": 500000.0, "Tpeak": 650.0, "rpmMax": 9300.0, "rpmIdle": 2200.0, "rpmShift": 8900.0,
		"gears": [3.10, 2.40, 1.95, 1.63, 1.40, 1.23, 1.09], "final": 3.4, "eff": 0.92, "wheelR": 0.355,
		"ClA": 3.4, "CdA": 0.93, "aeroFront": 0.44, "mu": 1.75,
		"brakeMax": 34000.0, "steerMax": 0.30, "absStd": false,
		"fuelCap": 75.0, "fuelRate": 0.042, "vmax": 94.0, "len": 5.0, "wid": 2.0, "cyl": 6,
	},
	"gt3": {
		"cls": "GT3", "key": "gt3", "mass": 1310.0, "L": 2.70, "a": 1.42, "h": 0.40, "Iz": 2500.0,
		"power": 400000.0, "Tpeak": 640.0, "rpmMax": 8200.0, "rpmIdle": 1800.0, "rpmShift": 7900.0,
		"gears": [3.00, 2.18, 1.73, 1.43, 1.23, 1.08], "final": 3.3, "eff": 0.92, "wheelR": 0.345,
		"ClA": 2.0, "CdA": 1.10, "aeroFront": 0.42, "mu": 1.58,
		"brakeMax": 36000.0, "steerMax": 0.33, "absStd": true,
		"fuelCap": 110.0, "fuelRate": 0.046, "vmax": 80.0, "len": 4.6, "wid": 2.0, "cyl": 8,
	},
}

# grip, wear multiplier, optimal temperature, grip on a wet track
const COMPOUNDS := {
	"soft": {"name": "Soft", "grip": 1.035, "wear": 1.55, "topt": 85.0, "wet": 0.60, "col": Color(0.9, 0.15, 0.15)},
	"medium": {"name": "Medium", "grip": 1.0, "wear": 1.0, "topt": 92.0, "wet": 0.62, "col": Color(1.0, 0.85, 0.1)},
	"hard": {"name": "Hard", "grip": 0.965, "wear": 0.62, "topt": 100.0, "wet": 0.61, "col": Color(0.95, 0.95, 0.95)},
	"wet": {"name": "Regen", "grip": 0.86, "wear": 2.4, "topt": 62.0, "wet": 0.93, "col": Color(0.2, 0.55, 1.0)},
}

static func default_setup(key: String) -> Dictionary:
	return {
		"compound": "medium", "press_f": 0.0, "press_r": 0.0, "wing": 5, "bias": 0.62 if key == "hyper" else 0.63,
		"arb_f": 5, "arb_r": 5, "spring": 5, "gearing": 1, "tc": 6, "abs": 0 if key == "hyper" else 6,
		"fuel": 75.0 if key == "hyper" else 110.0,
	}

var spec: Dictionary
var T  # Track
var setup: Dictionary

# state
var x := 0.0
var z := 0.0
var y := 0.0
var psi := 0.0
var u := 0.0
var v := 0.0
var r := 0.0
var gear := 1
var rpm := 2000.0
# engine start: ignition (dash on, fuel pump) then the starter cranks until the engine fires
var engine_on := true
var ignition := true
var starter := false          # starter button held
var crank_t := 0.0
var off_rpm := 0.0            # rpm running down after the engine was switched off
# drift launch: rev in neutral, drop it into first with full throttle and steer -> the rear breaks
# loose and the car slides round as long as throttle and steering are held (works in every steering mode)
var drift_t := 0.0
signal engine_started
var auto_shift := true
var steer := 0.0
var throttle := 0.0
var brake := 0.0
var ax := 0.0
var ay := 0.0
var fuel := 75.0
var wear_f := 0.0
var wear_r := 0.0
var temp_f := 72.0
var temp_r := 72.0
var compound := "medium"
var idx := 0
var s := 0.0
var lat := 0.0
var prev_lat := 0.0
# position on the pit lane's own centreline (valid while near_lane)
var draft := 0.0          # slipstream 0..1 (less drag behind another car, a little less downforce)
var flash := 0.0          # headlight flash timer (AI asking to get past)
var near_lane := false
var pidx := 0
var ps := 0.0
var plat := 0.0
var prev_plat := 0.0
var surface := "asphalt"
var slip_f := 0.0
var slip_r := 0.0
var lock_f := false
var lock_r := false
var spin_r := false
var wheel_spin := 0.0
var shift_timer := 0.0
var limiter := false
var tc_active := false
var abs_active := false
var impact := 0.0
var pitch := 0.0
var roll := 0.0
var grade_pitch := 0.0
var in_pit := false
var wet := 0.0            # track wetness 0..1 (set by race)
var tc_on := true
var abs_on := false
var hold := false         # held in place (grid / pit service)
var last_work := Vector2.ZERO
var ghost := 0.0          # > 0: AI car passes through other AI cars (pit lane dead lock breaker)

# suspension heave (visual + load variation)
var heave := 0.0
var heave_v := 0.0
var load_var := 1.0       # suspension compression (>1 = bottoming out, sparks)
var bump_phase := 0.0
var road_now := 0.0
var curb_hit := 0.0

# damage 0..1 per zone, parts lost
var dmg := {"front": 0.0, "rear": 0.0, "left": 0.0, "right": 0.0, "engine": 0.0, "susp_l": 0.0, "susp_r": 0.0}
var lost := {"splitter": false, "wing": false, "mirror_l": false, "mirror_r": false,
	"wheel_fl": false, "wheel_fr": false, "wheel_rl": false, "wheel_rr": false}
var retired := false
var hits: Array = []      # pending visual hits: [zone, amount, local_dir(Vector3)]
static var contacts: Array = []   # car-car contacts of this step for the race director: [A, B, closing speed]
static var fcy_speed := 0.0      # full course yellow: speed cap in m/s for everyone (0 = green)
static var formation := false    # formation lap of a rolling start: the cap also applies to the player
const FUEL_KG := 0.74             # kg per litre
var easy := false                 # "Sehr einfach" steering: stability assist, the car hardly slides
var pad_wear := 0.0               # brake pads 0 = new, 1 = worn out

# race bookkeeping (filled by race manager)
var lap := -1
var cp := true
var lap_start := -1.0
var best := -1.0
var last := -1.0
var finished := false
var lap_invalid := false
var finish_time := 0.0
var prev_s := 0.0
var name := ""
var num := 0
var is_player := false
var remote := false        # online: driven by another computer (state comes over the network)
var driver := ""          # human driver name (online / profile)
var trace := PackedFloat32Array()
var best_trace := PackedFloat32Array()


func _init(sp: Dictionary, track, su: Dictionary) -> void:
	spec = sp
	T = track
	setup = su.duplicate()
	compound = setup["compound"]
	fuel = clampf(setup["fuel"], 5.0, spec["fuelCap"])
	tc_on = int(setup["tc"]) > 0
	abs_on = int(setup["abs"]) > 0
	rpm = spec["rpmIdle"]


func place(sp: float, la: float) -> void:
	var p: Vector4 = T.point_at(sp, la)
	x = p.x
	y = p.y
	z = p.z
	psi = p.w
	u = 0.0
	v = 0.0
	r = 0.0
	T.locate_global(x, z)
	idx = T.loc_i
	s = T.loc_s
	lat = T.loc_lat
	prev_lat = lat
	prev_s = s
	_lane_update(true)
	prev_plat = plat


# parks the car on the pit lane (lane s, lane lateral), facing down the lane
func place_lane(lane_s: float, la: float) -> void:
	var p: Vector4 = T.lane_point(lane_s, la)
	x = p.x
	y = p.y
	z = p.z
	psi = p.w
	u = 0.0
	v = 0.0
	r = 0.0
	T.locate_global(x, z)
	idx = T.loc_i
	s = T.loc_s
	lat = T.loc_lat
	prev_lat = lat
	prev_s = s
	_lane_update(true)
	prev_plat = plat


func _lane_update(full: bool) -> void:
	if T.lN == 0 or not T.in_range(s, T.pit_in - 40.0, T.pit_out + 40.0):
		near_lane = false
		return
	var was_near := near_lane
	if full:
		T.lane_locate_global(x, z)
	else:
		# search around the lane sample that belongs to the current track position (never a stale one)
		var h: int = T.t2l[idx]
		if was_near and absf(float(h - pidx)) < 40.0:
			h = pidx
		T.lane_locate(x, z, maxi(0, h), 30)
	pidx = T.lloc_i
	ps = T.lloc_s
	plat = T.lloc_lat
	near_lane = T.lloc_d < 30.0
	# the lane lateral of the previous step is only comparable if we were already tracking the lane
	if not was_near or full:
		prev_plat = plat


# ---------------------------------------------------------------- derived parameters
func cmp() -> Dictionary:
	return COMPOUNDS[compound]


# cold tyres: the rubber is hard, grip builds up over the first corners; overheated: greasy
static func temp_grip(t: float, topt: float) -> float:
	# cold rubber is hard and slides (about 25 % less grip at 40-50 °C), in the window the tyre bites
	# a little better than nominal, overheated it gets greasy again
	var d := t - topt
	if d < 0.0:
		return lerpf(0.72, 1.03, smoothstep(-58.0, -6.0, d))
	return maxf(0.75, 1.03 - 0.00012 * d * d)


func grip_factor() -> Vector2:
	var c := cmp()
	var topt: float = c["topt"]
	var pf: float = setup["press_f"]
	var pr: float = setup["press_r"]
	var tf := temp_grip(temp_f, topt)
	var tr := temp_grip(temp_r, topt)
	var wf := 1.0 - 0.16 * pow(wear_f, 1.4)
	var wr := 1.0 - 0.16 * pow(wear_r, 1.4)
	var base: float = lerpf(c["grip"], c["wet"], wet)
	return Vector2(tf * wf * base * (1.0 - 0.07 * pf * pf), tr * wr * base * (1.0 - 0.07 * pr * pr))


func aero_cla() -> float:
	var w: float = 0.8 + 0.04 * float(setup["wing"])
	var lossf: float = 0.25 * float(lost["splitter"]) + 0.12 * float(dmg["front"])
	var lossr: float = 0.5 * float(lost["wing"]) + 0.1 * float(dmg["rear"])
	return spec["ClA"] * w * (1.0 - 0.5 * lossf - 0.5 * lossr) * (0.97 + 0.006 * float(setup["spring"])) * (1.0 - 0.12 * draft)


func aero_front_share() -> float:
	var af: float = spec["aeroFront"]
	if lost["wing"]:
		af += 0.22
	if lost["splitter"]:
		af -= 0.10
	return clampf(af, 0.25, 0.75)


func aero_cda() -> float:
	var w: float = 0.88 + 0.024 * float(setup["wing"])
	return spec["CdA"] * w * (1.0 + 0.10 * dmg["front"] + 0.06 * dmg["rear"] + 0.04 * (dmg["left"] + dmg["right"])) * (0.93 if lost["wing"] else 1.0) * (1.0 - 0.3 * draft)


func final_drive() -> float:
	return spec["final"] * [1.07, 1.0, 0.94][int(setup["gearing"])]


func power_factor() -> float:
	return 1.0 - 0.45 * dmg["engine"] - 0.05 * dmg["rear"]


func steer_pull() -> float:
	return (dmg["susp_r"] - dmg["susp_l"]) * 0.035


func torque(rp: float) -> float:
	var xx: float = rp / spec["rpmMax"]
	var f := 1.0
	if xx < 0.25:
		f = 0.55 + xx * 1.2
	elif xx < 0.6:
		f = 0.85 + (xx - 0.25) * 0.43
	elif xx < 0.85:
		f = 1.0
	else:
		f = 1.0 - (xx - 0.85)
	return spec["Tpeak"] * f * power_factor()


static func magic(alpha: float) -> float:
	var xx := 16.0 * alpha
	return sin(1.32 * atan(xx + 0.3 * (xx - atan(xx))))


func total_damage() -> float:
	return dmg["front"] + dmg["rear"] + dmg["left"] + dmg["right"] + dmg["engine"] + dmg["susp_l"] + dmg["susp_r"]


# ---------------------------------------------------------------- simulation step
func step(dt: float) -> void:
	ghost = maxf(0.0, ghost - dt)
	var m: float = spec["mass"] + fuel * FUEL_KG
	var L: float = spec["L"]
	var a: float = spec["a"]
	var b := L - a
	var h: float = spec["h"]
	var spd := sqrt(u * u + v * v)
	if retired:
		throttle = 0.0
	if not engine_on:
		throttle = 0.0

	# ---- locate & surface
	T.locate(x, z, idx, 12)
	idx = T.loc_i
	s = T.loc_s
	lat = T.loc_lat
	var al := absf(lat)
	var surf_mu := 1.0
	var roll_c := 0.012
	_lane_update(false)
	if near_lane and plat > -T.LANE_IN - 3.0 and plat < T.l_out[pidx] + 3.0:
		# on the pit lane the track position follows the lane's own mapping (the La Source loop
		# would otherwise lose the nearest piece of track)
		T.locate(x, z, T.idx(T.l_ts[pidx]), 6)
		idx = T.loc_i
		s = T.loc_s
		lat = T.loc_lat
		al = absf(lat)
	elif absf(lat) > 120.0:
		T.locate_global(x, z)
		idx = T.loc_i
		s = T.loc_s
		lat = T.loc_lat
		al = absf(lat)
	in_pit = near_lane and T.lane_inside(plat, pidx, lat)
	var on_curb := false
	var side_curb: int = T.curb_r[idx] if lat > 0.0 else T.curb_l[idx]
	var bands: String = T.band_r[idx] if lat > 0.0 else T.band_l[idx]
	if in_pit:
		surface = "pit"
	elif al <= T.half_w:
		surface = "asphalt"
	elif al <= T.half_w + 1.3 and side_curb == 1:
		surface = "curb"
		surf_mu = 0.92
		roll_c = 0.02
		on_curb = true
	elif al <= T.half_w + 1.5:
		surface = "edge"
		surf_mu = 0.85
		roll_c = 0.03
	elif _run_type() == 2 or (_run_type() == 1 and al <= T.half_w + 1.3 + 2.0 * bands.length()):
		surface = "runoff"      # asphalt run-off / painted bands: grippy, but outside the track limits
		surf_mu = 0.9
		roll_c = 0.016
	elif _run_type() == 1:
		surface = "gravel"
		# deep gravel drags hard at speed, but you can crawl out at low speed
		surf_mu = 0.42 + 0.18 * clampf(1.0 - absf(u) / 12.0, 0.0, 1.0)
		roll_c = 0.10 + 0.20 * clampf(absf(u) / 30.0, 0.0, 1.0)
	else:
		surface = "grass"
		surf_mu = 0.48
		roll_c = 0.07
	if wet > 0.0 and surface != "grass" and surface != "gravel":
		surf_mu *= 1.0 - 0.05 * wet

	# ---- suspension heave: curbs excite a spring-damper; the load variation costs grip
	var k_s := 40000.0 + float(setup["spring"]) * 9000.0
	var c_s := 2.0 * sqrt(k_s * m) * 0.32
	var road := 0.0
	if on_curb or surface == "edge":
		bump_phase += absf(u) * dt / 0.55
		road = 0.035 * signf(sin(bump_phase * TAU)) * (1.0 if on_curb else 0.4)
		curb_hit = 1.0
	elif surface == "grass" or surface == "gravel":
		bump_phase += absf(u) * dt / 1.7
		road = 0.03 * sin(bump_phase * TAU) * sin(bump_phase * 2.3)
	curb_hit = maxf(0.0, curb_hit - dt * 4.0)
	road_now = road
	var f_s := -k_s * (heave - road) - c_s * heave_v
	heave_v += f_s / m * dt
	heave += heave_v * dt
	load_var = clampf(1.0 + (-k_s * (heave - road)) / (m * G) * 0.6, 0.55, 1.4)

	# ---- loads
	var cla := aero_cla()
	var af := aero_front_share()
	var down := 0.5 * RHO * cla * u * u
	var gr: float = T.grade[idx] * cos(psi - T.head[idx])
	var W := m * G
	var fzf := (W * b / L + down * af - m * ax * h / L) * load_var
	var fzr := (W * a / L + down * (1.0 - af) + m * ax * h / L) * load_var
	fzf = maxf(fzf, 0.15 * W)
	fzr = maxf(fzr, 0.15 * W)
	# tyre load sensitivity is measured against the empty car: every litre on board costs grip
	var W0: float = float(spec["mass"]) * G
	var fz0f := W0 * b / L
	var fz0r := W0 * a / L
	var gf := grip_factor()
	var muf: float = spec["mu"] * surf_mu * gf.x * (1.0 - 0.07 * (fzf / fz0f - 1.0))
	var mur: float = spec["mu"] * surf_mu * gf.y * (1.0 - 0.07 * (fzr / fz0r - 1.0))
	# lateral load transfer: anti-roll bars move it between the axles (balance tuning)
	var ltt := minf(0.14, absf(ay) / G * h / 1.6 * 0.14)
	var ltf := ltt * (0.6 + 0.08 * float(setup["arb_f"]))
	var ltr := ltt * (0.6 + 0.08 * float(setup["arb_r"]))
	var cap_f := muf * fzf * (1.0 - ltf) * (1.0 - 0.25 * maxf(dmg["susp_l"], dmg["susp_r"]))
	var cap_r := mur * fzr * (1.0 - ltr)
	# missing wheel: that corner scrapes on the hub, the car limps along at walking pace
	var wl_f := int(lost["wheel_fl"]) + int(lost["wheel_fr"])
	var wl_r := int(lost["wheel_rl"]) + int(lost["wheel_rr"])
	cap_f *= 1.0 - 0.45 * wl_f
	cap_r *= 1.0 - 0.45 * wl_r

	# ---- drivetrain
	var wheel_w: float = u / spec["wheelR"]
	var gears: Array = spec["gears"]
	var fd := final_drive()
	if shift_timer > 0.0:
		shift_timer -= dt
	if auto_shift and gear > 0 and shift_timer <= 0.0:
		var ratio: float = gears[gear - 1] * fd
		var rpm_now := absf(wheel_w) * ratio * 60.0 / TAU
		if rpm_now > spec["rpmShift"] and gear < gears.size() and throttle > 0.1:
			shift(1)
		elif gear > 1:
			var rl: float = gears[gear - 2] * fd
			var rpm_low := absf(wheel_w) * rl * 60.0 / TAU
			if rpm_low < spec["rpmShift"] * (0.84 if brake > 0.1 else 0.70):
				shift(-1)
	var fdrive := 0.0
	if gear != 0:
		var grr: float = gears[gear - 1] if gear > 0 else -2.9
		var ratio := grr * fd
		var rp := absf(wheel_w * ratio) * 60.0 / TAU
		rp += wheel_spin * absf(ratio) * 60.0 / TAU / spec["wheelR"]
		rp = maxf(spec["rpmIdle"], rp)
		var thr := throttle
		if easy and absf(u) > 3.0 and drift_t <= 0.0:
			# assist: less throttle while the car is sliding (like a strong traction/stability control)
			thr *= clampf(1.0 - (absf(v) / absf(u) - 0.04) * 9.0, 0.25, 1.0)
		if shift_timer > 0.0:
			thr = 0.0
		if limiter:
			# hard 60 km/h cap: throttle fades out in the last 2.5 km/h and is cut above the limit
			# hard 60 km/h cap in the pit lane; under full course yellow the same button holds 80 km/h
			var lim_v: float = T.pit_limit if (near_lane or fcy_speed <= 0.0) else fcy_speed
			thr = minf(thr, clampf((lim_v - spd) * 1.4, 0.0, 1.0))
		elif fcy_speed > 0.0 and (not is_player or formation):
			thr = minf(thr, clampf((fcy_speed - spd) * 1.4, 0.0, 1.0))
		if rp >= spec["rpmMax"]:
			thr = 0.0
		var te := torque(minf(rp, spec["rpmMax"])) * thr
		var tb: float = (1.0 - thr) * 0.10 * spec["Tpeak"] * (rp / spec["rpmMax"])
		fdrive = te * ratio * spec["eff"] / spec["wheelR"] - signf(u) * tb * absf(ratio) / spec["wheelR"]
		if gear < 0 and u > 0.5:
			fdrive = 0.0
		rpm += (rp - rpm) * minf(1.0, dt * 25.0)
	else:
		rpm += ((spec["rpmIdle"] + throttle * (spec["rpmMax"] - spec["rpmIdle"])) - rpm) * minf(1.0, dt * 8.0)
	if not engine_on:
		fdrive = 0.0
		if starter and ignition and fuel > 0.0:
			# cranking: ~250 rpm with compression pulses, fires after about a second
			crank_t += dt
			rpm = 230.0 + 60.0 * sin(crank_t * 55.0)
			if crank_t > 1.05:
				engine_on = true
				crank_t = 0.0
				rpm = float(spec["rpmIdle"]) * 2.4      # first flare when it catches
				engine_started.emit()
		else:
			crank_t = 0.0
			off_rpm = maxf(0.0, off_rpm - dt * 2500.0)
			rpm = off_rpm

	# ---- brakes (bias from setup)
	var sgn_u := 1.0 if u >= 0.0 else -1.0
	var bias: float = setup["bias"]
	# worn pads lose bite in the last third of their life
	var pad_k := 1.0 - 0.45 * clampf((pad_wear - 0.65) / 0.35, 0.0, 1.0)
	var fbf: float = brake * spec["brakeMax"] * bias * pad_k
	var fbr: float = brake * spec["brakeMax"] * (1.0 - bias) * pad_k
	if absf(u) < 0.3:
		fbf = 0.0
		fbr = 0.0
	abs_active = false
	lock_f = false
	lock_r = false
	if abs_on:
		var al_cap := 0.93 + 0.004 * float(setup["abs"])
		if fbf > cap_f * al_cap:
			fbf = cap_f * al_cap
			abs_active = true
		if fbr > cap_r * al_cap:
			fbr = cap_r * al_cap
			abs_active = true
	else:
		if fbf > cap_f:
			fbf = cap_f * 0.82
			lock_f = true
		if fbr > cap_r:
			fbr = cap_r * 0.82
			lock_r = true

	var fx_r := fdrive - sgn_u * fbr
	var fx_f := -sgn_u * fbf
	tc_active = false
	spin_r = false
	var ue := maxf(absf(u), 2.5)
	var a_r0 := absf(atan2(v - b * r, ue))
	var tc_lim := cap_r * maxf(0.2, 0.98 - float(setup["tc"]) * 0.012 - a_r0 * (2.5 + 0.25 * float(setup["tc"])))
	if tc_on and drift_t <= 0.0 and fdrive > 0.0 and brake < 0.05 and fx_r > tc_lim:
		fx_r = tc_lim
		tc_active = true
	elif absf(fx_r) > cap_r * 0.98:
		fx_r = signf(fx_r) * cap_r * 0.9
		if fdrive > 0.0:
			spin_r = true
	if drift_t > 0.0 and fdrive > 0.0:
		spin_r = true
	wheel_spin += ((minf(25.0, absf(fdrive) / cap_r * 6.0) if spin_r else 0.0) - wheel_spin) * minf(1.0, dt * 6.0)

	# ---- slip angles & lateral forces
	var delta: float = steer * spec["steerMax"] + steer_pull()
	var a_f := atan2(v + a * r, ue) - delta * sgn_u
	var a_r := atan2(v - b * r, ue)
	var lat_cap_f := sqrt(maxf(0.0, cap_f * cap_f - fx_f * fx_f)) * (0.35 if lock_f else 1.0)
	var lat_cap_r := sqrt(maxf(0.0, cap_r * cap_r - fx_r * fx_r)) * (0.4 if lock_r else 1.0) * (0.55 if spin_r else 1.0)
	var fy_f := -lat_cap_f * magic(a_f)
	var fy_r := -lat_cap_r * magic(a_r)
	slip_f = a_f
	slip_r = a_r

	# ---- resistances
	var fdrag := 0.5 * RHO * aero_cda() * u * absf(u)
	var froll := roll_c * W * tanh(u * 2.0)
	var fgrade := m * G * sin(atan(gr))
	var cd := cos(delta)
	var sd := sin(delta)
	var scrape := 0.0
	if wl_f + wl_r > 0:
		scrape = m * G * 0.35 * float(wl_f + wl_r) * tanh(u * 0.5)
		r += (float(int(lost["wheel_fr"]) + int(lost["wheel_rr"]) - int(lost["wheel_fl"]) - int(lost["wheel_rl"]))) * 0.08 * tanh(u * 0.3) * dt
	var fx := fx_r + fx_f * cd - fy_f * sd - fdrag - froll - fgrade - scrape
	# drift launch (see drift_t): keeps sliding while throttle and steering are held
	var drifting := false
	if drift_t > 0.0:
		var steer_in: float = clampf(delta / float(spec["steerMax"]), -1.0, 1.0)
		if throttle > 0.6 and absf(steer_in) > 0.15 and absf(u) < 32.0 and engine_on:
			drift_t = maxf(drift_t, 0.6)
			drifting = true
			fy_r *= 0.4
			# the spinning rear swings the car round in the steering direction
			r += (steer_in * 2.3 * signf(maxf(u, 0.5)) - r) * minf(1.0, dt * 2.2)
		else:
			drift_t -= dt
	var fy := fy_r + fy_f * cd + fx_f * sd
	var mz := a * (fy_f * cd + fx_f * sd) - b * fy_r
	ax += (fx / m - ax) * minf(1.0, dt * 12.0)
	ay += (fy / m - ay) * minf(1.0, dt * 12.0)
	u += (fx / m + v * r) * dt
	v += (fy / m - u * r) * dt
	# a full tank sits in the middle of the car: more yaw inertia, the car turns in more lazily
	r += mz / (float(spec["Iz"]) * (1.0 + fuel * FUEL_KG / float(spec["mass"]) * 0.6)) * dt
	# low-speed stabiliser (parking speeds only). Judged by the TOTAL speed: a car sliding sideways
	# has little forward speed but is still fast - it must keep sliding, not stop dead
	var vtot := sqrt(u * u + v * v)
	if vtot < 4.0 and not drifting:
		var k := 1.0 - vtot / 4.0
		var rk := u * tan(delta) / L
		r += (rk - r) * minf(1.0, k * dt * 10.0)
		v *= maxf(0.0, 1.0 - k * dt * 8.0)
		if vtot < 1.5:
			# standing (almost) still: the car cannot turn on the spot, only roll the way the wheels point
			r = rk
			v *= maxf(0.0, 1.0 - dt * 20.0)
	if easy and absf(u) > 3.0 and not drifting:
		# stability assist: the car follows the steering, slides are caught almost at once
		var lat_g: float = G * 1.6 + down / m
		var rk2 := clampf(u * tan(delta) / L, -lat_g / absf(u), lat_g / absf(u))
		r += (rk2 - r) * minf(1.0, dt * 7.0)
		v *= maxf(0.0, 1.0 - dt * 6.0)
	if absf(u) < 0.05 and throttle < 0.02:
		u = 0.0
	if brake > 0.0 and signf(u) != sgn_u and gear >= 0:
		u = 0.0
	if hold:
		u = 0.0
		v = 0.0
		r = 0.0
	psi += r * dt
	var cp := cos(psi)
	var sp := sin(psi)
	x += (u * cp - v * sp) * dt
	z += (u * sp + v * cp) * dt

	impact = maxf(0.0, impact - dt * 2.0)
	_collide_walls()

	# ---- visuals: height, pitch, roll
	if in_pit:
		var li := clampi(int(ps), 0, T.lN - 1)
		y = lerpf(T.ly[li], T.ly[mini(T.lN - 1, li + 1)], ps - li)
	else:
		var off := maxf(0.0, absf(lat) - T.half_w - 2.0)
		y = T.height_at(s) - minf(0.3, off * 0.015)
	pitch += ((-ax * 0.0022) - pitch) * minf(1.0, dt * 8.0)
	roll += ((ay * 0.0028) - roll) * minf(1.0, dt * 8.0)
	grade_pitch = atan(gr)

	# ---- tyres: temperature, wear (pressure: low = hotter & more wear)
	var c := cmp()
	var heat_f := 1.0 - 0.6 * float(setup["press_f"])
	var heat_r := 1.0 - 0.6 * float(setup["press_r"])
	var work_f := (absf(a_f) * absf(fy_f) + absf(fx_f) * 0.02 + (cap_f * 0.1 if lock_f else 0.0)) * ue
	var work_r := (absf(a_r) * absf(fy_r) + absf(fx_r) * 0.006 + (cap_r * 0.1 if (spin_r or lock_r) else 0.0)) * ue
	last_work = Vector2(work_f, work_r)
	# warm-up within about one lap (time constant ~1 min at speed), working window ~85-95 °C
	var cool := 0.0108 * (1.0 + spd * 0.01) * (1.0 + 1.5 * wet)
	# heat input flattens out with a lot of sliding (normal driving ~85 °C, heavy sliding ~100 °C)
	var hf := 0.00106 * work_f / (1.0 + work_f / 1200.0)
	var hr := 0.00095 * work_r / (1.0 + work_r / 1200.0)
	temp_f = clampf(temp_f + (hf * heat_f - (temp_f - 30.0) * cool) * dt, 15.0, 140.0)
	temp_r = clampf(temp_r + (hr * heat_r - (temp_r - 30.0) * cool) * dt, 15.0, 140.0)
	var wm: float = wear_mul * c["wear"] * (1.0 + absf(float(setup["press_f"])))
	var wet_relief := 1.0 - 0.6 * wet if compound == "wet" else 1.0
	wear_f = minf(1.0, wear_f + work_f * 4e-8 * dt * wm * wet_relief)
	wear_r = minf(1.0, wear_r + work_r * 4e-8 * dt * wm * wet_relief)

	# brake pads: heavy braking with a heavy car wears them (a set lasts roughly 6-8 hours)
	pad_wear = minf(1.0, pad_wear + brake * absf(u) * m * 0.8e-11 * dt * 3600.0 * wear_mul / 6.5)

	# ---- fuel
	if engine_on and (gear != 0 or throttle > 0.0):
		fuel = maxf(0.0, fuel - (0.0015 + spec["fuelRate"] * throttle * (rpm / spec["rpmMax"])) * dt * fuel_mul)
	if fuel <= 0.0:
		throttle = 0.0

var wear_mul := 1.0
var fuel_mul := 1.0


func _run_type() -> int:
	return int(T.run_r[idx]) if lat > 0.0 else int(T.run_l[idx])


func shift(d: int) -> void:
	var n := gear + d
	var gears: Array = spec["gears"]
	if n < -1 or n > gears.size():
		return
	if n == -1 and u > 1.0:
		return
	if gear == 0 and n == 1 and throttle > 0.75 and rpm > float(spec["rpmMax"]) * 0.55 and absf(u) < 15.0:
		drift_t = 1.5
	gear = n
	shift_timer = 0.06


func _collide_walls() -> void:
	var i := idx
	var half: float = spec["wid"] * 0.5 + 0.1
	var lim_r: float = T.bar_r[i] - half
	var lim_l: float = -(T.bar_l[i] - half)
	if lat > lim_r:
		_bounce(T.rx[i], T.rz[i], lat - lim_r)
		lat = lim_r
	elif lat < lim_l:
		_bounce(-T.rx[i], -T.rz[i], lim_l - lat)
		lat = lim_l
	# pit lane: concrete pit wall on the track side, garage fronts / armco on the far side
	if near_lane:
		var li := pidx
		var nrx: float = T.lrx[li]
		var nrz: float = T.lrz[li]
		var wl: float = -T.LANE_IN - 0.25
		var lo: float = T.l_out[li]
		# only the lane's real body counts: not its first / last metres where it blends into the track
		var body: bool = ps > 6.0 and ps < T.lL - 6.0
		if body and T.l_wall[li] == 1 and absf(plat - prev_plat) < 1.5:
			if prev_plat >= wl and plat < wl + half and plat > wl - 1.0:
				_bounce(-nrx, -nrz, (wl + half) - plat)
				plat = wl + half
			elif prev_plat < wl and plat > wl - half and plat < wl + 1.0:
				_bounce(nrx, nrz, plat - (wl - half))
				plat = wl - half
		if body and in_pit and prev_plat <= lo and plat > lo - half and plat < lo + 1.0:
			_bounce(nrx, nrz, plat - (lo - half))
			plat = lo - half
	prev_lat = lat
	prev_plat = plat


# moves the car `push` metres away from the obstacle (n points from the car towards it) and bounces
func _bounce(nx: float, nz: float, push: float) -> void:
	x -= nx * push
	z -= nz * push
	var c := cos(psi)
	var sn := sin(psi)
	var vx := u * c - v * sn
	var vz := u * sn + v * c
	var vn := vx * nx + vz * nz
	if vn > 0.0:
		vx -= 1.25 * vn * nx
		vz -= 1.25 * vn * nz
		var fr := maxf(0.55, 1.0 - 0.035 * vn)
		vx *= fr
		vz *= fr
		u = vx * c + vz * sn
		v = -vx * sn + vz * c
		r *= 0.6
		var side := signf(-sn * nx + c * nz)    # obstacle on the car's right (+) or left (-)
		r += -side * signf(u) * minf(1.5, vn * 0.05)
		impact = minf(1.0, impact + vn / 12.0)
		apply_damage(Vector3(nx, 0.0, nz), vn)


# world-space hit direction (pointing from the car towards the obstacle) and impact speed (m/s)
func apply_damage(dir: Vector3, speed: float) -> void:
	if speed < 3.0 or damage_mul <= 0.0:
		return
	var amt := pow(speed - 3.0, 1.3) * 0.011 * damage_mul
	var c := cos(psi)
	var sn := sin(psi)
	var fwd := dir.x * c + dir.z * sn
	var side := -dir.x * sn + dir.z * c
	var zone := ""
	if absf(fwd) > absf(side):
		zone = "front" if fwd > 0.0 else "rear"
	else:
		zone = "right" if side > 0.0 else "left"
	dmg[zone] = minf(1.0, dmg[zone] + amt)
	if zone == "left" or zone == "right":
		var sk := "susp_l" if zone == "left" else "susp_r"
		dmg[sk] = minf(1.0, dmg[sk] + amt * 0.8)
	if zone == "front" and amt > 0.12:
		dmg["engine"] = minf(1.0, dmg["engine"] + (amt - 0.12) * 0.9)
	if zone == "rear" and amt > 0.2:
		dmg["engine"] = minf(1.0, dmg["engine"] + (amt - 0.2) * 0.5)
	if dmg["front"] > 0.35:
		lost["splitter"] = true
	if dmg["rear"] > 0.4:
		lost["wing"] = true
	if dmg["left"] > 0.3:
		lost["mirror_l"] = true
	if dmg["right"] > 0.3:
		lost["mirror_r"] = true
	# a broken suspension can tear the wheel off (front or rear, depending on where the hit came from)
	for sd2 in ["l", "r"]:
		var sk2: String = "susp_" + sd2
		if dmg[sk2] > 0.85 and amt > 0.18 and (zone == ("left" if sd2 == "l" else "right") or zone == ("front" if fwd > 0.0 else "rear")):
			var wk: String = "wheel_" + ("f" if fwd > 0.0 else "r") + sd2
			lost[wk] = true
	if dmg["engine"] >= 1.0:
		retired = true
	hits.append([zone, amt, Vector3(fwd, 0.0, side)])

var damage_mul := 1.0


func repair_time() -> float:
	var t := 0.0
	if lost["splitter"] or dmg["front"] > 0.05:
		t += 12.0 + 20.0 * dmg["front"]
	if lost["wing"] or dmg["rear"] > 0.05:
		t += 15.0 + 22.0 * dmg["rear"]
	for wk in ["wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"]:
		if lost[wk]:
			t += 25.0
	t += 30.0 * (dmg["susp_l"] + dmg["susp_r"]) + 10.0 * (dmg["left"] + dmg["right"])
	t += 60.0 * dmg["engine"]
	return t


func repair() -> void:
	for k in dmg.keys():
		dmg[k] = 0.0
	for k in lost.keys():
		lost[k] = false


func world_vel() -> Vector2:
	return Vector2(u * cos(psi) - v * sin(psi), u * sin(psi) + v * cos(psi))


func set_world_vel(vx: float, vz: float) -> void:
	var c := cos(psi)
	var sn := sin(psi)
	u = vx * c + vz * sn
	v = -vx * sn + vz * c


# car-to-car contacts: three circles per car along its length
# slipstream: right behind a car (up to ~45 m, nearly in line) the air is already moving -> less drag
static func update_draft(cars: Array, track_len: float, dt: float) -> void:
	for c in cars:
		var best := 0.0
		if not c.in_pit and absf(c.u) > 20.0:
			for o in cars:
				if o == c or o.in_pit or absf(o.u) < 15.0:
					continue
				var gap: float = wrapf(o.s - c.s, -track_len * 0.5, track_len * 0.5)
				if gap < 1.5 or gap > 45.0:
					continue
				var dl: float = absf(o.lat - c.lat)
				if dl > 2.6:
					continue
				best = maxf(best, pow(1.0 - gap / 45.0, 0.7) * (1.0 - dl / 2.6))
		c.draft = lerpf(c.draft, best, minf(1.0, dt * 3.0))


static func collide_cars(cars: Array) -> void:
	var n := cars.size()
	for i in n:
		var A = cars[i]
		for j in range(i + 1, n):
			var B = cars[j]
			if (A.ghost > 0.0 or B.ghost > 0.0) and not A.is_player and not B.is_player:
				continue
			var dx0: float = B.x - A.x
			var dz0: float = B.z - A.z
			if dx0 * dx0 + dz0 * dz0 > 49.0:
				continue
			var ca := Vector2(cos(A.psi), sin(A.psi))
			var cb := Vector2(cos(B.psi), sin(B.psi))
			var off_a: float = A.spec["len"] * 0.29
			var off_b: float = B.spec["len"] * 0.29
			var rad := 1.05
			for ka in [-1, 0, 1]:
				for kb in [-1, 0, 1]:
					var pax: float = A.x + ca.x * off_a * ka
					var paz: float = A.z + ca.y * off_a * ka
					var pbx: float = B.x + cb.x * off_b * kb
					var pbz: float = B.z + cb.y * off_b * kb
					var dx := pbx - pax
					var dz := pbz - paz
					var d := sqrt(dx * dx + dz * dz)
					if d < 2.0 * rad and d > 1e-4:
						var nx := dx / d
						var nz := dz / d
						var pen := 2.0 * rad - d
						A.x -= nx * pen * 0.5
						A.z -= nz * pen * 0.5
						B.x += nx * pen * 0.5
						B.z += nz * pen * 0.5
						var va: Vector2 = A.world_vel()
						var vb: Vector2 = B.world_vel()
						var rel := (vb.x - va.x) * nx + (vb.y - va.y) * nz
						if rel < 0.0:
							var ma: float = A.spec["mass"]
							var mb: float = B.spec["mass"]
							var jimp := -1.3 * rel / (1.0 / ma + 1.0 / mb)
							A.set_world_vel(va.x - jimp / ma * nx, va.y - jimp / ma * nz)
							B.set_world_vel(vb.x + jimp / mb * nx, vb.y + jimp / mb * nz)
							A.r += ka * jimp / ma * 0.09 * (randf() - 0.5)
							B.r += kb * jimp / mb * 0.09 * (randf() - 0.5)
							A.impact = minf(1.0, A.impact + absf(rel) / 15.0)
							B.impact = minf(1.0, B.impact + absf(rel) / 15.0)
							A.apply_damage(Vector3(nx, 0.0, nz), absf(rel) * 0.8)
							if A.is_player or B.is_player:
								contacts.append([A, B, absf(rel)])
							B.apply_damage(Vector3(-nx, 0.0, -nz), absf(rel) * 0.8)

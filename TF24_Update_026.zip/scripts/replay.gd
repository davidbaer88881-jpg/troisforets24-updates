extends RefCounted
# Records every car 20x per second during a race and plays it back (any camera, any car, slow motion).
# Replays can be saved as a file (Downloads/TF24 Replays) and turned into a video by the game itself.

const DT := 0.05
const NF := 14                       # floats per car and frame
const MAX_FRAMES := 36000            # keeps the last 30 minutes (long races)
const LOST_KEYS := ["splitter", "wing", "mirror_l", "mirror_r", "wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"]
const MAGIC := "TF24REPLAY1"

var frames: Array = []               # one PackedFloat32Array per car
var meta := PackedFloat32Array()     # per frame: hour, wet
var count := 0
var t0 := 0.0                        # race time of the first stored frame
var grid: Array = []                 # per car: {"cls", "team", "name", "player"}
var track := ""
var info := {}                       # track name, date, result line
var _acc := 0.0


func begin(cars: Array, track_key: String) -> void:
	frames.clear()
	meta = PackedFloat32Array()
	count = 0
	t0 = 0.0
	_acc = 0.0
	track = track_key
	grid.clear()
	for c in cars:
		frames.append(PackedFloat32Array())
		grid.append({"cls": String(c.spec["key"]), "team": c.get_meta("team", []), "name": String(c.name), "player": bool(c.is_player), "num": int(c.num)})
	info = {"date": Time.get_datetime_string_from_system(false, true)}


func has_data() -> bool:
	return count > 20


func length() -> float:
	return maxf(0.0, (count - 1) * DT)


func record(cars: Array, dt: float, race_time: float, hour: float, wet: float) -> void:
	if frames.size() != cars.size():
		return
	_acc += dt
	if _acc < DT - 1e-4:
		return
	_acc -= DT
	if count == 0:
		t0 = race_time
	for k in cars.size():
		var c = cars[k]
		var mask := 0
		for b in LOST_KEYS.size():
			if c.lost.get(LOST_KEYS[b], false):
				mask |= 1 << b
		var f: PackedFloat32Array = frames[k]
		f.append_array(PackedFloat32Array([c.x, c.y, c.z, c.psi, c.u, c.v, c.steer, c.pitch, c.roll, c.heave, c.brake, c.rpm, float(c.gear), float(mask)]))
		frames[k] = f
	meta.append(hour)
	meta.append(wet)
	count += 1
	if count >= int(MAX_FRAMES * 1.25):
		var drop := count - MAX_FRAMES
		for k in frames.size():
			var f2: PackedFloat32Array = frames[k]
			frames[k] = f2.slice(drop * NF)
		meta = meta.slice(drop * 2)
		count -= drop
		t0 += drop * DT


# writes the interpolated state at replay time t into the car objects; returns [hour, wet]
func apply(cars: Array, t: float) -> Vector2:
	if count < 2:
		return Vector2.ZERO
	var fi := clampf(t / DT, 0.0, float(count - 1) - 0.001)
	var i0 := int(fi)
	var a := fi - float(i0)
	var n := mini(cars.size(), frames.size())
	for k in n:
		var c = cars[k]
		var f: PackedFloat32Array = frames[k]
		var o0 := i0 * NF
		var o1 := o0 + NF
		c.x = lerpf(f[o0], f[o1], a)
		c.y = lerpf(f[o0 + 1], f[o1 + 1], a)
		c.z = lerpf(f[o0 + 2], f[o1 + 2], a)
		c.psi = lerp_angle(f[o0 + 3], f[o1 + 3], a)
		c.u = lerpf(f[o0 + 4], f[o1 + 4], a)
		c.v = lerpf(f[o0 + 5], f[o1 + 5], a)
		c.steer = lerpf(f[o0 + 6], f[o1 + 6], a)
		c.pitch = lerpf(f[o0 + 7], f[o1 + 7], a)
		c.roll = lerpf(f[o0 + 8], f[o1 + 8], a)
		c.heave = lerpf(f[o0 + 9], f[o1 + 9], a)
		c.brake = f[o0 + 10]
		c.rpm = lerpf(f[o0 + 11], f[o1 + 11], a)
		c.gear = int(f[o0 + 12])
		c.r = 0.0
		c.lock_f = false
		c.lock_r = false
		c.spin_r = false
		var mask := int(f[o0 + 13])
		for b in LOST_KEYS.size():
			c.lost[LOST_KEYS[b]] = (mask >> b) & 1 == 1
	return Vector2(lerpf(meta[i0 * 2], meta[i0 * 2 + 2], a), meta[i0 * 2 + 1])


# ------------------------------------------------------------------ files
static func folder() -> String:
	var d := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if d == "":
		d = OS.get_user_data_dir()
	return d.path_join("TF24 Replays")


func save_file() -> String:
	DirAccess.make_dir_recursive_absolute(folder())
	var stamp := Time.get_datetime_string_from_system(false, true).replace(":", "-").replace(" ", "_")
	var path := folder().path_join("TF24_%s_%s.tf24replay" % [track, stamp])
	var fa := FileAccess.open_compressed(path, FileAccess.WRITE, FileAccess.COMPRESSION_ZSTD)
	if fa == null:
		return ""
	fa.store_pascal_string(MAGIC)
	fa.store_var({"track": track, "grid": grid, "info": info, "count": count, "t0": t0, "meta": meta, "frames": frames})
	fa.close()
	return path


func load_file(path: String) -> bool:
	var fa := FileAccess.open_compressed(path, FileAccess.READ, FileAccess.COMPRESSION_ZSTD)
	if fa == null or fa.get_pascal_string() != MAGIC:
		return false
	var d = fa.get_var()
	fa.close()
	if not (d is Dictionary) or not d.has("frames"):
		return false
	track = String(d["track"])
	grid = d["grid"]
	info = d.get("info", {})
	count = int(d["count"])
	t0 = float(d.get("t0", 0.0))
	meta = d["meta"]
	frames = d["frames"]
	return count > 1 and frames.size() == grid.size()

# Procedural people: pit crew in work overalls (face, cap, headset, gloves, safety shoes) and racing
# drivers (race suit, helmet with visor, HANS, gloves, boots). The body is made of smooth lofted parts on
# a joint hierarchy, so the same skeleton can walk, kneel, carry tyres or sit in the car:
#   root - hips - torso - head / sh_l, sh_r - el_l, el_r ;  hips - th_l, th_r - kn_l, kn_r
# Colours come from vertex colours (suit pattern, stripes), so one figure needs only a few materials.
# Meshes are cached per look, many crew members share them.
extends RefCounted

const SEG := 16
static var _cache := {}
static var _mats := {}


# look: {"suit": Color, "accent": Color, "stripe": Color, "skin": Color, "hair": Color,
#        "helmet": Color, "helmet2": Color, "visor": "dark"/"gold"/"blue"/"clear", "pattern": "stripes"/"split"/"chevron"}
static func build(kind: String, look: Dictionary) -> Node3D:
	var key := kind + str(look)
	if not _cache.has(key):
		_cache[key] = _make_meshes(kind, look)
		if _cache.size() > 64:
			_cache.erase(_cache.keys()[0])
	var m: Dictionary = _cache[key]
	var p := Node3D.new()
	var j := {}
	var hips := _joint(p, "hips", Vector3(0, 0.95, 0), j)
	_mi(hips, m["hips"])
	var torso := _joint(hips, "torso", Vector3(0, 0.08, 0), j)
	_mi(torso, m["torso"])
	var head := _joint(torso, "head", Vector3(0, 0.66, 0), j)
	_mi(head, m["head"])
	for side in [-1.0, 1.0]:
		var nm := "l" if side < 0.0 else "r"
		var sh := _joint(torso, "sh_" + nm, Vector3(side * 0.205, 0.5, 0), j)
		_mi(sh, m["upper_" + nm])
		var el := _joint(sh, "el_" + nm, Vector3(0, -0.29, 0), j)
		_mi(el, m["fore_" + nm])
		var th := _joint(hips, "th_" + nm, Vector3(side * 0.095, -0.05, 0), j)
		_mi(th, m["thigh_" + nm])
		var kn := _joint(th, "kn_" + nm, Vector3(0, -0.44, 0), j)
		_mi(kn, m["shin_" + nm])
	p.set_meta("j", j)
	return p


static func _joint(parent: Node3D, nm: String, pos: Vector3, j: Dictionary) -> Node3D:
	var n := Node3D.new()
	n.name = nm
	n.position = pos
	parent.add_child(n)
	j[nm] = n
	return n


static func _mi(parent: Node3D, mesh: Mesh) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	parent.add_child(mi)


# ---------------------------------------------------------------- materials
static func _vc_mat(rough: float, metal: float = 0.0) -> StandardMaterial3D:
	var k := "vc%.2f_%.2f" % [rough, metal]
	if not _mats.has(k):
		var m := StandardMaterial3D.new()
		m.vertex_color_use_as_albedo = true
		m.roughness = rough
		m.metallic = metal
		_mats[k] = m
	return _mats[k]


static func _skin_mat(c: Color) -> StandardMaterial3D:
	var k := "skin" + c.to_html()
	if not _mats.has(k):
		var m := StandardMaterial3D.new()
		m.vertex_color_use_as_albedo = true
		m.roughness = 0.55
		m.rim_enabled = true
		m.rim = 0.25
		m.rim_tint = 0.6
		_mats[k] = m
	return _mats[k]


static func _visor_mat(kind: String) -> StandardMaterial3D:
	var k := "visor_" + kind
	if not _mats.has(k):
		var m := StandardMaterial3D.new()
		m.roughness = 0.04
		m.metallic = 0.9
		m.albedo_color = {"dark": Color(0.03, 0.035, 0.045), "gold": Color(0.85, 0.6, 0.15), "blue": Color(0.15, 0.4, 0.95), "clear": Color(0.25, 0.27, 0.3)}.get(kind, Color(0.03, 0.035, 0.045))
		if kind == "gold" or kind == "blue":
			m.metallic_specular = 1.0
		_mats[k] = m
	return _mats[k]


# ---------------------------------------------------------------- loft
# rings: [y, rx, rz, ox, oz]; col: Callable(y, angle) -> Color; the part runs along local Y
static func _loft(st: SurfaceTool, rings: Array, col: Callable, xf := Transform3D.IDENTITY, cap_a := true, cap_b := true) -> void:
	var pts: Array = []
	for rg in rings:
		var ring: Array = []
		var y: float = rg[0]
		for k in SEG + 1:
			var a := TAU * k / SEG
			ring.append(Vector3(sin(a) * float(rg[1]) + float(rg[3]), y, cos(a) * float(rg[2]) + float(rg[4])))
		pts.append(ring)
	var nb := xf.basis.inverse().transposed()
	var nrm_at := func(ri: int, ang: float) -> Vector3:
		var rg2: Array = rings[ri]
		var n0 := Vector3(sin(ang) / maxf(0.001, float(rg2[1])), 0.0, cos(ang) / maxf(0.001, float(rg2[2]))).normalized()
		var rp: Array = rings[maxi(0, ri - 1)]
		var rn: Array = rings[mini(rings.size() - 1, ri + 1)]
		var dy: float = float(rn[0]) - float(rp[0])
		if absf(dy) > 1e-5:
			var dr := ((float(rn[1]) + float(rn[2])) - (float(rp[1]) + float(rp[2]))) * 0.5
			n0 = (n0 + Vector3(0, -dr / dy, 0)).normalized()
		return n0
	for r in rings.size() - 1:
		var A: Array = pts[r]
		var B: Array = pts[r + 1]
		var cy: float = (float(rings[r][0]) + float(rings[r + 1][0])) * 0.5
		for k in SEG:
			var a0 := TAU * k / SEG
			var a1 := TAU * (k + 1) / SEG
			var colr: Color = col.call(cy, (a0 + a1) * 0.5)
			var n00: Vector3 = nb * nrm_at.call(r, a0)
			var n01: Vector3 = nb * nrm_at.call(r, a1)
			var n10: Vector3 = nb * nrm_at.call(r + 1, a0)
			var n11: Vector3 = nb * nrm_at.call(r + 1, a1)
			_tri(st, xf * (A[k] as Vector3), xf * (B[k] as Vector3), xf * (A[k + 1] as Vector3), n00, n10, n01, colr)
			_tri(st, xf * (A[k + 1] as Vector3), xf * (B[k] as Vector3), xf * (B[k + 1] as Vector3), n01, n10, n11, colr)
	for end in [0, rings.size() - 1]:
		if (end == 0 and not cap_a) or (end != 0 and not cap_b):
			continue
		var rg3: Array = rings[end]
		var c := xf * Vector3(float(rg3[3]), float(rg3[0]), float(rg3[4]))
		var ring2: Array = pts[end]
		var other: Array = rings[1 if end == 0 else end - 1]
		var up := signf(float(rg3[0]) - float(other[0]))
		var cn: Vector3 = (nb * Vector3(0, up, 0)).normalized()
		var ccol: Color = col.call(float(rg3[0]), 0.0)
		for k in SEG:
			_tri(st, c, xf * (ring2[k] as Vector3), xf * (ring2[k + 1] as Vector3), cn, cn, cn, ccol)


# one triangle; the winding is fixed so the side the normals point to is the front (Godot: clockwise)
static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3, col: Color) -> void:
	if (b - a).cross(c - a).dot(na + nb + nc) > 0.0:
		var t := b
		b = c
		c = t
		var tn := nb
		nb = nc
		nc = tn
	st.set_color(col)
	st.set_normal(na.normalized())
	st.add_vertex(a)
	st.set_normal(nb.normalized())
	st.add_vertex(b)
	st.set_normal(nc.normalized())
	st.add_vertex(c)


# deformed sphere: f(dir) -> radius vector scale; col(dir) -> colour
static func _blob(st: SurfaceTool, center: Vector3, radii: Vector3, shape: Callable, col: Callable, rings := 14, segs := 18, keep := Callable()) -> void:
	var grid: Array = []
	for i in rings + 1:
		var th := PI * i / rings
		var row: Array = []
		for k in segs + 1:
			var ph := TAU * k / segs
			var d := Vector3(sin(th) * sin(ph), cos(th), sin(th) * cos(ph))
			var r: Vector3 = radii * float(shape.call(d))
			row.append([center + Vector3(d.x * r.x, d.y * r.y, d.z * r.z), d])
		grid.append(row)
	for i in rings:
		for k in segs:
			var dm: Vector3 = ((grid[i][k][1] as Vector3) + (grid[i + 1][k + 1][1] as Vector3)).normalized()
			if keep.is_valid() and not keep.call(dm):
				continue
			var colr: Color = col.call(dm)
			var e00: Array = grid[i][k]
			var e10: Array = grid[i + 1][k]
			var e01: Array = grid[i][k + 1]
			var e11: Array = grid[i + 1][k + 1]
			var nf := func(d2: Vector3) -> Vector3: return Vector3(d2.x / radii.x, d2.y / radii.y, d2.z / radii.z).normalized()
			_tri(st, e00[0], e10[0], e01[0], nf.call(e00[1]), nf.call(e10[1]), nf.call(e01[1]), colr)
			_tri(st, e01[0], e10[0], e11[0], nf.call(e01[1]), nf.call(e10[1]), nf.call(e11[1]), colr)


static func _commit(st: SurfaceTool, mat: Material) -> ArrayMesh:
	var m := st.commit()
	if m.get_surface_count() > 0:
		m.surface_set_material(0, mat)
	return m


static func _begin() -> SurfaceTool:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	return st


# ---------------------------------------------------------------- the figure
static func _make_meshes(kind: String, lk: Dictionary) -> Dictionary:
	var driver := kind == "driver"
	var suit: Color = lk.get("suit", Color(0.1, 0.25, 0.7))
	var acc: Color = lk.get("accent", suit.darkened(0.45))
	var stripe: Color = lk.get("stripe", Color(0.95, 0.95, 0.95))
	var skin: Color = lk.get("skin", Color(0.86, 0.66, 0.52))
	var hair: Color = lk.get("hair", Color(0.18, 0.12, 0.08))
	var pattern: String = lk.get("pattern", "stripes")
	var glove := Color(0.07, 0.07, 0.08) if not driver else acc
	var shoe := Color(0.06, 0.06, 0.065) if not driver else acc.darkened(0.3)
	var reflect := Color(0.8, 0.82, 0.85)
	var cloth := _vc_mat(0.78)
	var out := {}

	# --- suit colouring (y = height in the part, a = angle around it, 0 = front)
	var torso_col := func(y: float, a: float) -> Color:
		var front := cos(a)
		var side := absf(sin(a))
		if driver:
			match pattern:
				"split":
					if y > 0.28:
						return acc
				"chevron":
					if absf(y - (0.32 - absf(sin(a)) * 0.12)) < 0.045 and front > 0.0:
						return stripe
				_:
					if side > 0.93:
						return stripe
			if y > 0.3 and y < 0.37 and front < -0.2:
				return stripe          # band across the back
			if y < 0.06:
				return acc             # waist band
			return suit
		# crew overall: reflective band across chest and back, side stripes, darker shoulder yoke
		if y > 0.33 and y < 0.385:
			return reflect
		if side > 0.95 and y < 0.3:
			return reflect
		if y > 0.47:
			return acc
		if front > 0.85 and absf(sin(a)) < 0.04:
			return acc                 # zip
		return suit
	var hips_col := func(y: float, a: float) -> Color:
		if y > 0.02 and y < 0.085:
			return Color(0.05, 0.05, 0.06) if not driver else acc     # belt
		return suit if driver else suit.darkened(0.08)
	var arm_col := func(y: float, a: float) -> Color:
		if not driver and y < -0.06 and y > -0.1:
			return reflect
		if driver and absf(sin(a)) > 0.92 and cos(a) < 0.0:
			return stripe
		return suit
	var fore_col := func(y: float, a: float) -> Color:
		if y < -0.215:
			return glove
		if y < -0.19:
			return acc
		return suit
	var thigh_col := func(y: float, a: float) -> Color:
		if driver and absf(sin(a)) > 0.93:
			return stripe
		if not driver and absf(sin(a)) > 0.95:
			return reflect
		return suit if driver else suit.darkened(0.08)
	var shin_col := func(y: float, a: float) -> Color:
		if y < -0.35:
			return shoe
		if not driver and y > -0.1 and y < 0.02 and cos(a) > 0.3:
			return Color(0.1, 0.1, 0.12)                                # knee pad
		if driver and absf(sin(a)) > 0.93:
			return stripe
		return suit if driver else suit.darkened(0.08)

	# --- hips / pelvis
	var st := _begin()
	_loft(st, [[-0.13, 0.13, 0.1, 0, 0], [-0.07, 0.165, 0.112, 0, 0.005], [0.0, 0.172, 0.115, 0, 0.005], [0.06, 0.162, 0.11, 0, 0.005], [0.11, 0.152, 0.105, 0, 0.005]], hips_col)
	out["hips"] = _commit(st, cloth)

	# --- torso (waist to shoulders) and neck
	st = _begin()
	_loft(st, [[0.0, 0.148, 0.104, 0, 0.005], [0.1, 0.146, 0.1, 0, 0.008], [0.22, 0.162, 0.11, 0, 0.014], [0.33, 0.178, 0.12, 0, 0.018],
			[0.385, 0.184, 0.12, 0, 0.016], [0.45, 0.188, 0.112, 0, 0.01], [0.5, 0.19, 0.1, 0, 0.0], [0.545, 0.165, 0.085, 0, -0.005],
			[0.575, 0.1, 0.07, 0, -0.005], [0.59, 0.068, 0.062, 0, 0.0]], torso_col, Transform3D.IDENTITY, true, false)
	# shoulder caps (deltoids) so the arm joins smoothly
	for sx in [-1.0, 1.0]:
		_blob(st, Vector3(sx * 0.185, 0.49, 0.0), Vector3(0.066, 0.058, 0.064), func(_d): return 1.0, func(_d): return torso_col.call(0.52, PI / 2), 8, 12)
	var neck_col := func(y: float, _a: float) -> Color:
		if driver:
			return acc if y < 0.665 else skin
		return acc if y < 0.62 else skin
	_loft(st, [[0.575, 0.06, 0.058, 0, 0.0], [0.62, 0.055, 0.053, 0, 0.008], [0.68, 0.052, 0.05, 0, 0.012]], neck_col, Transform3D.IDENTITY, false, false)
	if driver:
		# HANS device: carbon yoke over the shoulders with the collar behind the head
		var carbon := Color(0.07, 0.07, 0.08)
		for sx in [-1.0, 1.0]:
			_blob(st, Vector3(sx * 0.085, 0.575, 0.0), Vector3(0.075, 0.02, 0.12), func(_d): return 1.0, func(_d): return carbon, 6, 10)
		_blob(st, Vector3(0, 0.64, -0.075), Vector3(0.07, 0.07, 0.025), func(_d): return 1.0, func(_d): return carbon, 6, 10)
	else:
		_loft(st, [[0.555, 0.11, 0.09, 0, -0.004], [0.63, 0.07, 0.066, 0, 0.004]], func(_y, _a): return acc, Transform3D.IDENTITY, false, false)   # collar
	out["torso"] = _commit(st, cloth)

	# --- head
	out["head"] = _head(driver, lk, skin, hair)

	# --- arms
	for side in [-1.0, 1.0]:
		var nm := "l" if side < 0.0 else "r"
		st = _begin()
		_loft(st, [[0.03, 0.05, 0.055, 0, 0], [-0.03, 0.06, 0.062, 0, 0], [-0.12, 0.054, 0.056, 0, 0], [-0.22, 0.046, 0.05, 0, 0], [-0.3, 0.043, 0.046, 0, 0]], arm_col)
		out["upper_" + nm] = _commit(st, cloth)
		st = _begin()
		_loft(st, [[0.02, 0.043, 0.046, 0, 0], [-0.04, 0.047, 0.05, 0, 0.004], [-0.1, 0.045, 0.047, 0, 0.004], [-0.19, 0.036, 0.04, 0, 0], [-0.2, 0.04, 0.043, 0, 0], [-0.235, 0.038, 0.042, 0, 0], [-0.25, 0.032, 0.03, 0, 0]], fore_col)
		_hand(st, glove, side)
		out["fore_" + nm] = _commit(st, cloth)
		st = _begin()
		_loft(st, [[0.06, 0.08, 0.085, 0, 0], [-0.02, 0.09, 0.095, 0, 0.005], [-0.15, 0.08, 0.085, 0, 0.008], [-0.3, 0.066, 0.07, 0, 0.004], [-0.44, 0.055, 0.06, 0, 0]], thigh_col)
		out["thigh_" + nm] = _commit(st, cloth)
		st = _begin()
		_loft(st, [[0.02, 0.054, 0.058, 0, 0], [-0.06, 0.056, 0.064, 0, -0.012], [-0.16, 0.052, 0.058, 0, -0.01], [-0.3, 0.042, 0.045, 0, 0], [-0.37, 0.04, 0.042, 0, 0], [-0.39, 0.05, 0.055, 0, 0.005]], shin_col)
		_shoe(st, shoe, driver)
		out["shin_" + nm] = _commit(st, cloth)
	return out


# glove: palm, four fingers slightly curled and a thumb (hand hangs along -Y, palm facing inwards)
static func _hand(st: SurfaceTool, glove: Color, side: float) -> void:
	var c := func(_y, _a): return glove
	_loft(st, [[-0.245, 0.03, 0.022, 0, 0.004], [-0.28, 0.045, 0.02, 0, 0.008], [-0.33, 0.045, 0.019, 0, 0.012]], c)
	for f in 4:
		var x := -0.032 + f * 0.0215
		var len: float = [0.065, 0.075, 0.072, 0.058][f]
		var xf := Transform3D(Basis(Vector3.RIGHT, -0.35), Vector3(x, -0.325, 0.012))
		_loft(st, [[0.0, 0.0095, 0.0095, 0, 0], [-len * 0.5, 0.0088, 0.0088, 0, 0], [-len, 0.0075, 0.0075, 0, 0]], c, xf)
	var tx := Transform3D(Basis(Vector3.FORWARD, side * -0.6) * Basis(Vector3.RIGHT, -0.5), Vector3(-side * 0.04, -0.27, 0.018))
	_loft(st, [[0.0, 0.011, 0.011, 0, 0], [-0.03, 0.01, 0.01, 0, 0], [-0.055, 0.0085, 0.0085, 0, 0]], c, tx)


# shoe / race boot in the shin frame (ankle at y -0.4), toe pointing +Z
static func _shoe(st: SurfaceTool, col: Color, driver: bool) -> void:
	var c := func(_y, _a): return col
	var sole := func(_y, _a): return Color(0.85, 0.08, 0.06) if not driver else Color(0.08, 0.08, 0.08)
	var xf := Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(0, -0.425, -0.05))
	# lofted along +Z (the local Y of the loft becomes the foot's length)
	_loft(st, [[0.0, 0.045, 0.04, 0, 0.0], [0.05, 0.05, 0.045, 0, 0.005], [0.14, 0.052, 0.035, 0, 0.015], [0.2, 0.045, 0.026, 0, 0.022], [0.235, 0.028, 0.018, 0, 0.02]], c, xf)
	var xs := Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(0, -0.465, -0.05))
	_loft(st, [[-0.01, 0.048, 0.012, 0, 0.0], [0.12, 0.056, 0.012, 0, 0.0], [0.24, 0.035, 0.01, 0, 0.0]], sole, xs)


# ---------------------------------------------------------------- head: face or helmet
static func _head(driver: bool, lk: Dictionary, skin: Color, hair: Color) -> ArrayMesh:
	var st := _begin()
	var C := Vector3(0, 0.1, 0.008)
	if driver:
		_helmet(st, lk, C)
		var m := st.commit()
		m.surface_set_material(0, _vc_mat(0.18, 0.15))
		# visor as a separate surface (glossy, tinted)
		var sv := _begin()
		var R := Vector3(0.132, 0.142, 0.15)
		_blob(sv, C + Vector3(0, 0, 0.004), R * 1.012, func(_d): return 1.0, func(_d): return Color.WHITE, 16, 24,
				func(d: Vector3): return d.z > 0.45 and d.y > -0.14 and d.y < 0.36 and absf(d.x) < 0.82)
		sv.commit(m)
		m.surface_set_material(1, _visor_mat(String(lk.get("visor", "dark"))))
		return m
	# face: an egg with a narrower jaw, cheekbones, brow, nose and chin
	var shape := func(d: Vector3) -> float:
		var r := 1.0
		if d.y < 0.0:
			r -= 0.13 * (-d.y) * absf(d.x)                         # jaw narrows
		r += 0.05 * exp(-pow((d.y - 0.18) / 0.12, 2.0)) * maxf(0.0, d.z) # brow ridge
		r += 0.11 * exp(-(pow(d.x / 0.13, 2.0) + pow((d.y + 0.08) / 0.16, 2.0))) * maxf(0.0, d.z)   # nose
		r += 0.035 * exp(-(pow(d.x / 0.25, 2.0) + pow((d.y + 0.55) / 0.15, 2.0))) * maxf(0.0, d.z)  # chin
		r -= 0.035 * exp(-(pow((absf(d.x) - 0.36) / 0.13, 2.0) + pow((d.y - 0.07) / 0.1, 2.0))) * maxf(0.0, d.z)  # eye sockets
		return r
	var face_col := func(d: Vector3) -> Color:
		var c := skin
		if d.z > 0.6 and absf(d.x) < 0.16 and d.y < -0.3 and d.y > -0.36:
			c = skin.darkened(0.35).lerp(Color(0.6, 0.25, 0.25), 0.4)         # lips
		elif d.z > 0.3 and absf(d.x) > 0.6:
			c = skin.darkened(0.04)
		return c
	_blob(st, C, Vector3(0.082, 0.112, 0.1), shape, face_col, 18, 24)
	# hair: a shell over the top and the back
	var hair_keep := func(d: Vector3) -> bool:
		return d.y > 0.28 - maxf(0.0, -d.z) * 0.75 and not (d.z > 0.55 and d.y < 0.62)
	_blob(st, C + Vector3(0, 0.004, -0.004), Vector3(0.083, 0.114, 0.1), func(_d): return 1.0, func(_d): return hair, 12, 18, hair_keep)
	# eyes, eyebrows, ears
	for sx in [-1.0, 1.0]:
		_blob(st, C + Vector3(sx * 0.031, 0.014, 0.08), Vector3(0.014, 0.011, 0.008), func(_d): return 1.0,
				func(d: Vector3): return Color(0.08, 0.12, 0.18) if (d.z > 0.7 and absf(d.x) < 0.5) else Color(0.95, 0.94, 0.92), 6, 10)
		_blob(st, C + Vector3(sx * 0.031, 0.03, 0.083), Vector3(0.018, 0.004, 0.006), func(_d): return 1.0, func(_d): return hair.darkened(0.2), 4, 6)
		_blob(st, C + Vector3(sx * 0.079, 0.0, -0.004), Vector3(0.011, 0.026, 0.018), func(_d): return 1.0, func(_d): return skin.darkened(0.08), 6, 8)
	# cap with peak and headset (crew)
	var cap_c: Color = lk.get("accent", Color(0.1, 0.1, 0.12))
	_blob(st, C + Vector3(0, 0.035, -0.004), Vector3(0.088, 0.088, 0.103), func(_d): return 1.0, func(_d): return cap_c, 10, 18,
			func(d: Vector3): return d.y > 0.42)
	var peak := Transform3D(Basis(Vector3.RIGHT, PI / 2 + 0.12), C + Vector3(0, 0.08, 0.07))
	_loft(st, [[0.0, 0.07, 0.006, 0, 0], [0.07, 0.065, 0.004, 0, 0]], func(_y, _a): return cap_c, peak)
	var dark := Color(0.06, 0.06, 0.07)
	for sx in [-1.0, 1.0]:
		_blob(st, C + Vector3(sx * 0.09, 0.0, 0.0), Vector3(0.022, 0.038, 0.038), func(_d): return 1.0, func(_d): return dark, 6, 10)
	# headset band: an arc over the cap from ear to ear
	for k in 9:
		var ang := PI * (k + 0.5) / 9.0
		_blob(st, C + Vector3(cos(ang) * 0.094, sin(ang) * 0.105 + 0.005, -0.01), Vector3(0.012, 0.012, 0.014), func(_d): return 1.0, func(_d): return dark, 4, 6)
	var mic := Transform3D(Basis(Vector3.UP, 0.0) * Basis(Vector3.RIGHT, PI / 2 - 0.3), C + Vector3(0.088, -0.01, 0.02))
	_loft(st, [[0.0, 0.004, 0.004, 0, 0], [0.075, 0.004, 0.004, -0.04, 0]], func(_y, _a): return dark, mic)
	var m2 := st.commit()
	m2.surface_set_material(0, _skin_mat(skin))
	return m2


# modern full-face helmet: shell with chin bar, top air intake, rear spoiler and the paint design
static func _helmet(st: SurfaceTool, lk: Dictionary, C: Vector3) -> void:
	var base: Color = lk.get("helmet", Color(0.95, 0.95, 0.95))
	var c2: Color = lk.get("helmet2", Color(0.85, 0.1, 0.1))
	var c3: Color = lk.get("stripe", Color(0.1, 0.1, 0.12))
	var pattern: String = lk.get("pattern", "stripes")
	var R := Vector3(0.132, 0.142, 0.15)
	var shape := func(d: Vector3) -> float:
		var r := 1.0
		if d.y < -0.3:
			r -= 0.06 * (-d.y - 0.3) * (1.0 - maxf(0.0, d.z))        # tapers towards the neck at the back
		if d.z > 0.0 and d.y < -0.2:
			r += 0.05 * d.z                                            # chin bar sticks out
		return r
	var paint := func(d: Vector3) -> Color:
		if d.y < -0.82:
			return Color(0.05, 0.05, 0.06)                             # neck seal
		match pattern:
			"split":
				if d.y > 0.25:
					return c2
			"chevron":
				if absf(d.y - 0.35 + absf(d.x) * 0.5) < 0.12 and d.z > -0.3:
					return c2
			_:
				if absf(d.x) < 0.13 and d.y > -0.1:
					return c2                                          # centre stripe over the top
				if absf(d.x) < 0.2 and d.y > -0.1:
					return c3
		if d.y < -0.35 and d.z > 0.3:
			return c3                                                  # chin bar accent
		return base
	_blob(st, C, R, shape, paint, 16, 24)
	# top air intake and rear spoiler
	_blob(st, C + Vector3(0, 0.138, 0.06), Vector3(0.03, 0.014, 0.05), func(_d): return 1.0, func(_d): return Color(0.06, 0.06, 0.07), 6, 8)
	var sp := Transform3D(Basis(Vector3.FORWARD, PI / 2) * Basis(Vector3.UP, 0.0), C + Vector3(0, 0.1, -0.148))
	_loft(st, [[-0.085, 0.012, 0.03, 0, 0], [0.085, 0.012, 0.03, 0, 0]], func(_y, _a): return c3, sp)
	# visor seal and pivot screws
	for sx in [-1.0, 1.0]:
		_blob(st, C + Vector3(sx * 0.128, 0.03, 0.04), Vector3(0.008, 0.022, 0.022), func(_d): return 1.0, func(_d): return c3, 4, 8)


# driver look from the profile ({"suit": "121a33", ...} as html colours) with defaults
static func driver_look(d: Dictionary) -> Dictionary:
	var c := func(k: String, def: String) -> Color: return Color.html(String(d.get(k, def)))
	return {"suit": c.call("suit", "121a33"), "accent": c.call("accent", "f2bf0d"), "stripe": c.call("stripe", "f2f2f2"),
		"helmet": c.call("helmet", "f2f2f2"), "helmet2": c.call("helmet2", "d61a1a"), "skin": c.call("skin", "edc2a3"),
		"visor": String(d.get("visor", "dark")), "pattern": String(d.get("pattern", "stripes"))}


# sitting pose for the car seat: legs forward to the pedals, hands at the wheel (steer -1..1 turns the arms)
static func sit(fig: Node3D, steer: float) -> void:
	var j: Dictionary = fig.get_meta("j")
	(j["hips"] as Node3D).position.y = 0.0
	(j["hips"] as Node3D).rotation.x = -0.55               # reclined seat
	(j["torso"] as Node3D).rotation.x = 0.05
	(j["head"] as Node3D).rotation.x = 0.42                 # looks ahead despite the recline
	for side in ["l", "r"]:
		var sg := -1.0 if side == "l" else 1.0
		(j["th_" + side] as Node3D).rotation = Vector3(-1.05, 0.0, sg * 0.05)
		(j["kn_" + side] as Node3D).rotation.x = 0.55
		var wheel := steer * sg * 0.35
		(j["sh_" + side] as Node3D).rotation = Vector3(-0.72 + wheel, 0.0, -sg * 0.3)
		(j["el_" + side] as Node3D).rotation = Vector3(-0.38 - wheel * 0.5, 0.0, sg * 0.2)

# Procedural race car model (nose +X, right side +Z, ground at y = 0) with lights, particles,
# deformable body, detachable parts and an optional GLB override (res://models/hyper.glb / gt3.glb).
extends Node3D

const Gfx = preload("res://scripts/gfx.gd")
const Human = preload("res://scripts/human.gd")

const BODY := {
	"hyper": {
		"body": [[-2.5, 0.92, 0.16, 0.86, 4.0], [-2.25, 0.98, 0.14, 0.92, 4.5], [-1.95, 0.99, 0.30, 0.90, 5.0], [-1.5, 1.0, 0.42, 0.93, 5.0], [-1.05, 0.99, 0.30, 0.87, 5.0], [-0.8, 0.97, 0.11, 0.80, 5.0], [-0.3, 0.90, 0.10, 0.70, 4.5],
			[0.5, 0.88, 0.10, 0.66, 4.5], [1.0, 0.97, 0.11, 0.74, 5.0], [1.15, 0.99, 0.30, 0.79, 5.0], [1.55, 1.0, 0.42, 0.83, 5.0], [1.95, 0.97, 0.30, 0.70, 4.5], [2.25, 0.88, 0.14, 0.48, 3.5], [2.52, 0.62, 0.14, 0.26, 2.6]],
		"cabin": [[-0.9, 0.34, 0.6, 0.98, 2.6], [-0.3, 0.46, 0.6, 1.10, 2.6], [0.4, 0.46, 0.6, 1.06, 2.6], [1.0, 0.36, 0.6, 0.82, 2.6], [1.25, 0.2, 0.6, 0.68, 2.4]],
		"wheelbase": 3.05, "front_axle": 1.55, "track": 0.815, "wheel_r": 0.355, "tire_w": 0.32,
		"wing": Vector3(-2.35, 1.06, 1.95), "fin": true, "len": 5.0, "head": Vector3(2.12, 0.55, 0.66), "tail": Vector2(-2.5, 0.66),
		"eye": Vector3(0.05, 0.98, 0.18),
	},
	# front-engined GT3 coupé: long bonnet, cockpit set well back, wide haunches, fastback, swan-neck wing
	"gt3": {
		"body": [[-2.36, 0.84, 0.24, 0.84, 3.6], [-2.2, 0.97, 0.18, 0.93, 4.5], [-1.85, 1.02, 0.14, 0.96, 5.0], [-1.25, 1.04, 0.12, 0.97, 5.0],
			[-0.75, 1.0, 0.12, 0.93, 5.0], [-0.2, 0.96, 0.12, 0.88, 5.0], [0.45, 0.95, 0.12, 0.85, 5.0], [1.0, 0.97, 0.12, 0.84, 5.0],
			[1.4, 1.03, 0.12, 0.84, 5.0], [1.85, 1.0, 0.13, 0.78, 4.6], [2.15, 0.9, 0.14, 0.64, 3.6], [2.4, 0.66, 0.16, 0.46, 2.6]],
		"cabin": [[-1.95, 0.48, 0.8, 0.94, 2.6], [-1.45, 0.62, 0.8, 1.06, 2.8], [-0.9, 0.7, 0.8, 1.2, 3.0], [-0.35, 0.72, 0.8, 1.24, 3.0],
			[0.15, 0.69, 0.8, 1.1, 2.8], [0.5, 0.6, 0.8, 0.86, 2.6]],
		# axle positions, track and seat measured from the GT3 3D model (models/gt3/gt3.gltf)
		"wheelbase": 2.63, "front_axle": 1.404, "track": 0.86, "wheel_r": 0.35, "tire_w": 0.3,
		"wing": Vector3(-2.22, 1.3, 1.8), "fin": false, "len": 4.65, "head": Vector3(2.08, 0.62, 0.7), "tail": Vector2(-2.17, 0.76),
		"eye": Vector3(-0.62, 1.03, -0.395),
	},
}

var key := "hyper"
var B: Dictionary
var chassis: Node3D
var body_mi: MeshInstance3D
var body_mesh: ArrayMesh
var base_verts := PackedVector3Array()
var cur_verts := PackedVector3Array()
var body_arrays: Array
var paint: StandardMaterial3D
var head_mat: StandardMaterial3D
var tail_mat: StandardMaterial3D
var pos_mat: StandardMaterial3D
var disc_mat: StandardMaterial3D
var spots: Array = []
var wheels: Array = []            # {pivot, spin, tire, front, side}
var parts := {}                   # name -> Array[Node3D]
var part_home := {}               # node -> Transform3D
var smoke: CPUParticles3D
var spray: CPUParticles3D
var dust: CPUParticles3D
var stones: CPUParticles3D
var sparks: CPUParticles3D
var spark_t := 0.0
var jack := 0.0                   # pit jack lift (m)
var glb_used := false
var is_player := false
var team_cols: Array = []
var steer_node: Node3D           # the model's own steering wheel (GLB models only)
var steer_home := Transform3D.IDENTITY
var driver_fig: Node3D           # the driver in the seat (human.gd)
# column axis of the GT3 model's steering wheel (points from the rim towards the dashboard)
# steering column of the GT3 model, measured from the mesh: hub centre at the front, wheel face centre
# behind it -> almost horizontal axis; the wheel turns about this line (no wobble around a wrong pivot)
const GT3_STEER_AXIS := Vector3(1.0, 0.06, 0.0)
const GT3_STEER_PIVOT := Vector3(-0.09, 0.719, -0.3995)
# repaints the model's livery in the team colours: the original artwork's light/dark areas become a
# three-colour scheme, so stripes, panels and sponsor shapes stay visible but every car looks different
const LIVERY_SHADER := """
shader_type spatial;
render_mode cull_disabled;
uniform sampler2D tex : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D nrm : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform bool use_nrm = false;
uniform vec3 uv_scale = vec3(1.0);
uniform vec3 uv_offset = vec3(0.0);
uniform vec3 col_a : source_color;
uniform vec3 col_b : source_color;
uniform vec3 col_c : source_color;
void fragment() {
	vec2 uv = UV * uv_scale.xy + uv_offset.xy;
	vec3 t = texture(tex, uv).rgb;
	float l = dot(t, vec3(0.299, 0.587, 0.114));
	float sat = max(max(t.r, t.g), t.b) - min(min(t.r, t.g), t.b);
	vec3 c = mix(col_a, col_b, smoothstep(0.1, 0.32, l + sat * 0.5));
	c = mix(c, col_c, smoothstep(0.55, 0.85, l));
	ALBEDO = c * (0.75 + 0.5 * l);
	ROUGHNESS = 0.28;
	METALLIC = 0.12;
	SPECULAR = 0.6;
	CLEARCOAT = 0.6;
	CLEARCOAT_ROUGHNESS = 0.1;
	if (use_nrm) {
		NORMAL_MAP = texture(nrm, uv).rgb;
	}
}
"""


func setup(car_key: String, livery: Array, number: int, quality: String, player: bool = false) -> void:
	key = car_key
	is_player = player
	team_cols = livery
	B = BODY[key]
	chassis = Node3D.new()
	add_child(chassis)
	paint = StandardMaterial3D.new()
	paint.albedo_texture = Gfx.livery(livery[0], livery[1], livery[2])
	paint.roughness = 0.3
	paint.metallic = 0.35
	paint.clearcoat_enabled = true
	paint.clearcoat = 1.0
	paint.clearcoat_roughness = 0.05
	var solid := Gfx.mat(livery[0], 0.3, 0.35)
	solid.clearcoat_enabled = true
	var accent := Gfx.mat(livery[1], 0.35, 0.3)
	var carbon := Gfx.mat(Color(0.06, 0.065, 0.075), 0.35, 0.4)
	var glass := Gfx.mat(Color(0.03, 0.045, 0.06), 0.04, 0.2)
	glass.clearcoat_enabled = true
	var res := 26 if quality == "low" else 40
	# --- body
	var data := _loft(B["body"], res)
	body_arrays = data
	base_verts = (data[Mesh.ARRAY_VERTEX] as PackedVector3Array).duplicate()
	cur_verts = base_verts.duplicate()
	body_mesh = ArrayMesh.new()
	body_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, data)
	body_mi = _mi(chassis, body_mesh, paint, Vector3.ZERO)
	var cabin := _loft(B["cabin"], 24)
	var cab_mesh := ArrayMesh.new()
	cab_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, cabin)
	_mi(chassis, cab_mesh, glass, Vector3.ZERO)
	if key == "gt3":
		var roof_tab: Array = []
		var cab: Array = B["cabin"]
		for k in range(1, cab.size() - 1):
			var r: Array = cab[k]
			roof_tab.append([r[0], r[1] * 0.84, r[3] - 0.04, r[3] + 0.02, 3.0])
		var roof := ArrayMesh.new()
		roof.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, _loft(roof_tab, 20))
		_mi(chassis, roof, solid, Vector3.ZERO)
	else:
		# roof air scoop
		_box(chassis, Vector3(0.5, 0.12, 0.26), Vector3(-0.35, 1.13, 0), solid)
	var L: float = B["len"]
	_box(chassis, Vector3(L * 0.9, 0.05, 1.2), Vector3(0, 0.1, 0), carbon)
	if key == "gt3":
		_gt3_details(carbon, solid, accent, glass)
	else:
		_hyper_details(carbon, solid, accent)
	# numbers (white roundels with black numerals)
	var xn := -0.9 if key == "hyper" else -0.15
	var yn := 0.5 if key == "hyper" else 0.54
	for side in [-1.0, 1.0]:
		var disc := CylinderMesh.new()
		disc.top_radius = 0.26
		disc.bottom_radius = 0.26
		disc.height = 0.01
		var d := _mi(chassis, disc, Gfx.mat(Color(0.97, 0.97, 0.97), 0.4), Vector3(xn, yn, side * 1.0))
		d.rotation.x = PI / 2
		var lb := Label3D.new()
		lb.text = str(number)
		lb.font_size = 120
		lb.pixel_size = 0.0028
		lb.modulate = Color(0.05, 0.05, 0.05)
		lb.outline_size = 0
		lb.position = Vector3(xn, yn, side * 1.008)
		lb.rotation.y = 0.0 if side > 0.0 else PI
		lb.shaded = true
		chassis.add_child(lb)
	_lights()
	_wheels(quality)
	_contact_shadow()
	for pname in parts.keys():
		for p in parts[pname]:
			part_home[p] = p.transform
	_particles()
	_try_glb()


func _hyper_details(carbon: Material, solid: Material, accent: Material) -> void:
	var L: float = B["len"]
	parts["splitter"] = [_box(chassis, Vector3(0.55, 0.04, 1.85), Vector3(L / 2 - 0.2, 0.09, 0), carbon)]
	var diff := _box(chassis, Vector3(0.45, 0.16, 1.5), Vector3(-L / 2 + 0.3, 0.2, 0), carbon)
	diff.rotation.z = -0.25
	# --- rear wing assembly
	var W: Vector3 = B["wing"]
	var wing_parts: Array = []
	var wp := _box(chassis, Vector3(0.42, 0.05, W.z), Vector3(W.x, W.y, 0), carbon)
	wp.rotation.z = 0.12
	wing_parts.append(wp)
	var flap := _box(chassis, Vector3(0.2, 0.04, W.z), Vector3(W.x - 0.24, W.y + 0.08, 0), carbon)
	flap.rotation.z = 0.35
	wing_parts.append(flap)
	for zz in [-W.z / 2, W.z / 2]:
		wing_parts.append(_box(chassis, Vector3(0.62, 0.36, 0.03), Vector3(W.x - 0.05, W.y - 0.02, zz), accent))
	for zz in [-0.35, 0.35]:
		_box(chassis, Vector3(0.12, W.y - 0.7, 0.04), Vector3(W.x + 0.1, (W.y + 0.7) / 2, zz), carbon)
	parts["wing"] = wing_parts
	_box(chassis, Vector3(1.7, 0.28, 0.03), Vector3(-1.45, 0.98, 0), solid)
	# dive planes, tow hooks, exhausts
	for zz in [-0.86, 0.86]:
		var dp := _box(chassis, Vector3(0.28, 0.02, 0.16), Vector3(L / 2 - 0.45, 0.36, zz), carbon)
		dp.rotation.z = 0.25
	_box(chassis, Vector3(0.08, 0.05, 0.14), Vector3(L / 2 - 0.05, 0.2, 0.45), Gfx.mat(Color(0.9, 0.1, 0.1), 0.4))
	_box(chassis, Vector3(0.08, 0.05, 0.14), Vector3(-L / 2 + 0.02, 0.26, -0.45), Gfx.mat(Color(1.0, 0.8, 0.0), 0.4))
	for zz in [-0.25, 0.25]:
		var ex := CylinderMesh.new()
		ex.top_radius = 0.045
		ex.bottom_radius = 0.045
		ex.height = 0.2
		var exm := _mi(chassis, ex, Gfx.mat(Color(0.3, 0.28, 0.26), 0.3, 0.9), Vector3(-L / 2 + 0.05, 0.42, zz))
		exm.rotation.z = PI / 2
	var eye: Vector3 = B["eye"]
	parts["mirror_l"] = [_box(chassis, Vector3(0.14, 0.09, 0.2), Vector3(0.95, 0.84, -0.62), solid)]
	parts["mirror_r"] = [_box(chassis, Vector3(0.14, 0.09, 0.2), Vector3(0.95, 0.84, 0.62), solid)]
	var hm := SphereMesh.new()
	hm.radius = 0.14
	hm.height = 0.28
	_mi(chassis, hm, Gfx.mat(Color(0.95, 0.95, 0.95), 0.25), Vector3(eye.x, 0.92, eye.z))


# ---------------------------------------------------------------- GT3 body details
func _gt3_details(carbon: Material, solid: Material, accent: Material, glass: Material) -> void:
	var L: float = B["len"]
	var dark := Gfx.mat(Color(0.03, 0.03, 0.035), 0.55, 0.2)
	var mesh_m := Gfx.mat(Color(0.07, 0.07, 0.08), 0.45, 0.6)
	# front: wide grille with honeycomb mesh, side intakes, big splitter, canards
	_box(chassis, Vector3(0.06, 0.26, 0.86), Vector3(L / 2 + 0.01, 0.33, 0), mesh_m)
	for k in 6:
		_box(chassis, Vector3(0.02, 0.012, 0.84), Vector3(L / 2 + 0.035, 0.22 + k * 0.042, 0), dark)
	for zz in [-0.62, 0.62]:
		_box(chassis, Vector3(0.06, 0.12, 0.3), Vector3(L / 2 - 0.06, 0.23, zz), mesh_m)
	parts["splitter"] = [_box(chassis, Vector3(0.6, 0.035, 2.02), Vector3(L / 2 - 0.12, 0.1, 0), carbon)]
	for zz in [-0.97, 0.97]:
		for k in 2:
			var cn := _box(chassis, Vector3(0.24, 0.015, 0.14), Vector3(L / 2 - 0.3 - k * 0.12, 0.34 + k * 0.1, zz), carbon)
			cn.rotation.z = 0.22
		# front wheel-arch louvres and side sill with exhaust exit in front of the rear wheel
		_box(chassis, Vector3(0.34, 0.02, 0.22), Vector3(1.6, 0.83, zz * 0.82), dark)
		_box(chassis, Vector3(2.0, 0.07, 0.06), Vector3(0.05, 0.16, zz * 1.0), carbon)
		var ex := CylinderMesh.new()
		ex.top_radius = 0.05
		ex.bottom_radius = 0.05
		ex.height = 0.12
		var exm := _mi(chassis, ex, Gfx.mat(Color(0.32, 0.29, 0.27), 0.3, 0.9), Vector3(-0.78, 0.2, zz * 1.0))
		exm.rotation.x = PI / 2
	# bonnet vents with slats
	for zz in [-0.38, 0.38]:
		_box(chassis, Vector3(0.5, 0.012, 0.34), Vector3(1.15, 0.85, zz), dark)
		for k in 5:
			_box(chassis, Vector3(0.025, 0.02, 0.32), Vector3(0.95 + k * 0.1, 0.855, zz), carbon)
	# door mirrors on stalks
	for side in [-1.0, 1.0]:
		var m := _box(chassis, Vector3(0.16, 0.1, 0.22), Vector3(0.36, 1.0, side * 1.0), solid)
		var st := _box(chassis, Vector3(0.05, 0.12, 0.1), Vector3(0.38, 0.93, side * 0.9), carbon)
		parts["mirror_l" if side < 0.0 else "mirror_r"] = [m, st]
		_box(chassis, Vector3(0.01, 0.07, 0.18), Vector3(0.28, 1.0, side * 1.0), glass)
	# roof antenna, rear lip
	_box(chassis, Vector3(0.01, 0.22, 0.01), Vector3(-0.9, 1.31, 0), dark)
	_box(chassis, Vector3(0.08, 0.04, 1.6), Vector3(-2.3, 0.95, 0), carbon)
	# swan-neck rear wing: the plane hangs from two curved stands fixed to the deck
	var W: Vector3 = B["wing"]
	var wing_parts: Array = []
	var wp := _box(chassis, Vector3(0.4, 0.045, W.z), Vector3(W.x, W.y, 0), carbon)
	wp.rotation.z = 0.1
	wing_parts.append(wp)
	var flap := _box(chassis, Vector3(0.17, 0.035, W.z), Vector3(W.x - 0.24, W.y + 0.07, 0), carbon)
	flap.rotation.z = 0.38
	wing_parts.append(flap)
	for zz in [-W.z / 2, W.z / 2]:
		wing_parts.append(_box(chassis, Vector3(0.62, 0.3, 0.025), Vector3(W.x - 0.06, W.y + 0.0, zz), accent))
	for zz in [-0.32, 0.32]:
		_box(chassis, Vector3(0.09, W.y + 0.07 - 0.95, 0.025), Vector3(W.x + 0.22, (W.y + 0.07 + 0.95) / 2, zz), carbon)
		var hook := _box(chassis, Vector3(0.3, 0.045, 0.025), Vector3(W.x + 0.1, W.y + 0.06, zz), carbon)
		hook.rotation.z = -0.15
	parts["wing"] = wing_parts
	# rear: diffuser with vertical fins, tow hook, rain light
	var diff := _box(chassis, Vector3(0.55, 0.14, 1.6), Vector3(-L / 2 + 0.25, 0.2, 0), carbon)
	diff.rotation.z = -0.22
	for k in 5:
		_box(chassis, Vector3(0.5, 0.2, 0.02), Vector3(-L / 2 + 0.24, 0.22, -0.6 + k * 0.3), carbon)
	_box(chassis, Vector3(0.08, 0.05, 0.14), Vector3(L / 2 - 0.02, 0.2, 0.42), Gfx.mat(Color(0.9, 0.1, 0.1), 0.4))
	_box(chassis, Vector3(0.08, 0.05, 0.14), Vector3(-L / 2 + 0.02, 0.3, -0.45), Gfx.mat(Color(1.0, 0.8, 0.0), 0.4))


# ---------------------------------------------------------------- lights, wheels, shadow
func _lights() -> void:
	var carbon := Gfx.mat(Color(0.06, 0.065, 0.075), 0.35, 0.4)
	head_mat = Gfx.emissive(Color(1.0, 0.96, 0.88), 0.4)
	tail_mat = Gfx.emissive(Color(1.0, 0.05, 0.05), 1.0)
	var cls_col := Color(1.0, 0.1, 0.15) if key == "hyper" else Color(1.0, 0.55, 0.05)
	pos_mat = Gfx.emissive(cls_col, 2.0)
	var H: Vector3 = B["head"]
	for side in [-1.0, 1.0]:
		if key == "gt3":
			# slim swept LED headlights with a daytime-running-light brow
			var hl := _box(chassis, Vector3(0.34, 0.07, 0.3), Vector3(H.x, H.y, side * H.z), carbon)
			hl.rotation = Vector3(0, side * 0.35, -0.35)
			var drl := _box(chassis, Vector3(0.3, 0.015, 0.05), Vector3(H.x + 0.02, H.y + 0.03, side * (H.z - 0.04)), head_mat)
			drl.rotation = Vector3(0, side * 0.45, -0.35)
			var lens := _box(chassis, Vector3(0.1, 0.05, 0.1), Vector3(H.x + 0.08, H.y - 0.01, side * (H.z - 0.06)), head_mat)
			lens.rotation = hl.rotation
		else:
			var hl2 := _box(chassis, Vector3(0.22, 0.05, 0.26), Vector3(H.x, H.y, side * H.z), head_mat)
			hl2.rotation = Vector3(0, side * 0.25, -0.45)
		var sp := SpotLight3D.new()
		sp.position = Vector3(H.x + 0.1, H.y, side * H.z * 0.6)
		sp.rotation = Vector3(0, -PI / 2, 0)
		sp.rotate_object_local(Vector3.RIGHT, -0.06)
		sp.spot_range = 160.0
		sp.spot_angle = 24.0
		sp.light_energy = 0.0
		sp.light_color = Color(1.0, 0.95, 0.85)
		sp.shadow_enabled = false
		sp.visible = false
		chassis.add_child(sp)
		spots.append(sp)
		if key == "gt3":
			_box(chassis, Vector3(0.1, 0.03, 0.05), Vector3(-0.5, 1.255, side * 0.22), pos_mat)
		else:
			_box(chassis, Vector3(0.12, 0.03, 0.05), Vector3(0.1, 1.12, side * 0.25), pos_mat)
	var tl: Vector2 = B["tail"]
	if key == "gt3":
		for side in [-1.0, 1.0]:
			var t1 := _box(chassis, Vector3(0.04, 0.045, 0.42), Vector3(tl.x + 0.02, tl.y, side * 0.56), tail_mat)
			t1.rotation.y = side * 0.12
		_box(chassis, Vector3(0.03, 0.02, 0.6), Vector3(tl.x + 0.01, tl.y + 0.06, 0), tail_mat)
	else:
		_box(chassis, Vector3(0.04, 0.05, 1.6), Vector3(tl.x - 0.01, tl.y, 0), tail_mat)
	_box(chassis, Vector3(0.04, 0.12, 0.12), Vector3(tl.x - 0.02, 0.38, 0), tail_mat)


func _wheels(quality: String) -> void:
	disc_mat = Gfx.mat(Color(0.35, 0.35, 0.36), 0.5, 0.8)
	disc_mat.emission_enabled = true
	disc_mat.emission = Color(1.0, 0.35, 0.05)
	disc_mat.emission_energy_multiplier = 0.0
	var R: float = B["wheel_r"]
	var tw: float = B["tire_w"]
	var tire_m := Gfx.mat(Color(0.05, 0.05, 0.05), 0.85)
	var rim_m := Gfx.mat(Color(0.12, 0.12, 0.13), 0.3, 0.9)
	var nut_m := Gfx.mat(Color(0.85, 0.1, 0.1), 0.4, 0.6)
	var caliper := Gfx.mat(Color(0.75, 0.6, 0.1) if key == "gt3" else Color(0.8, 0.1, 0.1), 0.4, 0.3)
	for ax in [[B["front_axle"], true], [B["front_axle"] - B["wheelbase"], false]]:
		for side in [-1.0, 1.0]:
			var pivot := Node3D.new()
			pivot.position = Vector3(ax[0], R, side * B["track"])
			add_child(pivot)
			var spin := Node3D.new()
			pivot.add_child(spin)
			var tm := CylinderMesh.new()
			tm.top_radius = R
			tm.bottom_radius = R
			tm.height = tw
			tm.radial_segments = 16 if quality == "low" else 28
			var tire := _mi(spin, tm, tire_m, Vector3.ZERO)
			tire.rotation.x = PI / 2
			var rm := CylinderMesh.new()
			rm.top_radius = R * 0.68
			rm.bottom_radius = R * 0.68
			rm.height = tw + 0.012
			_mi(tire, rm, rim_m, Vector3.ZERO)
			# 10-spoke forged rim and a single centre-lock nut
			for k in 10:
				var sp2 := _box(spin, Vector3(0.035, R * 1.3, 0.02), Vector3(0, 0, side * (tw / 2 + 0.008)), rim_m)
				sp2.rotation.z = k * TAU / 10.0
			var nut := CylinderMesh.new()
			nut.top_radius = 0.045
			nut.bottom_radius = 0.05
			nut.height = 0.05
			var nm := _mi(spin, nut, nut_m, Vector3(0, 0, side * (tw / 2 + 0.02)))
			nm.rotation.x = PI / 2
			var dm := CylinderMesh.new()
			dm.top_radius = R * 0.58
			dm.bottom_radius = R * 0.58
			dm.height = 0.035
			var disc2 := _mi(pivot, dm, disc_mat, Vector3(0, 0, -side * 0.06))
			disc2.rotation.x = PI / 2
			_box(pivot, Vector3(0.16, 0.08, 0.06), Vector3(0.0, R * 0.48, -side * 0.06), caliper)
			wheels.append({"pivot": pivot, "spin": spin, "front": ax[1], "side": side, "home": pivot.position})


func _contact_shadow() -> void:
	var L: float = B["len"]
	var cs := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(L * 1.2, 2.5)
	cs.mesh = q
	var csm := StandardMaterial3D.new()
	csm.albedo_texture = Gfx.soft_dot()
	csm.albedo_color = Color(0, 0, 0, 0.75)
	csm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	csm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	cs.material_override = csm
	cs.rotation.x = -PI / 2
	cs.position.y = 0.03
	cs.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(cs)


# Real 3D model: res://models/gt3/gt3.gltf (player, with full interior) or gt3_ai.gltf (exterior only),
# or a single res://models/<key>.glb. Its wheels (W_FL_spin / W_FL_hub ...) are moved onto our wheel
# pivots so they still spin, steer and come off in pit stops; its steering wheel turns in the cockpit.
func _try_glb() -> void:
	var paths: Array = []
	if key == "gt3":
		# single-file models (models/gt3.glb, models/gt3_ai.glb) or the unpacked folder models/gt3/
		if is_player:
			paths = ["res://models/gt3.glb", "res://models/gt3/gt3.gltf", "res://models/gt3_ai.glb", "res://models/gt3/gt3_ai.gltf"]
		else:
			paths = ["res://models/gt3_ai.glb", "res://models/gt3/gt3_ai.gltf", "res://models/gt3.glb", "res://models/gt3/gt3.gltf"]
	else:
		paths.append("res://models/%s.glb" % key)
	var path := ""
	for pv in paths:
		if ResourceLoader.exists(String(pv)):
			path = String(pv)
			break
	if path == "":
		return
	var ps = load(path)
	if not (ps is PackedScene):
		return
	var inst: Node3D = (ps as PackedScene).instantiate()
	chassis.add_child(inst)
	# hide the procedural body; keep brake/tail light glow, class lights and the driver's helmet
	for c in chassis.get_children():
		if c is MeshInstance3D:
			var mi: MeshInstance3D = c
			var keep: bool = mi.material_override == tail_mat or mi.material_override == pos_mat
			mi.visible = keep
		elif c is Label3D:
			var lb: Label3D = c
			lb.visible = false
	var found_wheels := 0
	for w in wheels:
		var tag: String = ("F" if w["front"] else "R") + ("R" if float(w["side"]) > 0.0 else "L")
		var spin_src := inst.find_child("W_%s_spin" % tag, true, false) as Node3D
		var hub_src := inst.find_child("W_%s_hub" % tag, true, false) as Node3D
		if spin_src == null:
			continue
		found_wheels += 1
		var spin: Node3D = w["spin"]
		var pivot: Node3D = w["pivot"]
		for ch in spin.get_children():
			var n3: Node3D = ch
			n3.visible = false
		for ch in pivot.get_children():
			if ch is MeshInstance3D:
				var m3: MeshInstance3D = ch
				m3.visible = false
		spin_src.get_parent().remove_child(spin_src)
		spin.add_child(spin_src)
		spin_src.transform = Transform3D.IDENTITY
		if hub_src != null:
			hub_src.get_parent().remove_child(hub_src)
			pivot.add_child(hub_src)
			hub_src.transform = Transform3D.IDENTITY
	if found_wheels == 0:
		# a model without separate wheels: hide ours entirely
		for w in wheels:
			var pv2: Node3D = w["pivot"]
			pv2.visible = false
	if not is_player and team_cols.size() >= 3:
		_repaint(inst)
	steer_node = inst.find_child("SteeringWheel", true, false) as Node3D
	if steer_node != null:
		steer_home = steer_node.transform
	_split_model_parts(inst)
	# wheels can come off in a heavy crash
	for w in wheels:
		var tag: String = ("f" if w["front"] else "r") + ("r" if float(w["side"]) > 0.0 else "l")
		var pv: Node3D = w["pivot"]
		parts["wheel_" + tag] = [pv]
		part_home[pv] = pv.transform
	glb_used = true


# Regions of the real model (model space, +x = forward) that break off in a crash.
const PART_BOXES := {
	"wing": [Vector3(-2.45, 0.95, -1.15), Vector3(-1.85, 1.45, 1.15)],
	"splitter": [Vector3(1.9, -0.1, -1.15), Vector3(2.55, 0.25, 1.15)],
	"mirror_l": [Vector3(-0.08, 0.83, -1.12), Vector3(0.24, 0.99, -0.86)],
	"mirror_r": [Vector3(-0.08, 0.83, 0.86), Vector3(0.24, 0.99, 1.12)],
}
static var _split_cache := {}


# The model body is one mesh. Cut the triangles of wing, splitter and mirrors into their own meshes
# (once per model, shared by all cars) so they can disappear and fly off as debris.
func _split_model_parts(inst: Node3D) -> void:
	var body: MeshInstance3D = null
	var stack: Array = [inst]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		for ch in n.get_children():
			stack.append(ch)
		if n is MeshInstance3D:
			var mi: MeshInstance3D = n
			if mi.mesh != null and (body == null or mi.mesh.get_surface_count() > body.mesh.get_surface_count()):
				body = mi
	if body == null or not (body.mesh is ArrayMesh):
		return
	var xf: Transform3D = chassis.global_transform.affine_inverse() * body.global_transform
	var key: String = body.mesh.resource_path + "#" + str(body.mesh.get_rid().get_id()) if body.mesh.resource_path == "" else body.mesh.resource_path
	if not _split_cache.has(key):
		_split_cache[key] = _cut_mesh(body.mesh, xf)
	var res: Dictionary = _split_cache[key]
	if res.is_empty():
		return
	body.mesh = res["rest"]
	var pm: Dictionary = res["parts"]
	for pname in pm.keys():
		var part := MeshInstance3D.new()
		part.mesh = pm[pname]
		body.get_parent().add_child(part)
		part.transform = body.transform
		if not parts.has(pname):
			parts[pname] = []
		var lst: Array = parts[pname]
		lst.append(part)
		part_home[part] = part.transform


static func _cut_mesh(src: ArrayMesh, xf: Transform3D) -> Dictionary:
	var names: Array = PART_BOXES.keys()
	var rest := ArrayMesh.new()
	var part_meshes := {}
	var any := false
	for si in src.get_surface_count():
		var arr: Array = src.surface_get_arrays(si)
		var mat: Material = src.surface_get_material(si)
		var mname: String = mat.resource_name if mat != null else ""
		var verts: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var idx = arr[Mesh.ARRAY_INDEX]
		var candidate := mname.contains("Livery") or mname.contains("Exterior") or mname.contains("Grille") or mname.contains("Lights")
		if not candidate or idx == null:
			rest.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
			rest.surface_set_material(rest.get_surface_count() - 1, mat)
			continue
		# region of every vertex (0 = body)
		var reg := PackedByteArray()
		reg.resize(verts.size())
		for vi in verts.size():
			var p: Vector3 = xf * verts[vi]
			var r := 0
			for k in names.size():
				var bx: Array = PART_BOXES[names[k]]
				var lo: Vector3 = bx[0]
				var hi: Vector3 = bx[1]
				if p.x > lo.x and p.x < hi.x and p.y > lo.y and p.y < hi.y and p.z > lo.z and p.z < hi.z:
					r = k + 1
					break
			reg[vi] = r
		var ia: PackedInt32Array = idx
		var rest_idx := PackedInt32Array()
		var pidx: Array = []
		for k in names.size():
			pidx.append(PackedInt32Array())
		for t in range(0, ia.size() - 2, 3):
			var a := ia[t]
			var r0 := reg[a]
			if r0 != 0 and reg[ia[t + 1]] == r0 and reg[ia[t + 2]] == r0:
				var pl: PackedInt32Array = pidx[r0 - 1]
				pl.append(a)
				pl.append(ia[t + 1])
				pl.append(ia[t + 2])
				pidx[r0 - 1] = pl
			else:
				rest_idx.append(a)
				rest_idx.append(ia[t + 1])
				rest_idx.append(ia[t + 2])
		var ra := arr.duplicate()
		ra[Mesh.ARRAY_INDEX] = rest_idx
		if rest_idx.size() > 0:
			rest.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, ra)
			rest.surface_set_material(rest.get_surface_count() - 1, mat)
		for k in names.size():
			var pl2: PackedInt32Array = pidx[k]
			if pl2.size() == 0:
				continue
			any = true
			var pa := _compact(arr, pl2, verts.size())
			if not part_meshes.has(names[k]):
				part_meshes[names[k]] = ArrayMesh.new()
			var am: ArrayMesh = part_meshes[names[k]]
			am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, pa)
			am.surface_set_material(am.get_surface_count() - 1, mat)
	if not any:
		return {}
	return {"rest": rest, "parts": part_meshes}


# copy only the vertices a part uses (keeps the debris meshes small)
static func _compact(arr: Array, ids: PackedInt32Array, nv: int) -> Array:
	var remap := PackedInt32Array()
	remap.resize(nv)
	remap.fill(-1)
	var order := PackedInt32Array()
	var new_idx := PackedInt32Array()
	new_idx.resize(ids.size())
	for k in ids.size():
		var o := ids[k]
		if remap[o] < 0:
			remap[o] = order.size()
			order.append(o)
		new_idx[k] = remap[o]
	var out := []
	out.resize(Mesh.ARRAY_MAX)
	for a in Mesh.ARRAY_MAX:
		var src = arr[a]
		if src == null or a == Mesh.ARRAY_INDEX:
			continue
		var per := 0
		if src is PackedVector3Array or src is PackedVector2Array or src is PackedColorArray:
			per = 1
		elif src is PackedFloat32Array and (src as PackedFloat32Array).size() == nv * 4:
			per = 4
		elif src is PackedFloat32Array and (src as PackedFloat32Array).size() == nv * 2:
			per = 2
		if per == 0:
			continue
		if src is PackedVector3Array:
			var d := PackedVector3Array()
			for o in order:
				d.append(src[o])
			out[a] = d
		elif src is PackedVector2Array:
			var d2 := PackedVector2Array()
			for o in order:
				d2.append(src[o])
			out[a] = d2
		elif src is PackedColorArray:
			var d3 := PackedColorArray()
			for o in order:
				d3.append(src[o])
			out[a] = d3
		else:
			var d4 := PackedFloat32Array()
			for o in order:
				for q in per:
					d4.append(src[o * per + q])
			out[a] = d4
	out[Mesh.ARRAY_INDEX] = new_idx
	return out


func _repaint(root_node: Node) -> void:
	var sh := Shader.new()
	sh.code = LIVERY_SHADER
	var cache := {}
	var stack: Array = [root_node]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		for ch in n.get_children():
			stack.append(ch)
		if not (n is MeshInstance3D):
			continue
		var mi: MeshInstance3D = n
		if mi.mesh == null:
			continue
		for si in mi.mesh.get_surface_count():
			var m: Material = mi.mesh.surface_get_material(si)
			if m == null or not m.resource_name.contains("Livery") or not (m is BaseMaterial3D):
				continue
			if not cache.has(m):
				var bm: BaseMaterial3D = m
				var sm := ShaderMaterial.new()
				sm.shader = sh
				sm.set_shader_parameter("tex", bm.albedo_texture)
				sm.set_shader_parameter("use_nrm", bm.normal_enabled and bm.normal_texture != null)
				if bm.normal_texture != null:
					sm.set_shader_parameter("nrm", bm.normal_texture)
				sm.set_shader_parameter("uv_scale", bm.uv1_scale)
				sm.set_shader_parameter("uv_offset", bm.uv1_offset)
				sm.set_shader_parameter("col_a", team_cols[0])
				sm.set_shader_parameter("col_b", team_cols[1])
				sm.set_shader_parameter("col_c", team_cols[2])
				cache[m] = sm
			mi.set_surface_override_material(si, cache[m])


# turns the model's steering wheel about its column (angle in rad, positive = to the right)
# the driver sitting in the car: posed in the seat, the eyes exactly where the cockpit camera is
func add_driver(look: Dictionary) -> void:
	if driver_fig != null:
		driver_fig.queue_free()
	var eye: Vector3 = B["eye"]
	if glb_used and steer_node != null and key == "gt3":
		eye = Vector3(-0.56, 0.975, -0.4)
	driver_fig = Human.build("driver", look)
	Human.sit(driver_fig, 0.0)
	driver_fig.rotation.y = PI / 2
	chassis.add_child(driver_fig)
	var j: Dictionary = driver_fig.get_meta("j")
	var hips: Node3D = j["hips"]
	var torso: Node3D = j["torso"]
	var head: Node3D = j["head"]
	var eyes_local: Vector3 = (hips.transform * torso.transform * head.transform) * Vector3(0, 0.115, 0.03)
	driver_fig.position = eye - driver_fig.transform.basis * eyes_local


# where a passenger's eyes are: the driver's eye mirrored to the other side of the car
func passenger_eye() -> Vector3:
	var eye: Vector3 = B["eye"]
	if glb_used and steer_node != null and key == "gt3":
		eye = Vector3(-0.56, 0.975, -0.4)
	return Vector3(eye.x - 0.08, eye.y + 0.02, -eye.z)


func steer_model(angle: float) -> void:
	if steer_node != null:
		var r := Basis(GT3_STEER_AXIS.normalized(), angle)
		steer_node.transform = Transform3D(r, GT3_STEER_PIVOT - r * GT3_STEER_PIVOT) * steer_home


func _mi(parent: Node3D, mesh: Mesh, m: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi


func _box(parent: Node3D, size: Vector3, pos: Vector3, m: Material) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	return _mi(parent, bm, m, pos)


# Loft through superellipse cross-sections: rows [x, half_width, y_bottom, y_top, exponent]
func _loft(table: Array, M: int) -> Array:
	var rows: Array = []
	var x0: float = table[0][0]
	var x1: float = table[table.size() - 1][0]
	var R := 70
	for k in R + 1:
		var xx := lerpf(x0, x1, float(k) / R)
		var j := 0
		while j < table.size() - 2 and table[j + 1][0] < xx:
			j += 1
		var a: Array = table[j]
		var b: Array = table[j + 1]
		var t := smoothstep(0.0, 1.0, (xx - a[0]) / (b[0] - a[0]))
		var row: Array = []
		for q in 5:
			row.append(lerpf(a[q], b[q], t))
		rows.append(row)
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	var nrm := PackedVector3Array()
	var idx := PackedInt32Array()
	for k in rows.size():
		var r: Array = rows[k]
		var w: float = r[1]
		var yc: float = (r[2] + r[3]) / 2.0
		var hh: float = (r[3] - r[2]) / 2.0
		var n: float = r[4]
		for m in M + 1:
			var t := float(m) / M * TAU
			var c := cos(t)
			var s := sin(t)
			var zz := w * signf(c) * pow(absf(c), 2.0 / n)
			var yy := yc + hh * signf(s) * pow(absf(s), 2.0 / n)
			verts.append(Vector3(r[0], yy, zz))
			uvs.append(Vector2((r[0] - x0) / (x1 - x0), float(m) / M))
			# analytic superellipse normal
			var nz := signf(c) * pow(absf(c), 2.0 - 2.0 / n) / w
			var ny := signf(s) * pow(absf(s), 2.0 - 2.0 / n) / maxf(0.01, hh)
			nrm.append(Vector3(0, ny, nz).normalized() if absf(ny) + absf(nz) > 1e-6 else Vector3.UP)
	for k in rows.size() - 1:
		for m in M:
			var a := k * (M + 1) + m
			var c2 := a + M + 1
			idx.append_array([a, a + 1, c2, a + 1, c2 + 1, c2])
	# end caps
	for cap in [0, rows.size() - 1]:
		var r: Array = rows[cap]
		var center := verts.size()
		verts.append(Vector3(r[0], (r[2] + r[3]) / 2.0, 0))
		uvs.append(Vector2(0.0 if cap == 0 else 1.0, 0.25))
		nrm.append(Vector3(-1 if cap == 0 else 1, 0, 0))
		for m in M:
			var a: int = cap * (M + 1) + m
			idx.append_array([center, a, a + 1])
	# taper the normals at the nose and tail a little towards the length axis
	var mesh := Gfx.make_mesh(verts, nrm, uvs, PackedColorArray(), idx)
	return mesh.surface_get_arrays(0)


func _particles() -> void:
	var dot := Gfx.soft_dot()
	var make := func(col: Color, amount: int, life: float, size: float) -> CPUParticles3D:
		var p := CPUParticles3D.new()
		var q := QuadMesh.new()
		q.size = Vector2(1, 1)
		var m := StandardMaterial3D.new()
		m.albedo_texture = dot
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		m.vertex_color_use_as_albedo = true
		q.material = m
		p.mesh = q
		p.amount = amount
		p.lifetime = life
		p.emitting = false
		p.local_coords = false
		p.direction = Vector3(0, 1, 0)
		p.spread = 50.0
		p.initial_velocity_min = 0.5
		p.initial_velocity_max = 2.0
		p.gravity = Vector3(0, 0.4, 0)
		p.damping_min = 1.0
		p.damping_max = 2.0
		p.scale_amount_min = size
		p.scale_amount_max = size * 1.8
		var curve := Curve.new()
		curve.max_value = 2.0
		curve.add_point(Vector2(0, 0.4))
		curve.add_point(Vector2(1, 1.6))
		p.scale_amount_curve = curve
		var grad := Gradient.new()
		grad.set_color(0, Color(col.r, col.g, col.b, 0.45))
		grad.set_color(1, Color(col.r, col.g, col.b, 0.0))
		p.color_ramp = grad
		p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		p.emission_box_extents = Vector3(0.3, 0.1, 0.9)
		p.position = Vector3(-B["len"] * 0.35, 0.25, 0)
		add_child(p)
		return p
	smoke = make.call(Color(0.86, 0.86, 0.88), 140, 3.2, 1.3)
	smoke.initial_velocity_max = 3.0
	smoke.emission_box_extents = Vector3(0.4, 0.1, 1.0)
	dust = make.call(Color(0.55, 0.48, 0.36), 90, 2.0, 1.6)
	spray = make.call(Color(0.85, 0.88, 0.92), 140, 1.0, 1.9)
	spray.gravity = Vector3(0, -2.0, 0)
	spray.direction = Vector3(-1, 0.35, 0)
	spray.initial_velocity_min = 2.0
	spray.initial_velocity_max = 6.0
	_debris_particles()


# flying gravel / grass clods from the tyres and sparks from the plank and from impacts
func _debris_particles() -> void:
	stones = CPUParticles3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.05, 0.035, 0.045)
	var sm := StandardMaterial3D.new()
	sm.vertex_color_use_as_albedo = true
	sm.roughness = 0.95
	bm.material = sm
	stones.mesh = bm
	stones.amount = 160
	stones.lifetime = 1.3
	stones.emitting = false
	stones.local_coords = false
	stones.direction = Vector3(-1, 0.55, 0)
	stones.spread = 28.0
	stones.initial_velocity_min = 3.0
	stones.initial_velocity_max = 11.0
	stones.gravity = Vector3(0, -9.8, 0)
	stones.angular_velocity_min = -720.0
	stones.angular_velocity_max = 720.0
	stones.scale_amount_min = 0.6
	stones.scale_amount_max = 1.8
	stones.color = Color(0.62, 0.58, 0.52)
	stones.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	stones.emission_box_extents = Vector3(0.2, 0.05, 0.85)
	stones.position = Vector3(-B["len"] * 0.3, 0.2, 0)
	add_child(stones)
	sparks = CPUParticles3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(0.025, 0.32)
	var em := StandardMaterial3D.new()
	em.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	em.albedo_color = Color(1.0, 0.75, 0.35)
	em.cull_mode = BaseMaterial3D.CULL_DISABLED
	em.vertex_color_use_as_albedo = true
	em.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	em.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	qm.material = em
	sparks.mesh = qm
	sparks.amount = 120
	sparks.lifetime = 0.45
	sparks.emitting = false
	sparks.local_coords = false
	sparks.particle_flag_align_y = true
	sparks.direction = Vector3(-1, 0.15, 0)
	sparks.spread = 22.0
	sparks.initial_velocity_min = 6.0
	sparks.initial_velocity_max = 16.0
	sparks.gravity = Vector3(0, -9.8, 0)
	var g := Gradient.new()
	g.set_color(0, Color(3.0, 2.2, 1.2, 1.0))
	g.set_color(1, Color(2.0, 0.5, 0.1, 0.0))
	sparks.color_ramp = g
	sparks.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	sparks.emission_box_extents = Vector3(0.6, 0.02, 0.5)
	sparks.position = Vector3(-0.2, 0.04, 0)
	add_child(sparks)


func spark_burst(t: float, local_pos: Vector3 = Vector3(-0.2, 0.04, 0)) -> void:
	sparks.position = local_pos
	spark_t = maxf(spark_t, t)


# ---------------------------------------------------------------- per frame
# lead: time since the last physics tick; the body is drawn where the car is *now* (no 240 Hz judder)
func sync(car, dt: float, night: float, wet: float, cam_pos: Vector3, lead: float = 0.0) -> void:
	if driver_fig != null and driver_fig.visible:
		Human.sit(driver_fig, car.steer)
	var wv: Vector2 = car.world_vel()
	var ld: float = 0.0 if car.hold else lead
	position = Vector3(car.x + wv.x * ld, car.y + jack, car.z + wv.y * ld)
	basis = Basis(Vector3.UP, -(car.psi + car.r * ld)) * Basis(Vector3.BACK, car.grade_pitch)
	var road: float = car.road_now
	chassis.position.y = car.heave * 0.8 + road * 0.35
	chassis.rotation = Vector3(-car.roll, 0, -car.pitch)
	var R: float = B["wheel_r"]
	var spin: float = car.u / R * dt
	for w in wheels:
		var pv: Node3D = w["pivot"]
		if w["front"]:
			pv.rotation.y = -(car.steer * car.spec["steerMax"] + car.steer_pull())
		var extra: float = car.wheel_spin / R * dt if not w["front"] else 0.0
		if not (car.lock_f and w["front"]) and not (car.lock_r and not w["front"]):
			var sn: Node3D = w["spin"]
			sn.rotation.z -= spin + extra
		pv.position.y = R + road * 0.8
	var braking: bool = car.brake > 0.05
	tail_mat.emission_energy_multiplier = 7.0 if braking else (2.2 if night > 0.4 else 1.0)
	if wet > 0.3 and int(Time.get_ticks_msec() / 250) % 2 == 0:
		tail_mat.emission_energy_multiplier = maxf(tail_mat.emission_energy_multiplier, 5.0)
	head_mat.emission_energy_multiplier = 9.0 if night > 0.3 else 0.6
	var flashing: bool = car.flash > 0.0 and int(car.flash * 12.0) % 2 == 0
	if flashing:
		head_mat.emission_energy_multiplier = 16.0
	var near_cam := global_position.distance_to(cam_pos) < 260.0
	for spv in spots:
		var sl: SpotLight3D = spv
		sl.visible = (night > 0.3 or flashing) and near_cam
		sl.light_energy = 6.0 * maxf(night, 1.0 if flashing else 0.0)
	disc_mat.emission_energy_multiplier = clampf(car.brake * absf(car.u) / 40.0, 0.0, 1.0) * 3.0 * (1.0 if night > 0.2 else 0.3)
	# particles
	var spd := absf(car.u)
	var surf: String = car.surface
	var on_road := surf == "asphalt" or surf == "curb" or surf == "pit" or surf == "runoff"
	smoke.emitting = on_road and spd > 5.0 and (absf(car.slip_r) > 0.16 or car.spin_r or car.lock_f or car.lock_r) and near_cam
	dust.emitting = (surf == "grass" or surf == "gravel") and spd > 4.0 and near_cam
	spray.emitting = wet > 0.25 and spd > 15.0 and near_cam
	stones.emitting = (surf == "gravel" or surf == "grass") and spd > 5.0 and near_cam
	if stones.emitting:
		stones.color = Color(0.62, 0.58, 0.52) if surf == "gravel" else Color(0.26, 0.3, 0.16)
	# plank / skid block touching the road: heavy compression at speed (Eau Rouge, curbs)
	var lv: float = car.load_var
	if spd > 38.0 and lv > 1.18 and on_road:
		spark_t = maxf(spark_t, 0.08)
		sparks.position = Vector3(-0.2, 0.04, 0)
	spark_t = maxf(0.0, spark_t - dt)
	sparks.emitting = spark_t > 0.0 and near_cam


# ---------------------------------------------------------------- damage
func apply_hit(zone: String, amount: float, dir: Vector3) -> Array:
	# dent the body around the impact point (dir in car-local x/z)
	var d := Vector3(dir.x, 0, dir.z).normalized()
	var L: float = B["len"]
	var hit := Vector3(d.x * L * 0.5, 0.5, d.z * 1.0)
	var rad := 0.9 + amount
	var depth := clampf(amount, 0.0, 0.6) * 0.22
	for i in cur_verts.size():
		var p := cur_verts[i]
		var dist := p.distance_to(hit)
		if dist < rad:
			var f := 1.0 - dist / rad
			cur_verts[i] = p - d * depth * f * f + Vector3(0, -depth * 0.3 * f, 0) * randf()
	_rebuild_body()
	spark_burst(0.2 + amount * 0.8, Vector3(hit.x * 0.9, 0.3, hit.z))
	var dropped: Array = []
	return dropped


func _rebuild_body() -> void:
	var arr := body_arrays.duplicate()
	arr[Mesh.ARRAY_VERTEX] = cur_verts
	body_mesh.clear_surfaces()
	body_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)


# hide the parts the physics reports as lost; returns nodes for debris spawning
func update_lost(lost: Dictionary) -> Array:
	var out: Array = []
	for pname in lost.keys():
		if not parts.has(pname):
			continue
		for p in parts[pname]:
			var node: Node3D = p
			if lost[pname] and node.visible:
				node.visible = false
				node.set_meta("lost_hidden", true)
				out.append(node)
	return out


# replay: parts follow the recorded state without spawning debris
func show_lost(lost: Dictionary) -> void:
	for pname in lost.keys():
		if not parts.has(pname):
			continue
		for p in parts[pname]:
			var node: Node3D = p
			if lost[pname]:
				if node.visible:
					node.visible = false
					node.set_meta("lost_hidden", true)
			elif node.has_meta("lost_hidden"):
				node.remove_meta("lost_hidden")
				node.visible = true
				node.transform = part_home[p]


func repair_visual() -> void:
	cur_verts = base_verts.duplicate()
	_rebuild_body()
	# only what the crash took away comes back (hidden stand-in parts of the real model stay hidden)
	for pname in parts.keys():
		for p in parts[pname]:
			var nd: Node3D = p
			if nd.has_meta("lost_hidden"):
				nd.remove_meta("lost_hidden")
				nd.visible = true
			nd.transform = part_home[p]

# AI driver: pure pursuit on the racing line, speed-profile tracking, traffic avoidance and pit stops.
extends RefCounted

var car
var skill := 0.97
var vprof: PackedFloat32Array
var offset := 0.0
var steer_s := 0.0
var react_t := 0.0
var reaction := 0.4
var pit_state := "none"   # none, planned, service, out
var box_ps := 0.0        # lane s of the own garage
var service := 0.0
var lap_use := 4.0
var fuel_at_line := 0.0
var last_s := 0.0
var pit_plan := {}        # what the crew will do (read by the pit crew visuals)
var stuck_t := 0.0
var block_l := false
var block_r := false


func _init(c, difficulty: float) -> void:
	car = c
	# difficulty 50..120 %: how much of the tyre grip the AI uses in corners and under braking.
	# Above 100 % the AI cars also get a performance edge (grip, downforce, power) - at 120 % they lap
	# Spa in about 2:10 and pull away from a good human driver.
	var d := clampf(difficulty, 40.0, 130.0)
	skill = clampf(0.85 + 0.00125 * d + randf_range(-0.006, 0.004), 0.88, 1.0)
	if d > 100.0:
		var e := (d - 100.0) / 20.0
		var sp: Dictionary = car.spec.duplicate()
		sp["mu"] = float(sp["mu"]) * (1.0 + 0.45 * e)
		sp["ClA"] = float(sp["ClA"]) * (1.0 + 0.9 * e)
		# the engine model works on torque: more torque = more power at every rpm
		sp["Tpeak"] = float(sp["Tpeak"]) * (1.0 + 0.4 * e)
		sp["power"] = float(sp["power"]) * (1.0 + 0.4 * e)
		sp["brakeMax"] = float(sp["brakeMax"]) * (1.0 + 0.6 * e)
		sp["vmax"] = float(sp["vmax"]) * (1.0 + 0.15 * e)
		car.spec = sp
	var bk := snappedf(clampf(0.5 + 0.0038 * d, 0.6, 0.98), 0.01)     # 100 % -> 0.88, 120 % -> 0.96
	var gk := snappedf(clampf(0.88 + 0.001 * d, 0.9, 1.0), 0.01)      # cornering grip: 100 % -> 0.98, 120 % -> 1.0 (the physical limit)
	# acceleration is not limited by the profile: on the way out of a corner and on the straights the AI
	# goes flat out, traction control and the engine set the pace
	vprof = car.T.speed_profile(car.spec, gk, bk, 3.0)
	reaction = randf_range(0.2, 0.7)
	car.abs_on = true
	car.tc_on = true
	fuel_at_line = car.fuel
	last_s = car.s


# lateral offset on the pit lane: fast lane, swinging into the working lane in front of the own garage
func lane_lat(lane_s: float) -> float:
	var d := absf(lane_s - box_ps)
	# short, steep swing: the neighbouring boxes (14 m apart) stay free
	var lat: float = car.T.BOX_LAT * (1.0 - smoothstep(3.0, 13.0, d))
	# a car standing in a box on our way: stay in the fast lane past it
	if lat > 0.5:
		for o in lane_cars:
			if absf(float(o.ps) - lane_s) < 7.5 and absf(float(o.ps) - box_ps) > 4.0 and o.plat > car.T.BOX_LAT - 2.5:
				return 0.0
	return lat


var lane_cars: Array = []     # other cars in the pit lane (refreshed every update while pitting)
var wait_t := 0.0


func update(dt: float, cars: Array, started: bool) -> void:
	var c = car
	var T = c.T
	if c.retired:
		c.throttle = 0.0
		c.brake = 0.4
		return
	if not started:
		c.throttle = 0.25
		c.brake = 1.0
		c.steer = 0.0
		react_t = reaction
		return
	if react_t > 0.0:
		react_t -= dt
		c.brake = 1.0
		# revving on the grid; in the garage the engine stays off until shortly before driving out
		c.throttle = 0.0 if c.near_lane else 0.4
		c.steer = 0.0
		if c.near_lane and c.plat > T.BOX_LAT + 0.8:
			c.ignition = react_t < 3.0
			c.starter = react_t < 1.6 and not c.engine_on
			if react_t > 3.0:
				c.engine_on = false
				c.rpm = 0.0
				c.off_rpm = 0.0
		return
	c.starter = false
	if not c.engine_on:
		c.ignition = true
		c.engine_on = true
	var N: int = T.N
	var ds: float = T.ds
	var u: float = maxf(0.0, c.u)
	var pit_len: float = T.wrap_s(T.pit_out - T.pit_in)
	if last_s > T.length - 200.0 and c.s < 200.0:
		var used: float = fuel_at_line - c.fuel
		if used > 0.5:
			lap_use = used
		fuel_at_line = c.fuel
	last_s = c.s
	var to_entry: float = T.wrap_s(T.pit_in - c.s)
	if pit_state == "none" and to_entry > 400.0 and to_entry < 700.0:
		var need_fuel: bool = c.fuel < lap_use * 1.6
		var need_tyres: bool = maxf(c.wear_f, c.wear_r) > 0.8
		var need_repair: bool = c.lost["wing"] or c.lost["splitter"] or c.total_damage() > 0.5
		if need_fuel or need_tyres or need_repair:
			pit_state = "planned"
			pit_plan = {"fuel": c.spec["fuelCap"], "tyres": c.compound, "repair": need_repair}
	var s_in: float = T.wrap_s(c.s - T.pit_in)
	var pitting: bool = (pit_state == "planned" or pit_state == "service" or pit_state == "out") and s_in < pit_len
	lane_cars.clear()
	if pitting and c.near_lane:
		for o in cars:
			if o != c and o.near_lane and o.in_pit and not o.retired:
				lane_cars.append(o)
	if pit_state == "out" and s_in >= pit_len - 2.0:
		pit_state = "none"
	if pit_state == "service":
		c.throttle = 0.0
		c.brake = 1.0
		c.hold = true
		service -= dt
		if service <= 0.0:
			c.hold = false
			pit_state = "out"
			fuel_at_line = c.fuel
		return

	# ---- traffic: overtake on straights, follow in corners, let faster cars by, never turn into a car alongside
	var speed_cap := 1e9
	var desired := 0.0
	var yield_to := 0.0
	block_l = false
	block_r = false
	if not c.in_pit:
		var racing: bool = pit_state == "none"
		var k_here: float = absf(T.kap[c.idx])
		var k_ahead: float = absf(T.kap[(c.idx + int(80.0 / ds)) % N])
		var straight: bool = k_here < 1.0 / 450.0 and k_ahead < 1.0 / 300.0
		for o in cars:
			if o == c or o.in_pit or o.retired:
				continue
			var gap: float = wrapf(o.s - c.s, -T.length * 0.5, T.length * 0.5)
			var dl: float = o.lat - c.lat
			# somebody right next to us
			if absf(gap) < 5.5 and absf(dl) < 4.0:
				if dl > 0.0:
					block_r = true
				else:
					block_l = true
			if gap > 0.0 and gap < 50.0:
				var closing: float = c.u - o.u
				var my_lat: float = T.line_d[(c.idx + int(gap / ds)) % N] + offset
				var in_line: bool = absf(o.lat - my_lat) < 2.8 or absf(o.lat - c.lat) < 2.4
				if in_line and (closing > 0.5 or gap < 14.0):
					var room_r: float = T.half_w - 1.3 - o.lat
					var room_l: float = o.lat + T.half_w - 1.3
					var side := 1.0 if room_r > room_l else -1.0
					var room: float = maxf(room_r, room_l)
					if racing and room > 3.2 and (straight or closing > 6.0 or gap < 6.0):
						desired = o.lat + side * 3.5 - T.line_d[c.idx]
						# while still behind it, never close in faster than we could stop
						if absf(o.lat - c.lat) < 2.4:
							speed_cap = minf(speed_cap, _follow_cap(o, gap) + 4.0)
					else:
						speed_cap = minf(speed_cap, _follow_cap(o, gap))
					# stuck behind a clearly slower car: flash the lights now and then
					if gap < 30.0 and o.u < vprof[c.idx] * skill * 0.9:
						stuck_t += dt
			elif racing and gap < 0.0 and gap > -70.0 and straight:
				# a faster car (or a hypercar behind a GT3) is coming: move over and leave the line
				var closing2: float = o.u - c.u
				var faster_class: bool = o.spec["key"] == "hyper" and c.spec["key"] == "gt3"
				if closing2 > 2.5 or (faster_class and gap > -40.0 and closing2 > -1.0):
					yield_to = -1.0 if o.lat > c.lat else 1.0
		if yield_to != 0.0 and desired == 0.0:
			desired = yield_to * (T.half_w - 1.6) - T.line_d[c.idx]
			speed_cap = minf(speed_cap, c.u + 2.0)     # no sudden acceleration while being lapped
	stuck_t = maxf(0.0, stuck_t - dt * 0.3)
	if stuck_t > 2.5:
		c.flash = 0.45
		stuck_t = 0.0
	c.flash = maxf(0.0, c.flash - dt)
	offset += (desired - offset) * minf(1.0, dt * 1.4)
	var max_off: float = T.half_w - 1.2

	# ---- steering: pure pursuit + yaw damping + counter-steer
	var look := 7.0 + u * 0.42
	var j: int = (c.idx + int(roundf(look / ds))) % N
	var off: float = clampf(T.line_d[j] + offset, -max_off, max_off)
	# keep the line we have while a car is alongside instead of squeezing it
	if block_r:
		off = minf(off, c.lat + 0.3)
	if block_l:
		off = maxf(off, c.lat - 0.3)
	var tx: float = T.px[j] + T.rx[j] * off
	var tz: float = T.pz[j] + T.rz[j] * off
	if pit_state == "planned" and not pitting:
		# lining up for the pit entry on the right
		var to_in: float = T.wrap_s(T.pit_in - c.s)
		if to_in < 160.0:
			var la: float = lerpf(off, T.l_tlat[0] + 1.0, 1.0 - to_in / 160.0)
			tx = T.px[j] + T.rx[j] * la
			tz = T.pz[j] + T.rz[j] * la
	elif pitting:
		if c.near_lane and c.plat > T.BOX_LAT + 0.8:
			# rolling out of the garage: swing into the working lane in the driving direction
			var gp: Vector4 = T.lane_point(minf(T.lL, c.ps + 7.0), T.BOX_LAT - 1.5)
			tx = gp.x
			tz = gp.z
		elif c.near_lane and c.ps < T.lL - 3.0:
			var tps: float = minf(T.lL, c.ps + look)
			var lp: Vector4 = T.lane_point(tps, lane_lat(tps))
			tx = lp.x
			tz = lp.z
		else:
			var la2: float = T.l_tlat[0] + 1.0 if T.wrap_s(c.s - T.pit_in) < 60.0 else T.line_d[j]
			tx = T.px[j] + T.rx[j] * la2
			tz = T.pz[j] + T.rz[j] * la2
	var dx: float = tx - c.x
	var dz: float = tz - c.z
	var cp := cos(c.psi)
	var sp := sin(c.psi)
	var lx := dx * cp + dz * sp
	var ly := -dx * sp + dz * cp
	var curv := 2.0 * ly / maxf(1.0, lx * lx + ly * ly)
	var delta: float = atan(curv * c.spec["L"])
	delta -= (c.r - u * curv) * 0.06
	# counter-steer only against a real slide: the normal rear slip angle of a car at the limit (up to
	# ~0.05 rad) is how it corners, catching that would just make the AI run wide
	delta += c.slip_r * 0.35 + signf(c.slip_r) * maxf(0.0, absf(c.slip_r) - 0.05) * 0.9
	delta -= c.steer_pull()
	steer_s += (clampf(delta / c.spec["steerMax"], -1.0, 1.0) - steer_s) * minf(1.0, dt * 14.0)
	c.steer = steer_s

	# ---- speed target
	var lead: int = (c.idx + int(roundf((4.0 + u * 0.15) / ds))) % N
	var gf: Vector2 = c.grip_factor()
	var vt: float = vprof[lead] * skill * sqrt(minf(gf.x, gf.y))
	if vprof[lead] >= float(c.spec["vmax"]) - 0.5:
		vt = 999.0                          # straight: no speed limit, the drag decides
	# damaged aero -> slower in fast corners
	var aero_ratio: float = c.aero_cla() / (c.spec["ClA"] * (0.8 + 0.04 * float(c.setup["wing"])))
	vt *= lerpf(1.0, sqrt(aero_ratio), clampf((vt - 30.0) / 40.0, 0.0, 1.0))
	vt *= 1.0 - minf(0.08, absf(offset) * 0.01)
	vt = minf(vt, speed_cap)
	if absf(c.lat) > T.half_w + 1.0 and pit_state == "none":
		vt = minf(vt, 35.0)
	if pitting and c.near_lane:
		var lim: float = T.pit_limit - 0.6
		var lq: int = clampi(int(c.ps + 4.0 + u * 0.2), 0, T.lN - 1)
		vt = minf(vt, T.l_vmax[lq])
		if c.ps >= T.lim_a and c.ps <= T.lim_b:
			vt = minf(vt, lim)
		elif c.ps < T.lim_a:
			vt = minf(vt, sqrt(lim * lim + 2.0 * 8.0 * (T.lim_a - c.ps)))
		if pit_state == "planned":
			var to_box: float = box_ps - c.ps
			if to_box < 200.0:
				vt = minf(vt, sqrt(2.0 * 5.0 * maxf(0.0, to_box - 0.5)))
			if to_box < 1.2 and to_box > -4.0:
				pit_state = "service"
				var fuel_t: float = (c.spec["fuelCap"] - c.fuel) / 4.5
				# WEC: refuel first, then tyres
				service = 2.5 + fuel_t + 7.5 + (c.repair_time() if pit_plan.get("repair", false) else 0.0)
				pit_plan["duration"] = service
				pit_plan["start_fuel"] = c.fuel
				c.hold = true
				emit_pit = true
	elif pitting:
		vt = minf(vt, 45.0)
	if pitting and c.near_lane and c.plat > T.BOX_LAT + 0.8:
		vt = minf(vt, 3.5)
	if pitting and c.near_lane and pit_state != "service":
		vt = minf(vt, _lane_traffic(dt, u))
	var err := vt - u
	if err > 0.0:
		c.throttle = 1.0 if err > 0.6 else clampf(err * 1.1 + 0.3, 0.0, 1.0)
		if absf(c.slip_r) > 0.08:
			c.throttle *= maxf(0.1, 1.0 - (absf(c.slip_r) - 0.08) * 8.0)
		c.brake = 0.0
	else:
		c.throttle = 0.15 if err > -1.5 else 0.0
		c.brake = clampf((-err - 1.0) * 0.18, 0.0, 1.0)
	if u < 2.0 and absf(c.lat) > T.half_w and not pitting:
		c.brake = 0.0
		c.throttle = 0.6

var emit_pit := false


# highest speed that still lets us stop behind car o (braking ~7 m/s², keeps a car length + 2.5 m)
func _follow_cap(o, gap: float) -> float:
	var free: float = maxf(0.0, gap - float(car.spec["len"]) - 2.5)
	return sqrt(maxf(0.0, float(o.u)) * maxf(0.0, float(o.u)) + 2.0 * 7.0 * free)


# pit lane manners: follow the car ahead in the same lane, let the fast lane traffic pass before pulling
# out of the box, never wait forever (after a while the cars just slip past each other)
func _lane_traffic(dt: float, u: float) -> float:
	var c = car
	var T = c.T
	var cap := 1e9
	for o in lane_cars:
		var gap: float = float(o.ps) - float(c.ps)
		var dlat: float = absf(float(o.plat) - float(c.plat))
		# a car parked in its own box is not "ahead of us" unless our path goes through that box
		var path_lat := lane_lat(float(o.ps))
		var parked: bool = absf(float(o.u)) < 0.5 and float(o.plat) > T.BOX_LAT - 2.5
		var in_path: bool = absf(float(o.plat) - path_lat) < 2.3 and not (parked and path_lat < T.BOX_LAT - 2.5)
		if gap > 0.0 and gap < 35.0 and (in_path or (dlat < 2.0 and gap < 9.0)):
			var free: float = maxf(0.0, gap - c.spec["len"] - 2.0)
			cap = minf(cap, maxf(float(o.u), 0.0) + sqrt(2.0 * 4.0 * free))
		# leaving the box: give way to cars coming down the fast lane
		if pit_state == "out" and c.plat > 2.5 and u < 6.0 and gap < 0.0 and gap > -28.0 and o.plat < 2.0 and float(o.u) > 2.0:
			cap = minf(cap, 0.0 if wait_t < 5.0 else 1e9)
	if cap < 0.6 and pit_state != "service":
		wait_t += dt
	else:
		wait_t = maxf(0.0, wait_t - dt)
	# stuck for several seconds: let them slip past each other instead of a dead lock
	if wait_t > 5.0:
		c.ghost = 1.5
		return 1e9
	return cap
